/*<copyright                                                          */
/* notice="cics-rm-source-program"                                    */
/* pids="CA0U"                                                        */
/* years="2014,2015"                                                  */
/* crc="397132649" >                                                  */
/* 	Licensed Materials - Property of IBM                              */
/* 	"Restricted Materials of IBM"                                     */
/* 	CA0U                                                              */
/* 	(C) Copyright IBM Corp. 2014, 2015                                */
/* 	US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. */
/* </copyright>                                                       */
import com.ibm.cics.ucd.exceptions.StepFailedException
import com.ibm.cics.ucd.steps.NewcopyProgramStep
import com.ibm.cics.ucd.steps.Step


try {
	Step step = new NewcopyProgramStep(this.args[0], this.args[1]);
	step.run()
} catch (StepFailedException e) {
	System.exit(1)

} catch (Exception e){
	throw e
}

//Indicating step end with pass result
System.exit(0)
