import com.urbancode.air.CommandHelper


final def props = new Properties()
final def inputPropsFile = new File(args[0])
final def inputPropsStream = null
try {
    inputPropsStream = new FileInputStream(inputPropsFile)
    props.load(inputPropsStream)
}
catch (IOException e) {
    throw new RuntimeException(e)
}

final def group = props['group']
final def users = props['users'].split('\n')

def ch = new CommandHelper(new File('.'))
def argsGroupAdd = ['groupadd', group]

ch.runCommand(argsGroupAdd.join(' '), argsGroupAdd)

users.each {
    def argsUserMod = ['usermod', '-a', '-G', group, it]
    ch.runCommand(argsUserMod.join(' '), argsUserMod)
}