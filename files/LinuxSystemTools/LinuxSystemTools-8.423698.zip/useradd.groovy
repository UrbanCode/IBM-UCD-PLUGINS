import com.urbancode.air.CommandHelper


final def props = new Properties()
final def inputPropsFile = new File(args[0])
final def inputPropsStream = null
try {
    inputPropsStream = new FileInputStream(inputPropsFile)
    props.load(inputPropsStream)
}
catch (IOException e) {
    throw new RuntimeException(e)
}

final def user = props['user']
final def group = props['group']

def ch = new CommandHelper(new File('.'))
def args = ['useradd']

if (group) {
    args << '-G'
    args << group
}
args << user

ch.runCommand(args.join(' '), args);

