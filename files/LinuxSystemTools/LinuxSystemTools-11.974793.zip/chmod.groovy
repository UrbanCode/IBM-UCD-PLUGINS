/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.CommandHelper;
import com.urbancode.air.AirPluginTool;


final AirPluginTool apt = new AirPluginTool(new File(args[0]), new File(args[1]));
def props = apt.getStepProperties();

final def includes = props['includes'].split('\n');
final def excludes = props['excludes']?.split('\n');
final def mod = props['mod'];
final def fileType = props['fileType'];
final def maxParallel = props['maxParallel']

def failures = [];

def ant = new AntBuilder();

println "Chmodding to $mod files of type $fileType with includes :"
includes.each {
    println "\t" + it;
}
println "and excludes :" 
excludes.each {
    println "\t" + it;
}

ant.chmod(perm:mod,type:fileType,maxparallel:maxParallel) {
    fileset(dir:".") {
       for (inc in includes) {
          include(name:inc);
       }
       for (exc in excludes) {
          exclude(name:exc);
       }
    }
}
