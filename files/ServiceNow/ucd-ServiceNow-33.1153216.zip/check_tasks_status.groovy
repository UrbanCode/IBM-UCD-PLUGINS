/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2013, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def changeRequestId = props['changeRequestId']
def statuses = props['status']

def badStatus  = [:]
def changeRequestSysId
def taskList
def acceptedStatuses = statuses.split(',')*.trim()

println "Checking request with number ${changeRequestId}"
println "Checking for status ${statuses}"
println ""


HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(airPluginTool)
changeRequestSysId = helper.getChangeRequestSysId()
taskList = helper.getTaskList(changeRequestSysId)
taskList = taskList.result

if (taskList.size() == 0) {
    println "No tasks were found for Change Request ${changeRequestId}. Exiting failure."
    System.exit(1)
}

for (def task : taskList) {
    if (!acceptedStatuses.contains(task.state)) {
        badStatus.put(task.number, task.state)
    }
    else {
        println "Task " + task.number + " matches accepted status " + task.state + "!"
    }
}

if (!badStatus.isEmpty()) {
    println ""
    println "Not all tasks matched status: ${statuses}"
    badStatus.each { badStat ->
        println "TaskName : " + badStat.getKey()
        println "Status : " + badStat.getValue()
    }
    System.exit(1)
}

System.exit(0)
