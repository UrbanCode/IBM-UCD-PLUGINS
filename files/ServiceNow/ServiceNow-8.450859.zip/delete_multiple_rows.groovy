import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.JsonHelper

JsonHelper helper = new JsonHelper(new AirPluginTool(this.args[0], this.args[1]))

helper.deleteMultipleRows()