import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.JsonHelper

final def airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

def changeRequestId = props['changeRequestId'];
def status = props['status'];

println "Checking request with number ${changeRequestId}";
println "Setting status to ${status}";
println ""

JsonHelper jsonHelper = new JsonHelper(airTool)
jsonHelper.setStatus(status)

println "Status set to ${status}!";
System.exit(0);
