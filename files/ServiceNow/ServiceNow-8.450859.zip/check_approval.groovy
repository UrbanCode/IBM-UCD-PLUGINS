import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.JsonHelper

final def airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

def changeRequestId = props['changeRequestId'];
def status = props['status'];

println "Checking request with number ${changeRequestId}";
println "Checking for status ${status}";
println ""

JsonHelper jsonHelper = new JsonHelper(airTool)

def parsedApproval = jsonHelper.getApproval()
if (status.equalsIgnoreCase(parsedApproval)){
    println "Success! Approval status is ${parsedApproval}"
    System.exit(0)
}
else {
    println "Approval status, ${parsedApproval}, is not the specified approval status ${status}. Exiting failure."
    System.exit(1)
}
