import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.JsonHelper

final def airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

def tasksIds = props['tasksId'];
def status = props['status'];

println "Updating task Ids with number ${tasksIds}";
println "Updating with status ${status}";
println ""

JsonHelper jsonHelper = new JsonHelper(airTool)

tasksIds.split(',').each { taskId ->
   jsonHelper.setTaskStatus(taskId, status)
   println ""
}

println ""

println "All task statuses updated to ${status}!";
System.exit(0);
