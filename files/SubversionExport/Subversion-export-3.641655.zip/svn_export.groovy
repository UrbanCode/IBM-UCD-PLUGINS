/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
final def workDir = new File('.').canonicalFile
final def out = System.out
final def env = System.getenv()

final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def DATE_READ_1 = new java.text.SimpleDateFormat("E MMM dd HH:mm:ss zzz yyyy") // java.util.Date.toString()
final def DATE_READ_2 = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z") // ISO-like format
final def SVN_DATE = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S Z")
SVN_DATE.timeZone = TimeZone.getTimeZone("GMT")

//------------------------------------------------------------------------------
// GET ALL INPUT PARAMETERS 
//------------------------------------------------------------------------------
final def parseDate = { value ->
    if (!value) {
        return null
    }
    if (value.isLong()) {
        return new Date(value.toLong())
    }
    else {
        try {
            return DATE_READ_1.parse(value)
        }
        catch (java.text.ParseException e) {
            return DATE_READ_2.parse(value)
        }
    }
}

final def props = new Properties()
final def inputPropsFile = new File(args[0])
final def inputPropsStream = null
try {
    inputPropsStream = new FileInputStream(inputPropsFile)
    props.load(inputPropsStream)
}
catch (IOException e) {
    throw new RuntimeException(e)
}

final def svnRoot      = props['repositoryUrl']
final def svnUsr       = props['username']
final def svnPwd       = props['password']
final def projectPath     = props['projectPath']
final def dir          = new File(workDir, props['dirOffset'] ?: '.').canonicalFile // get checkout directory
final def commandPath = props['commandPath'] ?: "svn"


final def revisionNum  = props['revisionNum']
final def revisionDate = parseDate(props['revisionDate'])

final boolean doExport = true
final boolean clean    = props['cleanWorkspace']?.toBoolean()

final def pb = new ProcessBuilder(['echo'] as String[]).directory(workDir)
        
/**
 * A convenience method for running commands and optionally parsing the stdout of that command.
 * If closure is non-null, the closure will be passed the resultant {@link Process} and is expected to deal with all IO.
 * Otherwise, the process' stdOut and stdErr are forwarded to this scripts 'stdOut' and stdIn is untouched.
 * 
 * @param message an optional message to print prior to the commandline
 * @param command the command to be used as a String[]
 * @param closure an optional closure to deal with Process IO
 */
final def runCommand = {def message, def command, def closure ->
    pb.command(command as String[])
    println()
    if (message) {
        println(message)
    }
    println("command: ${pb.command().join(' ')}")
    def proc = pb.start()
    if (closure) {
        closure(proc)
    }
    else {
        proc.consumeProcessOutput(out, out) // forward stdout and stderr
        proc.getOutputStream().close() // close stdin
    }
    proc.waitFor()
    if (proc.exitValue()) {
        throw new Exception("Command failed with exit code: "+proc.exitValue())
    }
}

//------------------------------------------------------------------------------
// PREPARE WORKING DIRECTORY
//------------------------------------------------------------------------------

  // clean && create the working directory
  if (clean && dir.isDirectory()) {
    new AntBuilder().delete(includeemptydirs:'true') {
        fileset(dir: workDir.path, includes:'**/*', defaultexcludes:'false')
    }
  }
  
  dir.mkdirs()
  
  if (!dir.exists()) {
    throw new Exception("Could not create working directory ${workDir}")
  }
  else if (dir.isFile()) {
    throw new Exception("Specified working directory is a file!! ${workDir}")
  }

//------------------------------------------------------------------------------
// PREPARE COMMAND LINE
//------------------------------------------------------------------------------
  
	def command = [commandPath, '--non-interactive', '--no-auth-cache']
	
    if (doExport) {
        command << 'export' << '--force' // need force because target directory does/may exist
    }
    else {
        command << 'checkout'
    }
	
    if (svnUsr) {
      command << '--username' << svnUsr

      if (svnPwd) {
          command << '--password' << svnPwd
      }
    }

    if (revisionNum) {
      command << '--revision' << revisionNum
    }
    else if (revisionDate) {
      command << '--revision' << ('{'+SVN_DATE.format(revisionDate)+'}')
    }

    command << (svnRoot+'/'+projectPath)

    command << dir.path // check out to workDir

    //------------------------------------------------------------------------------
    // EXECUTE
    //------------------------------------------------------------------------------

    // prepare process and set environment: MUST cast command to String[] !!!
    runCommand('Subversion Export', command, null)
