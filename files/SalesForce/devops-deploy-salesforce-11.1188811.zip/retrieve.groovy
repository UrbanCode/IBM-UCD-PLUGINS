/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

// import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper
import com.urbancode.air.plugin.salesforce.NewAirPluginTool

airTool = new NewAirPluginTool(args[0], args[1])
def props = airTool.getStepProperties()

def workDir = new File('.').canonicalFile

String retrieveType = props['retrieveType']
String password = props['password']
String username = props['username']
String serverUrl = props['serverUrl']
String packageNames = props['packageNames']
String retrieveTarget = props['retrieveTarget']
String maxPoll = props['maxPoll']?:"200"
String pollWaitMillis = props['pollWaitMillis']?:"10000"
String unpackaged = props['unpackaged']

if (packageNames != "" && unpackaged != "") {
    println("[WARNING] 'packageNames' and 'unpackaged' were both specified, but only one can be used.")
}

// Throw error at the beginning if Package Names or Unpackaged are not specified
if (retrieveType == "retrieveUnpackaged" && unpackaged == "") {
    throw new Exception("Unpackaged is required if retrieveType is 'Unpackaged'")
}

if (retrieveType != "retrieveUnpackaged" && packageNames == "") {
    throw new Exception("Package Names is required if retrieveType is not 'Unpackaged'")
}

def helper = new SalesForceHelper(props)
AntBuilder ant = helper.buildAnt()

println("[ACTION] Retrieving from ${retrieveTarget}")

ant.taskdef name: "sfRetrieve", classname: "com.salesforce.ant.RetrieveTask"

if (retrieveType == "retrieveUnpackaged") {
    ant.sfRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            unpackaged: unpackaged,
            password: password,
            serverurl: serverUrl,
            maxPoll: maxPoll,
            pollWaitMillis: pollWaitMillis
    )
}
else {
    ant.sfRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            packageNames: packageNames,
            password: password,
            serverurl: serverUrl,
            maxPoll: maxPoll,
            pollWaitMillis: pollWaitMillis
    )
}
