import com.urbancode.air.AirPluginTool

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile


def password = props['password']
def username = props['username']
def serverUrl = props['serverUrl']
def apiVersion = props['apiVersion']
def metadataType = props['metadataType']
def folder = props['folder']
def resultFilePath = props['resultFilePath']
def trace = props['trace']

def ant = new AntBuilder()

ant.taskdef name: "sfListMetadata", classname: "com.salesforce.ant.ListMetadataTask"
if (resultFilePath) {
        ant.sfListMetadata(
                username: username,
                password: password,
                serverurl: serverUrl,
                apiVersion: apiVersion,
                trace: trace,
                metadataType: metadataType,
                folder: folder,
                resultFilePath: resultFilePath
        )
}
else {
        ant.sfListMetadata(
                username: username,
                password: password,
                serverurl: serverUrl,
                apiVersion: apiVersion,
                trace: trace,
                metadataType: metadataType,
                folder: folder
        )
}