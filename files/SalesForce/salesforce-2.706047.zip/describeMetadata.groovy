import com.urbancode.air.AirPluginTool

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile


def password = props['password']
def username = props['username']
def serverUrl = props['serverUrl']
def apiVersion = props['apiVersion']


def ant = new AntBuilder()

ant.taskdef name: "sfDescribeMetadata", classname: "com.salesforce.ant.DescribeMetadataTask"
ant.sfDescribeMetadata(
        username: username,
        password: password,
        serverurl: serverUrl,
        apiVersion: apiVersion
)