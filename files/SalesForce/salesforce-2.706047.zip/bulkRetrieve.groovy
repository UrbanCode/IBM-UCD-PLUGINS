import com.urbancode.air.AirPluginTool

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile


def containingFolder = props['containingFolder']
def password = props['password']
def username = props['username']
def serverUrl = props['serverUrl']
def metadataType = props['metadataType']
def retrieveTarget = props['retrieveTarget']
def batchSize = props['batchSize']
def apiVersion = props['apiVersion']
def maxPoll = props['maxPoll']
def unzip = props['unzip']

def ant = new AntBuilder()

ant.taskdef name: "sfBulkRetrieve", classname: "com.salesforce.ant.BulkRetrieveTask"

if (containingFolder != "") {
    ant.sfBulkRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            metadataType: metadataType,
            password: password,
            serverurl: serverUrl,
            batchSize: batchSize,
            maxPoll: maxPoll,
            apiVersion: apiVersion,
            unzip: unzip,
            containingFolder: containingFolder
    )
}
else {
    ant.sfBulkRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            metadataType: metadataType,
            password: password,
            serverurl: serverUrl,
            batchSize: batchSize,
            maxPoll: maxPoll,
            apiVersion: apiVersion,
            unzip: unzip
    )
}
