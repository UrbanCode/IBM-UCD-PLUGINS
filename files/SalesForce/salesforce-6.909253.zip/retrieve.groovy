/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Deploy
 * IBM Urbancode Release
 * (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile

String retrieveType = props['retrieveType']
String password = props['password']
String username = props['username']
String serverUrl = props['serverUrl']
String packageNames = props['packageNames']
String retrieveTarget = props['retrieveTarget']
String unpackaged = props['unpackaged']

if (packageNames != "" && unpackaged != "") {
    println("[WARNING] 'packageNames' and 'unpackaged' were both specified, but only one can be used.")
}

// Throw error at the beginning if Package Names or Unpackaged are not specified
if (retrieveType == "retrieveUnpackaged" && unpackaged == "") {
    throw new Exception("Unpackaged is required if retrieveType is 'Unpackaged'")
}

if (retrieveType != "retrieveUnpackaged" && packageNames == "") {
    throw new Exception("Package Names is required if retrieveType is not 'Unpackaged'")
}

def helper = new SalesForceHelper(props)
AntBuilder ant = helper.buildAnt()

println("[ACTION] Retrieving from ${retrieveTarget}")

ant.taskdef name: "sfRetrieve", classname: "com.salesforce.ant.RetrieveTask"

if (retrieveType == "retrieveUnpackaged") {
    ant.sfRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            unpackaged: unpackaged,
            password: password,
            serverurl: serverUrl
    )
}
else {
    ant.sfRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            packageNames: packageNames,
            password: password,
            serverurl: serverUrl
    )
}
