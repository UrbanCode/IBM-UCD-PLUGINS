import com.urbancode.air.AirPluginTool

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile


def containingFolder = props['containingFolder']
def password = props['password']
def username = props['username']
def serverUrl = props['serverUrl']
def metadataType = props['metadataType']
def retrieveTarget = props['retrieveTarget']
def batchSize = props['batchSize']
def apiVersion = props['apiVersion']
def maxPoll = props['maxPoll']
def unzip = props['unzip']
def proxyUser = props['proxyUser']
def proxyPassword = ['proxyPassword']
def proxyHost = props['proxyHost']
def proxyPort = props['proxyPort']
def socksProxyHost = props['socksProxyHost']
def socksProxyPort = props['socksProxyPort']

if (!proxyPort) {
        proxyPort = 80
}
if (!socksProxyPort) {
        socksProxyPort = 1080
}

def ant = new AntBuilder()
if (proxyHost) {
    if (proxyUser && proxyPassword) {
        ant.setproxy(
            proxyhost: proxyHost,
            proxyport: proxyPort,
            proxyuser: proxyUser,
            proxypassword: proxyPassword
        )
    }
    else {
        ant.setproxy(
            proxyhost: proxyHost,
            proxyport: proxyPort
        )
    }
}
else if (socksProxyHost) {
    if (proxyUser && proxyPassword) {
        ant.setproxy(
            socksproxyhost: socksProxyHost,
            socksproxyport: socksProxyPort,
            proxyuser: proxyUser,
            proxypassword: proxyPassword
        )
    }
    else {
        ant.setproxy(
            socksproxyhost: socksProxyHost,
            socksproxyport: socksProxyPort
        )
    }
}

ant.taskdef name: "sfBulkRetrieve", classname: "com.salesforce.ant.BulkRetrieveTask"

if (containingFolder != "") {
    ant.sfBulkRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            metadataType: metadataType,
            password: password,
            serverurl: serverUrl,
            batchSize: batchSize,
            maxPoll: maxPoll,
            apiVersion: apiVersion,
            unzip: unzip,
            containingFolder: containingFolder
    )
}
else {
    ant.sfBulkRetrieve(
            username: username,
            retrieveTarget: retrieveTarget,
            metadataType: metadataType,
            password: password,
            serverurl: serverUrl,
            batchSize: batchSize,
            maxPoll: maxPoll,
            apiVersion: apiVersion,
            unzip: unzip
    )
}
