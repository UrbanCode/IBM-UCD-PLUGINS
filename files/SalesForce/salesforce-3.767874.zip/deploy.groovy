import com.urbancode.air.AirPluginTool

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile


def password = props['password']
def username = props['username']
def serverUrl = props['serverUrl']
def deployRoot = props['deployRoot']
def isRollback = Boolean.valueOf(props['isRollback'])
def proxyUser = props['proxyUser']
def proxyPassword = ['proxyPassword']
def proxyHost = props['proxyHost']
def proxyPort = props['proxyPort']
def socksProxyHost = props['socksProxyHost']
def socksProxyPort = props['socksProxyPort']

def deployRootPath = null

if (new File(deployRoot).isAbsolute()) {
    deployRootPath = deployRoot.canonicalPath
}
else {
    deployRootPath = new File(workDir, deployRoot).canonicalPath
}

if (!proxyPort) {
    proxyPort = 80
}
if (!socksProxyPort) {
    socksProxyPort = 1080
}

def ant = new AntBuilder()
if (proxyHost) {
    if (proxyUser && proxyPassword) {
        ant.setproxy(
            proxyhost: proxyHost,
            proxyport: proxyPort,
            proxyuser: proxyUser,
            proxypassword: proxyPassword
        )
    }
    else {
        ant.setproxy(
            proxyhost: proxyHost,
            proxyport: proxyPort
        )
    }
}
else if (socksProxyHost) {
    if (proxyUser && proxyPassword) {
        ant.setproxy(
            socksproxyhost: socksProxyHost,
            socksproxyport: socksProxyPort,
            proxyuser: proxyUser,
            proxypassword: proxyPassword
        )
    }
    else {
        ant.setproxy(
            socksproxyhost: socksProxyHost,
            socksproxyport: socksProxyPort
        )
    }
}

ant.taskdef name: "sfDeploy", classname: "com.salesforce.ant.DeployTask"
ant.sfDeploy(
    username: username,
    password: password,
    serverurl: serverUrl,
    deployRoot: deployRootPath,
    rollbackOnError: isRollback
)

    //deployRoot: "tools/sample/codepkg",