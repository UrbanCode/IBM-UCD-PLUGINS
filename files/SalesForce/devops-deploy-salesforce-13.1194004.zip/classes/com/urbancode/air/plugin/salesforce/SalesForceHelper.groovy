/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2026. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
package com.urbancode.air.plugin.salesforce

import groovy.json.JsonSlurper
import java.net.URLEncoder
import java.nio.file.Files
import java.nio.file.attribute.PosixFilePermission

/**
 * Runs Salesforce CLI v2 ('sf') commands on behalf of the plugin steps.
 *
 * Replaces the retired Force.com Migration Tool (ant-salesforce.jar / com.salesforce.ant.*
 * Ant tasks), which stopped receiving updates at API v59.0.
 *
 * Responsibilities:
 *   - authenticate headlessly via the JWT bearer flow or an SFDX auth URL
 *   - isolate CLI state per step invocation so concurrent agent processes cannot
 *     clobber each other's default org
 *   - translate UCD proxy properties into the environment variables the Node-based
 *     CLI actually honours
 *   - execute commands, stream or capture output, and parse --json payloads
 *   - guarantee that secrets written to disk and the CLI session are cleaned up
 *
 * Typical use from a step script:
 *
 *   def helper = new SalesForceHelper(props)
 *   try {
 *       helper.login()
 *       def json = helper.runJson("Deploying", args)
 *   }
 *   finally {
 *       helper.cleanup()
 *   }
 */
public class SalesForceHelper {

    public static final String AUTH_JWT = 'jwt'
    public static final String AUTH_SFDX_URL = 'sfdx-url'

    private static final int DEFAULT_MAX_POLL = 200
    private static final int DEFAULT_POLL_WAIT_MILLIS = 10000
    private static final int MAX_WAIT_MINUTES = 1440

    final String cliPath
    final String authMethod
    final String username
    final String instanceUrl
    final String apiVersion
    final int waitMinutes

    private final String clientId
    private final String jwtKeyFile
    private final String jwtKey
    private final String sfdxAuthUrl

    private final File workDir
    private final File runtimeDir
    private final String alias
    private final Map<String, String> childEnv = [:]
    private final List<File> tempFiles = []
    private final List<String> secrets = []

    private boolean loggedIn = false
    private File createdProjectStub = null

    public SalesForceHelper(props) {
        this.workDir = new File('.').canonicalFile
        this.alias = 'ucd-sf-' + UUID.randomUUID().toString().substring(0, 8)

        this.runtimeDir = new File(workDir, ".sf-${alias}")
        this.runtimeDir.mkdirs()

        this.cliPath = resolveProperty(props['sfCliPath']) ?: 'sf'
        this.authMethod = (resolveProperty(props['authMethod']) ?: AUTH_JWT).trim().toLowerCase()

        this.username = resolveProperty(props['username'])
        this.instanceUrl = resolveProperty(props['instanceUrl'])
        this.apiVersion = resolveProperty(props['apiVersion'])

        this.clientId = resolveProperty(props['clientId'])
        this.jwtKeyFile = resolveProperty(props['jwtKeyFile'])
        this.jwtKey = resolveProperty(props['jwtKey'])
        this.sfdxAuthUrl = resolveProperty(props['sfdxAuthUrl'])

        this.waitMinutes = toWaitMinutes(props['maxPoll'], props['pollWaitMillis'])

        if (clientId) { secrets << clientId }
        if (sfdxAuthUrl) { secrets << sfdxAuthUrl }

        validateAuthMethod()
        configureEnvironment(props)
    }

    // ------------------------------------------------------------------
    // Property helpers
    // ------------------------------------------------------------------

    /**
     * UCD leaves an unresolved '${p:...}' token in place when a referenced property
     * does not exist. Treat those, and blank strings, as "not supplied".
     */
    private static String resolveProperty(value) {
        if (value == null) {
            return null
        }
        String text = value.toString().trim()
        if (!text || text.contains('${p:') || text.contains('${p?:')) {
            return null
        }
        return text
    }

    private static int parseIntProperty(value, int defaultValue) {
        String text = resolveProperty(value)
        if (!text) {
            return defaultValue
        }
        try {
            return Integer.parseInt(text)
        }
        catch (NumberFormatException e) {
            return defaultValue
        }
    }

    private static boolean parseBooleanProperty(value, boolean defaultValue) {
        String text = resolveProperty(value)
        if (!text) {
            return defaultValue
        }
        return Boolean.valueOf(text)
    }

    /**
     * The Ant tool polled maxPoll times waiting pollWaitMillis between attempts.
     * The CLI takes a single --wait value in whole minutes, so collapse the pair.
     * Defaults (200 x 10000ms) work out to roughly 34 minutes.
     */
    public static int toWaitMinutes(maxPoll, pollWaitMillis) {
        int polls = parseIntProperty(maxPoll, DEFAULT_MAX_POLL)
        int millis = parseIntProperty(pollWaitMillis, DEFAULT_POLL_WAIT_MILLIS)
        long totalMillis = (long) polls * (long) millis
        int minutes = (int) Math.ceil(totalMillis / 60000.0d)
        if (minutes < 1) {
            minutes = 1
        }
        if (minutes > MAX_WAIT_MINUTES) {
            minutes = MAX_WAIT_MINUTES
        }
        return minutes
    }

    // ------------------------------------------------------------------
    // Configuration
    // ------------------------------------------------------------------

    private void validateAuthMethod() {
        if (authMethod == AUTH_JWT) {
            List<String> missing = []
            if (!username) { missing << "'User'" }
            if (!clientId) { missing << "'Consumer Key'" }
            if (!jwtKeyFile && !jwtKey) { missing << "'JWT Key File' or 'JWT Private Key'" }
            if (missing) {
                throw new IllegalArgumentException(
                        "JWT authentication requires ${missing.join(', ')}. " +
                        "Salesforce CLI v2 does not support username/password login.")
            }
        }
        else if (authMethod == AUTH_SFDX_URL) {
            if (!sfdxAuthUrl) {
                throw new IllegalArgumentException(
                        "SFDX auth URL authentication requires 'SFDX Auth URL'. " +
                        "Generate one with: sf org display --target-org <alias> --verbose")
            }
        }
        else {
            throw new IllegalArgumentException(
                    "Unsupported authentication method '${authMethod}'. " +
                    "Expected '${AUTH_JWT}' or '${AUTH_SFDX_URL}'.")
        }
    }

    private void configureEnvironment(props) {
        // Isolate all CLI state under this step's runtime directory. Without this,
        // two concurrent UCD processes on the same agent share ~/.sf and race on
        // the default target org.
        childEnv.put('SF_DATA_DIR', new File(runtimeDir, 'data').absolutePath)
        childEnv.put('SF_CONFIG_DIR', new File(runtimeDir, 'config').absolutePath)
        childEnv.put('SF_CACHE_DIR', new File(runtimeDir, 'cache').absolutePath)

        // Headless agents have no desktop keyring; force the file-based key store.
        childEnv.put('SF_CONTAINER_MODE', 'true')
        childEnv.put('SF_USE_GENERIC_UNIX_KEYCHAIN', 'true')

        // Keep builds deterministic and offline-safe.
        childEnv.put('SF_DISABLE_TELEMETRY', 'true')
        childEnv.put('SF_AUTOUPDATE_DISABLE', 'true')
        childEnv.put('SF_DISABLE_AUTOUPDATE', 'true')

        if (parseBooleanProperty(props['trace'], false)) {
            childEnv.put('SF_LOG_LEVEL', 'debug')
        }

        configureProxy(props)
    }

    /**
     * The Ant task used <setproxy>. The CLI is a Node process and ignores JVM proxy
     * settings, so translate to the standard proxy environment variables instead.
     *
     * Note: SOCKS proxies are not supported by the Salesforce CLI and are no longer
     * exposed as plugin properties.
     */
    private void configureProxy(props) {
        String proxyHost = resolveProperty(props['proxyHost'])
        if (!proxyHost) {
            return
        }

        int proxyPort = parseIntProperty(props['proxyPort'], 80)
        String proxyUser = resolveProperty(props['proxyUser'])
        String proxyPassword = resolveProperty(props['proxyPassword'])

        StringBuilder url = new StringBuilder('http://')
        if (proxyUser) {
            url.append(URLEncoder.encode(proxyUser, 'UTF-8'))
            if (proxyPassword) {
                secrets << proxyPassword
                url.append(':').append(URLEncoder.encode(proxyPassword, 'UTF-8'))
            }
            url.append('@')
        }
        url.append(proxyHost).append(':').append(proxyPort)

        String proxyUrl = url.toString()
        secrets << proxyUrl

        childEnv.put('HTTP_PROXY', proxyUrl)
        childEnv.put('HTTPS_PROXY', proxyUrl)
        childEnv.put('http_proxy', proxyUrl)
        childEnv.put('https_proxy', proxyUrl)

        String noProxy = resolveProperty(props['noProxy'])
        if (noProxy) {
            childEnv.put('NO_PROXY', noProxy)
            childEnv.put('no_proxy', noProxy)
        }

        println("[INFO] Routing Salesforce CLI traffic through proxy ${proxyHost}:${proxyPort}.")
    }

    // ------------------------------------------------------------------
    // Authentication
    // ------------------------------------------------------------------

    public String getAlias() {
        return alias
    }

    /** Fails fast with an actionable message when 'sf' is missing from the agent. */
    public void verifyCli() {
        Map result = exec("Checking Salesforce CLI availability", ['--version'], false, false)
        if (result.exitCode != 0) {
            throw new IllegalStateException(
                    "Unable to run '${cliPath}'. Install Salesforce CLI v2 on this agent " +
                    "(npm install --global @salesforce/cli) or set the 'Salesforce CLI Path' property.")
        }
        println("[INFO] ${result.stdout.toString().trim()}")
    }

    public void login() {
        if (loggedIn) {
            return
        }
        verifyCli()

        if (authMethod == AUTH_JWT) {
            loginJwt()
        }
        else {
            loginSfdxUrl()
        }

        loggedIn = true
        println("[OK] Authenticated to Salesforce. Session alias: ${alias}")
    }

    private void loginJwt() {
        File keyFile = resolveJwtKeyFile()

        List<String> args = ['org', 'login', 'jwt',
                             '--username', username,
                             '--jwt-key-file', keyFile.absolutePath,
                             '--client-id', clientId,
                             '--alias', alias]
                             
        runJson("Authenticating to Salesforce using the JWT bearer flow", args)
    }

    private void loginSfdxUrl() {
        File urlFile = writeSecretFile('sfdx-auth-url', sfdxAuthUrl)

        List<String> args = ['org', 'login', 'sfdx-url',
                             '--sfdx-url-file', urlFile.absolutePath,
                             '--alias', alias]

        runJson("Authenticating to Salesforce using an SFDX auth URL", args)
    }

    private File resolveJwtKeyFile() {
        if (jwtKeyFile) {
            File file = new File(jwtKeyFile)
            if (!file.isAbsolute()) {
                file = new File(workDir, jwtKeyFile)
            }
            if (!file.isFile()) {
                throw new IllegalArgumentException("JWT key file not found: ${file.absolutePath}")
            }
            return file
        }
        // The key was supplied inline as a secure property; stage it on disk because
        // the CLI only accepts a file path.
        String content = normalizePemPrivateKey(jwtKey)
        //String content = jwtKey.endsWith('\n') ? jwtKey : (jwtKey + '\n')
        return writeSecretFile('jwt-key', content)
    }

    private File writeSecretFile(String prefix, String content) {
        File file = File.createTempFile(prefix, '.tmp', runtimeDir)
        tempFiles << file
        restrictToOwner(file)
        file.setText(content, 'UTF-8')
        return file
    }

    private static void restrictToOwner(File file) {
        try {
            Set<PosixFilePermission> permissions = new HashSet<PosixFilePermission>()
            permissions.add(PosixFilePermission.OWNER_READ)
            permissions.add(PosixFilePermission.OWNER_WRITE)
            Files.setPosixFilePermissions(file.toPath(), permissions)
        }
        catch (Exception e) {
            // Windows agents have no POSIX permissions; fall back to the java.io API.
            file.setReadable(false, false)
            file.setReadable(true, true)
            file.setWritable(false, false)
            file.setWritable(true, true)
        }
    }

    // ------------------------------------------------------------------
    // Command execution
    // ------------------------------------------------------------------

    /** Arguments every org-scoped command needs. */
    public List<String> targetOrgArgs() {
        List<String> args = ['--target-org', alias]
        if (apiVersion) {
            args.addAll(['--api-version', apiVersion])
        }
        return args
    }

    /**
     * Runs a command with --json, returning the parsed payload.
     * Throws on a non-zero exit code after reporting the CLI's structured errors.
     */
    public Map runJson(String description, List<String> args) {
        List<String> fullArgs = new ArrayList<String>(args)
        if (!fullArgs.contains('--json')) {
            fullArgs.add('--json')
        }

        Map result = exec(description, fullArgs, false, false)
        Map payload = parseJson(result.stdout.toString(), result.stderr.toString())

        if (result.exitCode != 0) {
            reportFailure(payload, result)
            throw new RuntimeException(
                    "Salesforce CLI command failed with exit code ${result.exitCode}.")
        }
        return payload
    }

    /** Runs a command streaming its output to the UCD log. Throws on a non-zero exit code. */
    public void runStreaming(String description, List<String> args) {
        Map result = exec(description, args, true, false)
        if (result.exitCode != 0) {
            throw new RuntimeException(
                    "Salesforce CLI command failed with exit code ${result.exitCode}.")
        }
    }

    private Map exec(String description, List<String> args, boolean echoStdout, boolean quiet) {
        List<String> command = [cliPath]
        args.each { arg ->
            if (arg != null) {
                command.add(arg.toString())
            }
        }

        if (!quiet) {
            println("[ACTION] ${description}...")
            println("[INFO] Executing: ${redact(command.join(' '))}")
        }

        ProcessBuilder builder = new ProcessBuilder(command)
        builder.directory(workDir)
        builder.environment().putAll(childEnv)

        Process process = builder.start()
        process.outputStream.close()

        StringBuilder stdout = new StringBuilder()
        StringBuilder stderr = new StringBuilder()
        Thread outReader = consume(process.inputStream, stdout, echoStdout)
        Thread errReader = consume(process.errorStream, stderr, true)

        int exitCode = process.waitFor()
        outReader.join()
        errReader.join()

        return [exitCode: exitCode, stdout: stdout, stderr: stderr]
    }

    private Thread consume(InputStream stream, StringBuilder sink, boolean echo) {
        Runnable task = {
            try {
                stream.withReader('UTF-8') { reader ->
                    String line = reader.readLine()
                    while (line != null) {
                        sink.append(line).append('\n')
                        if (echo) {
                            println(redact(line))
                        }
                        line = reader.readLine()
                    }
                }
            }
            catch (Exception e) {
                println("[WARN] Failed reading Salesforce CLI output: ${e.message}")
            }
        } as Runnable

        Thread thread = new Thread(task)
        thread.setDaemon(true)
        thread.start()
        return thread
    }

    /** Keeps consumer keys, auth URLs and proxy credentials out of the UCD log. */
    private String redact(String text) {
        if (!text) {
            return text
        }
        String result = text
        secrets.each { secret ->
            if (secret) {
                result = result.replace(secret, '****')
            }
        }
        return result
    }

    private static Map parseJson(String stdout, String stderr) {
        String candidate = firstJsonObject(stdout)
        if (!candidate) {
            candidate = firstJsonObject(stderr)
        }
        if (!candidate) {
            return [:]
        }
        try {
            def parsed = new JsonSlurper().parseText(candidate)
            return (parsed instanceof Map) ? (Map) parsed : [:]
        }
        catch (Exception e) {
            return [:]
        }
    }

    private static String firstJsonObject(String text) {
        if (!text) {
            return null
        }
        int start = text.indexOf('{')
        int end = text.lastIndexOf('}')
        if (start < 0 || end <= start) {
            return null
        }
        return text.substring(start, end + 1)
    }

    private void reportFailure(Map payload, Map result) {
        if (payload && payload['message']) {
            println("[ERROR] ${redact(payload['message'].toString())}")
        }

        // Depending on the command and CLI version, failure detail hangs off either
        // 'data' (error payloads) or 'result' (completed-but-failed deployments).
        def details = payload?.data?.details ?: payload?.result?.details

        def componentFailures = details?.componentFailures
        if (componentFailures instanceof List) {
            componentFailures.each { failure ->
                println("[ERROR] ${failure['fullName']} (${failure['componentType']}): ${failure['problem']}")
            }
        }

        def testFailures = details?.runTestResult?.failures
        if (testFailures instanceof List) {
            testFailures.each { failure ->
                println("[ERROR] Test failed - ${failure['name']}.${failure['methodName']}: ${failure['message']}")
            }
        }

        if (!payload) {
            println("[ERROR] ${redact(result.stdout.toString())}")
        }
    }

    // ------------------------------------------------------------------
    // Project stub
    // ------------------------------------------------------------------

    /**
     * Some 'sf project ...' commands expect to run inside a Salesforce DX project even
     * when operating on a metadata-format directory. Create a throwaway sfdx-project.json
     * if the working directory does not already have one; it is removed by cleanup().
     */
    public void ensureProjectStub() {
        File projectFile = new File(workDir, 'sfdx-project.json')
        if (projectFile.exists()) {
            return
        }

        String version = apiVersion ?: '62.0'
        projectFile.setText("""{
  "packageDirectories": [ { "path": "force-app", "default": true } ],
  "namespace": "",
  "sfdcLoginUrl": "${instanceUrl ?: 'https://login.salesforce.com'}",
  "sourceApiVersion": "${version}"
}
""", 'UTF-8')

        createdProjectStub = projectFile
        println("[INFO] Created a temporary sfdx-project.json in the working directory.")
    }

    // ------------------------------------------------------------------
    // Teardown
    // ------------------------------------------------------------------

    public void logout() {
        if (!loggedIn) {
            return
        }
        try {
            exec("Ending Salesforce CLI session",
                 ['org', 'logout', '--target-org', alias, '--no-prompt', '--json'],
                 false, true)
        }
        catch (Exception e) {
            println("[WARN] Failed to log out of the Salesforce CLI session: ${e.message}")
        }
        loggedIn = false
    }

    /** Always call this from a finally block. Removes the session, secrets and stub project. */
    public void cleanup() {
        logout()

        tempFiles.each { file ->
            try {
                if (file.exists()) {
                    file.delete()
                }
            }
            catch (Exception e) {
                println("[WARN] Failed to delete temporary file ${file.name}: ${e.message}")
            }
        }
        tempFiles.clear()

        if (createdProjectStub != null) {
            try {
                createdProjectStub.delete()
            }
            catch (Exception e) {
                println("[WARN] Failed to delete temporary sfdx-project.json: ${e.message}")
            }
            createdProjectStub = null
        }

        deleteRecursively(runtimeDir)
    }

    private static void deleteRecursively(File target) {
        if (target == null || !target.exists()) {
            return
        }
        try {
            if (target.isDirectory()) {
                File[] children = target.listFiles()
                if (children != null) {
                    children.each { child -> deleteRecursively(child) }
                }
            }
            target.delete()
        }
        catch (Exception e) {
            println("[WARN] Failed to clean up ${target.absolutePath}: ${e.message}")
        }
    }

    /**
    * Normalizes an inline PEM private key before writing it to disk.
    *
    * UCD secure properties may arrive as a single line with spaces between
    * the PEM/Base64 lines. Salesforce CLI requires a valid PEM structure.
    */
    private static String normalizePemPrivateKey(String key) {
        if (!key) {
            throw new IllegalArgumentException("JWT private key is empty.")
        }

        String normalized = key.trim()

        // Normalize escaped newlines if they are present.
        normalized = normalized.replace('\\r\\n', '\n')
                            .replace('\\n', '\n')
                            .replace('\\r', '\n')

        // Remove PEM headers/footers temporarily.
        String beginMarker = '-----BEGIN PRIVATE KEY-----'
        String endMarker = '-----END PRIVATE KEY-----'

        if (!normalized.contains(beginMarker) || !normalized.contains(endMarker)) {
            throw new IllegalArgumentException(
                    "JWT private key must be PEM formatted with " +
                    "'-----BEGIN PRIVATE KEY-----' and '-----END PRIVATE KEY-----'.")
        }

        String body = normalized
                .replace(beginMarker, '')
                .replace(endMarker, '')
                .replaceAll('\\s+', '')

        if (!body) {
            throw new IllegalArgumentException("JWT private key contains no key data.")
        }

        // Re-wrap Base64 data at 64 characters per line.
        StringBuilder wrapped = new StringBuilder()
        for (int i = 0; i < body.length(); i += 64) {
            int end = Math.min(i + 64, body.length())
            wrapped.append(body.substring(i, end)).append('\n')
        }

        return beginMarker + '\n' +
            wrapped.toString() +
            endMarker + '\n'
    }
}
