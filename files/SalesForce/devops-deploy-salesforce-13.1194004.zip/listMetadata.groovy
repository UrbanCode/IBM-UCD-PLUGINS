/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2026. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper

airTool = new AirPluginTool(args[0], args[1])
def props = airTool.getStepProperties()

def workDir = new File('.').canonicalFile

String metadataType = props['metadataType']
String folder = props['folder']
String resultFilePath = props['resultFilePath']

if (!metadataType) {
    println("[ERROR] 'Metadata Type' is required.")
    System.exit(1)
}

// 'trace' is consumed by SalesForceHelper, which maps it to SF_LOG_LEVEL=debug.
def helper = null
int exitCode = 0

try {
    // Constructed inside the try so a credential/config error is reported cleanly
    // and the runtime directory is still torn down by the finally block.
    helper = new SalesForceHelper(props)
    helper.login()

    List<String> cliArgs = ['org', 'list', 'metadata']
    cliArgs.addAll(['--metadata-type', metadataType])
    cliArgs.addAll(helper.targetOrgArgs())

    if (folder) {
        cliArgs.addAll(['--folder', folder])
    }

    if (resultFilePath) {
        File outputFile = new File(resultFilePath)
        if (!outputFile.isAbsolute()) {
            outputFile = new File(workDir, resultFilePath)
        }
        outputFile.parentFile?.mkdirs()
        cliArgs.addAll(['--output-file', outputFile.canonicalPath])
        println("[INFO] Results will be written to ${outputFile.canonicalPath}")
    }

    Map payload = helper.runJson("Listing ${metadataType} metadata", cliArgs)

    def components = payload['result']
    if (components instanceof List) {
        println("[INFO] ${components.size()} component(s) of type ${metadataType}:")
        components.each { component ->
            println("  ${component['fullName']} (id: ${component['id'] ?: 'n/a'}, " +
                    "modified: ${component['lastModifiedDate'] ?: 'n/a'})")
        }
    }

    println("[OK] List metadata complete.")
}
catch (Exception e) {
    println("[ERROR] ${e.message}")
    exitCode = 1
}
finally {
    if (helper != null) {
        helper.cleanup()
    }
}

System.exit(exitCode)
