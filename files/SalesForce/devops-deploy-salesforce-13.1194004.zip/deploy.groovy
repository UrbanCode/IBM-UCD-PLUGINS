/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2026. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper

airTool = new AirPluginTool(args[0], args[1])
def props = airTool.getStepProperties()

def workDir = new File('.').canonicalFile

String deployRoot = props['deployRoot']
String testLevel = props['testLevel']
String testList = props['testList'] ?: ""
boolean checkOnly = Boolean.valueOf(props['checkOnly'])
boolean isRollback = props['isRollback'] == null ? true : Boolean.valueOf(props['isRollback'])

String[] testNames = testList ? testList.split('\n')*.trim().findAll { it } as String[] : [] as String[]

// ---------------------------------------------------------------------------
// Resolve the metadata-format directory to deploy
// ---------------------------------------------------------------------------

if (!deployRoot) {
    println("[ERROR] 'Deploy Root' is required.")
    System.exit(1)
}

File deployRootFile = new File(deployRoot)
if (!deployRootFile.isAbsolute()) {
    deployRootFile = new File(workDir, deployRoot)
}

if (!deployRootFile.exists()) {
    println("[ERROR] Deployment root '${deployRoot}' not set to a valid file or directory.")
    System.exit(1)
}

String deployRootPath = deployRootFile.canonicalPath

if (deployRootFile.isDirectory() && !new File(deployRootFile, 'package.xml').isFile()) {
    println("[WARNING] No package.xml found in '${deployRootPath}'. " +
            "This step deploys metadata-format directories; source-format projects will fail.")
}

// ---------------------------------------------------------------------------
// Build the Salesforce CLI v2 command
// ---------------------------------------------------------------------------

def helper = null
int exitCode = 0

try {
    // Constructed inside the try so a credential/config error is reported cleanly
    // and the runtime directory is still torn down by the finally block.
    helper = new SalesForceHelper(props)
    helper.login()
    helper.ensureProjectStub()

    // 'validate' is the CLI equivalent of the old checkOnly deployment. It produces a
    // validated deployment that the 'Deploy Recent Validation' step can quick-deploy.
    String subCommand = checkOnly ? 'validate' : 'start'

    List<String> cliArgs = ['project', 'deploy', subCommand]
    cliArgs.addAll(['--metadata-dir', deployRootPath])
    cliArgs.addAll(helper.targetOrgArgs())
    cliArgs.addAll(['--wait', String.valueOf(helper.waitMinutes)])

    if (testLevel) {
        cliArgs.addAll(['--test-level', testLevel])

        if (testLevel == 'RunSpecifiedTests') {
            if (!testNames) {
                // Throw rather than System.exit: exit() skips the finally block, which
                // would leave the CLI session and any staged private key on disk.
                throw new IllegalArgumentException(
                        "'Test Level' is 'RunSpecifiedTests' but no test names were provided.")
            }
            testNames.each { testName ->
                cliArgs.addAll(['--tests', testName])
            }
        }
    }

    if (checkOnly) {
        if (!testLevel || testLevel == 'NoTestRun') {
            println("[WARNING] Validations against production require a test level of " +
                    "RunLocalTests, RunAllTestsInOrg or RunSpecifiedTests to qualify for quick deploy.")
        }
        if (!isRollback) {
            println("[INFO] 'Roll Back on Error' is ignored for validations; " +
                    "a validation is always all-or-nothing.")
        }
    }
    else if (!isRollback) {
        // The CLI rolls back on error by default. --ignore-errors is the opt-out.
        println("[WARNING] 'Roll Back on Error' is disabled; successful components will be " +
                "committed even if others fail. This is rejected by production orgs.")
        cliArgs.add('--ignore-errors')
    }

    String description = checkOnly ?
            "Validating deployment from '${deployRoot}' without saving to the target org" :
            "Deploying from '${deployRoot}'"

    Map payload = helper.runJson(description, cliArgs)

    // -----------------------------------------------------------------------
    // Publish the deployment id. Replaces the old approach of redirecting the
    // Ant BuildLogger to a temp file and scraping "[sfDeploy] Finished request".
    // -----------------------------------------------------------------------

    def result = payload['result'] ?: [:]
    String deploymentId = result['id'] ?: result['deployId'] ?: result['deploymentId']

    if (!deploymentId) {
        println("[WARNING] The Salesforce CLI did not report a deployment id.")
        deploymentId = "null"
    }

    if (checkOnly) {
        println("[ACTION] Setting recentValidationId as output property: ${deploymentId}")
        airTool.setOutputProperty("recentValidationId", deploymentId)
    }
    else {
        println("[INFO] Deployment id: ${deploymentId}")
    }

    airTool.setOutputProperty("deploymentId", deploymentId)
    airTool.setOutputProperties()

    def numberDeployed = result['numberComponentsDeployed']
    def numberTotal = result['numberComponentsTotal']
    if (numberTotal != null) {
        println("[OK] Components processed: ${numberDeployed ?: 0}/${numberTotal}")
    }
}
catch (Exception e) {
    println("[ERROR] ${e.message}")
    exitCode = 1
}
finally {
    if (helper != null) {
        helper.cleanup()
    }
}

System.exit(exitCode)
