/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2026. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper

airTool = new AirPluginTool(args[0], args[1])
def props = airTool.getStepProperties()

String recentValidationId = props['recentValidationId']

if (!recentValidationId || recentValidationId == "null") {
    println("[ERROR] 'Recent Validation ID' is required. Run the 'Deploy' step with " +
            "'Check Only' selected to produce one.")
    System.exit(1)
}

def helper = null
int exitCode = 0

try {
    // Constructed inside the try so a credential/config error is reported cleanly
    // and the runtime directory is still torn down by the finally block.
    helper = new SalesForceHelper(props)
    helper.login()
    helper.ensureProjectStub()

    List<String> cliArgs = ['project', 'deploy', 'quick']
    cliArgs.addAll(['--job-id', recentValidationId])
    cliArgs.addAll(helper.targetOrgArgs())
    cliArgs.addAll(['--wait', String.valueOf(helper.waitMinutes)])

    Map payload = helper.runJson(
            "Deploying recent validation '${recentValidationId}'", cliArgs)

    def result = payload['result'] ?: [:]

    // Known CLI behaviour: --json has historically echoed the input validation id
    // rather than the new quick-deploy job id, so report both and do not rely on
    // this value being distinct from the input.
    String reportedId = result['id'] ?: result['deployId'] ?: recentValidationId
    println("[INFO] Validation id: ${recentValidationId}")
    println("[INFO] Deployment id reported by the CLI: ${reportedId}")

    airTool.setOutputProperty("deploymentId", reportedId)
    airTool.setOutputProperties()

    if (result['success'] == false) {
        println("[ERROR] The quick deployment did not complete successfully.")
        exitCode = 1
    }
    else {
        println("[OK] Quick deployment complete.")
    }
}
catch (Exception e) {
    println("[ERROR] ${e.message}")
    exitCode = 1
}
finally {
    if (helper != null) {
        helper.cleanup()
    }
}

System.exit(exitCode)
