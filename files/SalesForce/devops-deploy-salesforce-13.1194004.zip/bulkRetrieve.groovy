/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2026. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper

airTool = new AirPluginTool(args[0], args[1])
def props = airTool.getStepProperties()

def workDir = new File('.').canonicalFile

String metadataType = props['metadataType']
String containingFolder = props['containingFolder'] ?: ""
String retrieveTarget = props['retrieveTarget']
boolean unzip = props['unzip'] == null ? true : Boolean.valueOf(props['unzip'])

if (!metadataType) {
    println("[ERROR] 'Metadata Type' is required.")
    System.exit(1)
}

if (!retrieveTarget) {
    println("[ERROR] 'Retrieve Target' is required.")
    System.exit(1)
}

File retrieveTargetFile = new File(retrieveTarget)
if (!retrieveTargetFile.isAbsolute()) {
    retrieveTargetFile = new File(workDir, retrieveTarget)
}
retrieveTargetFile.mkdirs()

def helper = null
int exitCode = 0

try {
    // Constructed inside the try so a credential/config error is reported cleanly
    // and the runtime directory is still torn down by the finally block.
    helper = new SalesForceHelper(props)
    helper.login()
    helper.ensureProjectStub()

    // Folder-based types (Report, Dashboard, Document, EmailTemplate) are addressed
    // with the Type:FolderName form rather than a separate containingFolder argument.
    String metadataArg = containingFolder ? "${metadataType}:${containingFolder}" : metadataType

    List<String> cliArgs = ['project', 'retrieve', 'start']
    cliArgs.addAll(['--metadata', metadataArg])
    cliArgs.addAll(helper.targetOrgArgs())
    cliArgs.addAll(['--wait', String.valueOf(helper.waitMinutes)])
    cliArgs.addAll(['--target-metadata-dir', retrieveTargetFile.canonicalPath])
    if (unzip) {
        cliArgs.add('--unzip')
    }

    Map payload = helper.runJson("Retrieving to ${retrieveTargetFile.canonicalPath}", cliArgs)

    def result = payload?.get('result')

    // Check the actual Salesforce operation status.
    if (result?.get('success') != true ||
        result?.get('status') != 'Succeeded') {

        def error = result?.get('errorMessage') ?:
                    result?.get('messages')?.toString() ?:
                    'Unknown Salesforce retrieve error'

        throw new RuntimeException(
            "Salesforce metadata retrieval failed: ${error}"
        )
    }

    def files = result?.get('files')
    def fileProperties = result?.get('fileProperties')

    if (files instanceof List && !files.isEmpty()) {
        println("[OK] Retrieved ${files.size()} component(s).")
    } else if (fileProperties instanceof List) {
        def components = fileProperties.findAll {
            it?.get('type') != 'Package'
        }

        println("[OK] Retrieve completed successfully. " +
                "Component count reported by CLI: ${components.size()}.")
    } else {
        println("[OK] Retrieve completed successfully.")
    }

    airTool.setOutputProperty("retrieveTargetPath", retrieveTargetFile.canonicalPath)
    airTool.setOutputProperties()
}
catch (Exception e) {
    println("[ERROR] ${e.message}")
    exitCode = 1
}
finally {
    if (helper != null) {
        helper.cleanup()
    }
}

System.exit(exitCode)
