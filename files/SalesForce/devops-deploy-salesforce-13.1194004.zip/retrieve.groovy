/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2026. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.salesforce.SalesForceHelper

airTool = new AirPluginTool(args[0], args[1])
def props = airTool.getStepProperties()

def workDir = new File('.').canonicalFile

String retrieveType = props['retrieveType']
String packageNames = props['packageNames'] ?: ""
String retrieveTarget = props['retrieveTarget']
String unpackaged = props['unpackaged'] ?: ""
boolean unzip = props['unzip'] == null ? true : Boolean.valueOf(props['unzip'])

if (packageNames && unpackaged) {
    println("[WARNING] 'packageNames' and 'unpackaged' were both specified, but only one can be used.")
}

if (retrieveType == "retrieveUnpackaged" && !unpackaged) {
    println("[ERROR] 'Unpackaged' is required if 'Retrieve Type' is 'Unpackaged'.")
    System.exit(1)
}

if (retrieveType != "retrieveUnpackaged" && !packageNames) {
    println("[ERROR] 'Package Names' is required if 'Retrieve Type' is not 'Unpackaged'.")
    System.exit(1)
}

if (!retrieveTarget) {
    println("[ERROR] 'Retrieve Target' is required.")
    System.exit(1)
}

File retrieveTargetFile = new File(retrieveTarget)
if (!retrieveTargetFile.isAbsolute()) {
    retrieveTargetFile = new File(workDir, retrieveTarget)
}
retrieveTargetFile.mkdirs()

def helper = null
int exitCode = 0

try {
    // Constructed inside the try so a credential/config error is reported cleanly
    // and the runtime directory is still torn down by the finally block.
    helper = new SalesForceHelper(props)
    helper.login()
    helper.ensureProjectStub()

    List<String> cliArgs = ['project', 'retrieve', 'start']
    cliArgs.addAll(helper.targetOrgArgs())
    cliArgs.addAll(['--wait', String.valueOf(helper.waitMinutes)])

    // --target-metadata-dir keeps the output in metadata format, matching what the
    // retired Ant RetrieveTask produced. Without it the CLI writes source format.
    cliArgs.addAll(['--target-metadata-dir', retrieveTargetFile.canonicalPath])
    if (unzip) {
        cliArgs.add('--unzip')
    }

    if (retrieveType == "retrieveUnpackaged") {
        File manifest = new File(unpackaged)
        if (!manifest.isAbsolute()) {
            manifest = new File(workDir, unpackaged)
        }
        if (!manifest.isFile()) {
            // Throw rather than System.exit: exit() skips the finally block, which
            // would leave the CLI session and any staged private key on disk.
            throw new IllegalArgumentException("Manifest file not found: ${manifest.canonicalPath}")
        }
        cliArgs.addAll(['--manifest', manifest.canonicalPath])
    }
    else {
        // 'retrievePkg' and 'retrieveOutput' both map to --package-name; the CLI has
        // no separate "output" retrieve mode.
        packageNames.split(',')*.trim().findAll { it }.each { name ->
            cliArgs.addAll(['--package-name', name])
        }
    }
    
    Map payload = helper.runJson("Retrieving to ${retrieveTargetFile.canonicalPath}", cliArgs)

    def result = payload?.get('result')

    // Check the actual Salesforce operation status.
    if (result?.get('success') != true ||
        result?.get('status') != 'Succeeded') {

        def error = result?.get('errorMessage') ?:
                    result?.get('messages')?.toString() ?:
                    'Unknown Salesforce retrieve error'

        throw new RuntimeException(
            "Salesforce metadata retrieval failed: ${error}"
        )
    }

    def files = result?.get('files')
    def fileProperties = result?.get('fileProperties')

    if (files instanceof List && !files.isEmpty()) {
        println("[OK] Retrieved ${files.size()} component(s).")
    } else if (fileProperties instanceof List) {
        def components = fileProperties.findAll {
            it?.get('type') != 'Package'
        }

        println("[OK] Retrieve completed successfully. " +
                "Component count reported by CLI: ${components.size()}.")
    } else {
        println("[OK] Retrieve completed successfully.")
    }

    airTool.setOutputProperty("retrieveTargetPath", retrieveTargetFile.canonicalPath)
    airTool.setOutputProperties()
}
catch (Exception e) {
    println("[ERROR] ${e.message}")
    exitCode = 1
}
finally {
    if (helper != null) {
        helper.cleanup()
    }
}

System.exit(exitCode)
