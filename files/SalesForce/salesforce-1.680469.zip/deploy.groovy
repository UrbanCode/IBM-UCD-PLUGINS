import com.urbancode.air.AirPluginTool

final airTool = new AirPluginTool(args[0], args[1])
final def props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile


def password = props['password']
def username = props['username']
def serverUrl = props['serverUrl']
def deployRoot = props['deployRoot']
def isRollback = Boolean.valueOf(props['isRollback'])

def deployRootPath = null

if (new File(deployRoot).isAbsolute()) {
    deployRootPath = deployRoot.canonicalPath
}
else {
    deployRootPath = new File(workDir, deployRoot).canonicalPath
}

def ant = new AntBuilder()

ant.taskdef name: "sfDeploy", classname: "com.salesforce.ant.DeployTask"
ant.sfDeploy(
    username: username,
    password: password,
    serverurl: serverUrl,
    deployRoot: deployRootPath,
    rollbackOnError: isRollback
)

    //deployRoot: "tools/sample/codepkg",