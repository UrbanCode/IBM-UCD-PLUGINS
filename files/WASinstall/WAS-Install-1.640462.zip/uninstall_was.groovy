import java.io.*;
import java.util.*;
import com.urbancode.air.CommandHelper;
import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();
final def isWindows = apTool.isWindows;

def wasInstallPath = props['WASInstallPath']
def imInstallPath = props['IMInstallPath']
def versionName = props['VersionName']

try {
    while (imInstallPath.endsWith(File.separator)) {
        imInstallPath = imInstallPath.substring(0, imInstallPath.length()-1);
    }
    def toolsDir = new File(imInstallPath, "tools");
    def imclName = "imcl"+(isWindows?".bat":"");
    def imclExe = new File(toolsDir, imclName);
    def ch = new CommandHelper(toolsDir);
    def cmdArgs = [imclExe.absolutePath,
                       "uninstall", versionName];
    ch.runCommand("Running imcl", cmdArgs);
    if (new File(wasInstallPath).exists()) {
        def ant = new AntBuilder();
        ant.delete(verbose: 'true', includeemptydirs: 'true') {
            fileset(dir:wasInstallPath, casesensitive: 'false', followsymlinks: 'false', defaultexcludes: 'false')
        }
    }
}
catch (Exception e) {
    println "Uninstalling WebSphere Application Server failed.";
    System.exit(1);;
}
