package com.urbancode.util

class OneTestUCDConstants {
	
	public static String RESPONSE_ERROR = "No <missingVar>  \"<varName>\" was found on the Server. Please check <missingVar> Attribute in your Plugin input for possible errors."
	public static String RESPONSE_ERROR_FILEPATH_ASSET = "The server did not find a test asset at file path ..... \"<varName>\"....� Please check if the file path or test asset name is incorrect."
}
