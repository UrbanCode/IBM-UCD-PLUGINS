#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def jdbcDriver = props['jdbcDriver']
final def connectionString = props['connectionString']
final def username = props['username']
final def passScript = props['passScript']
final def password = props['password']?:passScript
final def includes = props['includes']
final def excludes = props['excludes']
final def delimiter = props['delimiter']
final def autocommit = props['autocommit']
final def print = props['print']
final def onerror = props['onerror']
final def files = props['files'];

try {
    def ant = new AntBuilder()
    if (files != null && files.trim() != "") {
        ant.sql(
                driver:jdbcDriver,
                url:connectionString,
                userid:username,
                'password':password,
                'delimiter':delimiter,
                'autocommit':autocommit,
                'print':print,
                'onerror':onerror
        ) {
            filelist(
                dir:'.',
                'files':files
            )
        }
    }
    else {
        if (excludes) {
            ant.sql(
                    driver:jdbcDriver,
                    url:connectionString,
                    userid:username,
                    'password':password,
                    'delimiter':delimiter,
                    'autocommit':autocommit,
                    'print':print,
                    'onerror':onerror
            ) {
                fileset(
                        dir: '.',
                        defaultexcludes: 'no',
                        'includes': includes.split('\n').join(','),
                        'excludes': excludes.split('\n').join(',')
                )
            }
        }
        else {
            ant.sql(
                    driver:jdbcDriver,
                    url:connectionString,
                    userid:username,
                    'password':password,
                    'delimiter':delimiter,
                    'autocommit':autocommit,
                    'print':print,
                    'onerror':onerror
            ) {
                fileset(
                        dir: '.',
                        defaultexcludes: 'no',
                        'includes': includes.split('\n').join(',')
                )
            }
        }
    }
}
catch (Exception e) {
    println "Error Executing SQL Scripts: ${e.message}"
    System.exit(1)

}
finally {
    if (inputPropsFile != null) {
        inputPropsFile.delete()
    }
}

System.exit(0)
