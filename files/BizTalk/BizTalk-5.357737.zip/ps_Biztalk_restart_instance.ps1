$instanceName = $args[0]
$btsInstance = Get-WmiObject MSBTS_HostInstance -n '$instanceName' -filter HostType=1
if ($btsInstance -ne $null) {
    try {
        Write-Host "Stopping $instanceName"
        $btsInstance.Stop()
        Write-Host "Starting $instanceName"
        $btsInstance.Start()
        Write-Host "done"
        exit 0
    }
    catch {
        exit 1
    }
}
exit 1
