
import com.urbancode.air.CommandHelper
import com.urbancode.air.AirPluginTool

final AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = apTool.getStepProperties()

def powershell = props['powerShellExe']? props['powerShellExe'] : 'PowerShell.exe'
def application = props['application'];
def file = new File(props['file']).canonicalPath
def btsTask = props['btsTask']? props['btsTask'] : 'btsTask.exe'
def btDatabase = props['btDatabase'];
def btDbServer = props['btDbServer'];
def PLUGIN_HOME = System.getenv()['PLUGIN_HOME']
def commandHelper = new CommandHelper(new File('.'));

def psScript = PLUGIN_HOME + '\\ps_Biztalk_modify_app.ps1'
psScript = "\'${psScript}\'"
def appArg = "\'${application}\'"
def fileArg = "\'${file}\'"
def btsTaskArg = "\'${btsTask}\'"
def btDbServerArg = btDbServer ? "\'${btDbServer}\'" : "\'.\'"
def btDatabaseArg = btDatabase ? "\'${btDatabase}\'" : "\'BizTalkMgmtDb\'"

def args = [];
args = [powershell, "-Command", "\"& ${psScript} ${appArg} ${fileArg} ${btsTaskArg} ${btDbServerArg} ${btDatabaseArg}\""]
commandHelper.runCommand("Installing/Upgrading BizTalk application ${appArg}: ", args);
