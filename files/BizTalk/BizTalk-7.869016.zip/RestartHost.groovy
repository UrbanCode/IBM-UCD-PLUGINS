import com.urbancode.air.CommandHelper
import com.urbancode.air.AirPluginTool

final AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = apTool.getStepProperties()

def powershell = props['powerShellExe'] ? props['powerShellExe'] : 'PowerShell.exe'
def hostName = props['hostName'] ? props['hostName'] : "root\\MicrosoftBizTalkServer"
def PLUGIN_HOME = System.getenv()['PLUGIN_HOME']
def commandHelper = new CommandHelper(new File('.'));

def psScript = PLUGIN_HOME + '\\ps_Biztalk_restart_instance.ps1'
psScript = "\'${psScript}\'"
def instanceArg = "\'${hostName}\'"

def args = [];
args = [powershell, "-Command", "\"& ${psScript} ${instanceArg}\""]
commandHelper.runCommand("Restarting instance, \'${hostName}\'", args);
