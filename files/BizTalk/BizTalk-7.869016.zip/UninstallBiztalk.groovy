
import com.urbancode.air.CommandHelper
import com.urbancode.air.AirPluginTool

final AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = apTool.getStepProperties()

def btsTask = props['btsTask']? props['btsTask'] : 'btsTask.exe'
def application = props['application'];
try {
    def ch = new CommandHelper(new File('.'));
    def args = [];
    args = [btsTask, 'UninstallApp', '/ApplicationName:' + application];
    ch.runCommand(args.join(' '), args);
}
catch (e) {
    println e
}
