
import com.urbancode.air.CommandHelper
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
def btsTask = props['btsTask']? props['btsTask'] : 'btsTask.exe'
def application = props['application'];
try {
    def ch = new CommandHelper(new File('.'));
    def args = [];
    args = [btsTask, 'UninstallApp', '/ApplicationName:' + application];
    ch.runCommand(args.join(' '), args);
}
catch (e) {
    println e
}