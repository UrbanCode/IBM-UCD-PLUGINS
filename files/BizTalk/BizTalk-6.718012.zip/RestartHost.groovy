import com.urbancode.air.CommandHelper

final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
def powershell = props['powerShellExe'] ? props['powerShellExe'] : 'PowerShell.exe'
def hostName = props['hostName'] ? props['hostName'] : "root\\MicrosoftBizTalkServer"
def PLUGIN_HOME = System.getenv()['PLUGIN_HOME']
def commandHelper = new CommandHelper(new File('.'));

def psScript = PLUGIN_HOME + '\\ps_Biztalk_restart_instance.ps1'
psScript = "\'${psScript}\'"
def instanceArg = "\'${hostName}\'"

def args = [];
args = [powershell, "-Command", "\"& ${psScript} ${instanceArg}\""]
commandHelper.runCommand("Restarting instance, \'${hostName}\'", args);
