import com.urbancode.air.plugin.selenium.SeleniumHelper
import com.urbancode.air.AirPluginTool;


def apTool = new AirPluginTool(this.args[0], this.args[1]);

final def selenium = new SeleniumHelper(apTool.getStepProperties());
selenium.runTest();
selenium.checkResults();

