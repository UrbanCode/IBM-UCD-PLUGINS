
import com.urbancode.air.CommandHelper

final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
def sharepointUrl = props['sharepointUrl']
def stsadmPath = props['stsadmPath'] ? props['stsadmPath'] : 'stsadm.exe';
def cmpFileName = props['cmpFileName'];
def ch = new CommandHelper(new File('.'));

try {
    args = [];
    args = [stsadmPath, '-o', 'import', '-url', sharepointUrl, '-filename', cmpFileName];
    ch.runCommand(args.join(' '), args);
    }

catch (e) {
    println e
    System.exit 1
}