
import com.urbancode.air.CommandHelper

final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
def stsadmPath = props['stsadmPath'] ? props['stsadmPath'] : 'stsadm.exe';
def sharepointUrl = props['sharepointUrl']
def cmpFileName = props['cmpFileName'];
def ch = new CommandHelper(new File('.'));

try 
{
    def args = [];
    args = [stsadmPath, '-o', 'export', '-url', sharepointUrl, '-filename', cmpFileName, '-versions', '2'];
    ch.runCommand(args.join(' '), args);
}
catch (e) {
    println e
    System.exit 1
}
    
    