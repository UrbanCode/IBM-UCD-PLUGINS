The "SQLPlus through control file" step takes in a control file that lists what sql files are going to be run and where. The control file allows you to set order execution and enables you to execute scripts across different oracle databases in one action. 

The format of each line of the control file is as follows:

file	connectionId	user	abort_flag

file : The name of the file containing the SQL commands to run. Should be in the same directory as the control file
connectionId : The connection ID for the oracle instance that the sql file should be run on. Each distinct connectionId should have a correspoding connectionId specified in the "ConnectionId x User to Password" field. This is how you can use the plugin to run scripts across different databases using only one control file
user : the user to execute the sql script as. This should match the a user specified in the "ConnectionId x User to Password" field.
abort_flag : Used to specify fail-fast mode for the script execution. If abort_flag is set to true and the script execution fails, the step will fail. If abort_flag is set to false and the script execution fails, the execution will note it and proceed to the next line of the control file

The whitespace between each of the arguments is a tab. In order to use the control file, you must have a tab in between each of the arguments.

Using the control.example.txt as an example, here's what a SQLPlus deployment will look like:

1) sql1.sql will be executed on the oracle.example1.com connection as user_1. If the execution fails, script will continue with the next line.
2) sql2.sql will be executed on the oracle.example2.com connection as user_2. If the execution fails, the process within UrbanCode Deploy will fail.
3) sql3.sql will be executed on the oracle.example3.com connection as user_1. If the execution fails, the process within UrbanCode Deploy will fail.
4) sql4.sql will be executed on the oracle.example4.com connection as Oracle Wallet's specified user. If the execution fails, script will continue with the next line.
Note: The string "wallet" must be specified in place of the user to authenticate with Oracle Wallet. This means that a user named "wallet" is not supported.
