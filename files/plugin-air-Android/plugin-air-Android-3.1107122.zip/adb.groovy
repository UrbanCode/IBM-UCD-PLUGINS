/**
* Licensed Materials - Property of IBM
* 5748-XX8
* (C) Copyright IBM Corp. 2013, 2014 All Rights Reserved
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
**/

import com.urbancode.air.AirPluginTool;
import com.ibm.rational.air.plugin.android.ADBCommandHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def pathToSDK = props['pathToSDK']
def additionalArgs = props['additionalArgs']
def timeout = props['timeout']

def adbHelper = new ADBCommandHelper(pathToSDK, apTool.isWindows);
adbHelper.printVersion();
adbHelper.adbCmd(additionalArgs, timeout);