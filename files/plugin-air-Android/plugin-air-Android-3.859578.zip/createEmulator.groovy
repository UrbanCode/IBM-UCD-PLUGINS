/**
* Licensed Materials - Property of IBM
* 5748-XX8
* (C) Copyright IBM Corp. 2014 All Rights Reserved
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
**/

import com.urbancode.air.AirPluginTool;
import com.ibm.rational.air.plugin.android.EmulatorHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def pathToSDK = props['pathToSDK']
def name = props['name']
def id = props['id']
def cpu = props['cpu']
boolean force = Boolean.parseBoolean(props['force'])
boolean snapshot = Boolean.parseBoolean(props['snapshot'])
def additionalArgs = props['additionalArgs']

def emulatorHelper = new EmulatorHelper(pathToSDK, apTool.isWindows);
emulatorHelper.createEmulator(name, id, cpu, force, snapshot, additionalArgs);