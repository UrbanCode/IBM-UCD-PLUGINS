/**
 * (c) Copyright IBM Corporation 2015.
 * (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
 * This is licensed under the following license.
 * The Eclipse Public 1.0 License (http://www.eclipse.org/legal/epl-v10.html)
 * U.S. Government Users Restricted Rights:  Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.plugin.AppScanSaaS.NewAirPluginTool
import com.urbancode.air.plugin.AppScanSaaS.SCXRestClient

def quoteForLog(String value) {
    if (value == null) {
        return "''"
    }
    if (value.contains(" ") || value.contains("\t") || value.contains("\"")) {
        return '"' + value.replace('"', '\\"') + '"'
    }
    return value
}

def runCommand(List command, File workingDirectory, Map extraEnvironment) {
    List<String> normalizedCommand = command.collect { arg ->
        arg == null ? "" : String.valueOf(arg)
    }

    String commandForLog = normalizedCommand.collect { quoteForLog(it) }.join(" ")
    println "[Action] Executing command: ${commandForLog}"
    if (workingDirectory != null) {
        println "[Action] Working directory: ${workingDirectory.absolutePath}"
    }

    ProcessBuilder processBuilder = new ProcessBuilder(normalizedCommand)
    if (workingDirectory != null) {
        processBuilder.directory(workingDirectory)
    }
    processBuilder.redirectErrorStream(true)

    Map<String, String> environment = processBuilder.environment()
    extraEnvironment.each { key, value ->
        environment.put(String.valueOf(key), String.valueOf(value))
    }

    Process process = processBuilder.start()
    String output = process.inputStream.getText("UTF-8")
    int exitCode = process.waitFor()

    if (output != null && !output.trim().isEmpty()) {
        println output.trim()
    }

    return [exitCode: exitCode, output: output]
}

def startBackgroundCommand(List command, File workingDirectory, Map extraEnvironment, String outputPrefix) {
    List<String> normalizedCommand = command.collect { arg ->
        arg == null ? "" : String.valueOf(arg)
    }

    String commandForLog = normalizedCommand.collect { quoteForLog(it) }.join(" ")
    println "[Action] Executing command: ${commandForLog}"
    if (workingDirectory != null) {
        println "[Action] Working directory: ${workingDirectory.absolutePath}"
    }

    ProcessBuilder processBuilder = new ProcessBuilder(normalizedCommand)
    if (workingDirectory != null) {
        processBuilder.directory(workingDirectory)
    }
    processBuilder.redirectErrorStream(true)

    Map<String, String> environment = processBuilder.environment()
    extraEnvironment.each { key, value ->
        environment.put(String.valueOf(key), String.valueOf(value))
    }

    Process process = processBuilder.start()
    Thread outputThread = new Thread({
        process.inputStream.withReader("UTF-8") { reader ->
            String line
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue
                }
                println outputPrefix + line
            }
        }
    } as Runnable)
    outputThread.setDaemon(true)
    outputThread.start()

    return process
}

def assertCommandSucceeded(Map commandResult, String errorMessage) {
    if (commandResult.exitCode != 0) {
        println "[Error] ${errorMessage}"
        System.exit(1)
    }
}

def trimTrailingSlash(String input) {
    if (input == null) {
        return null
    }

    String result = input.trim()
    while (result.endsWith("/")) {
        result = result.substring(0, result.length() - 1)
    }
    return result
}

def buildIastHost(String baseUrlApp) {
    String host = baseUrlApp?.trim()
    if (host == null || host.isEmpty()) {
        return null
    }

    if (host.startsWith("http://")) {
        host = host.substring("http://".length())
    }
    else if (host.startsWith("https://")) {
        host = host.substring("https://".length())
    }

    host = trimTrailingSlash(host)
    return "https://${host}/IAST"
}

def normalizePackageVersion(String value) {
    if (value == null) {
        return null
    }
    return value.trim()
}

def flattenMap(def input, String prefix, Map<String, Object> output) {
    if (input instanceof Map) {
        input.each { key, value ->
            String keyText = String.valueOf(key)
            String nextPrefix = prefix == null || prefix.isEmpty() ? keyText : prefix + "." + keyText
            flattenMap(value, nextPrefix, output)
        }
    }
    else {
        output.put(prefix, input)
    }

    return output
}

def extractAgentKeyFromResponse(def response) {
    if (!(response instanceof Map)) {
        return null
    }

    Map<String, Object> flattened = flattenMap(response, "", new LinkedHashMap<String, Object>())
    List<String> acceptedKeys = ["agentkey", "agentkeyvalue", "agentaccesskey", "accesskey"]

    for (Map.Entry<String, Object> entry : flattened.entrySet()) {
        String leafKey = entry.key
        int separatorIndex = leafKey.lastIndexOf('.')
        if (separatorIndex >= 0) {
            leafKey = leafKey.substring(separatorIndex + 1)
        }

        if (acceptedKeys.contains(leafKey.toLowerCase())) {
            String value = entry.value == null ? null : String.valueOf(entry.value).trim()
            if (value != null && !value.isEmpty()) {
                return value
            }
        }
    }

    return null
}

def detectPackageVersion(String downloadLink, File downloadedFile) {
    String[] candidates = [downloadLink, downloadedFile?.name]
    for (String candidate : candidates) {
        if (candidate == null) {
            continue
        }

        def matcher = (candidate =~ /(?i)com\.HCL\.AppScan\.IAST\.agent\.([0-9]+(?:\.[0-9]+)*)\.nupkg/)
        if (matcher.find()) {
            return normalizePackageVersion(matcher.group(1))
        }
    }

    return "1.16.0"
}

def ensureNupkgFile(File downloadedFile, File outputDirectory, String packageVersion) {
    String targetFileName = "com.HCL.AppScan.IAST.agent.${packageVersion}.nupkg"
    File targetFile = new File(outputDirectory, targetFileName)

    if (downloadedFile.name.equalsIgnoreCase(targetFileName)) {
        return downloadedFile
    }

    println "[Action] Normalizing downloaded agent package name to ${targetFileName}."
    targetFile.bytes = downloadedFile.bytes
    if (!targetFile.exists() || targetFile.length() == 0) {
        println "[Error] Failed to prepare normalized dotnet agent package at ${targetFile.absolutePath}."
        System.exit(1)
    }

    return targetFile
}

def maskToken(String token) {
    if (token == null || token.length() <= 8) {
        return "********"
    }
    return token.substring(0, 4) + "..." + token.substring(token.length() - 4)
}

def writeEnvironmentScript(
    File applicationRoot,
    boolean isWindows,
    String iastHost,
    String iastAccessToken)
{
    String fileName = isWindows ? "set_iast_dotnet_env.ps1" : "set_iast_dotnet_env.sh"
    File scriptFile = new File(applicationRoot, fileName)

    if (isWindows) {
        scriptFile.text = """
\$env:ASPNETCORE_HOSTINGSTARTUPASSEMBLIES=\"SecagentCore\"
\$env:IAST_HOST=\"${iastHost}\"
\$env:IAST_ACCESS_TOKEN=\"${iastAccessToken}\"
Write-Host \"IAST environment variables are set for the current PowerShell session.\"
""".trim() + "\n"
    }
    else {
        scriptFile.text = """
#!/usr/bin/env sh
export ASPNETCORE_HOSTINGSTARTUPASSEMBLIES=\"SecagentCore\"
export IAST_HOST=\"${iastHost}\"
export IAST_ACCESS_TOKEN=\"${iastAccessToken}\"
echo \"IAST environment variables are set for the current shell session.\"
""".trim() + "\n"
        scriptFile.setExecutable(true)
    }

    return scriptFile
}

final def airHelper = new NewAirPluginTool(args[0], args[1])
final Properties props = airHelper.getStepProperties()

String appId = props["applicationId"]?.trim()
String dotnetApplicationRoot = props["dotnetApplicationRoot"]?.trim()
String baseUrlApp = props["baseUrlApp"]?.trim()

if (appId == null || appId.isEmpty()) {
    println "[Error] AS360 Application ID has not been specified."
    System.exit(1)
}

if (dotnetApplicationRoot == null || dotnetApplicationRoot.isEmpty()) {
    println "[Error] Dotnet Application root has not been specified."
    System.exit(1)
}

if (baseUrlApp == null || baseUrlApp.isEmpty()) {
    println "[Error] Base AS360 URL has not been specified."
    System.exit(1)
}

println "[Pre-check] Checking Dotnet Application root at '${dotnetApplicationRoot}'."
File applicationRoot = new File(dotnetApplicationRoot)
if (!applicationRoot.exists() || !applicationRoot.isDirectory()) {
    println "[Error] Dotnet Application root '${dotnetApplicationRoot}' does not exist or is not a directory."
    System.exit(1)
}

SCXRestClient restClient = new SCXRestClient(props)

String scanName = "IAST DotNet Agent " + new Date().format("yyyyMMdd-HHmmss")
String description = "IAST scan created by Deploy IAST DotNet Agent step"
String comment = "Created by Deploy IAST DotNet Agent step"

println "[Action] Step-1: Authentication with API key is handled by SCXRestClient initialization."

println "[Action] Step-2: Creating IAST scan for appId=${appId}."
Map scanStartResult = restClient.startIastScan(
    appId,
    scanName,
    description,
    true,
    "en-US",
    true,
    false,
    comment,
    43200,
    "DotNet")

String scanId = scanStartResult.scanId
String executionId = scanStartResult.executionId
String agentAccessToken = extractAgentKeyFromResponse(scanStartResult.response)

if (agentAccessToken == null || agentAccessToken.isEmpty()) {
    println "[Error] Agent key was not found in the Create IAST scan response (expected key 'Agentkey')."
    System.exit(1)
}

airHelper.setOutputProperty("ScanId", scanId)
if (executionId != null && !executionId.trim().isEmpty()) {
    airHelper.setOutputProperty("ExecutionId", executionId)
}
airHelper.setOutputProperty("IastAccessToken", agentAccessToken)

File workDirectory = new File("iast-dotnet-agent-${scanId}")
println "[Action] Step-3: Downloading preconfigured IAST DotNet agent for scanId=${scanId}."
Map downloadResult = restClient.downloadIastAgentWithKey(scanId, workDirectory)
File downloadedAgentFile = (File) downloadResult.zipFile
String downloadLink = downloadResult.downloadLink
String packageVersion = detectPackageVersion(downloadLink, downloadedAgentFile)
File nupkgFile = ensureNupkgFile(downloadedAgentFile, workDirectory, packageVersion)

if (downloadLink != null && !downloadLink.trim().isEmpty()) {
    println "[OK] IAST agent download link: ${downloadLink}."
}
println "[OK] IAST DotNet agent package is available at ${nupkgFile.absolutePath}."
println "[OK] IAST DotNet agent package version: ${packageVersion}."

airHelper.setOutputProperty("IastDotnetPackageVersion", packageVersion)
airHelper.setOutputProperty("IastDotnetPackageFile", nupkgFile.absolutePath)

println "[Action] Step-4: Deploying IAST DotNet agent package to application root '${applicationRoot.absolutePath}'."
println "[Action] Verifying dotnet CLI availability."
Map dotnetVersionResult = runCommand(["dotnet", "--version"], applicationRoot, [:])
assertCommandSucceeded(dotnetVersionResult, "dotnet CLI is not available on this agent machine.")

String localSourceName = "LocalDownloads"
String localSourcePath = workDirectory.absolutePath

println "[Action] Adding temporary local NuGet source '${localSourceName}' from '${localSourcePath}'."
Map addSourceResult = runCommand(
    ["dotnet", "nuget", "add", "source", localSourcePath, "--name", localSourceName],
    applicationRoot,
    [:])
assertCommandSucceeded(addSourceResult, "Failed to add local nuget source '${localSourceName}'.")

try {
    println "[Action] Installing package 'com.HCL.AppScan.IAST.agent' version '${packageVersion}'."
    Map addPackageResult = runCommand(
        ["dotnet", "add", "package", "com.HCL.AppScan.IAST.agent", "-v", packageVersion],
        applicationRoot,
        [:])
    assertCommandSucceeded(addPackageResult, "Failed to install com.HCL.AppScan.IAST.agent package version ${packageVersion}.")
}
finally {
    println "[Action] Removing temporary local NuGet source '${localSourceName}'."
    Map removeSourceResult = runCommand(
        ["dotnet", "nuget", "remove", "source", localSourceName],
        applicationRoot,
        [:])
    if (removeSourceResult.exitCode != 0) {
        println "[Warning] Could not remove temporary nuget source '${localSourceName}'. Remove it manually if needed."
    }
}

String iastHost = buildIastHost(baseUrlApp)
if (iastHost == null || iastHost.isEmpty()) {
    println "[Error] Failed to build IAST_HOST from Base AS360 URL '${baseUrlApp}'."
    System.exit(1)
}

println "[Action] Preparing IAST environment values for application startup."

Map<String, String> dotnetRunEnvironment = [
    ASPNETCORE_HOSTINGSTARTUPASSEMBLIES: "SecagentCore",
    IAST_HOST: iastHost,
    IAST_ACCESS_TOKEN: agentAccessToken
]

File environmentScript = writeEnvironmentScript(applicationRoot, airHelper.isWindows, iastHost, agentAccessToken)
println "[OK] Environment setup script generated at ${environmentScript.absolutePath}."
println "[OK] ASPNETCORE_HOSTINGSTARTUPASSEMBLIES is set to 'SecagentCore'."
println "[OK] IAST_HOST is set to '${iastHost}'."
println "[OK] IAST_ACCESS_TOKEN has been prepared from the scan response."

airHelper.setOutputProperty("IastHost", iastHost)
airHelper.setOutputProperty("IastEnvironmentScript", environmentScript.absolutePath)

println "[Action] Step-5: Starting dotnet application and exiting step."
println "[Action] Starting dotnet application using 'dotnet run'."
startBackgroundCommand(
    ["dotnet", "run"],
    applicationRoot,
    dotnetRunEnvironment,
    "[dotnet run] ")
println "[OK] dotnet run was started successfully."

airHelper.storeOutputProperties()
println "[OK] Deploy IAST DotNet Agent step finished."
