/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.docker.DockerHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])
def command = this.args[2]
def props = apTool.getStepProperties()
def helper = new DockerHelper(apTool)

helper.runDockerCommand(command, props)

apTool.storeOutputProperties()
