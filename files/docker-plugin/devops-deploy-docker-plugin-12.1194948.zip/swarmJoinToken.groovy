/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.docker.DockerHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()
def helper = new DockerHelper(apTool)
def swarmManagerAddress

apTool.setOutputProperty("swarmToken", helper.getSwarmToken(props))
swarmManagerAddress = helper.getSwarmManagerAddr()
if (swarmManagerAddress) {
    apTool.setOutputProperty("swarmManagerAddress", swarmManagerAddress)
}
apTool.storeOutputProperties()
