/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;

final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(args[0], args[1]);

final def props = apTool.getStepProperties();

final def errorRegexs = ["(?i)Error at line",
                                "(?i)invalid username/password; logon denied",
                                "(?i)the account is locked",
                                "ERROR:"];

def mode = props['mode'];
if (mode.equalsIgnoreCase("deploy")) {
    mode = "deploy";
}
else if (mode.equalsIgnoreCase("check")) {
    mode = "check";
}
else {
    System.println("Mode must either be deploy or check.");
    System.exit(1);
}


println "Mode : " + mode;
def sqlPlusExecutable = props['sqlPlusExecutable'];
def oracleHome = props['oracleHome']
println "Oracle Home: ${oracleHome?:''}"


println "Executable : " + sqlPlusExecutable;
def cntrlFileIncludes = props['controlFileIncludes'].split('\n');
def cntrlFileExcludes = props['controlFileExcludes'].split('\n');

def connectionIdUserToPasswordList = props['connectionIdUserToPassword'].split('\n');

def connectionIdToUserToPasswordMap = [:];
connectionIdUserToPasswordList.each { it ->
    def parts = it.split("@",2);
    if (parts.length != 2) {
        System.out.println("Invalid User x Connection to password entry : " + it);
        System.out.println("Expected format is username@connectionId=Password.");
        System.exit(1);
    }
    else {
        def username = parts[0];
        parts = parts[1].split("=",2);
        if (parts.length != 2) {
            System.out.println("Invalid User x Connection to password entry : " + it);
            System.out.println("Expected format is username@connectionId=Password.");
            System.exit(1);
        }
        else {
            def connectionId = parts[0];
            def password = parts[1];
            def curUserPassMap = connectionIdToUserToPasswordMap[connectionId];
            if (curUserPassMap == null) {
                curUserPassMap = [:];
            }
            curUserPassMap[username] = password;
            connectionIdToUserToPasswordMap[connectionId]=curUserPassMap;
        }
    }
}

println connectionIdToUserToPasswordMap;
println "Control File Includes : " + cntrlFileIncludes.join(' ');
println "Control File Excludes : " + cntrlFileExcludes.join(' ');

def cntrlFile = [];
def ant = new AntBuilder();

def cntrlFiles = ant.fileset(dir:".") {
    for (include in cntrlFileIncludes) {
        ant.include(name:include);
    }
    for (exclude in cntrlFileExcludes) {
        ant.exclude(name:exclude);
    }
}

println("Control Files Found : ");
cntrlFiles.each { cntrFile ->
    println cntrFile;
}

def parseLine = { line, lineNumber ->
    def parts = line.split("\t");
    if (parts.length != 4) {
        System.out.println("Illegal Cntrl File. Line ${lineNumber} does not match expected: scriptName\\tconnectionId\\tuser\\tABORT_FLAG");
        System.out.println(line);
        System.exit(1);
    }
    def atts = [:];
    atts['script'] = parts[0];
    atts['connId'] = parts[1];
    atts['user'] = parts[2];
    atts['abort'] = Boolean.valueOf(parts[3]);
    return atts;
}

def getPassword = { connId, user ->
    def password;
    def userToPassword = connectionIdToUserToPasswordMap[connId];
    if (userToPassword == null) {
        System.out.println("No passwords configured for connId ${connId}");
        System.exit(1);
    }
    else {
        password = userToPassword[user];
        if (password == null) {
            System.out.println("No passwords configured for connId ${connId} and user ${user}");
            System.exit(1);
        }
    }
    return password;
}

def runSQLPlusScript = { user, password, connectionID, existingFileName, workingDirectory ->
    def result = 0;
    def ch = new CommandHelper(workingDirectory);
    if (oracleHome) {
        ch.addEnvironmentVariable("ORACLE_HOME", oracleHome);
    }
    ch.ignoreExitValue(true);
    System.out.println("-----------------------------------------------------------------");
    def cmdArgs = [sqlPlusExecutable, "${user}/${password}@${connectionID}", '@'+existingFileName];
    def errorFound = false;
    def exitValue = ch.runCommand("Running SQLPlus Command", cmdArgs) { proc ->
        proc.withWriter { writer ->
            writer.write("exit\n");
        }
        BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.in));
        BufferedReader errInput = new BufferedReader(new InputStreamReader(proc.err));
        def th1 = Thread.start {
            def line
            while ((line = stdInput.readLine()) != null) {
                println line
                errorRegexs.each { regex ->
                    if (line =~ regex) {
                        errorFound = true;
                    }
                }
            }
        }
        def th2 = Thread.start {
            def line
            while ((line = errInput.readLine()) != null) {
                println line
                errorRegexs.each { regex ->
                    if (line =~ regex) {
                        errorFound = true;
                    }
                }
            }
        }
        th1.join();
        th2.join();
    }

    if (exitValue != 0) {
        result = exitValue;
    }
    else if (errorFound) {
        result = 1;
    }

    return result;
}

def connectionAlreadyTested = { connId, user, testedConns ->
    def result = false;
    def userList = testedConns[connId];
    if (userList != null && userList.contains(user)) {
        result = true;
    }
    return result;
}

def addTestedConnection = { connId, user, testedConns ->
    def userList = testedConns['connId'];
    if (userList == null) {
        userList = [];
    }
    if (!userList.contains(user)) {
        userList.add(user);
    }
    testedConns[connId] = userList;
}

def testConnection = { connId, user, password, testedConns ->
   if (!connectionAlreadyTested(connId, user, testedConns)) {
       System.out.println("Testing connection to ${connId} with user ${user}");
       def tempSQLFile = File.createTempFile("select",".sql");
       tempSQLFile.delete();
       tempSQLFile = new File(workDir, tempSQLFile.name);
       tempSQLFile << "select 1\n";
       def exit = runSQLPlusScript(user, password, connId, tempSQLFile.name, workDir);
       addTestedConnection(connId, user, testedConns);
       tempSQLFile.delete();
       if (exit != 0) {
           System.out.println("Failure connecting to ${connId} as ${user}!");
           System.exit(exit);
       }
   }
}

def verifyControlFile = { controlFile, testedConns ->
    System.out.println();
    System.out.println();
    System.out.println();
    System.out.println("************************************************************************************************");
    System.out.println("Verifing control file " + controlFile.absolutePath);
    def curWorkDir = controlFile.parentFile;
    def lineNumber = 1;
    controlFile.eachLine { line ->
        def atts = parseLine(line, lineNumber);
        def script = atts['script'];
        def connId = atts['connId'];
        def user = atts['user'];
        File scriptFile = new File(curWorkDir, script);
        if (!scriptFile.isFile()) {
            System.out.println("Script " + script + " does not exist in expected location : " + scriptFile.absolutePath);
            System.out.println("As declared by control file " + controlFile.absolutePath + " on line " + lineNumber);
            System.exit(1);
        }
        else {
            def password = getPassword(connId, user);
            testConnection(connId, user, password, testedConns);
        }
        lineNumber ++;
    }
}

def executeCntrFile = { controlFile ->
    System.out.println();
    System.out.println();
    System.out.println();
    System.out.println("************************************************************************************************");
    System.out.println("Executing Control File " + controlFile.absolutePath);
    def curWorkDir = controlFile.parentFile;
    def lineNumber = 1;
    controlFile.eachLine { line ->
        def atts = parseLine(line, lineNumber);
        def script = atts['script'];
        def connId = atts['connId'];
        def user = atts['user'];
        def abort = atts['abort'];
        def password = getPassword(connId, user);
        File scriptFile = new File(curWorkDir, script);
        def exit = runSQLPlusScript(user, password, connId, scriptFile.name, scriptFile.parentFile);
        if (exit != 0) {
            System.out.println("Failure executing script " + script + " defined in control file " + controlFile.name + " at line:");
            System.out.println(lineNumber + " " + line);
            if (abort) {
                System.exit(exit);
            }
            else {
                System.out.println("Abort set to false, ignoring and continuing...");
            }
        }
        lineNumber ++;
    }
}

def testedConnections = [:];
cntrlFiles.each { cntrFile ->
    verifyControlFile(cntrFile.file, testedConnections);
}

if (mode == "deploy") {
    cntrlFiles.each { cntrFile ->
        executeCntrFile(cntrFile.file);
    }
}


System.exit(0);
