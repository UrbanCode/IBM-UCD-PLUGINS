import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*


final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String serverUrl = props['tfsUrl']
final String serverUserName = props['tfsUsername']
final String serverPassword = props['tfsPassword']
final String tfsVersion = props['tfsVersion']

final String workItemId = props['workItemId']?:''
final String state = props['status']
final String reason = props['reason']

ChangeDefectStatus cds = new ChangeDefectStatus()
cds.serverUrl = serverUrl
cds.serverUserName = serverUserName
cds.serverPassword = serverPassword
cds.tfsVersion = tfsVersion

cds.workItemId = workItemId
cds.state = state
cds.reason = reason

cds.execute()