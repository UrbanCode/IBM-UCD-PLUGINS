#!/usr/bin/env groovy
/*
- Licensed Materials - Property of IBM Corp.
- IBM UrbanCode Deploy
- (c) Copyright IBM Corporation 2014. All Rights Reserved.
-
- U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
- GSA ADP Schedule Contract with IBM Corp.
*/
import java.io.FileNotFoundException
import java.io.IOException
import com.ibm.urbancode.deploy.wsrr.WSDLLoader

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}


def csvFile = props['csvfile'];
println "csvFile: " + csvFile;

def wsdlPath = props['wsdlpath'];
println "wsdlPath: " + wsdlPath;

def hostName = props['hostname'];
println "hostName : " + hostName;

def port = props['port'];
println "port: " + port;

def user = props['user'];
println "user : " + user;

def password = props['password'];
println "password: " + password;


try {
	csvFile = new File(csvFile);
	wsdlPath = new File(wsdlPath);
	def wsdlLoader = new WSDLLoader(csvFile, wsdlPath, hostName, port, user, password);
	wsdlLoader.loadServices();
} catch (NumberFormatException e) {
	e.printStackTrace();
} catch (FileNotFoundException e) {
	e.printStackTrace();
} catch (IOException e) {
	e.printStackTrace();
} catch(Exception e){
	e.printStackTrace();
}
