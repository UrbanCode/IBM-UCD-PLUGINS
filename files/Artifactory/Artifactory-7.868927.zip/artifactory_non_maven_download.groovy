/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Deploy
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import groovy.json.JsonSlurper

import javax.servlet.http.*

import org.apache.http.HttpResponse
import org.apache.http.HttpStatus
import org.apache.http.client.methods.HttpGet
import org.apache.http.util.EntityUtils

import com.urbancode.air.plugin.artifactory.ArtifactoryHelper
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.util.IO
import com.urbancode.air.AirPluginTool

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

def isEmpty(value) {
    return value == null || value.equals("")
}

final def workDir = new File('.').canonicalFile

final def REPO_PATH_SEPARATOR = "/";

def repoName = props['repositoryName']
def artifacts = props['artifacts'].split('\n');
def username = props['username'];
def password = props['password'];
def apiKey = props['apiKey'].trim()
def checkHash = props['checkHash'];
def repoUrl = props['artifactoryUrl'];
while (repoUrl.endsWith(REPO_PATH_SEPARATOR)) {
    repoUrl = repoUrl.substring(0, repoUrl.length() - 1);
}

def exitVal = 0;
ArtifactoryHelper aHelper = new ArtifactoryHelper(username, password, apiKey)

def searchArtifacts = { searchUrl ->
    println ("[Action] Searching for artifacts at: ${searchUrl}")
    def response = aHelper.executeHttpRequest(searchUrl, new HttpGet(), null)
    if (!response) {
        println ('[Error] Could not find artifacts')
        return []
    }
    int status = response.getStatusLine().getStatusCode();
    if (status == HttpStatus.SC_OK) {
        def artifactUris = []
        def jsonString = EntityUtils.toString(response.getEntity());
        def slurper = new JsonSlurper();
        def children = slurper.parseText(jsonString).children;
        for (child in children) {
            def isFolder = child.folder.toString();
            if (isFolder.equals("false")) {
                artifactUris.add(child.uri)
            }
        }
        if (artifactUris.size() > 0) {
            println ("[Ok] Found ${artifactUris.size()} artifacts")
        }
        else {
            println ("[Ok] Did not find any child artifacts to download")
        }
        return artifactUris;
    }
    else {
        throw new Exception("[Error] Exception searching: " + searchUrl + "\nErrorCode : " + status.toString());
    }
}

try {
    artifacts.each { artifact ->
        String[] attrs = artifact.split('/');
        String version = attrs[attrs.length - 1];
        String groupId = attrs[0];
        String artifactId = "";
        for (int i = 1; i <= attrs.length - 2; ++i) {
            artifactId = artifactId + attrs[i] + REPO_PATH_SEPARATOR;
        }
        String searchUrl = repoUrl + REPO_PATH_SEPARATOR + 'api/storage/' +
                repoName + REPO_PATH_SEPARATOR + groupId + REPO_PATH_SEPARATOR + artifactId + version;
        println ("[Action] Searching for artifacts at ${searchUrl}")
        def artifactUris = searchArtifacts(searchUrl);
        for (artifactUri in artifactUris) {
            File artifactFile = aHelper.downloadFileFromRepo(searchUrl + artifactUri, checkHash.toString());
            if (artifactFile == null) {
                throw new Exception("[Error] Failed to download artifact : " + artifact);
            }

            //copy the temp file to this directory with the file name
            String[] currFile = artifactUri.split(REPO_PATH_SEPARATOR);
            def filename = currFile[currFile.length - 1];
            File finalFile = new File(workDir, filename);
            println "[Action] Moving downloaded artifact to : " + finalFile.getAbsolutePath() + "\n";
            try {
                IO.move(artifactFile, finalFile);
            }
            catch (IOException ex) {
                println ("[Error] Could not move downloaded artifact: ${ex.getMessage()}")
            }
            artifactFile.delete();
        }
    }
}
catch (Exception e) {
    e.printStackTrace();
    exitVal=1;
}
System.exit(exitVal);
