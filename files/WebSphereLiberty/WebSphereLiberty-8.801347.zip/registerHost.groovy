/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();

def wlpHome = props['wlpHome'];
def hostToRegister = props['hostToRegister'];
def controllerHostName = props['controllerHostName'];
def controllerPort = props['controllerPort'];
def adminUser = props['adminUser'];
def adminPassword = props['adminPassword'];
def rpcUser = props['rpcUser'];
def rpcUserPassword = props['rpcUserPassword'];
def sshPrivateKey = props['sshPrivateKey'];
def sshPrivateKeyPassword = props['sshPrivateKeyPassword'];
def hostJavaHome = props['hostJavaHome'];
def hostReadPath = props['hostReadPath'];
def hostWritePath = props['hostWritePath'];
def optionalArgs = props['optionalArgs'];

def wslh = new WebSphereLibertyHelper(wlpHome);
wslh.registerHost(hostToRegister, controllerHostName, controllerPort, adminUser, adminPassword, rpcUser, rpcUserPassword, sshPrivateKey, sshPrivateKeyPassword, hostJavaHome, hostReadPath, hostWritePath, optionalArgs, apTool.isWindows);


