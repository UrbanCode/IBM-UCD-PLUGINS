import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyJMXHelper;
import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();
def userName = props['userName'];
def userPassword = props['userPassword'];
def appName = props['appName'];
def waitTimeout = props['waitTimeout'];
def server = props['server'];
def httpsPort = props['httpsPort'];
def trustStorePath = props['trustStorePath'];
def trustStorePassword = props['trustStorePassword'];

def jmxHelper = new WebSphereLibertyJMXHelper(userName, userPassword, server, httpsPort, trustStorePath, trustStorePassword);
jmxHelper.startApp(appName);
