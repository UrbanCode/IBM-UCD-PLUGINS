import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyServerXmlHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();

def wlpHome = props['wlpHome'];
def serverName = props['server'];
def name = props['name'];

def wslh = new WebSphereLibertyServerXmlHelper(wlpHome, serverName);
wslh.uninstallApplicationFromXml(name);
