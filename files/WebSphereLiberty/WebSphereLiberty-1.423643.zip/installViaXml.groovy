import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyServerXmlHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();

def source = props['source'];
def wlpHome = props['wlpHome'];
def serverName = props['server'];
def type = props['type'];
def context = props['context'];
def autoStart = Boolean.valueOf(props['autoStart']);
def name = props['name'];

def wslh = new WebSphereLibertyServerXmlHelper(wlpHome, serverName);
wslh.installOrUpdateApplicationIntoXml(source, name, type, context, autoStart);
