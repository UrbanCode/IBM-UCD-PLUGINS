import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyJMXHelper;
import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();
def userName = props['userName'];
def userPassword = props['userPassword'];
def appName = props['appName'];
def waitTimeout = props['waitTimeout'];
def server = props['server'];
def httpsPort = props['httpsPort'];
def trustStorePath = props['trustStorePath'];
def trustStorePassword = props['trustStorePassword'];

def state = props['state'];
if (this.args.size() >= 3) {
    state = this.args[2];
}

try {
    waitTimeout = Long.valueOf(waitTimeout);
}
catch (NumberFormatException e) {
    System.out.println("Wait Timeout must be a long!");
    System.exit(1);
}


def jmxHelper = new WebSphereLibertyJMXHelper(userName, userPassword, server, httpsPort, trustStorePath, trustStorePassword);
jmxHelper.waitForApplication(appName, state, waitTimeout);
