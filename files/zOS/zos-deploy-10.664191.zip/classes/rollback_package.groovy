import com.ibm.urbancode.zos.common.DeploymentConstants;
import com.ibm.urbancode.zos.common.DeploymentHelper;

/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

try{
	final def workDir = new File('.').canonicalFile
	final def props = new Properties();
	final def inputPropsFile = new File(args[0]);
	try {
		inputPropsStream = new FileInputStream(inputPropsFile);
		props.load(inputPropsStream);
	}
	catch (IOException e) {
		throw new RuntimeException(e);
	}

	final def componentName 	= DeploymentHelper.getStringInput(props['componentName']);
	final def versionName 		= DeploymentHelper.getStringInput(props['versionName']);
	final def deployBasePath 	= DeploymentHelper.getStringInput(props['deployBasePath']);
	def toolKitHome 		= DeploymentHelper.getStringInput(System.getenv().get("BUZ_TOOLKIT_HOME"));
	if (!toolKitHome) {//try to compatible with application build on old plug-in(before v5)
		toolKitHome = DeploymentHelper.getStringInput(props['ucdToolKitHome']);
	}
	
	final def checkAccess 		= DeploymentHelper.getBooleanInput(props['checkAccess']);

	final def zosScriptPath 		= DeploymentHelper.getPath4ExecScriptInToolkit(toolKitHome , DeploymentConstants.ZOS_TOOLKIT_ISPF_SCRIPT_NAME);
	final def checkAccessExePath	= DeploymentHelper.getPath4ExecScriptInToolkit(toolKitHome , DeploymentConstants.CHECK_ACCESS_EXE);

	DeploymentHelper.validateDirectoryExist(deployBasePath, "Deploy Base Path ${deployBasePath} does not exist!");

	final def deployBasePathForVersion 	= DeploymentHelper.getVersionPathInDeployBasePath(deployBasePath, componentName, versionName);
	final def rollbackMfFilePath 		= DeploymentHelper.getFilePathinDeployBasePath(deployBasePath, componentName, versionName, DeploymentConstants.ROLLBACK_MANIFEST_FILE_NAME);
	final def backupZipFilePath 		= DeploymentHelper.getFilePathinDeployBasePath(deployBasePath, componentName, versionName, DeploymentConstants.DEPLOY_BACKUP_FILE_NAME);
	final def containerFilePath 		= DeploymentHelper.getFilePathinDeployBasePath(deployBasePath, componentName, versionName, DeploymentConstants.CONTAINER_MAPPER_FILE_NAME);
	final def dsListFilePath 			= DeploymentHelper.getFilePathinDeployBasePath(deployBasePath, componentName, versionName, DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME);

	//Do some validation
	DeploymentHelper.validateFileExist(zosScriptPath, "Can not find the ispf gateway script: ${zosScriptPath}. Please make sure z/OS Deploy Toolkit is installed and z/OS Toolkit Home is set to the correct location.");
	def errorInfo = """ does not exist or is not a file. 
Error rolling back because one of the files needed for rollback is not found. 
Please make sure you have deployed the version successfully and haven't rolled back it already."""
	DeploymentHelper.validateFileExist(rollbackMfFilePath, rollbackMfFilePath + errorInfo);
	DeploymentHelper.validateFileExist(containerFilePath, containerFilePath + errorInfo);
	DeploymentHelper.validateFileExist(backupZipFilePath, backupZipFilePath + errorInfo);

	def dsListFileExist = true;
	if( checkAccess ){
		if( !DeploymentHelper.fileExists(dsListFilePath) ){
			dsListFileExist = false;
			println "Warning:The target dataset list file ${dsListFilePath} is not found, make sure you have checked the 'Check Access' option during the deployment stage,the check access was skipped."
			//		throwRollbackFileNotFoundException(dsListFilePath);
		}
	}

	final def wdPath = workDir.canonicalPath;
	final def currentVersionWorkingDir 	= DeploymentHelper.getVersionDirPathInWorkingDir(wdPath,versionName);
	final def toRollbackMfFilePath 		= DeploymentHelper.getFilePathInWorkingDir(wdPath, versionName, DeploymentConstants.ROLLBACK_MANIFEST_FILE_NAME);
	final def toBackupZipFilePath 		= DeploymentHelper.getFilePathInWorkingDir(wdPath, versionName, DeploymentConstants.DEPLOY_BACKUP_FILE_NAME);
	final def toContainerFilePath 		= DeploymentHelper.getFilePathInWorkingDir(wdPath, versionName, DeploymentConstants.CONTAINER_MAPPER_FILE_NAME);
	final def toDsListFilePath 			= DeploymentHelper.getFilePathInWorkingDir(wdPath, versionName, DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME);

	//Do some clean work before copying files
	DeploymentHelper.cleanWorkDir(currentVersionWorkingDir);

	//Copy files need by rollback
	def antCopy = new AntBuilder();
	try {
		println "Copy back up into working directory!"
		antCopy.copy(verbose: "true",file:"$rollbackMfFilePath", tofile:"$toRollbackMfFilePath",overwrite: "true");
		antCopy.copy(verbose: "true",file:"$containerFilePath", tofile:"$toContainerFilePath",overwrite: "true");
		antCopy.copy(verbose: "true",file:"$backupZipFilePath", tofile:"$toBackupZipFilePath",overwrite: "true");

		if(checkAccess && dsListFileExist){
			antCopy.copy(verbose: "true",file:"$dsListFilePath", tofile:"$toDsListFilePath",overwrite: "true");
		}
	}
	catch (Exception e) {
		println "Error getting backup data.${e.message}";
		System.exit(1);
	}

	if(checkAccess && dsListFileExist){
		println "Check access for Roll back action!";
		DeploymentHelper.callCheckAccess(checkAccessExePath, toDsListFilePath, "output");
	}

	//Call the ant task rollback in deploy.xml
	def entryAntScriptDir = DeploymentHelper.getAntScriptFolderPath();

	def antRollBack = new AntBuilder();
	//Set those properties for the ant script
	antRollBack.getProject().setProperty("deploy.rootPath", deployBasePath);
	antRollBack.getProject().setProperty("deploy.componentName", componentName);
	antRollBack.getProject().setProperty("deploy.versionName", versionName);
	antRollBack.getProject().setProperty("deploy.workDirectory", currentVersionWorkingDir);
	antRollBack.getProject().setProperty("team.deploy.zos.script", zosScriptPath);
	antRollBack.getProject().setProperty("team.deploy.zos.timestamp", new Date().getTime().toString());

	try{
		antRollBack.ant(antfile:DeploymentConstants.ENTRY_ANT_SCRIPT, target:DeploymentConstants.ENTRY_ANT_SCRIPT_TASK_ROLLBACK, dir:entryAntScriptDir);
	}
	catch(Exception e){
		println "Error rollback package: ${e.message}";
		System.exit(1);
	}
	final def delBackUpFiles = DeploymentHelper.getBooleanInput(props['delBackUpFiles']);
	if( delBackUpFiles ){
		println "Delete those back up files on request!"
		DeploymentHelper.cleanBackUpData(deployBasePathForVersion);
	}

	//Clear the working directory to avoid dirty data
	//Just delete those files we created
	DeploymentHelper.cleanWorkDir(currentVersionWorkingDir);
} catch (Exception e) {
	println "${e.message}";
	e.printStackTrace();
	System.exit(1);
}

System.exit(0);