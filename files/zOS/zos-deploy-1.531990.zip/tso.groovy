/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def tsoCommand = props['tsoCommand']?.trim();
final def ispfGatewayPath = props['ispfGatewayPath']?.trim();
final def reuseSession = Boolean.valueOf(props['reuseSession']);
final def showLog = Boolean.valueOf(props['showLog']);
final def serviceType = props['serviceType']?.trim();
final def ispProf = props['ispProf']?.trim();
final def loopType = props['loopType']?.trim();  //NONE, PDS, Member
final def deployType = props['deployType']?.trim(); //* for all
final def deployBasePath = props['deployBasePath']?.trim();
final def componentName = props['componentName']?.trim();
final def versionName = props['versionName']?.trim();;

try{

	def tsoHelper = new TSOHelper()
	tsoHelper.ispfGatewayPath = ispfGatewayPath
	tsoHelper.reuseSession = reuseSession
	tsoHelper.serviceType = serviceType
	tsoHelper.ispProf = ispProf
//	tsoHelper.debug=true
	
	if(loopType == "NONE"){
		//run single command
		runTSOCommand(tsoCommand, tsoHelper, showLog)
	}else if(loopType == "PDS" || loopType == "Member"){
		//iterate for each deployed PDS or member with deployType equals ...
		
		if(deployBasePath == null || deployBasePath.trim().length()==0){
			throw new Exception("Deploy Base Path must be set to run commands for deployed data sets");
		}

		//the deploy report file
		def reportXMLPath = "${deployBasePath}/deploy/${componentName}/${versionName}/rollbackManifest.xml"

		def file = new File(reportXMLPath)
		if(!file.exists()){
			throw new Exception("Deploy records not found, please make sure the version has been successfully deployed using a Deploy Package plug-in step")
		}
		
		def manifest = new XmlParser().parse(reportXMLPath)
		def containers = manifest.'**'.findAll { it.name() == 'container' }
		containers.each{
			dataset = it.attribute("name").trim()
			dsDeployType = it.attribute("deployType")
			if(loopType == "PDS"){
				if(dsDeployType == deployType || deployType == "*"){
					Map vars = [dataset: dataset, member: "", deployType: dsDeployType]
					runTSOCommand(envCommand(tsoCommand, vars), tsoHelper, showLog)
				}
			}else if(loopType == "Member"){
				it.resource.each{
					member = it.attribute("name").trim()
					resDeployType = it.attribute("deployType");
					if(resDeployType == null || resDeployType.trim().length()==0){
						//If deployType is not set on member, inherit from PDS 
						resDeployType = dsDeployType
					}
					if(resDeployType == deployType || deployType == "*"){
						Map vars = [dataset: dataset, member: member, deployType: resDeployType]
						runTSOCommand(envCommand(tsoCommand, vars), tsoHelper, showLog)
					}
				}//end resource.each
			}
		}//end container.each
	}

}
catch (Exception e) {
    println "Error executing TSO/ISPF command: ${e.message}";
	e.printStackTrace();
    System.exit(1);
}

def envCommand(String s, Map vars) { 
	Binding bind = new Binding(vars)
	GroovyShell gs = new GroovyShell(bind) 
	return gs.evaluate("\"\"\"${s}\"\"\"") 
} 			

def runTSOCommand(tsoCommand, TSOHelper tsoHelper, boolean showLog){


	println('===============================')
	println (tsoHelper.serviceType + " command: ")
	println (tsoCommand);
	
	exitValue = tsoHelper.runCommand(tsoCommand)
	if( exitValue == 0){
		println('===============================')
		println("Command output: ")

		if(tsoHelper.serviceType == "ISPF"){
			print("Return Code: ")			
			println(tsoHelper.returnCode)
		}

		println(tsoHelper.outputText)
	
		if(showLog){
			println('===============================')
			println("ISPF Gateway operations log")
			println(tsoHelper.operationsLog)
		}
	}
	println('===============================')
	println("Command exit code: ${exitValue}")
	println("")
}

System.exit(0);

