/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def packageFileName = "package.zip";
final def packageMenifestFileName = "packageManifest.xml";
final def componentName = props['componentName']?.trim();
final def versionName = props['versionName']?.trim();
final def fromFtpDir = props['basePath']?.trim() + File.separator + componentName + File.separator + versionName;
final def hostName = props['hostName']?.trim();
final def userid = props['userid']?.trim();
final def password = props['password']?.trim();

if(!hostName){
	throw new IllegalArgumentException("Host name should not be empty");
}

def directoryOffset = props['directoryOffset'];
def toBaseDirectory = workDir;
if (directoryOffset) {
	toBaseDirectory = new File(workDir, directoryOffset).canonicalFile;
}
final def toDir = toBaseDirectory.canonicalPath + File.separator + versionName;
def packageFilePath = toDir + File.separator + packageFileName;
def packageManifestFilePath = toDir + File.separator + packageMenifestFileName;

def oldPackageFile = new File(packageFilePath);
if(oldPackageFile.exists() && oldPackageFile.isFile()){
	oldPackageFile.delete();
}
def oldPackageManifestFile = new File(packageManifestFilePath);
if(oldPackageManifestFile.exists() && oldPackageManifestFile.isFile()){
	oldPackageManifestFile.delete();
}

println "FTP Host name is $hostName";

def ant = new AntBuilder();
try {
	ant.ftp( server:"$hostName",
		userid:"$userid",
		password:"$password",
		passive:"yes",
		verbose:"true",
		action:"get",
		remotedir:"$fromFtpDir",
		binary:"yes" ) {
			fileset( dir:"$toDir" ) {
				include( name:"$packageFileName" );
				include( name:"$packageMenifestFileName" );
			}
		}
}
catch (Exception e) {
    println "Error getting package: ${e.message}";
    System.exit(1);
}

def packageFile = new File(packageFilePath);
if(!packageFile.exists() || !packageFile.isFile()){
	throw new IOException("Error getting package.zip:${packageFilePath} does not exist in the repository");
}

def packageManifestFile = new File(packageManifestFilePath);
if(!packageManifestFile.exists() || !packageManifestFile.isFile()){
	throw new IOException("Error getting packageManifest.xml:${packageManifestFilePath} does not exist in the repository");
}

System.exit(0);