/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def packageFileName = "package.zip"
final def packageMenifestFileName = "packageManifest.xml"

final def componentName = props['componentName']?.trim();
final def fromDir = props['basePath']?.trim() + File.separator + componentName;
final def versionName = props['versionName']?.trim();;
def directoryOffset = props['directoryOffset'];

if(!fromDir || fromDir.length() < 1){
	throw new IllegalArgumentException("Repository path should not be empty");
}
def fromDirFile = new File(fromDir); 
if(fromDirFile.isFile()){
	throw new IllegalArgumentException("Repository path should not be a file");
}

def toBaseDirectory = workDir;
if (directoryOffset) {
	toBaseDirectory = new File(workDir, directoryOffset).canonicalFile;
}
final def toDir = toBaseDirectory.canonicalPath;

final def pkgFromFile = fromDir + File.separator + versionName + File.separator + packageFileName;
final def pkgToFile = toDir + File.separator + versionName + File.separator + packageFileName;

final def pkgMenifestFromFile = fromDir + File.separator + versionName + File.separator + packageMenifestFileName;
final def pkgMenifestToFile = toDir + File.separator + versionName + File.separator + packageMenifestFileName;

def ant = new AntBuilder();
println "Start to copy files";
try {
	ant.copy(verbose: "true",file:"$pkgFromFile", tofile:"$pkgToFile",overwrite: "true");
	ant.copy(verbose: "true",file:"$pkgMenifestFromFile", tofile:"$pkgMenifestToFile",overwrite: "true");
}
catch (Exception e) {
    println "Error copying package: ${e.message}";
    System.exit(1);
}

System.exit(0);

