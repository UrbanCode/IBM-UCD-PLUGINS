/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.ibm.jzos.ZFile
import com.ibm.jzos.ZFileException

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
	inputPropsStream = new FileInputStream(inputPropsFile);
	props.load(inputPropsStream);
}
catch (IOException e) {
	throw new RuntimeException(e);
}

final def src2TargetDelimeter = ",";
final def src2CurrSysTargetPairDelimeter = System.getProperty("line.separator");
final def src2TargetPairDelimeter = "\n";
final def defaultContainerMapperFileName = "containerMapper.xml";
final def defaultDSListFileName4backUp = "dataSetListFile4BackUp";
final def defaultDSListFile = "dataSetListFile";
final def dataSetListInputLeader = "INPUT";
final def dataSetListOutPutLeader = "OUTPUT";
final def checkAccessExeName = "checkaccess";
final def zosScriptName = "startispf.sh";
final def toolkitExeFolderName = "bin";
final def packageFileName = "package.zip"
final def packageManifestFileName = "packageManifest.xml";
final def rollbackManifestFileName = "rollbackManifest.xml";
final def deployDeltaFileName = "deltaDeployed.xml";
final def backUpFileName = "backup.zip";


final def componentName = props['componentName']?.trim();
final def versionName = props['versionName']?.trim();
final def deployBasePath = props['deployBasePath']?.trim();
final def pdsMapping = props['pdsMapping']?.trim();
final def checkAccess = Boolean.valueOf(props['checkAccess']);
//final def backupPds = Boolean.valueOf(props['backupPds']);
final def backupPds = true;
final def useEnvPdsMapping = Boolean.valueOf(props['useEnvPdsMapping']);
final def envPdsMapping = props['envPdsMapping']?.trim();
final def toolKitHome = props['ucdToolKitHome']?.trim();

//The deploy working directory
final def componentVersionWorkingDir = workDir.canonicalPath + File.separator + versionName;
final def packageZipFilePath = componentVersionWorkingDir + File.separator + packageFileName;
final def packageManifestFileNamePath = componentVersionWorkingDir + File.separator + packageManifestFileName;
final def conainerMapperXmlFilePath = componentVersionWorkingDir + File.separator + defaultContainerMapperFileName;
final def dsListFile4BackUpPath = componentVersionWorkingDir + File.separator + defaultDSListFileName4backUp;
final def dsListFilePath = componentVersionWorkingDir + File.separator + defaultDSListFile;
final def zosScriptPath = toolKitHome + File.separator + toolkitExeFolderName + File.separator + zosScriptName;
final def checkAccessExePath = toolKitHome + File.separator + toolkitExeFolderName + File.separator + checkAccessExeName;

//Do parameter checking
def deployBasePathFile = new File(deployBasePath);
if(deployBasePathFile.isFile()){
	throw new IllegalArgumentException("Deploy Base Path ${deployBasePath} is a file!");
}
def zosScriptFile = new File(zosScriptPath);
if(!zosScriptFile.exists()){
	throw new IllegalArgumentException("Can not find the ispf gateway script:${zosScriptPath}. Please make sure z/OS Deploy Toolkit is installed and z/OS Toolkit Home is set to the correct location.");
}
def packageZipFile = new File(packageZipFilePath);
if(!packageZipFile.exists()){
	throw new IllegalArgumentException("${packageZipFilePath} not found. Please make sure a Copy or FTP plug-in step is successfully executed before the Deploy plug-in step.");
}
def packageManifestFile = new File(packageManifestFileNamePath);
if(!packageManifestFile.exists()){
	throw new IllegalArgumentException("${packageManifestFileNamePath} not found. Please make sure a Copy or FTP plug-in step is successfully executed before the Deploy plug-in step.");
}

//Combile the user input and the environment pds mapping
def src2TargetMap = [:];
def targetDsSet = new HashSet();
//Handle user input pds mapping
def pdsMappingStr = "";
if(pdsMapping && pdsMapping.size() > 0){
	pdsMappingStr = pdsMapping.trim();
	pdsMappingStr.replaceAll(src2CurrSysTargetPairDelimeter, src2TargetPairDelimeter);
	def pdsMappingPairs = pdsMappingStr.split(src2TargetPairDelimeter);
	pdsMappingPairs.each {pair->
		pair = pair.trim();
		if(pair.length() > 0){//Allow empty line which will be ignore
			def onePair = pair.split(src2TargetDelimeter);
			onePair = onePair*.trim();
			if(onePair.size() == 2){
				if(!src2TargetMap.containsKey(onePair[0])){
					src2TargetMap.put(onePair[0], onePair[1]);
					targetDsSet.add(onePair[1]);
				}else{
					println "Warning - The mapping rule ${onePair[0]}, ${onePair[1]} is ignored,which was already set by ${onePair[0]}, ${src2TargetMap[onePair[0]]}";
				}
			}else{//abc,cc,dd or abc, or ,cc will be treat as illegal input
				throw new IllegalArgumentException("The format of ${pair} PDS mapping field is not correctly!");
			}
		}
	}
}

//Handle system env pds mapping
def envPdsMappingStr = "";
if(useEnvPdsMapping && envPdsMapping && envPdsMapping.size() > 0){
	envPdsMappingStr = envPdsMapping.trim();
	envPdsMappingStr.replaceAll(src2CurrSysTargetPairDelimeter, src2TargetPairDelimeter);
	def envPdsMappingPairs = envPdsMappingStr.split(src2TargetPairDelimeter);
	envPdsMappingPairs.each {pair->
		pair = pair.trim();
		if(pair.length() > 0){//Allow empty line which will be ignore
			def oneEnvPair = pair.split(src2TargetDelimeter);
			oneEnvPair = oneEnvPair*.trim();
			if(oneEnvPair.size() == 2){
				if(!src2TargetMap.containsKey(oneEnvPair[0])){
					src2TargetMap.put(oneEnvPair[0], oneEnvPair[1]);
					targetDsSet.add(oneEnvPair[1]);
				}else{
					println "Warning - The mapping rule ${oneEnvPair[0]}, ${oneEnvPair[1]} is ignored,which was already set by ${oneEnvPair[0]}, ${src2TargetMap[oneEnvPair[0]]}";
				}
			}else{//abc,cc,dd or abc, or ,cc will be treat as illegal input
				throw new IllegalArgumentException("The format of ${pair} PDS mapping field is not correctly!");
			}
		}
	}
}

//Check the mapping rule to see if some datasets were missed
def pkgManifestHelper = new PackageManifestXMLHelper();
def dsNeedToDeploy = pkgManifestHelper.getAllDeployDatasets(packageManifestFileNamePath);
def dsIncludedByUser = src2TargetMap.keySet();
def missedDsByUser = dsNeedToDeploy - dsIncludedByUser;
if(missedDsByUser && missedDsByUser.size() > 0){
	def dsStr = "";
	for (ds in missedDsByUser) {
		dsStr += " " + ds;
	}
	
	throw new IllegalArgumentException("Missing PDS mapping rules for: ${dsStr}");
}

//Check access
//If use back up the data, we need to check "INPUT" access for those target dataset
if(backupPds && checkAccess){
	def InputTargetVolumeMap = [:];
	targetDsSet.each { datasetName->
		def dsn = "'" + datasetName + "'";
		def exists = dsExist(dsn);
		if(!exists){
			println "Warning - Input dataset ${dsn} is not found!";
		}
		try {
				def vols = ZFile.locateDSN(dsn);
				if(null == vols || vols.size()<1){
					println "Warning - Input dataset ${dsn} is not found!";
				}else if( vols.size() > 1){
				}else{
					InputTargetVolumeMap.put(datasetName, vols[0]);
				}
			} 
		catch(Exception locateException){
				//Can't find the the dsn
			}
	}
	//Generate the datasetlist file to call native checkaccess for deploy
	new File(dsListFile4BackUpPath).withWriter('IBM-1047'){ out ->
		InputTargetVolumeMap.each {datasetName,volume->
			out.println("${dataSetListInputLeader} ${datasetName} ${volume}");
		}
	}
	//Call native script to get the access code
	def accessResult4InputPro = ["${checkAccessExePath}", "-d", "${dsListFile4BackUpPath}"].execute();
	println "Check access for back up action!"
	accessResult4InputPro.waitFor();
	println accessResult4InputPro.text;
	def accessResult4Input = accessResult4InputPro.exitValue();
	if(accessResult4Input != 0){
		println "checkaccess:rc=${accessResult4Input}";
		if(137 == accessResult4Input){
			println "checkaccess utility failed. Please verify that checkaccess utility is set as APF authorized by running command \"extattr +a checkaccess\"";
			System.exit(137);
		}
		throw new IOException("These Datasets you listed in PDS mapping can't be used as the input of the program!");
	}
}

//Check access for "OUTPUT" access for deployment process.
if(checkAccess){
	def OutPutTargetVolumeMap = [:];
	targetDsSet.each { datasetName->
		def dsn = "'" + datasetName + "'";
		def exists = dsExist(dsn);
		if(!exists){
			OutPutTargetVolumeMap.put(datasetName, "******");
		}else{
			def vols = null;
			try{
				vols = ZFile.locateDSN(dsn);
			}catch(Exception locateException){
				println "The volumn of ${dsn} was not found for OUTPUT!";
			}
			
			if(null == vols || vols.size()){
				OutPutTargetVolumeMap.put(datasetName, "******");
			}else if( vols.size() > 1){
			}else{
				OutPutTargetVolumeMap.put(datasetName, vols[0]);
			}
		}
	}
	//Generate the datasetlist file to call native checkaccess for deploy
	new File(dsListFilePath).withWriter('IBM-1047'){ out ->
		OutPutTargetVolumeMap.each {datasetName,volume->
			out.println("${dataSetListOutPutLeader} ${datasetName} ${volume}");
		}
	}
	def accessResult4OutputPro = ["${checkAccessExePath}", "-d", "${dsListFilePath}"].execute();
	println "Check access for deployment action!"
	accessResult4OutputPro.waitFor();
	println accessResult4OutputPro.text;
	def accessResult4Output = accessResult4OutputPro.exitValue();
	
	if(accessResult4Output != 0){
		println "checkaccess:rc=${accessResult4Output}";
		if(137 == accessResult4Output){
			println "checkaccess utility failed. Please verify that checkaccess utility is set as APF authorized by running command \"extattr +a checkaccess\"";
			System.exit(137);
		}
		throw new IOException("These Datasets you listed in PDS mapping can't used as the output of the program!");
	}
}


//Generate the containerMapping file logic
def pdsXmlStrWriter = new StringWriter();
pdsXmlStrWriter.append('<?xml version="1.0" encoding="IBM-1047"?>');
def containerMapperXml = new groovy.xml.MarkupBuilder(pdsXmlStrWriter);
containerMapperXml.setDoubleQuotes(true);
if(src2TargetMap.size() > 0){
	containerMapperXml.maps(){
		src2TargetMap.each { pdsSrc, pdsTarget->
			map(type:"PDS"){
				sourceContainer(name:pdsSrc);
				targetContainer(name:pdsTarget);
			}
		}
	}
}else{
	//Handle the issue of no mapping
	throw new IllegalArgumentException("PDS mapping not found. Make sure you have specified the mapping either in PDS mapping or Environment PDS mapping.");
}
//Put the content into log
println "The containerMapper.xml contents"
println pdsXmlStrWriter.toString();
//Generate the containerMapper.xml file
new File(conainerMapperXmlFilePath).withWriter('IBM-1047'){ out ->
	out.print(pdsXmlStrWriter);
}


//Call the ant task in deploy.xml
final def pluginHome = System.getenv("PLUGIN_HOME");
def entryAntScriptFileName = "deploy.xml";
def entryAntScriptDefaultTask = "main";
//This will depends on our pacakge structure
def entryAntScriptDir = "scripts" + File.separator + "deployment";
entryAntScriptDir = pluginHome + File.separator + entryAntScriptDir;

def ant = new AntBuilder();
//Set those properties for the ant script
ant.getProject().setProperty("deploy.rootPath", deployBasePath);
ant.getProject().setProperty("deploy.componentName", componentName);
ant.getProject().setProperty("deploy.versionName", versionName);
ant.getProject().setProperty("deploy.workDirectory", componentVersionWorkingDir);
ant.getProject().setProperty("team.deploy.zos.script", zosScriptPath);
ant.getProject().setProperty("team.deploy.zos.timestamp", new Date().getTime().toString());
ant.getProject().setProperty("deploy.checkaccess", checkAccess.toString());
ant.getProject().setProperty("deploy.backupPds", backupPds.toString());
ant.getProject().setProperty("deploy.defaultDSListFile", defaultDSListFile);
try {
	ant.ant(antfile:entryAntScriptFileName, target:entryAntScriptDefaultTask, dir:entryAntScriptDir);
} catch (Exception e) {
	println "Error deploying version. ${e.message}";
	System.exit(1);
}

//Clear the working directory to avoid dirty data
//Just delete those files we created
def filesCanBeDeleted = new HashSet();
filesCanBeDeleted.add(packageManifestFileName);
filesCanBeDeleted.add(rollbackManifestFileName);
filesCanBeDeleted.add(deployDeltaFileName);
filesCanBeDeleted.add(backUpFileName);
filesCanBeDeleted.add(defaultContainerMapperFileName);
filesCanBeDeleted.add(defaultDSListFileName4backUp);
filesCanBeDeleted.add(defaultDSListFile);
filesCanBeDeleted.add(packageFileName);
def versionWorkingDirectory = new File(componentVersionWorkingDir);
versionWorkingDirectory.eachFile{it->
	if( filesCanBeDeleted.contains(it.name) ){
		it.delete();
	}
}

def dsExist(singleQuotedDsName){
	def isExist = false;
	def f = null;
	try {
		f = new ZFile("//" + singleQuotedDsName, "r");
		isExist = true;
	} catch(ZFileException e) {
		// Assume that the file does not exist in this case.
	} finally {
		if (null != f) {
			f.close();
		}
	}

	return(isExist);
}

System.exit(0);