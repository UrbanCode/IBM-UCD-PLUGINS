/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.ibm.jzos.ZFile
import com.ibm.jzos.ZFileException

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
	inputPropsStream = new FileInputStream(inputPropsFile);
	props.load(inputPropsStream);
}
catch (IOException e) {
	throw new RuntimeException(e);
}

final def defaultContainerMapperFileName = "containerMapper.xml";
final def backUpFileName = "backup.zip";
final def rollbackManifestFileName = "rollbackManifest.xml";
final def defaultDSListFile = "dataSetListFile";
final def additionalFolderForBasePath = "deploy";
final def toolkitExeFolderName = "bin";
final def checkAccessExeName = "checkaccess";
final def zosScriptName = "startispf.sh";

final def componentName = props['componentName']?.trim();
final def versionName = props['versionName']?.trim();
final def deployBasePath = props['deployBasePath']?.trim();
final def toolKitHome = props['ucdToolKitHome']?.trim();
final def checkAccess = Boolean.valueOf(props['checkAccess']);
final def componentWorkingDir = workDir.canonicalPath + File.separator + versionName;
final def conainerMapperXmlFile = componentWorkingDir + File.separator + defaultContainerMapperFileName;
final def zosScriptPath = toolKitHome + File.separator + toolkitExeFolderName + File.separator + zosScriptName;
final def checkAccessExePath = toolKitHome + File.separator + toolkitExeFolderName + File.separator + checkAccessExeName;

def deployBasePathFile = new File(deployBasePath);
if(deployBasePathFile.isFile()){
	throw new IllegalArgumentException("Deploy Base Path ${deployBasePath} is not a folder.");
}
def zosScriptFile = new File(zosScriptPath);
if(!zosScriptFile.exists()){
	throw new IllegalArgumentException("Can not find the ispf gateway script: ${zosScriptPath}. Please make sure z/OS Deploy Toolkit is installed and z/OS Toolkit Home is set to the correct location.");
}

final def repoBasePathWithAddtionalFolder = deployBasePath + File.separator + additionalFolderForBasePath + File.separator + componentName + File.separator + versionName;
final def rollbackMfFilePath = repoBasePathWithAddtionalFolder + File.separator + rollbackManifestFileName;
final def backupZipFilePath = repoBasePathWithAddtionalFolder  + File.separator + backUpFileName;
final def containerFilePath = repoBasePathWithAddtionalFolder + File.separator + defaultContainerMapperFileName;
final def dsListFilePath = repoBasePathWithAddtionalFolder + File.separator + defaultDSListFile;

//Check if file exists
final def rollbackMfFile = new File(rollbackMfFilePath);
final def backupZipFile = new File(backupZipFilePath);
final def containerFile = new File(containerFilePath);
final def dsListFile = new File(dsListFilePath);

if( !(rollbackMfFile.exists()&&rollbackMfFile.isFile()) ){
	throwRollbackFileNotFoundException(rollbackMfFilePath);
}
if( !(containerFile.exists() && containerFile.isFile()) ){
	throwRollbackFileNotFoundException(containerFilePath);
}
if( !(backupZipFile.exists() && backupZipFile.isFile()) ){
	throwRollbackFileNotFoundException(backupZipFilePath);
}

def dsListFileExist = true;
if( checkAccess ){
	if( !(dsListFile.exists() && dsListFile.isFile()) ){
		dsListFileExist = false;
		println "Warning:The target dataset list file is not found, make sure you have checked the 'Check Access' option during the deployment stage,the check access was skipped."
//		throwRollbackFileNotFoundException(dsListFilePath);
	}
}

final def toDir = workDir.canonicalPath + File.separator + versionName;
final def toRollbackMfFilePath = toDir + File.separator + rollbackManifestFileName;
final def toBackupZipFilePath = toDir  + File.separator + backUpFileName;
final def toContainerFilePath = toDir + File.separator + defaultContainerMapperFileName;
final def toDsListFilePath = toDir + File.separator + defaultDSListFile;
//Copy files need by rollback
def antCopy = new AntBuilder();
try {
	println "Copy back up into working directory!"
	antCopy.copy(verbose: "true",file:"$rollbackMfFilePath", tofile:"$toRollbackMfFilePath",overwrite: "true");
	antCopy.copy(verbose: "true",file:"$containerFilePath", tofile:"$toContainerFilePath",overwrite: "true");
	if(backupZipFile.exists() && backupZipFile.isFile()){
		antCopy.copy(verbose: "true",file:"$backupZipFilePath", tofile:"$toBackupZipFilePath",overwrite: "true");	
	}
	if(checkAccess && dsListFileExist){
		antCopy.copy(verbose: "true",file:"$dsListFilePath", tofile:"$toDsListFilePath",overwrite: "true");
	}
}
catch (Exception e) {
	println "Error getting backup data.${e.message}";
	System.exit(1);
}

if(checkAccess && dsListFileExist){
	def accessResult4OutPutPro = ["${checkAccessExePath}", "-d", "${toDsListFilePath}"].execute();
	println "Check access for Roll back actiion!";
	accessResult4OutPutPro.waitFor();
	println accessResult4OutPutPro.text;
	def accessResult4OutPut = accessResult4OutPutPro.exitValue();
	if(accessResult4OutPut != 0){
		println "checkaccess:rc=${accessResult4OutPut}";
		if(137 == accessResult4OutPut){
			println "checkaccess utility failed. Please verify that checkaccess utility is set as APF authorized by running command \"extattr +a checkaccess\"";
			System.exit(137);
		}
		throw new IOException("These Datasets you listed in PDS mapping can't be used as the output of the program!");
	}
}

//Call the ant task rollback in deploy.xml
final def pluginHome = System.getenv("PLUGIN_HOME");
def entryAntScriptFileName = "deploy.xml";
def entryAntScriptDefaultTask = "rollbackMain";
//This will depends on our pacakge structure
def entryAntScriptDir = "scripts" + File.separator + "deployment";
entryAntScriptDir = pluginHome + File.separator + entryAntScriptDir;

def antRollBack = new AntBuilder();
//Set those properties for the ant script
antRollBack.getProject().setProperty("deploy.rootPath", deployBasePath);
antRollBack.getProject().setProperty("deploy.componentName", componentName);
antRollBack.getProject().setProperty("deploy.versionName", versionName);
antRollBack.getProject().setProperty("deploy.workDirectory", componentWorkingDir);
antRollBack.getProject().setProperty("team.deploy.zos.script", zosScriptPath);
antRollBack.getProject().setProperty("team.deploy.zos.timestamp", new Date().getTime().toString());

try{
	antRollBack.ant(antfile:entryAntScriptFileName, target:entryAntScriptDefaultTask, dir:entryAntScriptDir);
}
catch(Exception e){
	println "Error rollback package: ${e.message}";
	System.exit(1);
}

final def delBackUpFiles = Boolean.valueOf(props['delBackUpFiles']);
if( delBackUpFiles ){
	def antDelete = new AntBuilder();
	println "Delete those back up files on request!"
	try {
		antDelete.delete(verbose: "true", file: "$rollbackMfFilePath");
		antDelete.delete(verbose: "true", file: "$backupZipFilePath");
	} catch(Exception e){
		println "Error delete package: ${e.message}";
		System.exit(1);
	}
}

//Clear the working directory to avoid dirty data
//Just delete those files we created
def filesCanBeDeleted = new HashSet();
filesCanBeDeleted.add(rollbackManifestFileName);
filesCanBeDeleted.add(backUpFileName);
filesCanBeDeleted.add(defaultContainerMapperFileName);
filesCanBeDeleted.add(defaultDSListFile);
def versionWorkingDirectory = new File(toDir);
versionWorkingDirectory.eachFile{it->
	if( filesCanBeDeleted.contains(it.name) ){
		it.delete();
	}
}

def throwRollbackFileNotFoundException(fileName){
	throw new IllegalArgumentException("""${fileName} does not exist or is not a file. 
Error rolling back because one of the files needed for rollback is not found. 
Please make sure you have deployed the version successfully and haven't rolled back it already.""");
}

def dsExist(singleQuotedDsName){
	def isExist = false;
	def f = null;
	try {
		f = ZFile("//" + singleQuotedDsName, "r");
		isExist = true;
	} catch(ZFileException e){
		// Assume that the file does not exist in this case.
	} finally {
		if (null != f) {
			f.close();
		}
	}

	return(isExist);
}

System.exit(0);

