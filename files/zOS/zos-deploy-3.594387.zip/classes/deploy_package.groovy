import com.ibm.urbancode.zos.common.DeploymentConstants;
import com.ibm.urbancode.zos.common.DeploymentHelper;
import com.ibm.urbancode.zos.common.PackageManifestXMLHelper;

/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
	inputPropsStream = new FileInputStream(inputPropsFile);
	props.load(inputPropsStream);
}
catch (IOException e) {
	throw new RuntimeException(e);
}


final def componentName   	= DeploymentHelper.getStringInput(props['componentName']);
final def versionName 	  	= DeploymentHelper.getStringInput(props['versionName']);
final def deployBasePath  	= DeploymentHelper.getStringInput(props['deployBasePath']);
final def pdsMapping 	  	= DeploymentHelper.getStringInput(props['pdsMapping']);
final def checkAccess 	  	= DeploymentHelper.getBooleanInput(props['checkAccess']);
//final def backupPds = Boolean.valueOf(props['backupPds']);
final def backupPds 	  	= true;
final def useEnvPdsMapping	= DeploymentHelper.getBooleanInput(props['useEnvPdsMapping']);
final def envPdsMapping 	= DeploymentHelper.getStringInput(props['envPdsMapping']);
final def toolKitHome 		= DeploymentHelper.getStringInput(props['ucdToolKitHome']);

DeploymentHelper.validateDirectoryExist(deployBasePath, "Deploy Base Path ${deployBasePath} does not exist!");

//The deploy working directory
final def workDirPath = workDir.canonicalPath;
final def componentVersionWorkingDir  = DeploymentHelper.getVersionDirPathInWorkingDir(workDirPath,versionName);
final def packageZipFilePath 		  = DeploymentHelper.getFilePathInWorkingDir(workDirPath, versionName, DeploymentConstants.PACKAGE_FILE_NAME);
final def packageManifestFileNamePath = DeploymentHelper.getFilePathInWorkingDir(workDirPath, versionName, DeploymentConstants.PACKAGE_MANIFEST_FILE_NAME);
final def conainerMapperXmlFilePath   = DeploymentHelper.getFilePathInWorkingDir(workDirPath, versionName, DeploymentConstants.CONTAINER_MAPPER_FILE_NAME);
final def dsListFile4BackUpPath 	  = DeploymentHelper.getFilePathInWorkingDir(workDirPath, versionName, DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME_BACKUP);
final def dsListFilePath 			  = DeploymentHelper.getFilePathInWorkingDir(workDirPath, versionName, DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME);
final def zosScriptPath 			  = DeploymentHelper.getPath4ExecScriptInToolkit(toolKitHome , DeploymentConstants.ZOS_TOOLKIT_ISPF_SCRIPT_NAME);
final def checkAccessExePath 		  = DeploymentHelper.getPath4ExecScriptInToolkit(toolKitHome , DeploymentConstants.CHECK_ACCESS_EXE);

//Do parameter checking
DeploymentHelper.validateFileExist(zosScriptPath, "Can not find the ispf gateway script:${zosScriptPath}. Please make sure z/OS Deploy Toolkit is installed and z/OS Toolkit Home is set to the correct location.");
DeploymentHelper.validateFileExist(packageZipFilePath, "${packageZipFilePath} not found. Please make sure a Copy or FTP plug-in step is successfully executed before the Deploy plug-in step.");
DeploymentHelper.validateFileExist(packageManifestFileNamePath, "${packageManifestFileNamePath} not found. Please make sure a Copy or FTP plug-in step is successfully executed before the Deploy plug-in step.");

//Combile the user input and the environment pds mapping
def src2TargetMap = [:];
//Handle user input pds mapping
DeploymentHelper.handleMappingRule(pdsMapping, src2TargetMap)
//Handle system env pds mapping
if(useEnvPdsMapping){
	DeploymentHelper.handleMappingRule(envPdsMapping, src2TargetMap);
}
def targetDsSet =  src2TargetMap.values().toSet();


//Check the mapping rule to see if some datasets were missed
def pkgManifestHelper 	= 	new PackageManifestXMLHelper();
def dsNeedToDeploy 		= 	pkgManifestHelper.getAllDeployDatasets(packageManifestFileNamePath);
def dsIncludedByUser 	= 	src2TargetMap.keySet();
def missedDsByUser 		= 	dsNeedToDeploy - dsIncludedByUser;
if(missedDsByUser && missedDsByUser.size() > 0){
	def dsStr = "";
	for (ds in missedDsByUser) {
		dsStr += " " + ds;
	}
	
	throw new IllegalArgumentException("Missing PDS mapping rules for: ${dsStr}");
}


//Check access
//If use back up the data, we need to check "INPUT" access for those target dataset
if(backupPds && checkAccess){
	println "Check access for back up action!"
	DeploymentHelper.checkAccess4Input(targetDsSet, dsListFile4BackUpPath, checkAccessExePath)
}
//Check access for "OUTPUT" access for deployment process.
if(checkAccess){
	println "Check access for deployment action!"
	DeploymentHelper.checkAccess4Output(targetDsSet, dsListFilePath, checkAccessExePath)
}


//Generate the containerMapping file logic
def pdsXmlStrWriter = new StringWriter();
pdsXmlStrWriter.append('<?xml version="1.0" encoding="IBM-1047"?>');
def containerMapperXml = new groovy.xml.MarkupBuilder(pdsXmlStrWriter);
containerMapperXml.setDoubleQuotes(true);
if(src2TargetMap.size() > 0){
	containerMapperXml.maps(){
		src2TargetMap.each { pdsSrc, pdsTarget->
			map(type:"PDS"){
				sourceContainer(name:pdsSrc);
				targetContainer(name:pdsTarget);
			}
		}
	}
}else{
	//Handle the issue of no mapping
	throw new IllegalArgumentException("PDS mapping not found. Make sure you have specified the mapping either in PDS mapping or Environment PDS mapping.");
}


//Put the content into log
println "The containerMapper.xml contents"
println pdsXmlStrWriter.toString();
//Generate the containerMapper.xml file
new File(conainerMapperXmlFilePath).withWriter('IBM-1047'){ out ->
	out.print(pdsXmlStrWriter);
}


//Call the ant task in deploy.xml
def entryAntScriptDir = DeploymentHelper.getAntScriptFolderPath();
def ant = new AntBuilder();
//Set those properties for the ant script
ant.getProject().setProperty("deploy.rootPath", deployBasePath);
ant.getProject().setProperty("deploy.componentName", componentName);
ant.getProject().setProperty("deploy.versionName", versionName);
ant.getProject().setProperty("deploy.workDirectory", componentVersionWorkingDir);
ant.getProject().setProperty("team.deploy.zos.script", zosScriptPath);
ant.getProject().setProperty("team.deploy.zos.timestamp", new Date().getTime().toString());
ant.getProject().setProperty("deploy.checkaccess", checkAccess.toString());
ant.getProject().setProperty("deploy.backupPds", backupPds.toString());
ant.getProject().setProperty("deploy.defaultDSListFile", DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME);
try {
	ant.ant(antfile:DeploymentConstants.ENTRY_ANT_SCRIPT, target:DeploymentConstants.ENTRY_ANT_SCRIPT_TASK_DEPLOY, dir:entryAntScriptDir);
} catch (Exception e) {
	println "Error deploying version. ${e.message}";
	System.exit(1);
}


//Clear the working directory to avoid dirty data
//Just delete those files we created
DeploymentHelper.cleanWorkDir(componentVersionWorkingDir);


System.exit(0);