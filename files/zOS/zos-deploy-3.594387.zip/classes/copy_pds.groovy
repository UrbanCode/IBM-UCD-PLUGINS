/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/


import com.ibm.urbancode.zos.common.RexxHelper;
import com.urbancode.air.AirPluginTool

def apiTool = new AirPluginTool(this.args[0], this.args[1])
def props = apiTool.getStepProperties()

// verify parameter format
def sourcePDS
def toPDS
def includeMembers
def excludeMembers
try {
    sourcePDS = verifyDatasetName(props['sourcePDS']);
    toPDS = verifyDatasetName(props['toPDS']);
    if (!sourcePDS.equals(toPDS)) {
        includeMembers = verifyMembers(props['includeMembers'])
        excludeMembers = verifyMembers(props['excludeMembers'])
    }
} catch (Exception e1) {
    apiTool.setOutputProperty("returnCode", 8.toString());
    apiTool.setOutputProperties();
    apiTool.err.println('Error verifying parameters.')
    e1.printStackTrace();
    System.exit(8);
}

try {
    //generate a rexx script to copy pds
    def rexxScript = generateRexxScript(sourcePDS, toPDS, includeMembers, excludeMembers);
    def rexxHelper = new RexxHelper()
    def returnCode = rexxHelper.execute(rexxScript, "cp037")
    if (returnCode == 0) {
        apiTool.out.println("Copy data set completed.")
        apiTool.out.println(rexxHelper.getOutput())
    } else {
        apiTool.err.println(rexxHelper.getOutput())
        apiTool.err.println('Program terminated with return code ' + returnCode.toString())
        apiTool.err.println(rexxHelper.getError())
    }

    apiTool.setOutputProperty("returnCode", returnCode.toString());
    apiTool.storeOutputProperties();//write the output properties to the file

} catch (Exception e) {
    e.printStackTrace();
    apiTool.setOutputProperty("returnCode", 8.toString());
    apiTool.storeOutputProperties();//write the output properties to the file
    System.exit(8)
}


def generateRexxScript(sourcePDS, toPDS, includeMember, excludeMemeber) {
    def controllines = []
    def inputdds = []
    def freedds = []
    def inddlist = []

    if (sourcePDS) {
        def lines = sourcePDS.split(System.getProperty("line.separator"))
        int length = lines.size();
        for (int i = 0; i < length; i++) {
            if (lines[i].trim()) {
                def line = lines[i].split(",")
                if (line.size() > 1) {
                    inddlist.add("(INDD$i,R)")
                } else if (line.size() > 0) {
                    inddlist.add("INDD$i")
                } else {
                    continue
                }
                inputdds.add(
                        """\"ALLOC DATASET(${line[0]}) DDNAME(INDD$i) SHR  REUSE\"
                    say "Allocation for data set ${line[0]} ends with "rc
                    if rc <> 0 then return 8""")
                freedds.add("\"FREE DDNAME(INDD$i)\"")
            }
        }
        statement = "COPERST1 COPYMOD INDD=("
        size = inddlist.size()
        for (int i = 0; i < size; i++) {
            if (i != 0) {
                statement = "$statement,"
            }
            statement = "$statement${inddlist[i]}"
        }
        statement = "$statement),OUTDD=SYSUT2"
        controllines.add(statement)
    }
    if (includeMember) {
        if (excludeMemeber) {
            throw new InvalidPropertiesFormatException(
                    "Include Memebers and Exclude Members are mutually exclusive."
            )
        }
        def lines = includeMember.split(System.getProperty("line.separator"))
        lines.each { line ->
            if (line.trim()) {
                if (line.toString().contains("(")) {
                    controllines.add("         SELECT MEMBER=(${line})\n")
                } else if (line.toString().contains(",")) {
                    controllines.add("         SELECT MEMBER=((${line}))\n")
                } else {
                    controllines.add("         SELECT MEMBER=${line}\n")
                }
            }
        }
    } else if (excludeMemeber) {
        def lines = excludeMemeber.split(System.getProperty("line.separator"))
        lines.each { line ->
            if (line.trim()) {
                controllines.add("        EXCLUDE MEMBER=${line}")
            }
        }
    }
    def controlstatement = ''
    controllines.each { line ->
        controlstatement = "${controlstatement}QUEUE \"${line}\"\n"
    }
    controlstatement = "${controlstatement}QUEUE \"\"\n"
    def ddstatement = ""
    inputdds.each { line ->
        ddstatement = "$ddstatement$line\n"
    }
    def freeDDstatement = ""
    freedds.each { line ->
        freeDDstatement = "$freeDDstatement$line\n"
    }
    def result = """/* rexx */
userid = USERID()
rc=bpxwdyn( "ALLOC DD(SYSIN) DSN("userid".TMP.IEBIN) NEW CATALOG SPACE(1,1) TRACKS REUSE RECFM(F,B) LRECL(80)")
if rc <> 0 then
do
  say "Error allocating DD for control statement"
  exit 8
end
$controlstatement
address mvs "EXECIO * DISKW SYSIN (FINIS"
if rc <> 0 then
do
  say "Error writing control statement to DD"
  exit 8
end

rc=bpxwdyn( "free dd(SYSIN)")
if rc <> 0 then
do
  say 'Error free SYSIN'rc
end
ADDRESS TSO
"FREE DDN(SYSIN)"
"ALLOC DSN('"userid".TMP.IEBIN') DDN(SYSIN) OLD DELETE"
if rc <> 0 then
do
    say 'Error allocating SYSIN for IEBCOPY '
    return 8
end
$ddstatement
"ALLOC DATASET($toPDS) DDNAME(SYSUT2) SHR  REUSE"
if rc <> 0 then
do
 say 'Error allocating DD for To PDS'
 return 8
end
"ALLOC DDNAME(SYSPRINT) FILEDATA(TEXT) PATH('/dev/fd1')"
ADDRESS TSO 'LISTALC STATUS'
ADDRESS TSO 'IEBCOPY'
exitRC =rc
if rc <> 0 then say 'Error executing IEBCOPY'
$freeDDstatement
"FREE DDNAME(SYSUT2) "
if rc <> 0 then say 'Error free To PDS'
"FREE DDNAME(SYSPRINT) "
"FREE DA('"userid".TMP.IEBIN') "
return exitRC
"""
    return result
}

def verifyDatasetName(name) {
    if (name) {
        name = name.trim()
        if (name.length() > 0) {
            return name
        }
    }
    throw new InvalidPropertiesFormatException("$name is not an valid data set name")
    return null;
}

def verifyMembers(members) {
    if (members) {
        return members = members.trim()
    }
}

