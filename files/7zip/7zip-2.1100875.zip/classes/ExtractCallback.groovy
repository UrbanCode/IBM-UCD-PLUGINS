import net.sf.sevenzipjbinding.IArchiveExtractCallback
import net.sf.sevenzipjbinding.ISevenZipInArchive
import net.sf.sevenzipjbinding.ISequentialOutStream
import net.sf.sevenzipjbinding.ExtractAskMode
import net.sf.sevenzipjbinding.SevenZipException
import net.sf.sevenzipjbinding.ExtractOperationResult
import net.sf.sevenzipjbinding.PropID

public class ExtractCallback implements IArchiveExtractCallback {
    def inArchive
    def targetDir
    def out
    def isFolder = false
    def folderCreated = false
    def filePath

    public ExtractCallback(ISevenZipInArchive inArchive, File targetDir) {
        this.inArchive = inArchive
        this.targetDir = targetDir
    }

    public ISequentialOutStream getStream(int index, ExtractAskMode extractAskMode) throws SevenZipException {
        isFolder = inArchive.getProperty(index, PropID.IS_FOLDER)
        filePath = inArchive.getProperty(index, PropID.PATH)
        if (extractAskMode == ExtractAskMode.EXTRACT && !isFolder) {
            return new ISequentialOutStream() {
                public int write(byte[] data) throws SevenZipException {
                    out.write(data)
                    return data.length
                }
            }
        }
    }

    public void prepareOperation(ExtractAskMode extractAskMode)
    throws SevenZipException {
        if (extractAskMode == ExtractAskMode.EXTRACT) {
            def file = new File(targetDir, filePath)
            file.getParentFile().mkdirs()
            if (isFolder) {
                folderCreated = file.mkdirs()
            }
            else {
                out = new BufferedOutputStream(new FileOutputStream(file))
            }
        }
    }

    public void setOperationResult(ExtractOperationResult extractOperationResult) throws SevenZipException {
        if (extractOperationResult != ExtractOperationResult.OK) {
            println("Extraction error: " + extractOperationResult.toString())
        }
        else if (isFolder) {
            if (folderCreated) println("Created directory " + filePath)
        }
        else {
            println("Extracted " + filePath)
        }

        if (out) {
            out.flush()
            out.close()
        }
    }

    public void setCompleted(long completeValue) throws SevenZipException {
    }

    public void setTotal(long total) throws SevenZipException {
    }

}