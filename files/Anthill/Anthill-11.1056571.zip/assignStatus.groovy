#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import java.net.URI

import org.apache.log4j.BasicConfigurator
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpStatus;
import org.apache.http.util.EntityUtils;

import com.urbancode.air.AirPluginTool
import com.urbancode.air.XTrustProvider
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

XTrustProvider.install();

BasicConfigurator.resetConfiguration()
BasicConfigurator.configure()
Logger.getRootLogger().setLevel(Level.ERROR)

final def workDir = new File('.').canonicalFile

String encodePath(String path) {
    String result;
    URI uri;
    try {
        uri = new URI(null, null, path, null);
        result = uri.toASCIIString();
    }
    catch (Exception e) {
         println e.getMessage();
         result = path;
    }
    return result;
}

def anthillUrl      = props['anthillUrl']
final def proxyHost = props['proxyHost']
final def proxyPort = props['proxyPort']
final def proxyUserName = props['proxyUserName']
final def proxyUserPassword = props['proxyUserPassword']
final def anthillUser = props['anthillUser']
final def anthillPassword = props['anthillPassword']
final def buildLifeId = props['buildLifeId']
final def statusName = props['statusName'];
def message = props['message'];
def config;

message = "Assignment from uDeploy - " + message;

while (anthillUrl.endsWith("/")) {
     anthillUrl = anthillUrl.substring(0, anthillUrl.length() - 1);
}

final def fullUrl = anthillUrl + "/rest2/buildlife/${buildLifeId}/statuses?" +
                               "statusName=" + encodePath(statusName) + "&" +
                               "message=" + encodePath(message);
println fullUrl;

HttpClientBuilder builder = new HttpClientBuilder();
builder.setPreemptiveAuthentication(true);

if(proxyPort && proxyHost){
    try{
       def proxyPortNumber = Integer.parseInt(proxyPort);
       builder.setProxyHost(proxyHost);
       builder.setProxyPort(proxyPort);

       if (proxyUserName && proxyUserPassword) {
           println("Proxy Authentication required with user "+proxyUserName);
           builder.setProxyUsername(proxyUserName);
           builder.setProxyPassword(proxyUserPassword);
       }
    }
    catch (NumberFormatException ex) {
        println "Warning: The proxy port must be a number !";
        println "Error: "+ex.toString();
    }
}

builder.setUsername(anthillUser);
builder.setPassword(anthillPassword);
DefaultHttpClient client = builder.buildClient();

HttpPost method = new HttpPost(fullUrl);
HttpResponse response = client.execute(method);
def status = response.getStatusLine().getStatusCode();

if (status == HttpStatus.SC_OK || status == HttpStatus.SC_CREATED) {
    println "Successfully assigned status ${statusName}";
}
else {
    throw new Exception(String.format("%d - %s", status, EntityUtils.toString(response.getEntity())));
}
