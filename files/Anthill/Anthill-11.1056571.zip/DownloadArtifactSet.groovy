#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import org.apache.log4j.BasicConfigurator
import org.apache.log4j.Level
import org.apache.log4j.Logger

import com.urbancode.air.AirPluginTool
import com.urbancode.codestation2.client.*
import com.urbancode.codestation2.client.base.*
import com.urbancode.codestation2.client.util.*

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

BasicConfigurator.resetConfiguration()
BasicConfigurator.configure()
Logger.getRootLogger().setLevel(Level.ERROR)

final def workDir = new File('.').canonicalFile

final def anthillUrl = props['anthillUrl']
final def anthillUser = props['anthillUser']
final def anthillPassword = props['anthillPassword']
//Proxy Informtaion
final def proxyHost = props['proxyHost']
final def proxyPort = props['proxyPort']
final def proxyUserName = props['proxyUserName']
final def proxyUserPassword = props['proxyUserPassword']

final def projectName = props['projectName']
final def workflowName = props['workflowName']
final def buildLifeId = props['buildLifeId']
final def buildLifeStamp = props['buildLifeStamp']
final def buildLifeStatus = props['buildLifeStatus']
final def artifactSetName = props['artifactSetName']
final def disableCache = Boolean.valueOf(props['disableCache'])

final def credentials = new Credentials(anthillUser, anthillPassword)
final def clientLogger = Logger.getLogger("Codestation Client")
final def clientLogBridge = new Log4jBridge(clientLogger)

clientLogger.setLevel(Level.INFO)
def proxyPortNumber;
def proxyCredentials;

def clientBuilder = new CodestationFacadeBuilder()
clientBuilder.setNoCache(disableCache)
clientBuilder.setServer(anthillUrl)
clientBuilder.setNoCheckCertificate(true)
clientBuilder.setCredentials(credentials)
clientBuilder.setLog(clientLogBridge)
clientBuilder.setForce(true)
clientBuilder.setVerbose(true)
clientBuilder.setSuppressBoms(true)
clientBuilder.setIncludeDirsAndSymlinks(false)
clientBuilder.setIncludePermissions(false)
clientBuilder.setWorkingDir(workDir)

if (!proxyPort.equals("") && !proxyHost.equals("")) {
    try{
       proxyPortNumber = Integer.parseInt(proxyPort);
       clientBuilder.getProxySetupBuilder().setPort(proxyPortNumber)
       clientBuilder.getProxySetupBuilder().setHost(proxyHost)
       println("Connection using a proxy ");
       //Authentication required
       if (!proxyUserName.equals("") && !proxyUserPassword.equals("")) {
           println("Proxy Authentication required with user "+proxyUserName);
           proxyCredentials = new Credentials(proxyUserName, proxyUserPassword)
           clientBuilder.getProxySetupBuilder().setCredentials(proxyCredentials)
       }
       else {
           println("Proxy User or Password empty !");
       }
    }
    catch (NumberFormatException ex) {
        println "Warning: The proxy port must be a number !";
        println "Error: "+ex.toString();
    }
}

def client = clientBuilder.build()

if (buildLifeId) {
    client.resolveArtifacts(projectName, workflowName, Long.valueOf(buildLifeId), artifactSetName);
}
else {
    client.resolveArtifacts(projectName, workflowName, buildLifeStamp, buildLifeStatus, artifactSetName);
}
