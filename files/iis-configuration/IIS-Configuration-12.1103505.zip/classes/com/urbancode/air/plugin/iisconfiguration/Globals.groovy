/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2002-2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
package com.urbancode.air.plugin.iisconfiguration

class Globals{
    static String ROOT_ROLE_NAME = "IISWebServer"
    static String SITE_ROLE_NAME = "IISSite"
    static String APP_ROLE_NAME = "IISApp"
    static String APP_POOL_ROLE_NAME = "IISAppPool"
    static String WEBSERVER_RESOURCE_NAME = "webServer"

    //file names
    static String UCD_METADATA_FILE_NAME = "ucd_metadata.properties"
    static String CONFIG_FILE = "archive.xml"
    static String DEFAULT_WWWROOT_PATH = "C:\\inetpub\\wwwroot\\"

    //properties for ucd metadata file
    static String PROPERTY_CONFIG_FOLDER = "configOutputFolder"
    static String PROPERTY_RESOURCE_ROLE = "resourceRoleName"
    static String PROPERTY_SRCPATH = "srcPath"
    static String PROPERTY_SRCTYPE = "srcType"

    //msdeploy command line
    static String TYPE_PACKAGE = "package"

    //defaults for roles
    //UPDATE HERE IF YOU UPDATE PLUGIN.XML!!
    static String WEB_DEPLOY_PATH_DEFAULT = "C:\\Program Files (x86)\\IIS\\Microsoft Web Deploy V3\\"
    static String APP_CMD_FILE_DEFAULT = "C:\\Windows\\System32\\inetsrv\\appcmd.exe"
}
