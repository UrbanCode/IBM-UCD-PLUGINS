/*
 * FILE-NAME = bindPackage.groovy
 *                                                               
 * DESCRIPTIVE-NAME = Bind Package Script               
 *                                                               
 *    Licensed Materials - Property of IBM                       
 *                                                               
 *    (C) COPYRIGHT 2014 IBM Corp.  All Rights Reserved.         
 *                                                               
 *    STATUS = Version 1.0                                       
 *                                                               
 *    FUNCTION = This script is called from plugin.xml. It then gathers
 *    		 	 all the variables needed and then passes it to BindPackage.java
 *    			 to run the bind commangs.
 *    
 *    NOTES =
 *                                                                                                                                  
 * Change activity:
 * Date  Developer                Description/Tag
 * ----- ------------------------ ---------------------------------------------
 * Dec14 Gary Seto                Birth
 *                                                               
 */
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;
import com.ibm.db2.ucd.dsn.BindPackage;

/* This gets us the plugin tool helper.
 * This assumes that args[0] is input props file and args[1] is output props file.
 * By default, this is true. If your plugin.xml looks like the example.
 * Any arguments you wish to pass from the plugin.xml to this script that you don't want to
 * pass through the step properties can be accessed using this argument syntax
 */
def apTool = new AirPluginTool(this.args[0], this.args[1])

/* Here we call getStepProperties() to get a Properties object that contains the step properties
 * provided by the user.
 */
def props = apTool.getStepProperties();

/* This is how you retrieve properties from the object. You provide the "name" attribute of the
 * <property> element
 *
 */

//defines and pulled form the plugin.xml
//trimmed to take out any white spaces
def locationName = props['locationName'].trim();
def collectionId = props['collectionId'].trim();
def owner = props['owner'].trim();
def qualifier = props['qualifier'].trim();

def enable = props['enable'].trim();
def disable = props['disable'].trim();
def dlibatch = props['dlibatch'].trim();
def cics = props['cics'].trim();
def imsbmp = props['imsbmp'].trim();
def imsmpp = props['imsmpp'].trim();

def member = props['member'].trim();
def library = props['library'].trim();

//not used till further notice
//def copy = props['copy'].trim();
//def copy_copyver = props['copy_copyver'].trim();
//def copy_options = props['copy_options'].trim();
//def deploy = props['deploy'].trim();
//def deploy_copyver = props['deploy_copyver'].trim();

def defer = props['defer'].trim();
def nodefer = props['nodefer'].trim();

def action = props['action'].trim();
def action_replver = props['action_replver'].trim();

def currentdata= props['currentdata'].trim();
def dbprotocol = props['dbprotocol'].trim();
def degree = props['degree'].trim();
def descstat = props['descstat'].trim();
def dynamicrules = props['dynamicrules'].trim();

def encoding = props['encoding'].trim();
def encoding_ccsid = props['encoding_ccsid'].trim();

def explain = props['explain'].trim();
def flag = props['flag'].trim();
def immedwrite = props['immedwrite'].trim();
def isolation = props['isolation'].trim();
def keepdynamic = props['keepdynamic'].trim();
def reopt = props['reopt'].trim();
def opthint = props['opthint'].trim();
def path = props['path'].trim();
def rounding = props['rounding'].trim();
def release = props['release'].trim();
def sqlerror = props['sqlerror'].trim();
def validate = props['validate'].trim();
def extendedindicator = props['extendedindicator'].trim();
def concurrentaccessresolution = props['concurrentaccessresolution'].trim();
def apreuse = props['apreuse'].trim();
def apcompare = props['apcompare'].trim();
def generic = props['generic'].trim();
def bustimesensitive = props['bustimesensitive'].trim();
def systimesensitive = props['systimesensitive'].trim();
def archivesensitive = props['archivesensitive'].trim();
def applcompat = props['applcompat'].trim();

def Host = props['Host'].trim();
def PortNumber = props['PortNumber'].trim();
def Location = props['Location'].trim();
def UserName = props['UserName'].trim();
def Password = props['Password'].trim();

def bindPackage = new BindPackage();


//passes all the values into java
bindPackage.executeBindPackage(Host, PortNumber, Location, UserName, Password,
	locationName, collectionId, owner, qualifier, enable, disable, dlibatch, cics,
	imsbmp, imsmpp, member, library, 
//	not used till further notice
//	copy, copy_copyver, copy_options, deploy,deploy_copyver, 
	defer, nodefer, action, action_replver, currentdata, dbprotocol, degree, descstat,
	dynamicrules, encoding, encoding_ccsid, explain, flag, immedwrite, isolation,
	keepdynamic, reopt, opthint, path, rounding, release, sqlerror, validate, 
	extendedindicator, concurrentaccessresolution, apreuse, apcompare, generic, 
	bustimesensitive, systimesensitive, archivesensitive, applcompat);

//Set an output property
//grabs output values from java code
apTool.setOutputProperty("SQLCODE", bindPackage.SQLCODE);
apTool.setOutputProperty("SQLSTATE", bindPackage.SQLSTATE);
apTool.setOutputProperty("TOKEN", bindPackage.TOKENS);

//maps all the bind files and SQL states
def map = BindPackage.map;
map.each {k,v -> apTool.setOutputProperty("${k}", "${v}")};

apTool.storeOutputProperties();//write the output properties to the file
System.exit(bindPackage.exitCode);