/*
 * FILE-NAME = bindPlan.groovy
 *                                                               
 * DESCRIPTIVE-NAME = Bind Plan Script               
 *                                                               
 *    Licensed Materials - Property of IBM                       
 *                                                               
 *    (C) COPYRIGHT 2014 IBM Corp.  All Rights Reserved.         
 *                                                               
 *    STATUS = Version 1.0                                       
 *                                                               
 *    FUNCTION = This script is called from plugin.xml. It then gathers
 *    		 	 all the variables needed and then passes it to BindPlan.java
 *    			 to run the bind commangs.
 *    
 *    NOTES =
 *                                                                                                                                  
 * Change activity:
 * Date  Developer                Description/Tag
 * ----- ------------------------ ---------------------------------------------
 * Dec14 Gary Seto                Birth
 *                                                               
 */
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;
import com.ibm.db2.ucd.dsn.BindPlan;

/* This gets us the plugin tool helper.
 * This assumes that args[0] is input props file and args[1] is output props file.
 * By default, this is true. If your plugin.xml looks like the example.
 * Any arguments you wish to pass from the plugin.xml to this script that you don't want to
 * pass through the step properties can be accessed using this argument syntax
 */
def apTool = new AirPluginTool(this.args[0], this.args[1])

/* Here we call getStepProperties() to get a Properties object that contains the step properties
 * provided by the user.
 */
def props = apTool.getStepProperties();

/* This is how you retrieve properties from the object. You provide the "name" attribute of the
 * <property> element
 *
 */

//defines and pulled form the plugin.xml
//trimmed to take out any white spaces
def planName = props['planName'].trim();
def owner = props['owner'].trim();
def qualifier = props['qualifier'].trim();

def enable = props['enable'].trim();
def disable = props['disable'].trim();
def dlibatch = props['dlibatch'].trim();
def cics = props['cics'].trim();
def imsbmp = props['imsbmp'].trim();
def imsmpp = props['imsmpp'].trim();

def pkist = props['pkist'].trim();

def acquire= props['acquire'].trim();

def action = props['action'].trim();
def action_retain = props['action_retain'].trim();

def cachesize = props['cachesize'].trim();
def currentdata = props['currentdata'].trim();
def currentserver = props['currentserver'].trim();
def dbprotocol = props['dbprotocol'].trim();
def degree = props['degree'].trim();
def disconnect = props['disconnect'].trim();
def dynamicrules = props['dynamicrules'].trim();

def encoding = props['encoding'].trim();
def encoding_ccsid = props['encoding_ccsid'].trim();

def explain= props['explain'].trim();
def flag = props['flag'].trim();
def immedwrite = props['immedwrite'].trim();
def isolation = props['isolation'].trim();
def keepdynamic = props['keepdynamic'].trim();
def reopt = props['reopt'].trim();
def opthint= props['opthint'].trim();
def path = props['path'].trim();
def release= props['release'].trim();
def rounding = props['rounding'].trim();
def sqlrules = props['sqlrules'].trim();
def validate = props['validate'].trim();
def concurrentaccessresolution = props['concurrentaccessresolution'].trim();
def progauth = props['progauth'].trim();

def Host = props['Host'].trim();
def PortNumber = props['PortNumber'].trim();
def Location = props['Location'].trim();
def UserName = props['UserName'].trim();
def Password = props['Password'].trim();

def bindPlan = new BindPlan();

//passes all the values into java
bindPlan.executeBindPlan(Host, PortNumber, Location, UserName, Password, 
	planName, owner, qualifier, enable, disable, dlibatch, cics, imsbmp,
	imsmpp, pkist, acquire, action, action_retain, cachesize, currentdata,
	currentserver, dbprotocol, degree, disconnect, dynamicrules, encoding,
	encoding_ccsid, explain, flag, immedwrite, isolation, keepdynamic,                             
	reopt, opthint, path, release, rounding, sqlrules, validate,                                
	concurrentaccessresolution, progauth);

//Set an output property
apTool.setOutputProperty("SQLCODE", bindPlan.SQLCODE);
apTool.setOutputProperty("SQLSTATE", bindPlan.SQLSTATE);
apTool.setOutputProperty("TOKEN", bindPlan.TOKENS);

apTool.storeOutputProperties();//write the output properties to the file
System.exit(bindPlan.exitCode);