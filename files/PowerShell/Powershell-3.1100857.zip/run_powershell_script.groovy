import com.urbancode.air.CommandHelper;
import com.urbancode.air.AirPluginTool;
import com.urbancode.shell.Shell;
import com.urbancode.commons.util.processes.Processes

final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties();

def scriptBody = props['scriptBody'] != "" ? props['scriptBody'] : null
def scriptFile = props['scriptFile'] != "" ? props['scriptFile'] : null
def commandPath = props['commandPath'] != ("") ? props['commandPath'] : ""
final def daemon = Boolean.valueOf(props['runAsDaemon'])
def threadMode = props['threadMode']
def outputFilePath = props['outputFile']

final Processes processes = new Processes()
final File PLUGIN_HOME = new File(System.getenv().get("PLUGIN_HOME"))

if (scriptBody == null && scriptFile == null) {
    println "You must provide either a Script Body or a Script File"
    System.exit(1)
}

if (scriptBody != null && scriptFile != null) {
    println "You must provide either a Script Body or a Script File, not both"
    System.exit(1)
}

if (scriptBody != null && daemon) {
    println "If you run in daemon mode, you must provide a Script File"
    System.exit(1)
}

def String getArch() {
    String result
    String arch = System.getProperty("os.arch").toLowerCase(Locale.US)

    if (arch.indexOf("amd64") > -1 || arch.indexOf("x64") > -1 || arch.indexOf("x86_64") > -1) {
        result = "x64"
    }
    else if (arch.indexOf("x86") > -1 || arch.indexOf("386") > -1 || arch.indexOf("486") > -1 ||
             arch.indexOf("586") > -1 || arch.indexOf("686") > -1 || arch.indexOf("pentium") > -1) {
        result = "x86"
    }
    else {
        result = "unknown"
    }
             
    return result
}

def arch = getArch()
def libraryPath = new File(PLUGIN_HOME, "lib/native/${arch}/WinAPI.dll")
System.setProperty("com.urbancode.winapi.WinAPI.dllPath", libraryPath.absolutePath)

def inputPropsFile = new File(args[0])
def outputPropsFile = new File(args[1])

def commandScriptPath = ""

//create the script, set it to delete when the step exits, create it and clear it just in case there was somehow some data there.
if (scriptBody != null) {
    def scriptData = File.createTempFile("tmp",".ps1")
    scriptData.deleteOnExit()
    scriptData.createNewFile()
    scriptData.write("")
    scriptData.write(scriptBody)
    commandScriptPath = scriptData.getAbsolutePath()
    
}
else {
    commandScriptPath = scriptFile
}

def cmdArgs = []

if (!commandPath.equals("")) {
    commandPath.trim()
    
    while (commandPath.endsWith("\\")) {
        commandPath = commandPath.substring(0, commandPath.length-1)
    }
    
    cmdArgs << commandPath + File.separator + "powershell.exe"
}
else {
    cmdArgs << "powershell.exe"
}

cmdArgs << "-NonInteractive" << "-ExecutionPolicy" << "unrestricted" << "-NoLogo" << "-NoProfile"

if (!threadMode.equals("default")) {
    if (threadMode.startsWith("S")) {
        cmdArgs << "-Sta"
    }
    else{
        cmdArgs << "-Mta"
    }
}
cmdArgs << "&" << "'"+commandScriptPath+"'" << "'"+inputPropsFile.absolutePath+"'" << "'"+outputPropsFile.absolutePath+"'"

outputFilePath = outputFilePath?.trim()
File outputFile = null
if (outputFilePath) {
    outputFile = new File(outputFilePath)
    if (!outputFile.isAbsolute()) {
        outputFile = new File(workDir, outputFile.getPath()).absoluteFile
    }
    
    outputFile.createNewFile();
}

def shell = new Shell(cmdArgs as String[])
shell.workingDirectory = workDir
shell.daemon = daemon
shell.outputFile = outputFile

println("")
println("command line: ${cmdArgs}")
if (scriptBody != null) {
    println("script content: ")
    println('-------------------------------')
    println(scriptBody)
    println('-------------------------------')
}
println("working directory: ${workDir.path}")

if (daemon) {
    def message = "running as daemon: output "
    message += (outputFile ? "redirected to ${outputFile.path}" : 'discarded')
    println(message)
    
    // WORKAROUND: Had a problem where running a daemon process in urban-deploy allowed
    // the plugin runtime process to terminate as expected, but the agent continued to
    // read from stdout/err. Closing the streams BEFORE running the daemon process
    // prevents that. The simplest explanation is that the handles from agent<->plugin_runtime
    // pipes are being inherited, but the cause for that is unknown. It may be that handle
    // inheritance flags get inherited with the handle.
    //
        
    //System.out.close();
    //System.err.close();
    //System.in.close();
}
else {
    println('===============================')
    println("command output: ")
}

shell.execute()
def proc = shell.process
def exitCode = -1

if (!daemon) {
    def hook = {
        proc.destroy()
    }
    Runtime.getRuntime().addShutdownHook(hook as Thread);
        
    proc.outputStream.close()           // close process stdin
    def outFuture = processes.redirectOutput(proc, System.out);
    def errFuture = processes.redirectError(proc, System.err);
    outFuture.await()
    errFuture.await()
    proc.waitFor()

    Runtime.getRuntime().removeShutdownHook(hook as Thread);

    // print results
    println('===============================')
    println("command exit code: ${proc.exitValue()}")
    println("")
    
    exitCode = proc.exitValue()

    if (exitCode != 0) {
        println "Failed to execute script."
        System.exit(exitCode)
    }
    else {
        println "Script executed successfully."
        System.exit(0)
    }
}