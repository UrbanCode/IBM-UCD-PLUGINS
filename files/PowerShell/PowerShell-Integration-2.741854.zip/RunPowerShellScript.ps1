<#
Licensed Materials - Property of IBM Corp.
IBM UrbanCode Deploy
(c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
GSA ADP Schedule Contract with IBM Corp.
#>

# Sets path parameters for the input/output Java properties files that are passed through the command execution
Param (
  [string]$_IBMUCDPathToPluginInputPropsFile,
  [string]$_IBMUCDPathToPluginOutputPropsFile
)

$_IBMUCDErrorIterator = $Error.Count

Function _IBMUCDWriteErrorToHost {
    if ($_IBMUCDErrorIterator -lt $Error.Count) {
    Write-Host $Args[0] -foregroundcolor red
    While ($_IBMUCDErrorIterator -lt $Error.Count) {
        Write-Host "------------------------------------------------"
        Write-Host "///Error[$_IBMUCDErrorIterator]\\\"
        Write-Host "///Invocation Info\\\"
        $Error[$_IBMUCDErrorIterator].InvocationInfo
        Write-Host "///Exception\\\"
        $Error[$_IBMUCDErrorIterator].Exception
        Write-Host "///FullyQualifiedErrorId\\\"
        $Error[$_IBMUCDErrorIterator].FullyQualifiedErrorId
        Write-Host "///TargetObject\\\"
        $Error[$_IBMUCDErrorIterator].TargetObject
        Write-Host "///ScriptStackTrace\\\"
        $Error[$_IBMUCDErrorIterator].ScriptStackTrace
        $global:_IBMUCDErrorIterator++
  }
   Write-Host " "
  }
}

Function _IBMUCDWriteUserOutputToPropsFile {
    $ArrayContainingOutputsToUCD = @() # Initializes an array
    foreach($UserOutput in $_IBMUCDInputsHashTable."userOutputs".split([char]0x000A)) {
        $TrimmedUserOutput = $UserOutput.Trim()
        if($TrimmedUserOutput) {
            $ScriptOutputs = Invoke-Expression $TrimmedUserOutput
            _IBMUCDWriteErrorToHost "Output contained invalid PowerShell syntax. Object not exported."
            if(!$ScriptOutputs) {
                $ArrayContainingOutputsToUCD = $ArrayContainingOutputsToUCD + "$TrimmedUserOutput=[null]"
            }
            else {
                $JSONScriptOutputs = ConvertTo-Json -InputObject @($ScriptOutputs) -Compress
                $ArrayContainingOutputsToUCD = $ArrayContainingOutputsToUCD + "$TrimmedUserOutput=$JSONScriptOutputs"
            }
        }
    }
    Set-Content $_IBMUCDPathToPluginOutputPropsFile $ArrayContainingOutputsToUCD
}

# Accepts all valid .properties files
# Grabs a Java props file (assumes ASCll encoding), and converting it to a hash-map object System.Collections.Hash-table
$_IBMUCDInputsHashTable = ConvertFrom-StringData (Out-String -InputObject (Get-Content $_IBMUCDPathToPluginInputPropsFile))
_IBMUCDWriteErrorToHost "An Error has been encountered importing plug-in Properties. Please contact IBM UrbanCode support and ask for L3 support."


# Sets default console output and error handling preferences for the script
if ($_IBMUCDInputsHashTable.defaultPreferenceVariables) {
    $DebugPreference = 'Continue'
    $VerbosePreference = 'Continue'
    $InformationPreference = 'Continue'
    $WarningPreference = 'Continue'
    $ProgressPreference = 'SilentlyContinue'
    $ErrorActionPreference = 'SilentlyContinue'
    $ConfirmPreference = 'None'
    $LogCommandHealthEvent = $true
    $LogCommandLifecycleEvent = $true
    $LogEngineHealthEvent = $true
    $LogEngineLifecycleEvent = $true
    $LogProviderHealthEvent = $true
    $LogProviderLifecycleEvent = $true
    $PSModuleAutoloadingPreference = 'All'
}
# Accepts all valid PowerShell Script
# Executes PowerShell Script in Local Scope
Write-Host "======================================================"
Write-Host "Script begin:"
. ([ScriptBlock]::Create($_IBMUCDInputsHashTable.powerShellScript))
Write-Host "Script end.`n"
Write-Host "======================================================"
_IBMUCDWriteErrorToHost "Your script encounter error(s). Please contact your script developer for assistance and relay this output."

# Accepts all valid single line PowerShell Code and passes output to UCD as string
# Builds and saves output Java properties file to the pass in path (OutputPath)
_IBMUCDWriteUserOutputToPropsFile # Executes Function
_IBMUCDWriteErrorToHost "An Error has been encountered outputting PowerShell variables to UCD. Please contact IBM UbanCode support and ask for L3 support."

# Will fail if with 1 (see post-processing) if any errors occurred (except if user cleared errors upon script exit)
# Error Handling
if ($_IBMUCDErrorIterator -eq 0) {
    Write-Host "Script executed successfully."
    exit $_IBMUCDInputsHashTable.successfulExitStatus
}
Write-Host "Script executed with errors!"
