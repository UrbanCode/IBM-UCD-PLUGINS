package com.urbancode.air.plugin.rtw

// RIT, RFT
enum RTWProduct {
	RPT("com.hcl.onetest.performance_"), RTWec("com.hcl.onetest.ui_"), RST("com.ibm.rational.service.tester_"),
	MTE("com.ibm.rational.test.workbench.mobile_")	
	
	private featurepkg;
	
	RTWProduct(def fpkg){
		featurepkg = fpkg;
	}
	
	def getFeaturePackage(){
		return featurepkg;
	}
}

