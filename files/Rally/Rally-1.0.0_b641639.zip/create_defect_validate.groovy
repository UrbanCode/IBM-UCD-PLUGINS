/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
if(projectKey && reqKey) {
  errors.reqKey = "Either User Story ID or Project Name must be empty!"
  errors.projectKey = "Either User Story ID or Project Name must be empty!"
}
if(!projectKey && !reqKey) {
  errors.reqKey = "Either User Story ID or Project Name must be set!"
  errors.projectKey = "Either User Story ID or Project Name must be set!"
}