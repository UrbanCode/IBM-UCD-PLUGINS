if(projectKey && reqKey) {
  errors.reqKey = "Either User Story ID or Project Name must be empty!"
  errors.projectKey = "Either User Story ID or Project Name must be empty!"
}
if(!projectKey && !reqKey) {
  errors.reqKey = "Either User Story ID or Project Name must be set!"
  errors.projectKey = "Either User Story ID or Project Name must be set!"
}