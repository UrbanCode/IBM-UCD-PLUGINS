import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def out = System.out

//-------------------------------------------------------------------------
// Scripts variables
//=========================================================================

final def props = apTool.getStepProperties()

//get rally props for GETS and POSTS to rally
final String base_url           = new URL(props['rallyUrl']).getHost()
final String url                = props['rallyUrl'] + "/slm/webservice/" + props['rallyVer']+"/"
final String user               = props['rallyUser']
final String password           = props['rallyPass']
final String proxyHost          = props['proxyHost']
final String proxyPort          = props['proxyPort']
final String proxyPass          = props['proxyPass']
final String proxyUser          = props['proxyUser']
final String workspace          = props['workspace']

final String newValue     = props['newValue']
final String artifactKey  = props['artifactKey']
final String defectType   = props['type']
final String property     = props['property']

println "Server:\t" + props['rallyUrl']
println "Artifact(s):\t" + artifactKey
println "Type:\t" + defectType
println "Property:\t" + property
println "New Value:\t" + newValue

//-------------------------------------------------------------------------
// Execute
//=========================================================================

ChangeArtifactProperty cap = new ChangeArtifactProperty()
cap.base_url = base_url
cap.url = url
cap.user = user
cap.password = password
cap.proxyHost = proxyHost
cap.proxyPort = proxyPort
cap.proxyPass = proxyPass
cap.proxyUser = proxyUser
cap.workspace = workspace

cap.newValue = newValue
cap.artifactKey = artifactKey
cap.defectType = defectType
cap.property = property

cap.execute()
