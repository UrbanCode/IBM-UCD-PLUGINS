import sys;
import os;
from org.codehaus.jettison.json import JSONObject, JSONArray, JSONException;

configurationInputFile = sys.argv[1];
inputFile = open(configurationInputFile);
inputData = inputFile.readlines();
fullResConf = ''.join(inputData);

resourceJSONArray = JSONArray(fullResConf);
objMap = {};
for i in range(resourceJSONArray.length()):
  myObj = resourceJSONArray.getJSONObject(i);
  thispath = myObj.getString('path');
  objMap[thispath] = myObj;
  children = myObj.optJSONArray("children");
  if children is None:
      myObj.put("children", JSONArray());

root = None;

for entry in objMap.keys():
  path = entry;
  curObj = objMap[path];

  if (root is None):
    root = curObj;
  else:
    rootPath = root.getString("path");
    if (rootPath.startswith(path + "/")):
      root = curObj;

  objMapKeys = objMap.keys();
  ind = path.rfind("/");
  if (ind != -1):
    parentPath = path[0:ind];
    if parentPath in objMapKeys:
      parent = objMap[parentPath];
      children = parent.optJSONArray("children");
      if children is None:
        children = JSONArray();
        parent.put("children", children);
      children.put(curObj);

resourceJSONObject = root;
print root.toString(4);
