from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = "websphere.datasource.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'DataSource');

  containmentpath = "%(parentconpath)sDataSource:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'DataSource');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereDataSource");
  exportedObject.put("roleName", "WebSphereDataSource");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.statementcachesize", objid, "statementCacheSize","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.logmissingtransactioncontext", objid, "logMissingTransactionContext","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.datasourcehelperclassname", objid, "datasourceHelperClassname","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.authmechanismpreference", objid, "authMechanismPreference","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.providertype", objid, "providerType","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.authdataalias", objid, "authDataAlias","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.jndiname", objid, "jndiName","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.managecachedhandles", objid, "manageCachedHandles","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.category", objid, "category","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.xarecoveryauthalias", objid, "xaRecoveryAuthAlias","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.description", objid, "description","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.diagnoseconnectionusage", objid, "diagnoseConnectionUsage","DataSource");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datasource.name", objid, "name","DataSource");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DataSource resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.datasource.name"):
    raise Exception("Resource role properties does not contain websphere.datasource.name!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create DataSource on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DataSource resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.datasource.name"):
    raise Exception("Resource role properties does not contain websphere.datasource.name!");

  properties = [];
  Util.addIfNotNone(properties, "statementCacheSize", roleProperties.optString("websphere.datasource.statementcachesize", None));
  Util.addIfNotNone(properties, "logMissingTransactionContext", roleProperties.optString("websphere.datasource.logmissingtransactioncontext", None));
  Util.addIfNotNone(properties, "datasourceHelperClassname", roleProperties.optString("websphere.datasource.datasourcehelperclassname", None));
  Util.addIfNotNone(properties, "authMechanismPreference", roleProperties.optString("websphere.datasource.authmechanismpreference", None));
  Util.addIfNotNone(properties, "providerType", roleProperties.optString("websphere.datasource.providertype", None));
  Util.addIfNotNone(properties, "authDataAlias", roleProperties.optString("websphere.datasource.authdataalias", None));
  Util.addIfNotNone(properties, "jndiName", roleProperties.optString("websphere.datasource.jndiname", None));
  Util.addIfNotNone(properties, "manageCachedHandles", roleProperties.optString("websphere.datasource.managecachedhandles", None));
  Util.addIfNotNone(properties, "category", roleProperties.optString("websphere.datasource.category", None));
  Util.addIfNotNone(properties, "xaRecoveryAuthAlias", roleProperties.optString("websphere.datasource.xarecoveryauthalias", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.datasource.description", None));
  Util.addIfNotNone(properties, "diagnoseConnectionUsage", roleProperties.optString("websphere.datasource.diagnoseconnectionusage", None));
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.datasource.name", None));
  print "Creating DataSource with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("DataSource", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DataSource resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.datasource.name"):
    raise Exception("Resource role properties does not contain websphere.datasource.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.statementcachesize", None), "statementCacheSize","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.logmissingtransactioncontext", None), "logMissingTransactionContext","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.datasourcehelperclassname", None), "datasourceHelperClassname","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.authmechanismpreference", None), "authMechanismPreference","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.providertype", None), "providerType","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.authdataalias", None), "authDataAlias","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.jndiname", None), "jndiName","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.managecachedhandles", None), "manageCachedHandles","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.category", None), "category","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.xarecoveryauthalias", None), "xaRecoveryAuthAlias","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.description", None), "description","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.diagnoseconnectionusage", None), "diagnoseConnectionUsage","DataSource");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datasource.name", None), "name","DataSource");
  if len(atts) != 0:
    print "Modifying DataSource with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "DataSource configuration up to date.";

