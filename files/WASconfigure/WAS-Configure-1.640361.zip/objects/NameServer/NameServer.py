from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from Service import Service
from Component import Component
from Property import Property
from utilities import Util
from EndPoint import EndPoint

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereNameServer");
  exportedObject.put("roleName", "WebSphereNameServer");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.nameserver.name", objid, "name","NameServer");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"NameServer");
  extraObjects = Component.exportComponents(objid, respath, extraObjects, typeFolders, 'components', "NameServer");
  extraObjects = Service.exportServices(objid, respath, extraObjects, typeFolders, 'services', "NameServer");

  bootstrapAddress = Util.getOptionalAttribute(objid, 'BOOTSTRAP_ADDRESS', "NameServer");
  if (bootstrapAddress != None):
    returndict = Util.createTypeFolder(respath, "EndPoint", typeFolders);
    currespath = returndict['path'];
    if returndict.has_key('object'):
      extraObjects.append(returndict['object']);
    Util.addAllFromExport(extraObjects, EndPoint._export(bootstrapAddress, currespath, "BOOTSTRAP_ADDRESS"));

  bootstrapServerAddress = Util.getOptionalAttribute(objid, 'bootstrapServerAddress', "NameServer");
  if (bootstrapServerAddress != None):
    returndict = Util.createTypeFolder(respath, "EndPoint", typeFolders);
    currespath = returndict['path'];
    if returndict.has_key('object'):
      extraObjects.append(returndict['object']);
    Util.addAllFromExport(extraObjects, EndPoint._export(bootstrapServerAddress, currespath, "bootstrapServerAddress"));

  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("NameServer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.nameserver.name", None));
  print "Creating NameServer with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("NameServer", parentid, properties);

  Component.removeComponents(objid, 'components', "NameServer");
  Service.removeServices(objid, 'services', "NameServer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      componentObject = 0;
      componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
      if (componentObject == 0):
        propertyObject = 0;
        propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
        if (propertyObject == 0):
          serviceObject = 0;
          serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
          if (serviceObject == 0):
            if currole == "WebSphereEndPoint":
              name = curjsonobject.getString('name');
              if name == "BOOTSTRAP_ADDRESS":
                oep = Util.getRequiredAttribute(objid, "BOOTSTRAP_ADDRESS", "NameServer");
                EndPoint.update(oep, curjsonobject);
              elif name == "bootstrapServerAddress":
                oep = Util.getRequiredAttribute(objid, "bootstrapServerAddress", "NameServer");
                EndPoint.update(oep, curjsonobject);
              else:
                print ("Warning: Attempted to update WebSphereEndPoint but could not find one named " +
                "BOOTSTRAP_ADDRESS or bootstrapServerAddress.  Found one with name " + name + ".");

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("NameServer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.nameserver.name", None), "name","NameServer");
  if len(atts) != 0:
    print "Modifying NameServer with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "NameServer configuration up to date.";

  Property.removeProperties(objid, 'properties',"NameServer");
  Component.removeComponents(objid, 'components', "NameServer");
  Service.removeServices(objid, 'services', "NameServer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      componentObject = 0;
      componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
      if (componentObject == 0):
        propertyObject = 0;
        propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
        if (propertyObject == 0):
          serviceObject = 0;
          serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
          if (serviceObject == 0):
            if currole == "WebSphereEndPoint":
              name = curjsonobject.getString('name');
              if name == "BOOTSTRAP_ADDRESS":
                oep = Util.getRequiredAttribute(objid, "BOOTSTRAP_ADDRESS", "NameServer");
                EndPoint.update(oep, curjsonobject);
              elif name == "bootstrapServerAddress":
                oep = Util.getRequiredAttribute(objid, "bootstrapServerAddress", "NameServer");
                EndPoint.update(oep, curjsonobject);
              else:
                print ("Warning: Attempted to update WebSphereEndPoint but could not find one named " +
                "BOOTSTRAP_ADDRESS or bootstrapServerAddress.  Found one with name " + name + ".");
