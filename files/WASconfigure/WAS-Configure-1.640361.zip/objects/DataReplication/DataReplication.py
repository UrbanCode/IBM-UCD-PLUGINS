from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereDataReplication");
  exportedObject.put("roleName", "WebSphereDataReplication");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.requesttimeout", objid, "requestTimeout","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.encryptiontype", objid, "encryptionType","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.usessl", objid, "useSSL","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.userid", objid, "userId","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.encryptionkeyvalue", objid, "encryptionKeyValue","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.messagebrokername", objid, "messageBrokerName","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.password", objid, "password","DataReplication");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.datareplication.numberofreplicas", objid, "numberOfReplicas","DataReplication");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DataReplication resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "requestTimeout", roleProperties.optString("websphere.datareplication.requesttimeout", None));
  Util.addIfNotNone(properties, "encryptionType", roleProperties.optString("websphere.datareplication.encryptiontype", None));
  Util.addIfNotNone(properties, "useSSL", roleProperties.optString("websphere.datareplication.usessl", None));
  Util.addIfNotNone(properties, "userId", roleProperties.optString("websphere.datareplication.userid", None));
  Util.addIfNotNone(properties, "encryptionKeyValue", roleProperties.optString("websphere.datareplication.encryptionkeyvalue", None));
  Util.addIfNotNone(properties, "messageBrokerName", roleProperties.optString("websphere.datareplication.messagebrokername", None));
  Util.addIfNotNone(properties, "password", roleProperties.optString("websphere.datareplication.password", None));
  Util.addIfNotNone(properties, "numberOfReplicas", roleProperties.optString("websphere.datareplication.numberofreplicas", None));
  print "Creating DataReplication with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("DataReplication", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DataReplication resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.requesttimeout", None), "requestTimeout","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.encryptiontype", None), "encryptionType","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.usessl", None), "useSSL","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.userid", None), "userId","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.encryptionkeyvalue", None), "encryptionKeyValue","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.messagebrokername", None), "messageBrokerName","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.password", None), "password","DataReplication");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.datareplication.numberofreplicas", None), "numberOfReplicas","DataReplication");
  if len(atts) != 0:
    print "Modifying DataReplication with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "DataReplication configuration up to date.";

