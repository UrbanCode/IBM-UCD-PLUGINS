from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = "websphere.cell"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'Cell');

  containmentpath = "%(parentconpath)sCell:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'Cell');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereCell");
  exportedObject.put("roleName", "WebSphereCell");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell", objid, "name","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.enablebidi", objid, "enableBiDi","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.cellregistered", objid, "cellRegistered","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.shortname", objid, "shortName","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.biditextdirection", objid, "biDiTextDirection","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.celldiscoveryprotocol", objid, "cellDiscoveryProtocol","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.celltype", objid, "cellType","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.discoveryaddressendpointname", objid, "discoveryAddressEndpointName","Cell");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cell.multicastdiscoveryaddressendpointname", objid, "multicastDiscoveryAddressEndpointName","Cell");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("Cell resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.cell"):
    raise Exception("Resource role properties does not contain websphere.cell!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create Cell on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("Cell resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.cell"):
    raise Exception("Resource role properties does not contain websphere.cell!");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.cell", None));
  Util.addIfNotNone(properties, "enableBiDi", roleProperties.optString("websphere.cell.enablebidi", None));
  Util.addIfNotNone(properties, "cellRegistered", roleProperties.optString("websphere.cell.cellregistered", None));
  Util.addIfNotNone(properties, "shortName", roleProperties.optString("websphere.cell.shortname", None));
  Util.addIfNotNone(properties, "biDiTextDirection", roleProperties.optString("websphere.cell.biditextdirection", None));
  Util.addIfNotNone(properties, "cellDiscoveryProtocol", roleProperties.optString("websphere.cell.celldiscoveryprotocol", None));
  Util.addIfNotNone(properties, "cellType", roleProperties.optString("websphere.cell.celltype", None));
  Util.addIfNotNone(properties, "discoveryAddressEndpointName", roleProperties.optString("websphere.cell.discoveryaddressendpointname", None));
  Util.addIfNotNone(properties, "multicastDiscoveryAddressEndpointName", roleProperties.optString("websphere.cell.multicastdiscoveryaddressendpointname", None));
  print "Creating Cell with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("Cell", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("Cell resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.cell"):
    raise Exception("Resource role properties does not contain websphere.cell!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell", None), "name","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.enablebidi", None), "enableBiDi","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.cellregistered", None), "cellRegistered","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.shortname", None), "shortName","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.biditextdirection", None), "biDiTextDirection","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.celldiscoveryprotocol", None), "cellDiscoveryProtocol","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.celltype", None), "cellType","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.discoveryaddressendpointname", None), "discoveryAddressEndpointName","Cell");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cell.multicastdiscoveryaddressendpointname", None), "multicastDiscoveryAddressEndpointName","Cell");
  if len(atts) != 0:
    print "Modifying Cell with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "Cell configuration up to date.";

