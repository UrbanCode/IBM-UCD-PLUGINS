from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from CoreGroupServerRef import CoreGroupServerRef
from MatchCriteria import MatchCriteria 
from Property import Property
from utilities import Util

__name_att__ = "websphere.oneofnpolicy.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'OneOfNPolicy');

  containmentpath = "%(parentconpath)sOneOfNPolicy:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'OneOfNPolicy');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereOneOfNPolicy");
  exportedObject.put("roleName", "WebSphereOneOfNPolicy");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.name", objid, "name","OneOfNPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.failback", objid, "failback","OneOfNPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.quorumenabled", objid, "quorumEnabled","OneOfNPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.preferredonly", objid, "preferredOnly","OneOfNPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.description", objid, "description","OneOfNPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.policyfactory", objid, "policyFactory","OneOfNPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.oneofnpolicy.isaliveperiodsec", objid, "isAlivePeriodSec","OneOfNPolicy");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  i = 0;
  coregroupservers = Util.parseConfigIdListAttribute(objid, 'preferredServers',"OneOfNPolicy");
  for coregroupserver in coregroupservers:
    if len(coregroupserver) > 0:
      returndict = Util.createTypeFolder(respath, "PreferredServer", typeFolders);
      currespath = returndict['path'];
      if returndict.has_key('object'):
        extraObjects.append(returndict['object']);
      Util.addAllFromExport(extraObjects, CoreGroupServerRef._export(coregroupserver, currespath, "PreferredServer%s" % i));
      i = i + 1;
  first = 0;
  matchcriterias = Util.parseConfigIdListAttribute(objid, 'MatchCriteria',"OneOfNPolicy");
  for criteria in matchcriterias:
    returndict = Util.createTypeFolder(respath, "MatchCriteria", typeFolders);
    currespath = returndict['path'];
    if returndict.has_key('object'):
      extraObjects.append(returndict['object']);
    Util.addAllFromExport(extraObjects, MatchCriteria._export(criteria, currespath));

  extraObjects = Property.exportProperties(objid,respath,extraObjects,typeFolders,'customProperties',"OneOfNPolicy");

  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("OneOfNPolicy resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.oneofnpolicy.name"):
    raise Exception("Resource role properties does not contain websphere.oneofnpolicy.name!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create OneOfNPolicy on.");
    objid = create(parentid, jsonobject);
  else:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    update(objid,jsonobject, parentid);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("OneOfNPolicy resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.oneofnpolicy.name"):
    raise Exception("Resource role properties does not contain websphere.oneofnpolicy.name!");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.oneofnpolicy.name", None));
  Util.addIfNotNone(properties, "failback", roleProperties.optString("websphere.oneofnpolicy.failback", None));
  Util.addIfNotNone(properties, "quorumEnabled", roleProperties.optString("websphere.oneofnpolicy.quorumenabled", None));
  Util.addIfNotNone(properties, "preferredOnly", roleProperties.optString("websphere.oneofnpolicy.preferredonly", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.oneofnpolicy.description", None));
  Util.addIfNotNone(properties, "policyFactory", roleProperties.optString("websphere.oneofnpolicy.policyfactory", None));
  Util.addIfNotNone(properties, "isAlivePeriodSec", roleProperties.optString("websphere.oneofnpolicy.isaliveperiodsec", None));
  print "Creating OneOfNPolicy with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("OneOfNPolicy", parentid, properties);

  coreGroupServers = Util.parseConfigIdListAttribute(parentid, 'coreGroupServers',"OneOfNPolicy");
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
      if (propertyObject == 0):
        if currole == "WebSphereCoreGroupServerRef":
          CoreGroupServerRef.create(objid, curjsonobject, 'preferredServers', coreGroupServers);
        elif currole == "WebSphereMatchCriteria":
          MatchCriteria.create(objid, curjsonobject);
  return objid;


def update(objid,jsonobject,parentid = None):
  if not jsonobject.has("roleProperties"):
    raise Exception("OneOfNPolicy resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.oneofnpolicy.name"):
    raise Exception("Resource role properties does not contain websphere.oneofnpolicy.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.name", None), "name","OneOfNPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.failback", None), "failback","OneOfNPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.quorumenabled", None), "quorumEnabled","OneOfNPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.preferredonly", None), "preferredOnly","OneOfNPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.description", None), "description","OneOfNPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.policyfactory", None), "policyFactory","OneOfNPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.oneofnpolicy.isaliveperiodsec", None), "isAlivePeriodSec","OneOfNPolicy");
  if len(atts) != 0:
    print "Modifying OneOfNPolicy with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "OneOfNPolicy configuration up to date.";

  AdminConfig.modify(objid, [['preferredServers', '']]);
  AdminConfig.modify(objid, [['MatchCriteria', '']]);
  Property.removeProperties(objid, 'customProperties',"OneOfNPolicy");

  coreGroupServers = None;
  if parentid is not None and len(parentid) > 0:
    #the parent of policies has to be a CoreGroup
    coreGroupServers = Util.parseConfigIdListAttribute(parentid, 'coreGroupServers',"OneOfNPolicy");
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
      if (propertyObject == 0):
        if currole == "WebSphereCoreGroupServerRef":
          CoreGroupServerRef.create(objid, curjsonobject, 'preferredServers', coreGroupServers);
        elif currole == "WebSphereMatchCriteria":
          MatchCriteria.create(objid, curjsonobject);

