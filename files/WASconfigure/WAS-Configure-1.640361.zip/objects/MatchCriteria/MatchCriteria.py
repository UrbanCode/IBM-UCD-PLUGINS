from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):

  if len(name) == 0:
    name = Util.getRequiredAttribute(objid, 'name', 'MatchCriteria');

  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereMatchCriteria");
  exportedObject.put("roleName", "WebSphereMatchCriteria");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.matchcriteria.name", objid, "name","MatchCriteria");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.matchcriteria.description", objid, "description","MatchCriteria");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.matchcriteria.value", objid, "value","MatchCriteria");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("MatchCriteria resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.matchcriteria.name", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.matchcriteria.description", None));
  Util.addIfNotNone(properties, "value", roleProperties.optString("websphere.matchcriteria.value", None));
  print "Creating MatchCriteria with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("MatchCriteria", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("MatchCriteria resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.matchcriteria.name", None), "name","MatchCriteria");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.matchcriteria.description", None), "description","MatchCriteria");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.matchcriteria.value", None), "value","MatchCriteria");
  if len(atts) != 0:
    print "Modifying MatchCriteria with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "MatchCriteria configuration up to date.";

