from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereKeySet");
  exportedObject.put("roleName", "WebSphereKeySet");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.name", objid, "name","KeySet");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.keygenerationclass", objid, "keyGenerationClass","KeySet");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.maxkeyreferences", objid, "maxKeyReferences","KeySet");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.deleteoldkeys", objid, "deleteOldKeys","KeySet");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.iskeypair", objid, "isKeyPair","KeySet");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.password", objid, "password","KeySet");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keyset.aliasprefix", objid, "aliasPrefix","KeySet");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("KeySet resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.keyset.name", None));
  Util.addIfNotNone(properties, "keyGenerationClass", roleProperties.optString("websphere.keyset.keygenerationclass", None));
  Util.addIfNotNone(properties, "maxKeyReferences", roleProperties.optString("websphere.keyset.maxkeyreferences", None));
  Util.addIfNotNone(properties, "deleteOldKeys", roleProperties.optString("websphere.keyset.deleteoldkeys", None));
  Util.addIfNotNone(properties, "isKeyPair", roleProperties.optString("websphere.keyset.iskeypair", None));
  Util.addIfNotNone(properties, "password", roleProperties.optString("websphere.keyset.password", None));
  Util.addIfNotNone(properties, "aliasPrefix", roleProperties.optString("websphere.keyset.aliasprefix", None));
  print "Creating KeySet with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("KeySet", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("KeySet resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.name", None), "name","KeySet");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.keygenerationclass", None), "keyGenerationClass","KeySet");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.maxkeyreferences", None), "maxKeyReferences","KeySet");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.deleteoldkeys", None), "deleteOldKeys","KeySet");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.iskeypair", None), "isKeyPair","KeySet");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.password", None), "password","KeySet");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keyset.aliasprefix", None), "aliasPrefix","KeySet");
  if len(atts) != 0:
    print "Modifying KeySet with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "KeySet configuration up to date.";

