from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereCustomAdvisor");
  exportedObject.put("roleName", "WebSphereCustomAdvisor");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.blaid", objid, "blaID","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.enablelogging", objid, "enableLogging","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.pollinterval", objid, "pollInterval","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.cuid", objid, "cuID","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.iotimeout", objid, "ioTimeout","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.connecttimeout", objid, "connectTimeout","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.enablelogfilewrapping", objid, "enableLogFileWrapping","CustomAdvisor");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customadvisor.logfilesize", objid, "logFileSize","CustomAdvisor");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"CustomAdvisor");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CustomAdvisor resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "blaID", roleProperties.optString("websphere.customadvisor.blaid", None));
  Util.addIfNotNone(properties, "enableLogging", roleProperties.optString("websphere.customadvisor.enablelogging", None));
  Util.addIfNotNone(properties, "pollInterval", roleProperties.optString("websphere.customadvisor.pollinterval", None));
  Util.addIfNotNone(properties, "cuID", roleProperties.optString("websphere.customadvisor.cuid", None));
  Util.addIfNotNone(properties, "ioTimeout", roleProperties.optString("websphere.customadvisor.iotimeout", None));
  Util.addIfNotNone(properties, "connectTimeout", roleProperties.optString("websphere.customadvisor.connecttimeout", None));
  Util.addIfNotNone(properties, "enableLogFileWrapping", roleProperties.optString("websphere.customadvisor.enablelogfilewrapping", None));
  Util.addIfNotNone(properties, "logFileSize", roleProperties.optString("websphere.customadvisor.logfilesize", None));
  print "Creating CustomAdvisor with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("CustomAdvisor", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CustomAdvisor resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.blaid", None), "blaID","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.enablelogging", None), "enableLogging","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.pollinterval", None), "pollInterval","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.cuid", None), "cuID","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.iotimeout", None), "ioTimeout","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.connecttimeout", None), "connectTimeout","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.enablelogfilewrapping", None), "enableLogFileWrapping","CustomAdvisor");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customadvisor.logfilesize", None), "logFileSize","CustomAdvisor");
  if len(atts) != 0:
    print "Modifying CustomAdvisor with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "CustomAdvisor configuration up to date.";

  Property.removeProperties(objid, 'properties',"CustomAdvisor");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
