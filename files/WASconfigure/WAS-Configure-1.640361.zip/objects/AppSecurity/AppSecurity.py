from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereAppSecurity");
  exportedObject.put("roleName", "WebSphereAppSecurity");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.allowbasicauth", objid, "allowBasicAuth","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.uselocalsecurityserver", objid, "useLocalSecurityServer","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.usedomainqualifiedusernames", objid, "useDomainQualifiedUserNames","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.enabled", objid, "enabled","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.cachetimeout", objid, "cacheTimeout","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.enforcefinegrainedjcasecurity", objid, "enforceFineGrainedJCASecurity","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.enablejava2secruntimefiltering", objid, "enableJava2SecRuntimeFiltering","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.enforcejava2security", objid, "enforceJava2Security","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.allowallpermissionforapplication", objid, "allowAllPermissionForApplication","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.appenabled", objid, "appEnabled","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.dynamicallyupdatesslconfig", objid, "dynamicallyUpdateSSLConfig","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.activeprotocol", objid, "activeProtocol","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.internalserverid", objid, "internalServerId","AppSecurity");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.appsecurity.issuepermissionwarning", objid, "issuePermissionWarning","AppSecurity");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"AppSecurity");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AppSecurity resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "allowBasicAuth", roleProperties.optString("websphere.appsecurity.allowbasicauth", None));
  Util.addIfNotNone(properties, "useLocalSecurityServer", roleProperties.optString("websphere.appsecurity.uselocalsecurityserver", None));
  Util.addIfNotNone(properties, "useDomainQualifiedUserNames", roleProperties.optString("websphere.appsecurity.usedomainqualifiedusernames", None));
  Util.addIfNotNone(properties, "enabled", roleProperties.optString("websphere.appsecurity.enabled", None));
  Util.addIfNotNone(properties, "cacheTimeout", roleProperties.optString("websphere.appsecurity.cachetimeout", None));
  Util.addIfNotNone(properties, "enforceFineGrainedJCASecurity", roleProperties.optString("websphere.appsecurity.enforcefinegrainedjcasecurity", None));
  Util.addIfNotNone(properties, "enableJava2SecRuntimeFiltering", roleProperties.optString("websphere.appsecurity.enablejava2secruntimefiltering", None));
  Util.addIfNotNone(properties, "enforceJava2Security", roleProperties.optString("websphere.appsecurity.enforcejava2security", None));
  Util.addIfNotNone(properties, "allowAllPermissionForApplication", roleProperties.optString("websphere.appsecurity.allowallpermissionforapplication", None));
  Util.addIfNotNone(properties, "appEnabled", roleProperties.optString("websphere.appsecurity.appenabled", None));
  Util.addIfNotNone(properties, "dynamicallyUpdateSSLConfig", roleProperties.optString("websphere.appsecurity.dynamicallyupdatesslconfig", None));
  Util.addIfNotNone(properties, "activeProtocol", roleProperties.optString("websphere.appsecurity.activeprotocol", None));
  Util.addIfNotNone(properties, "internalServerId", roleProperties.optString("websphere.appsecurity.internalserverid", None));
  Util.addIfNotNone(properties, "issuePermissionWarning", roleProperties.optString("websphere.appsecurity.issuepermissionwarning", None));
  print "Creating AppSecurity with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("AppSecurity", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);


def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AppSecurity resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.allowbasicauth", None), "allowBasicAuth","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.uselocalsecurityserver", None), "useLocalSecurityServer","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.usedomainqualifiedusernames", None), "useDomainQualifiedUserNames","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.enabled", None), "enabled","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.cachetimeout", None), "cacheTimeout","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.enforcefinegrainedjcasecurity", None), "enforceFineGrainedJCASecurity","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.enablejava2secruntimefiltering", None), "enableJava2SecRuntimeFiltering","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.enforcejava2security", None), "enforceJava2Security","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.allowallpermissionforapplication", None), "allowAllPermissionForApplication","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.appenabled", None), "appEnabled","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.dynamicallyupdatesslconfig", None), "dynamicallyUpdateSSLConfig","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.activeprotocol", None), "activeProtocol","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.internalserverid", None), "internalServerId","AppSecurity");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.appsecurity.issuepermissionwarning", None), "issuePermissionWarning","AppSecurity");
  if len(atts) != 0:
    print "Modifying AppSecurity with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "AppSecurity configuration up to date.";

  Property.removeProperties(objid, 'properties',"AppSecurity");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
