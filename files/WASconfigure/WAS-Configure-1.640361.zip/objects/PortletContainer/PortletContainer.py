from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from Service import Service
from Component import Component
from Property import Property
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSpherePortletContainer");
  exportedObject.put("roleName", "WebSpherePortletContainer");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.portletcontainer.name", objid, "name","PortletContainer");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.portletcontainer.enableportletcaching", objid, "enablePortletCaching","PortletContainer");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.portletcontainer.maxprocesseventcount", objid, "maxProcessEventCount","PortletContainer");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"PortletContainer");
  extraObjects = Component.exportComponents(objid, respath, extraObjects, typeFolders, 'components', "PortletContainer");
  extraObjects = Service.exportServices(objid, respath, extraObjects, typeFolders, 'services', "PortletContainer");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("PortletContainer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.portletcontainer.name", None));
  Util.addIfNotNone(properties, "enablePortletCaching", roleProperties.optString("websphere.portletcontainer.enableportletcaching", None));
  Util.addIfNotNone(properties, "maxProcessEventCount", roleProperties.optString("websphere.portletcontainer.maxprocesseventcount", None));
  print "Creating PortletContainer with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("PortletContainer", parentid, properties);

  Component.removeComponents(objid, 'components', "PortletContainer");
  Service.removeServices(objid, 'services', "PortletContainer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      serviceObject = 0;
      componentObject = 0;
      propertyObject = 0;
      serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
      if (serviceObject == 0):
        componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
        if (componentObject == 0):
          propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("PortletContainer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.portletcontainer.name", None), "name","PortletContainer");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.portletcontainer.enableportletcaching", None), "enablePortletCaching","PortletContainer");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.portletcontainer.maxprocesseventcount", None), "maxProcessEventCount","PortletContainer");
  if len(atts) != 0:
    print "Modifying PortletContainer with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "PortletContainer configuration up to date.";

  Property.removeProperties(objid, 'properties',"PortletContainer");
  Component.removeComponents(objid, 'components', "PortletContainer");
  Service.removeServices(objid, 'services', "PortletContainer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      serviceObject = 0;
      componentObject = 0;
      propertyObject = 0;
      serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
      if (serviceObject == 0):
        componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
        if (componentObject == 0):
          propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
