from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereMethodMessageCondition");
  exportedObject.put("roleName", "WebSphereMethodMessageCondition");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.methodmessagecondition.value", objid, "value","MethodMessageCondition");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"MethodMessageCondition");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("MethodMessageCondition resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "value", roleProperties.optString("websphere.methodmessagecondition.value", None));
  print "Creating MethodMessageCondition with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("MethodMessageCondition", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("MethodMessageCondition resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.methodmessagecondition.value", None), "value","MethodMessageCondition");
  if len(atts) != 0:
    print "Modifying MethodMessageCondition with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "MethodMessageCondition configuration up to date.";

  Property.removeProperties(objid, 'properties',"MethodMessageCondition");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
