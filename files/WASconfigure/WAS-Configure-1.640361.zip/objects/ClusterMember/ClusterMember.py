from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = "websphere.clustermember.membername";

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "memberName", 'ClusterMember');

  containmentpath = "%(parentconpath)sClusterMember:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath, name = ""):

  if name is None or len(name) <1:
    name = Util.getRequiredAttribute(objid, "memberName", 'ClusterMember');

  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereClusterMember");
  exportedObject.put("roleName", "WebSphereClusterMember");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.clustermember.membername", objid, "memberName","ClusterMember");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.clustermember.weight", objid, "weight","ClusterMember");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.clustermember.nodename", objid, "nodeName","ClusterMember");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;


def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ClusterMember resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.clustermember.membername"):
    raise Exception("Resource role properties does not contain websphere.clustermember.membername!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create ClusterMember on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;

def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ClusterMember resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.clustermember.membername"):
    raise Exception("Resource role properties does not contain websphere.clustermember.membername!");

  properties = [];
  Util.addIfNotNone(properties, "memberName", roleProperties.optString("websphere.clustermember.membername", None));
  Util.addIfNotNone(properties, "weight", roleProperties.optString("websphere.clustermember.weight", None));
  Util.addIfNotNone(properties, "nodeName", roleProperties.optString("websphere.clustermember.nodename", None));
  print "Creating ClusterMember with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("ClusterMember", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ClusterMember resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.clustermember.membername"):
    raise Exception("Resource role properties does not contain websphere.clustermember.membername!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.clustermember.membername", None), "memberName","ClusterMember");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.clustermember.weight", None), "weight","ClusterMember");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.clustermember.nodename", None), "nodeName","ClusterMember");
  if len(atts) != 0:
    print "Modifying ClusterMember with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "ClusterMember configuration up to date.";

