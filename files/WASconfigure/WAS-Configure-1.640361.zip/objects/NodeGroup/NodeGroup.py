from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = "websphere.nodegroup.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'NodeGroup');

  containmentpath = "%(parentconpath)sNodeGroup:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'NodeGroup');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereNodeGroup");
  exportedObject.put("roleName", "WebSphereNodeGroup");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.nodegroup.shortname", objid, "shortName","NodeGroup");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.nodegroup.name", objid, "name","NodeGroup");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.nodegroup.description", objid, "description","NodeGroup");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("NodeGroup resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.nodegroup.name"):
    raise Exception("Resource role properties does not contain websphere.nodegroup.name!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create NodeGroup on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("NodeGroup resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.nodegroup.name"):
    raise Exception("Resource role properties does not contain websphere.nodegroup.name!");

  properties = [];
  Util.addIfNotNone(properties, "shortName", roleProperties.optString("websphere.nodegroup.shortname", None));
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.nodegroup.name", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.nodegroup.description", None));
  print "Creating NodeGroup with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("NodeGroup", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("NodeGroup resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.nodegroup.name"):
    raise Exception("Resource role properties does not contain websphere.nodegroup.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.nodegroup.shortname", None), "shortName","NodeGroup");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.nodegroup.name", None), "name","NodeGroup");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.nodegroup.description", None), "description","NodeGroup");
  if len(atts) != 0:
    print "Modifying NodeGroup with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "NodeGroup configuration up to date.";

