from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereHTTPRequestHeaderAction");
  exportedObject.put("roleName", "WebSphereHTTPRequestHeaderAction");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.httprequestheaderaction.name", objid, "name","HTTPRequestHeaderAction");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.httprequestheaderaction.headermodifyaction", objid, "headerModifyAction","HTTPRequestHeaderAction");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.httprequestheaderaction.headervalueexpression", objid, "headerValueExpression","HTTPRequestHeaderAction");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.httprequestheaderaction.headername", objid, "headerName","HTTPRequestHeaderAction");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.httprequestheaderaction.headervalue", objid, "headerValue","HTTPRequestHeaderAction");
  Util.addAttributePathPropertyToJson(roleProperties, "websphere.httprequestheaderaction.methodnames", objid, "methodNames","HTTPRequestHeaderAction");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"HTTPRequestHeaderAction");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("HTTPRequestHeaderAction resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.httprequestheaderaction.name", None));
  Util.addIfNotNone(properties, "headerModifyAction", roleProperties.optString("websphere.httprequestheaderaction.headermodifyaction", None));
  Util.addIfNotNone(properties, "headerValueExpression", roleProperties.optString("websphere.httprequestheaderaction.headervalueexpression", None));
  Util.addIfNotNone(properties, "headerName", roleProperties.optString("websphere.httprequestheaderaction.headername", None));
  Util.addIfNotNone(properties, "headerValue", roleProperties.optString("websphere.httprequestheaderaction.headervalue", None));
  Util.addPathProperty(properties, "methodNames", roleProperties.optString("websphere.httprequestheaderaction.methodnames", None));
  print "Creating HTTPRequestHeaderAction with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("HTTPRequestHeaderAction", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("HTTPRequestHeaderAction resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.httprequestheaderaction.name", None), "name","HTTPRequestHeaderAction");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.httprequestheaderaction.headermodifyaction", None), "headerModifyAction","HTTPRequestHeaderAction");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.httprequestheaderaction.headervalueexpression", None), "headerValueExpression","HTTPRequestHeaderAction");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.httprequestheaderaction.headername", None), "headerName","HTTPRequestHeaderAction");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.httprequestheaderaction.headervalue", None), "headerValue","HTTPRequestHeaderAction");
  Util.addPathAttIfChanged(objid, atts, roleProperties.optString("websphere.httprequestheaderaction.methodnames", None), "methodNames","HTTPRequestHeaderAction");
  if len(atts) != 0:
    print "Modifying HTTPRequestHeaderAction with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "HTTPRequestHeaderAction configuration up to date.";

  Property.removeProperties(objid, 'properties',"HTTPRequestHeaderAction");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
