from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from HTTPConnector import HTTPConnector
from JMSConnector import JMSConnector
from RMIConnector import RMIConnector
from SOAPConnector import SOAPConnector
from IPCConnector import IPCConnector
from JSR160RMIConnector import JSR160RMIConnector
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereJMXConnector");
  exportedObject.put("roleName", "WebSphereJMXConnector");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.jmxconnector.enable", objid, "enable","JMXConnector");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"JMXConnector");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("JMXConnector resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "enable", roleProperties.optString("websphere.jmxconnector.enable", None));
  print "Creating JMXConnector with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("JMXConnector", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("JMXConnector resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.jmxconnector.enable", None), "enable","JMXConnector");
  if len(atts) != 0:
    print "Modifying JMXConnector with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "JMXConnector configuration up to date.";

  Property.removeProperties(objid, 'properties',"JMXConnector");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def removeJMXConnectors(objid, attributeName, parentType):
  jmxconnectors = Util.parseConfigIdListAttribute(objid, attributeName, parentType);
  if jmxconnectors is not None and len(jmxconnectors) > 0:
    for jmxconnector in jmxconnectors:
      AdminConfig.remove(jmxconnector);

def exportJMXConnectors(objid, respath, extraObjects, typeFolders, attributeName, parentType):
  counterHTTPConnector = 0;
  counterJMSConnector = 0;
  counterRMIConnector = 0;
  counterSOAPConnector = 0;
  counterIPCConnector = 0;
  counterJSR160RMIConnector = 0;

  jmxconnectors = Util.parseConfigIdListAttribute(objid, attributeName, parentType);
  if jmxconnectors is not None and len(jmxconnectors) > 0:
    for jmxconnector in jmxconnectors:
      if len(jmxconnector) > 0:
        if jmxconnector.find("#HTTPConnector_") != -1:
          returndict = Util.createTypeFolder(respath, "HTTPConnector", typeFolders);
          currespath = returndict['path'];
          if returndict.has_key('object'):
            extraObjects.append(returndict['object']);
          Util.addAllFromExport(extraObjects, HTTPConnector._export(jmxconnector, currespath, 'HTTPConnector%s' % counterHTTPConnector));
          counterHTTPConnector = counterHTTPConnector + 1;
        elif jmxconnector.find("#JMSConnector_") != -1:
          returndict = Util.createTypeFolder(respath, "JMSConnector", typeFolders);
          currespath = returndict['path'];
          if returndict.has_key('object'):
            extraObjects.append(returndict['object']);
          Util.addAllFromExport(extraObjects, JMSConnector._export(jmxconnector, currespath, 'JMSConnector%s' % counterJMSConnector));
          counterJMSConnector = counterJMSConnector + 1;
        elif jmxconnector.find("#RMIConnector_") != -1:
          returndict = Util.createTypeFolder(respath, "RMIConnector", typeFolders);
          currespath = returndict['path'];
          if returndict.has_key('object'):
            extraObjects.append(returndict['object']);
          Util.addAllFromExport(extraObjects, RMIConnector._export(jmxconnector, currespath, 'RMIConnector%s' % counterRMIConnector));
          counterRMIConnector = counterRMIConnector + 1;
        elif jmxconnector.find("#SOAPConnector_") != -1:
          returndict = Util.createTypeFolder(respath, "SOAPConnector", typeFolders);
          currespath = returndict['path'];
          if returndict.has_key('object'):
            extraObjects.append(returndict['object']);
          Util.addAllFromExport(extraObjects, SOAPConnector._export(jmxconnector, currespath, 'SOAPConnector%s' % counterSOAPConnector));
          counterSOAPConnector = counterSOAPConnector + 1;
        elif jmxconnector.find("#IPCConnector_") != -1:
          returndict = Util.createTypeFolder(respath, "IPCConnector", typeFolders);
          currespath = returndict['path'];
          if returndict.has_key('object'):
            extraObjects.append(returndict['object']);
          Util.addAllFromExport(extraObjects, IPCConnector._export(jmxconnector, currespath, 'IPCConnector%s' % counterIPCConnector));
          counterIPCConnector = counterIPCConnector + 1;
        elif jmxconnector.find("#JSR160RMIConnector_") != -1:
          returndict = Util.createTypeFolder(respath, "JSR160RMIConnector", typeFolders);
          currespath = returndict['path'];
          if returndict.has_key('object'):
            extraObjects.append(returndict['object']);
          Util.addAllFromExport(extraObjects, JSR160RMIConnector._export(jmxconnector, currespath, 'JSR160RMIConnector%s' % counterJSR160RMIConnector));
          counterJSR160RMIConnector = counterJSR160RMIConnector + 1;

  return extraObjects;

def createObjIfRole(objid, curjsonobject, currole):
  if currole == "WebSphereHTTPConnector":
    HTTPConnector.create(objid, curjsonobject);
    return 1;
  elif currole == "WebSphereJMSConnector":
    JMSConnector.create(objid, curjsonobject);
    return 1;
  elif currole == "WebSphereRMIConnector":
    RMIConnector.create(objid, curjsonobject);
    return 1;
  elif currole == "WebSphereSOAPConnector":
    SOAPConnector.create(objid, curjsonobject);
    return 1;
  elif currole == "WebSphereIPCConnector":
    IPCConnector.create(objid, curjsonobject);
    return 1;
  elif currole == "WebSphereJSR160RMIConnector":
    JSR160RMIConnector.create(objid, curjsonobject);
    return 1;
  return 0;
