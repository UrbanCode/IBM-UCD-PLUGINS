from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereCookieMapping");
  exportedObject.put("roleName", "WebSphereCookieMapping");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cookiemapping.port", objid, "port","CookieMapping");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cookiemapping.host", objid, "host","CookieMapping");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.cookiemapping.cookievalue", objid, "cookieValue","CookieMapping");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CookieMapping resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "port", roleProperties.optString("websphere.cookiemapping.port", None));
  Util.addIfNotNone(properties, "host", roleProperties.optString("websphere.cookiemapping.host", None));
  Util.addIfNotNone(properties, "cookieValue", roleProperties.optString("websphere.cookiemapping.cookievalue", None));
  print "Creating CookieMapping with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("CookieMapping", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CookieMapping resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cookiemapping.port", None), "port","CookieMapping");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cookiemapping.host", None), "host","CookieMapping");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.cookiemapping.cookievalue", None), "cookieValue","CookieMapping");
  if len(atts) != 0:
    print "Modifying CookieMapping with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "CookieMapping configuration up to date.";

