from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereDynamicSSLConfigSelection");
  exportedObject.put("roleName", "WebSphereDynamicSSLConfigSelection");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamicsslconfigselection.name", objid, "name","DynamicSSLConfigSelection");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamicsslconfigselection.description", objid, "description","DynamicSSLConfigSelection");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamicsslconfigselection.dynamicselectioninfo", objid, "dynamicSelectionInfo","DynamicSSLConfigSelection");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamicsslconfigselection.certificatealias", objid, "certificateAlias","DynamicSSLConfigSelection");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DynamicSSLConfigSelection resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.dynamicsslconfigselection.name", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.dynamicsslconfigselection.description", None));
  Util.addIfNotNone(properties, "dynamicSelectionInfo", roleProperties.optString("websphere.dynamicsslconfigselection.dynamicselectioninfo", None));
  Util.addIfNotNone(properties, "certificateAlias", roleProperties.optString("websphere.dynamicsslconfigselection.certificatealias", None));
  print "Creating DynamicSSLConfigSelection with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("DynamicSSLConfigSelection", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DynamicSSLConfigSelection resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamicsslconfigselection.name", None), "name","DynamicSSLConfigSelection");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamicsslconfigselection.description", None), "description","DynamicSSLConfigSelection");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamicsslconfigselection.dynamicselectioninfo", None), "dynamicSelectionInfo","DynamicSSLConfigSelection");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamicsslconfigselection.certificatealias", None), "certificateAlias","DynamicSSLConfigSelection");
  if len(atts) != 0:
    print "Modifying DynamicSSLConfigSelection with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "DynamicSSLConfigSelection configuration up to date.";

