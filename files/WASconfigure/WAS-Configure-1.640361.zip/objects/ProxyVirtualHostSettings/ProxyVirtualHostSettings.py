from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereProxyVirtualHostSettings");
  exportedObject.put("roleName", "WebSphereProxyVirtualHostSettings");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.enablelogging", objid, "enableLogging","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.localaccesslog", objid, "localAccessLog","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.useserverloggingsettings", objid, "useServerLoggingSettings","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.proxyaccesslog", objid, "proxyAccessLog","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.useserverstaticfilesettings", objid, "useServerStaticFileSettings","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.useservererrorpagesettings", objid, "useServerErrorPageSettings","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.cacheaccesslog", objid, "cacheAccessLog","ProxyVirtualHostSettings");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.proxyvirtualhostsettings.maximumlogsize", objid, "maximumLogSize","ProxyVirtualHostSettings");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ProxyVirtualHostSettings resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "enableLogging", roleProperties.optString("websphere.proxyvirtualhostsettings.enablelogging", None));
  Util.addIfNotNone(properties, "localAccessLog", roleProperties.optString("websphere.proxyvirtualhostsettings.localaccesslog", None));
  Util.addIfNotNone(properties, "useServerLoggingSettings", roleProperties.optString("websphere.proxyvirtualhostsettings.useserverloggingsettings", None));
  Util.addIfNotNone(properties, "proxyAccessLog", roleProperties.optString("websphere.proxyvirtualhostsettings.proxyaccesslog", None));
  Util.addIfNotNone(properties, "useServerStaticFileSettings", roleProperties.optString("websphere.proxyvirtualhostsettings.useserverstaticfilesettings", None));
  Util.addIfNotNone(properties, "useServerErrorPageSettings", roleProperties.optString("websphere.proxyvirtualhostsettings.useservererrorpagesettings", None));
  Util.addIfNotNone(properties, "cacheAccessLog", roleProperties.optString("websphere.proxyvirtualhostsettings.cacheaccesslog", None));
  Util.addIfNotNone(properties, "maximumLogSize", roleProperties.optString("websphere.proxyvirtualhostsettings.maximumlogsize", None));
  print "Creating ProxyVirtualHostSettings with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("ProxyVirtualHostSettings", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ProxyVirtualHostSettings resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.enablelogging", None), "enableLogging","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.localaccesslog", None), "localAccessLog","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.useserverloggingsettings", None), "useServerLoggingSettings","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.proxyaccesslog", None), "proxyAccessLog","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.useserverstaticfilesettings", None), "useServerStaticFileSettings","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.useservererrorpagesettings", None), "useServerErrorPageSettings","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.cacheaccesslog", None), "cacheAccessLog","ProxyVirtualHostSettings");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.proxyvirtualhostsettings.maximumlogsize", None), "maximumLogSize","ProxyVirtualHostSettings");
  if len(atts) != 0:
    print "Modifying ProxyVirtualHostSettings with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "ProxyVirtualHostSettings configuration up to date.";

