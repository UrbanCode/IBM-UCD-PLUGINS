from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereGenericServerClusterTimeMapping");
  exportedObject.put("roleName", "WebSphereGenericServerClusterTimeMapping");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.genericserverclustertimemapping.endtime", objid, "endTime","GenericServerClusterTimeMapping");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.genericserverclustertimemapping.starttime", objid, "startTime","GenericServerClusterTimeMapping");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.genericserverclustertimemapping.action", objid, "action","GenericServerClusterTimeMapping");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("GenericServerClusterTimeMapping resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "endTime", roleProperties.optString("websphere.genericserverclustertimemapping.endtime", None));
  Util.addIfNotNone(properties, "startTime", roleProperties.optString("websphere.genericserverclustertimemapping.starttime", None));
  Util.addIfNotNone(properties, "action", roleProperties.optString("websphere.genericserverclustertimemapping.action", None));
  print "Creating GenericServerClusterTimeMapping with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("GenericServerClusterTimeMapping", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("GenericServerClusterTimeMapping resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.genericserverclustertimemapping.endtime", None), "endTime","GenericServerClusterTimeMapping");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.genericserverclustertimemapping.starttime", None), "startTime","GenericServerClusterTimeMapping");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.genericserverclustertimemapping.action", None), "action","GenericServerClusterTimeMapping");
  if len(atts) != 0:
    print "Modifying GenericServerClusterTimeMapping with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "GenericServerClusterTimeMapping configuration up to date.";

