from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereCustomAuthMechanism");
  exportedObject.put("roleName", "WebSphereCustomAuthMechanism");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customauthmechanism.simpleauthconfig", objid, "simpleAuthConfig","CustomAuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customauthmechanism.authcontextimplclass", objid, "authContextImplClass","CustomAuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customauthmechanism.authconfig", objid, "authConfig","CustomAuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customauthmechanism.iscredentialforwardable", objid, "isCredentialForwardable","CustomAuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customauthmechanism.oid", objid, "OID","CustomAuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.customauthmechanism.authvalidationconfig", objid, "authValidationConfig","CustomAuthMechanism");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"CustomAuthMechanism");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CustomAuthMechanism resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "simpleAuthConfig", roleProperties.optString("websphere.customauthmechanism.simpleauthconfig", None));
  Util.addIfNotNone(properties, "authContextImplClass", roleProperties.optString("websphere.customauthmechanism.authcontextimplclass", None));
  Util.addIfNotNone(properties, "authConfig", roleProperties.optString("websphere.customauthmechanism.authconfig", None));
  Util.addIfNotNone(properties, "isCredentialForwardable", roleProperties.optString("websphere.customauthmechanism.iscredentialforwardable", None));
  Util.addIfNotNone(properties, "OID", roleProperties.optString("websphere.customauthmechanism.oid", None));
  Util.addIfNotNone(properties, "authValidationConfig", roleProperties.optString("websphere.customauthmechanism.authvalidationconfig", None));
  print "Creating CustomAuthMechanism with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("CustomAuthMechanism", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CustomAuthMechanism resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customauthmechanism.simpleauthconfig", None), "simpleAuthConfig","CustomAuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customauthmechanism.authcontextimplclass", None), "authContextImplClass","CustomAuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customauthmechanism.authconfig", None), "authConfig","CustomAuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customauthmechanism.iscredentialforwardable", None), "isCredentialForwardable","CustomAuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customauthmechanism.oid", None), "OID","CustomAuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.customauthmechanism.authvalidationconfig", None), "authValidationConfig","CustomAuthMechanism");
  if len(atts) != 0:
    print "Modifying CustomAuthMechanism with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "CustomAuthMechanism configuration up to date.";

  Property.removeProperties(objid, 'properties',"CustomAuthMechanism");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
