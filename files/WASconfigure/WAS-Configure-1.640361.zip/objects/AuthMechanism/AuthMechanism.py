from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereAuthMechanism");
  exportedObject.put("roleName", "WebSphereAuthMechanism");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authmechanism.simpleauthconfig", objid, "simpleAuthConfig","AuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authmechanism.authcontextimplclass", objid, "authContextImplClass","AuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authmechanism.authconfig", objid, "authConfig","AuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authmechanism.iscredentialforwardable", objid, "isCredentialForwardable","AuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authmechanism.oid", objid, "OID","AuthMechanism");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authmechanism.authvalidationconfig", objid, "authValidationConfig","AuthMechanism");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"AuthMechanism");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AuthMechanism resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "simpleAuthConfig", roleProperties.optString("websphere.authmechanism.simpleauthconfig", None));
  Util.addIfNotNone(properties, "authContextImplClass", roleProperties.optString("websphere.authmechanism.authcontextimplclass", None));
  Util.addIfNotNone(properties, "authConfig", roleProperties.optString("websphere.authmechanism.authconfig", None));
  Util.addIfNotNone(properties, "isCredentialForwardable", roleProperties.optString("websphere.authmechanism.iscredentialforwardable", None));
  Util.addIfNotNone(properties, "OID", roleProperties.optString("websphere.authmechanism.oid", None));
  Util.addIfNotNone(properties, "authValidationConfig", roleProperties.optString("websphere.authmechanism.authvalidationconfig", None));
  print "Creating AuthMechanism with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("AuthMechanism", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);


def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AuthMechanism resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authmechanism.simpleauthconfig", None), "simpleAuthConfig","AuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authmechanism.authcontextimplclass", None), "authContextImplClass","AuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authmechanism.authconfig", None), "authConfig","AuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authmechanism.iscredentialforwardable", None), "isCredentialForwardable","AuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authmechanism.oid", None), "OID","AuthMechanism");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authmechanism.authvalidationconfig", None), "authValidationConfig","AuthMechanism");
  if len(atts) != 0:
    print "Modifying AuthMechanism with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "AuthMechanism configuration up to date.";

  Property.removeProperties(objid, 'properties',"AuthMechanism");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
