from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereRSAToken");
  exportedObject.put("roleName", "WebSphereRSAToken");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.simpleauthconfig", objid, "simpleAuthConfig","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.noncecachetimeout", objid, "nonceCacheTimeout","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.authcontextimplclass", objid, "authContextImplClass","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.tokenexpiration", objid, "tokenExpiration","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.authconfig", objid, "authConfig","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.iscredentialforwardable", objid, "isCredentialForwardable","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.oid", objid, "OID","RSAToken");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.rsatoken.authvalidationconfig", objid, "authValidationConfig","RSAToken");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"RSAToken");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("RSAToken resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "simpleAuthConfig", roleProperties.optString("websphere.rsatoken.simpleauthconfig", None));
  Util.addIfNotNone(properties, "nonceCacheTimeout", roleProperties.optString("websphere.rsatoken.noncecachetimeout", None));
  Util.addIfNotNone(properties, "authContextImplClass", roleProperties.optString("websphere.rsatoken.authcontextimplclass", None));
  Util.addIfNotNone(properties, "tokenExpiration", roleProperties.optString("websphere.rsatoken.tokenexpiration", None));
  Util.addIfNotNone(properties, "authConfig", roleProperties.optString("websphere.rsatoken.authconfig", None));
  Util.addIfNotNone(properties, "isCredentialForwardable", roleProperties.optString("websphere.rsatoken.iscredentialforwardable", None));
  Util.addIfNotNone(properties, "OID", roleProperties.optString("websphere.rsatoken.oid", None));
  Util.addIfNotNone(properties, "authValidationConfig", roleProperties.optString("websphere.rsatoken.authvalidationconfig", None));
  print "Creating RSAToken with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("RSAToken", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("RSAToken resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.simpleauthconfig", None), "simpleAuthConfig","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.noncecachetimeout", None), "nonceCacheTimeout","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.authcontextimplclass", None), "authContextImplClass","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.tokenexpiration", None), "tokenExpiration","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.authconfig", None), "authConfig","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.iscredentialforwardable", None), "isCredentialForwardable","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.oid", None), "OID","RSAToken");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.rsatoken.authvalidationconfig", None), "authValidationConfig","RSAToken");
  if len(atts) != 0:
    print "Modifying RSAToken with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "RSAToken configuration up to date.";

  Property.removeProperties(objid, 'properties',"RSAToken");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
