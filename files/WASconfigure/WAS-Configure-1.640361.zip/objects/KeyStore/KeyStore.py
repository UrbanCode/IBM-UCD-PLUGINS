from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereKeyStore");
  exportedObject.put("roleName", "WebSphereKeyStore");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.name", objid, "name","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.createstashfileforcms", objid, "createStashFileForCMS","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.initializeatstartup", objid, "initializeAtStartup","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.filebased", objid, "fileBased","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.hostlist", objid, "hostList","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.usage", objid, "usage","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.type", objid, "type","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.provider", objid, "provider","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.customproviderclass", objid, "customProviderClass","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.slot", objid, "slot","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.readonly", objid, "readOnly","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.location", objid, "location","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.password", objid, "password","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.description", objid, "description","KeyStore");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.keystore.useforacceleration", objid, "useForAcceleration","KeyStore");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("KeyStore resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.keystore.name", None));
  Util.addIfNotNone(properties, "createStashFileForCMS", roleProperties.optString("websphere.keystore.createstashfileforcms", None));
  Util.addIfNotNone(properties, "initializeAtStartup", roleProperties.optString("websphere.keystore.initializeatstartup", None));
  Util.addIfNotNone(properties, "fileBased", roleProperties.optString("websphere.keystore.filebased", None));
  Util.addIfNotNone(properties, "hostList", roleProperties.optString("websphere.keystore.hostlist", None));
  Util.addIfNotNone(properties, "usage", roleProperties.optString("websphere.keystore.usage", None));
  Util.addIfNotNone(properties, "type", roleProperties.optString("websphere.keystore.type", None));
  Util.addIfNotNone(properties, "provider", roleProperties.optString("websphere.keystore.provider", None));
  Util.addIfNotNone(properties, "customProviderClass", roleProperties.optString("websphere.keystore.customproviderclass", None));
  Util.addIfNotNone(properties, "slot", roleProperties.optString("websphere.keystore.slot", None));
  Util.addIfNotNone(properties, "readOnly", roleProperties.optString("websphere.keystore.readonly", None));
  Util.addIfNotNone(properties, "location", roleProperties.optString("websphere.keystore.location", None));
  Util.addIfNotNone(properties, "password", roleProperties.optString("websphere.keystore.password", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.keystore.description", None));
  Util.addIfNotNone(properties, "useForAcceleration", roleProperties.optString("websphere.keystore.useforacceleration", None));
  print "Creating KeyStore with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("KeyStore", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("KeyStore resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.name", None), "name","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.createstashfileforcms", None), "createStashFileForCMS","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.initializeatstartup", None), "initializeAtStartup","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.filebased", None), "fileBased","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.hostlist", None), "hostList","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.usage", None), "usage","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.type", None), "type","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.provider", None), "provider","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.customproviderclass", None), "customProviderClass","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.slot", None), "slot","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.readonly", None), "readOnly","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.location", None), "location","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.password", None), "password","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.description", None), "description","KeyStore");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.keystore.useforacceleration", None), "useForAcceleration","KeyStore");
  if len(atts) != 0:
    print "Modifying KeyStore with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "KeyStore configuration up to date.";

