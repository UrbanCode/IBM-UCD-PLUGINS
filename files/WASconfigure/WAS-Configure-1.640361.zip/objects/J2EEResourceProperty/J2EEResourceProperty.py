from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = "websphere.j2eeresourceproperty.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'J2EEResourceProperty');

  containmentpath = "%(parentconpath)sJ2EEResourceProperty:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'J2EEResourceProperty');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereJ2EEResourceProperty");
  exportedObject.put("roleName", "WebSphereJ2EEResourceProperty");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.name", objid, "name","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.type", objid, "type","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.description", objid, "description","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.confidential", objid, "confidential","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.value", objid, "value","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.supportsdynamicupdates", objid, "supportsDynamicUpdates","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.required", objid, "required","J2EEResourceProperty");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2eeresourceproperty.ignore", objid, "ignore","J2EEResourceProperty");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("J2EEResourceProperty resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.j2eeresourceproperty.name"):
    raise Exception("Resource role properties does not contain websphere.j2eeresourceproperty.name!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create J2EEResourceProperty on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("J2EEResourceProperty resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.j2eeresourceproperty.name"):
    raise Exception("Resource role properties does not contain websphere.j2eeresourceproperty.name!");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.j2eeresourceproperty.name", None));
  Util.addIfNotNone(properties, "type", roleProperties.optString("websphere.j2eeresourceproperty.type", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.j2eeresourceproperty.description", None));
  Util.addIfNotNone(properties, "confidential", roleProperties.optString("websphere.j2eeresourceproperty.confidential", None));
  Util.addIfNotNone(properties, "value", roleProperties.optString("websphere.j2eeresourceproperty.value", None));
  Util.addIfNotNone(properties, "supportsDynamicUpdates", roleProperties.optString("websphere.j2eeresourceproperty.supportsdynamicupdates", None));
  Util.addIfNotNone(properties, "required", roleProperties.optString("websphere.j2eeresourceproperty.required", None));
  Util.addIfNotNone(properties, "ignore", roleProperties.optString("websphere.j2eeresourceproperty.ignore", None));
  print "Creating J2EEResourceProperty with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("J2EEResourceProperty", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("J2EEResourceProperty resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.j2eeresourceproperty.name"):
    raise Exception("Resource role properties does not contain websphere.j2eeresourceproperty.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.name", None), "name","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.type", None), "type","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.description", None), "description","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.confidential", None), "confidential","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.value", None), "value","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.supportsdynamicupdates", None), "supportsDynamicUpdates","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.required", None), "required","J2EEResourceProperty");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2eeresourceproperty.ignore", None), "ignore","J2EEResourceProperty");
  if len(atts) != 0:
    print "Modifying J2EEResourceProperty with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "J2EEResourceProperty configuration up to date.";

