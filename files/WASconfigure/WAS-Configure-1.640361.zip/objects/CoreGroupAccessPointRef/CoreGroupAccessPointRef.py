from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from WASConfLog import Log;
from utilities import Util

__name_att__ = "websphere.coregroupaccesspointref.name"

def _export(objid, parentrespath, name = ""):

  if name == "":
    name = Util.getRequiredAttribute(objid, "name", "CoreGroupAccessPoint");
  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereCoreGroupAccessPointRef");
  exportedObject.put("roleName", "WebSphereCoreGroupAccessPointRef");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.coregroupaccesspointref.name", objid, "name","CoreGroupAccessPoint");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("CoreGroupAccessPointRef resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.coregroupaccesspointref.name"):
    raise Exception("Resource role properties does not contain websphere.coregroupaccesspointref.name!");

  name = roleProperties.getString("websphere.coregroupaccesspointref.name");

  #Parent is the object that we actually need to specify the reference on.
  index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
  parentconpath = containmentpath[0:index];
  parentid = AdminConfig.getid(parentconpath);
  if parentid == None or len(parentid) == 0:
    raise Exception("Parent does not exist to create CoreGroupAccessPoint on.");

  childid = AdminConfig.getid("/CoreGroupBridgeSettings:/CoreGroupAccessPoint:%s/" % name);
  if childid is None or len(childid) < 1:
    raise Exception("Cound not find CoreGroupAccessPoint with name %s specified by refernece!" % name);

  AdminConfig.modify(parentid, [['coreGroupAccessPointRefs', childid]]);
