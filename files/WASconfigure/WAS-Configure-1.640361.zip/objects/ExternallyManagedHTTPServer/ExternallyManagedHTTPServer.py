from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from Service import Service
from Component import Component
from Property import Property
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereExternallyManagedHTTPServer");
  exportedObject.put("roleName", "WebSphereExternallyManagedHTTPServer");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.externallymanagedhttpserver.name", objid, "name","ExternallyManagedHTTPServer");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"ExternallyManagedHTTPServer");
  extraObjects = Component.exportComponents(objid, respath, extraObjects, typeFolders, 'components', "ExternallyManagedHTTPServer");
  extraObjects = Service.exportServices(objid, respath, extraObjects, typeFolders, 'services', "ExternallyManagedHTTPServer");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ExternallyManagedHTTPServer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.externallymanagedhttpserver.name", None));
  print "Creating ExternallyManagedHTTPServer with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("ExternallyManagedHTTPServer", parentid, properties);

  Component.removeComponents(objid, 'components', "ExternallyManagedHTTPServer");
  Service.removeServices(objid, 'services', "ExternallyManagedHTTPServer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      serviceObject = 0;
      componentObject = 0;
      propertyObject = 0;
      serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
      if (serviceObject == 0):
        componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
        if (componentObject == 0):
          propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ExternallyManagedHTTPServer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.externallymanagedhttpserver.name", None), "name","ExternallyManagedHTTPServer");
  if len(atts) != 0:
    print "Modifying ExternallyManagedHTTPServer with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "ExternallyManagedHTTPServer configuration up to date.";

  Property.removeProperties(objid, 'properties',"ExternallyManagedHTTPServer");
  Component.removeComponents(objid, 'components', "ExternallyManagedHTTPServer");
  Service.removeServices(objid, 'services', "ExternallyManagedHTTPServer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      serviceObject = 0;
      componentObject = 0;
      propertyObject = 0;
      serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
      if (serviceObject == 0):
        componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
        if (componentObject == 0):
          propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

