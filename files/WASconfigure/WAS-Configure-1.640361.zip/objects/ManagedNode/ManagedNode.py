from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from utilities import Util

__name_att__ = "websphere.managednode.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'ManagedNode');

  containmentpath = "%(parentconpath)sManagedNode:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'ManagedNode');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereManagedNode");
  exportedObject.put("roleName", "WebSphereManagedNode");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.managednode.name", objid, "name","ManagedNode");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.managednode.pollingenabled", objid, "pollingEnabled","ManagedNode");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ManagedNode resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.managednode.name"):
    raise Exception("Resource role properties does not contain websphere.managednode.name!");

  objid = AdminConfig.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = AdminConfig.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create ManagedNode on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ManagedNode resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.managednode.name"):
    raise Exception("Resource role properties does not contain websphere.managednode.name!");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.managednode.name", None));
  Util.addIfNotNone(properties, "pollingEnabled", roleProperties.optString("websphere.managednode.pollingenabled", None));
  print "Creating ManagedNode with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("ManagedNode", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ManagedNode resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.managednode.name"):
    raise Exception("Resource role properties does not contain websphere.managednode.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.managednode.name", None), "name","ManagedNode");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.managednode.pollingenabled", None), "pollingEnabled","ManagedNode");
  if len(atts) != 0:
    print "Modifying ManagedNode with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "ManagedNode configuration up to date.";

