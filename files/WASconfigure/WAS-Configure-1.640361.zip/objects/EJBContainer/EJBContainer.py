from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
import AdminConfig;
import AdminControl;
import AdminTask;
import AdminApp;
from Service import Service
from Component import Component
from Property import Property
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereEJBContainer");
  exportedObject.put("roleName", "WebSphereEJBContainer");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.ejbcontainer.name", objid, "name","EJBContainer");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.ejbcontainer.enablesfsbfailover", objid, "enableSFSBFailover","EJBContainer");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.ejbcontainer.passivationdirectory", objid, "passivationDirectory","EJBContainer");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.ejbcontainer.defaultdatasourcejndiname", objid, "defaultDatasourceJNDIName","EJBContainer");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.ejbcontainer.inactivepoolcleanupinterval", objid, "inactivePoolCleanupInterval","EJBContainer");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"EJBContainer");
  extraObjects = Component.exportComponents(objid, respath, extraObjects, typeFolders, 'components', "EJBContainer");
  extraObjects = Service.exportServices(objid, respath, extraObjects, typeFolders, 'services', "EJBContainer");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("EJBContainer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.ejbcontainer.name", None));
  Util.addIfNotNone(properties, "enableSFSBFailover", roleProperties.optString("websphere.ejbcontainer.enablesfsbfailover", None));
  Util.addIfNotNone(properties, "passivationDirectory", roleProperties.optString("websphere.ejbcontainer.passivationdirectory", None));
  Util.addIfNotNone(properties, "defaultDatasourceJNDIName", roleProperties.optString("websphere.ejbcontainer.defaultdatasourcejndiname", None));
  Util.addIfNotNone(properties, "inactivePoolCleanupInterval", roleProperties.optString("websphere.ejbcontainer.inactivepoolcleanupinterval", None));
  print "Creating EJBContainer with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = AdminConfig.create("EJBContainer", parentid, properties);

  Component.removeComponents(objid, 'components', "EJBContainer");
  Service.removeServices(objid, 'services', "EJBContainer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      serviceObject = 0;
      componentObject = 0;
      propertyObject = 0;
      serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
      if (serviceObject == 0):
        componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
        if (componentObject == 0):
           propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("EJBContainer resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.ejbcontainer.name", None), "name","EJBContainer");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.ejbcontainer.enablesfsbfailover", None), "enableSFSBFailover","EJBContainer");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.ejbcontainer.passivationdirectory", None), "passivationDirectory","EJBContainer");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.ejbcontainer.defaultdatasourcejndiname", None), "defaultDatasourceJNDIName","EJBContainer");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.ejbcontainer.inactivepoolcleanupinterval", None), "inactivePoolCleanupInterval","EJBContainer");
  if len(atts) != 0:
    print "Modifying EJBContainer with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    AdminConfig.modify(objid, atts);
  else:   
    print "EJBContainer configuration up to date.";

  Property.removeProperties(objid, 'properties',"EJBContainer");
  Component.removeComponents(objid, 'components', "EJBContainer");
  Service.removeServices(objid, 'services', "EJBContainer");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      serviceObject = 0;
      componentObject = 0;
      propertyObject = 0;
      serviceObject = Service.createObjIfRole(objid, curjsonobject, currole);
      if (serviceObject == 0):
        componentObject = Component.createObjIfRole(objid, curjsonobject, currole);
        if (componentObject == 0):
           propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
