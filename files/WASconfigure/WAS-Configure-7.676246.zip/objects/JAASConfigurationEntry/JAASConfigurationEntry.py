from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util
from JAASLoginModule import JAASLoginModule

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereJAASConfigurationEntry");
  exportedObject.put("roleName", "WebSphereJAASConfigurationEntry");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.jaasconfigurationentry.alias", objid, "alias","JAASConfigurationEntry");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};

  i = 0;
  jaasLoginModules = Util.parseConfigIdListAttribute(objid, 'loginModules',"JAASConfigurationEntry");

  #Append moduleClassName to beginning of id so that we have a key to sort.
  #Sorting is needed in an attempt to keep the same order for the JAASLoginModules when doing a resource tree compare.
  sortedJaasLoginModules = [];
  for jaasLoginModule in jaasLoginModules:
    if len(jaasLoginModule) > 0:
      jaasLoginModule = Util.getOptionalAttribute(jaasLoginModule, "moduleClassName", "JAASLoginModule") + jaasLoginModule;
      sortedJaasLoginModules.append(jaasLoginModule);
  sortedJaasLoginModules.sort();

  for jaasLoginModule in sortedJaasLoginModules:
    if len(jaasLoginModule) > 0:
      jaasLoginModule = jaasLoginModule[jaasLoginModule.find("("):len(jaasLoginModule)];
      returndict = Util.createTypeFolder(respath, "JAASLoginModule", typeFolders);
      currespath = returndict['path'];
      if returndict.has_key('object'):
        extraObjects.append(returndict['object']);
      Util.addAllFromExport(extraObjects, JAASLoginModule._export(jaasLoginModule, currespath, "JAAS Login Module%s" % i));
      i = i + 1;

  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("JAASConfigurationEntry resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "alias", roleProperties.optString("websphere.jaasconfigurationentry.alias", None));
  print "Creating JAASConfigurationEntry with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("JAASConfigurationEntry", parentid, properties);

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      if currole == "WebSphereJAASLoginModule":
        JAASLoginModule.create(objid, curjsonobject);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("JAASConfigurationEntry resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.jaasconfigurationentry.alias", None), "alias","JAASConfigurationEntry");
  if len(atts) != 0:
    print "Modifying JAASConfigurationEntry with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "JAASConfigurationEntry configuration up to date.";

  jaasLoginModules = Util.parseConfigIdListAttribute(objid, 'loginModules',"JAASConfigurationEntry");
  for jaasLoginModule in jaasLoginModules:
    if len(jaasLoginModule) > 0:
      Util.remove(jaasLoginModule);

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      if currole == "WebSphereJAASLoginModule":
        JAASLoginModule.create(objid, curjsonobject);
