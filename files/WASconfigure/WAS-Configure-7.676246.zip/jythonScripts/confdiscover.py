###
# Licensed Materials - Property of IBM Corp.
# @product.name.full@
# (c) Copyright IBM Corporation 2003, 2014. All Rights Reserved.
# 
# U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
# GSA ADP Schedule Contract with IBM Corp.
# 
# Filename: confdiscover.py
# 
# 
###

from java.io import File, FileInputStream;
from java.util import HashMap, ArrayList, Properties;
from org.codehaus.jettison.json import JSONObject, JSONArray;
import sys;
import os;
import Queue;

import javaos
if javaos._osType == 'posix' and java.lang.System.getProperty('os.name').startswith('Windows'):
  sys.registry.setProperty('python.os', 'nt');
  reload(javaos);

sys.modules['AdminConfig'] = AdminConfig
sys.modules['AdminControl'] = AdminControl
sys.modules['AdminApp'] = AdminApp
sys.modules['AdminTask'] = AdminTask


def isValidType(type):
  return Util.isValidType(type);

#returns a JSONArray
def exportObjectToResources(objdir, objid, respath, containmentpath, roleName):
  mod = Util.getRoleModule(roleName);
  if mod is not None:
    if 'export' in dir(mod):
      #some objects are reliant on their parents to export them, so they don't implement an export method
      finalResult = JSONArray();
      execFileDict = mod.export(objid, containmentpath, respath);
      dictKeys = execFileDict.keys();
      if 'object' in dictKeys:
        exportedObject = execFileDict['object']
        curcontainmentpath = execFileDict['conpath'];
        Log.debug("Exported %s" % curcontainmentpath)
        currespath = execFileDict['respath'];
        if exportedObject != None:
          finalResult.put(exportedObject);
          f = open("%(dir)s%(fileSep)schildren" % { 'dir':objdir, 'fileSep': os.sep }, "r");
          line = f.readline();
          typeFolders = {}
          while line != "":
            childtype = line.strip();
            if childtype != "" and isValidType(childtype):
              childdir = Util.findObjectDir(childtype, objectsDir);
              childsearchpath = "%(curpath)s%(type)s:/" % { 'curpath': curcontainmentpath, 'type':childtype }
              Log.debug("Checking child searchpath %s" % childsearchpath);
              for x in Util.getid(childsearchpath).splitlines():
                returndict = Util.createTypeFolder(currespath, childtype, typeFolders);
                curchildrespath = returndict['path'];
                if returndict.has_key('object'):
                  finalResult.put(returndict['object']);
                Log.debug("Exporting %s" % x);
                curresources = exportObjectToResources(childdir, x, curchildrespath, curcontainmentpath, childtype)
                for y in range(curresources.length()):
                  finalResult.put(curresources.get(y));
            line = f.readline();
          f.close();
        if 'extraObjects' in dictKeys:
          extraObjects = execFileDict['extraObjects'];
          for obj in extraObjects:
            finalResult.put(obj);
      
  return finalResult

inputPropsFile = File(sys.argv[0]);
logDir = inputPropsFile.getParentFile();
inputProps = Properties();
inStream = FileInputStream(inputPropsFile);
inputProps.load(inStream);
inStream.close();


PLUGIN_HOME=os.environ['PLUGIN_HOME'];
objectsDir = "%(plugHome)s%(fileSep)sobjects" % { 'plugHome': PLUGIN_HOME, 'fileSep': os.sep };
sys.path.insert(0,objectsDir);
Util = __import__("utilities.Util").Util;
Log = __import__("WASConfLog.Log").Log;
logFile = open("%s/debugLog.txt" % logDir.getAbsolutePath(),'w');
redoFile = open("%s/redoLog.txt" % logDir.getAbsolutePath(),'w');
Log.setLogFile(logFile);
Log.setRedoFile(redoFile);


resourceJSONObject = JSONObject(inputProps.getProperty("fullResourceConfiguration"));

roleName = resourceJSONObject.getString("roleName");
roleName = Util.roleNameToType(roleName);
topObjectDir = Util.findObjectDir(roleName, objectsDir);

finalResources = JSONArray();
respath = "/"
containmentpath = Util.findContainmentPath(resourceJSONObject);

index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
parentcontainmentpath = containmentpath[0:index];
if parentcontainmentpath == "/":
  parentcontainmentpath="";
Log.debug("Initial Containment path %s" % containmentpath);
scope = None 
if containmentpath != "":
  objid = Util.getid(containmentpath);
else:
  objid = Util.getid("/Cell:/");
Log.debug("Fin Containment path %s" % containmentpath);
Log.debug("Parent Containment path %s" % parentcontainmentpath);
Log.debug(roleName);
Log.debug(respath)
Log.debug(objid)
curresources = exportObjectToResources(topObjectDir, objid, respath, parentcontainmentpath, roleName)
for y in range(curresources.length()):
  finalResources.put(curresources.get(y));

logFile.close();
print "\nConfiguration Discovery Complete.";
print finalResources.toString(4);
