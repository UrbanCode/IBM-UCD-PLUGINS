import sys;
import os;
import Queue;
from java.io import File, FileInputStream;
from java.util import Properties;
from org.codehaus.jettison.json import JSONObject, JSONArray;

import javaos
if javaos._osType == 'posix' and java.lang.System.getProperty('os.name').startswith('Windows'):
  sys.registry.setProperty('python.os', 'nt');
  reload(javaos);

sys.modules['AdminConfig'] = AdminConfig
sys.modules['AdminControl'] = AdminControl
sys.modules['AdminApp'] = AdminApp
sys.modules['AdminTask'] = AdminTask

importedConfigIds = {};

def addChildrenToImports(jsonArray, roledict, containmentpath):
  for i in range(jsonArray.length()):
    curcontainmentpath = containmentpath
    obj = jsonArray.getJSONObject(i);
    if obj.has("roleName"):
      curRoleName = Util.roleNameToType(obj.getString("roleName"));
      mod = Util.getRoleModule(curRoleName);
      if mod is not None:
        if 'import' in dir(mod):
          curName = Util.getObjectNameFromJson(curRoleName, obj);
          curcontainmentpath = "%(path)s%(type)s:%(name)s/" % { 'path':containmentpath, 'type':curRoleName, 'name':curName };
          rolelist = None;
          if roledict.has_key(curRoleName):
            rolelist = roledict[curRoleName];
          else:
            rolelist = [];
            roledict[curRoleName] = rolelist;
          Log.debug("Adding %(name)s with type %(type)s at containmentpath %(path)s" % { 'name':obj.getString("name"), 'type':curRoleName, 'path':curcontainmentpath});
          rolelist.append({'containmentpath':curcontainmentpath, 'jsonobject':obj});
          if obj.has('children'):
            childrenArray = obj.getJSONArray('children');
            addChildrenToImports(childrenArray, roledict, curcontainmentpath);
        else:  #end if import
          Log.debug("Skipping %s and all its children" % curRoleName);
      else:#mod is not None
        Log.debug("Skipping none websphere role %s" % curRoleName);
        if obj.has('children'):
          childrenArray = obj.getJSONArray('children');
          addChildrenToImports(childrenArray, roledict, curcontainmentpath);
        pass;
    else:#obj.has(roleName)
      Log.debug("Skipping %s" % obj.getString("name"));
      if obj.has('children'):
        childrenArray = obj.getJSONArray('children');
        addChildrenToImports(childrenArray, roledict, curcontainmentpath);
      pass;

def importObject(type, object):
  Log.debug("Start Import of containment path %s " % object['containmentpath']);
  mod = Util.getRoleModule(type);
  if mod is not None:
    if 'import' in dir(mod):
      #some objects are reliant on the parent to tell them to import
      #mostly things with no names
      containmentpath = object['containmentpath'];
      jsonobject = object['jsonobject'];
      Log.log("Running import for containmentpath %(conpath)s"  % { 'conpath': containmentpath });
      configId = mod.import(containmentpath, type, jsonobject);
      importedConfigIds[configId] = containmentpath;
      Log.log("Finished Import");
  else:
    Log.debug("Skipping object with none WebSphere role %s" % type);
  
def importTypes(type, objectsToImport):
  if type != "" and not type.startswith("#"):
    Log.debug("Importing %ss" % type);
    if objectsToImport.has_key(type):
      objectlist = objectsToImport[type];
      if objectlist != None:
        for curobj in objectlist:
          importObject(type, curobj);
    Log.debug("Finished Importing %ss" % type);

def isValidType(type):
  return Util.isValidType(type);

def doCleanup(conpath, roleName, objectsToImport, objectsDir):
  #assume the obj with conpath has already been checked
  objdir = Util.findObjectDir(roleName, objectsDir);
  f = open("%(dir)s%(fileSep)schildren" % { 'dir':objdir, 'fileSep': os.sep }, "r");
  line = f.readline();
  while line != "":
    childtype = line.strip();
    line = f.readline();
    childImportedObjects = [];
    if objectsToImport.has_key(childtype):
      childImportedObjects = objectsToImport[childtype];

    if childtype != "" and isValidType(childtype):
      childsearchpath = "%(curpath)s%(type)s:/" % { 'curpath': conpath, 'type': childtype }
      Log.debug("Checking child serachpath %s for deletions" % childsearchpath);
      for objid in Util.getid(childsearchpath).splitlines():
        if importedConfigIds.has_key(objid):
          Log.debug("Not deleting imported config id %s" % objid);
          doCleanup(importedConfigIds[objid], childtype, objectsToImport, objectsDir);
        else:
          Log.log("Deleting config id %s" % objid);
          Util.remove(objid);
  

PLUGIN_HOME=os.environ['PLUGIN_HOME'];
objectsDir = "%(plugHome)s%(fileSep)sobjects" % { 'plugHome': PLUGIN_HOME, 'fileSep': os.sep };
sys.path.insert(0,objectsDir);
Util = __import__("utilities.Util").Util;

inputPropsFile = File(sys.argv[0]);
inputProps = Properties();
inStream = FileInputStream(inputPropsFile);
inputProps.load(inStream);
inStream.close();

logDir = inputPropsFile.getParentFile();
Log = __import__("WASConfLog.Log").Log;
logFile = open("%s/debugLog.txt" % logDir.getAbsolutePath(),'w');
Log.setLogFile(logFile);


resourceJSONObject = JSONObject(inputProps.getProperty("fullResourceConfiguration"));
curcontainmentpath = Util.findContainmentPath(resourceJSONObject);

roleName = resourceJSONObject.getString("roleName");
roleName = Util.roleNameToType(roleName);



objectsToImport = {};
if resourceJSONObject.has("parent"):
  resourceJSONObject.remove("parent");

children = None;
if resourceJSONObject.has("children"):
  children = resourceJSONObject.getJSONArray("children");

objectsToImport[roleName] = [];
objectsToImport[roleName].append({ 'containmentpath':curcontainmentpath, 'jsonobject':resourceJSONObject });
Log.debug("Adding ROOT Object with type %(type)s at containmentpath %(path)s" % { 'type':roleName, 'path':curcontainmentpath});
if children != None:
  addChildrenToImports(children, objectsToImport, curcontainmentpath);

orderlist = [];
orderfile = open("%s/order.txt" % objectsDir, 'r');
for type in orderfile.readlines():
  type = type.strip();
  importTypes(type, objectsToImport);

doCleanup(curcontainmentpath, roleName, objectsToImport, objectsDir);

AdminConfig.save();
logFile.close();
print "\nConfiguration Apply Complete.";
