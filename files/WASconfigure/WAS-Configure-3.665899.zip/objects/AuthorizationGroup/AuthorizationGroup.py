from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util
from Property import Property

__name_att__ = "websphere.authorizationgroup.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'AuthorizationGroup');

  containmentpath = "%(parentconpath)sAuthorizationGroup:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'AuthorizationGroup');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereAuthorizationGroup");
  exportedObject.put("roleName", "WebSphereAuthorizationGroup");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authorizationgroup.name", objid, "name","AuthorizationGroup");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authorizationgroup.resourcename", objid, "resourceName","AuthorizationGroup");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authorizationgroup.resourcetype", objid, "resourceType","AuthorizationGroup");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.authorizationgroup.description", objid, "description","AuthorizationGroup");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'memberProperties',"AuthorizationGroup");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AuthorizationGroup resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.authorizationgroup.name"):
    raise Exception("Resource role properties does not contain websphere.authorizationgroup.name!");

  objid = Util.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = Util.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create AuthorizationGroup on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AuthorizationGroup resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.authorizationgroup.name"):
    raise Exception("Resource role properties does not contain websphere.authorizationgroup.name!");

  properties = [];
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.authorizationgroup.name", None));
  Util.addIfNotNone(properties, "resourceName", roleProperties.optString("websphere.authorizationgroup.resourcename", None));
  Util.addIfNotNone(properties, "resourceType", roleProperties.optString("websphere.authorizationgroup.resourcetype", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.authorizationgroup.description", None));
  print "Creating AuthorizationGroup with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("AuthorizationGroup", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
  return objid;


def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("AuthorizationGroup resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.authorizationgroup.name"):
    raise Exception("Resource role properties does not contain websphere.authorizationgroup.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authorizationgroup.name", None), "name","AuthorizationGroup");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authorizationgroup.resourcename", None), "resourceName","AuthorizationGroup");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authorizationgroup.resourcetype", None), "resourceType","AuthorizationGroup");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.authorizationgroup.description", None), "description","AuthorizationGroup");
  if len(atts) != 0:
    print "Modifying AuthorizationGroup with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "AuthorizationGroup configuration up to date.";

  Property.removeProperties(objid, 'memberProperties',"AuthorizationGroup");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString('roleName');
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
