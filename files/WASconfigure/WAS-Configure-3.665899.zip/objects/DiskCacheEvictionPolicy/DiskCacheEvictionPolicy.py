from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util

__name_att__ = None;

def export(objid, parentcontainmentpath, parentrespath):

  name = "DiskCacheEvictionPolicy";

  containmentpath = "%(parentconpath)sDiskCacheEvictionPolicy:/" % {'parentconpath':parentcontainmentpath }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath, name);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereDiskCacheEvictionPolicy");
  exportedObject.put("roleName", "WebSphereDiskCacheEvictionPolicy");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.diskcacheevictionpolicy.algorithm", objid, "algorithm","DiskCacheEvictionPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.diskcacheevictionpolicy.lowthreshold", objid, "lowThreshold","DiskCacheEvictionPolicy");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.diskcacheevictionpolicy.highthreshold", objid, "highThreshold","DiskCacheEvictionPolicy");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;

def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DiskCacheEvictionPolicy resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  objid = Util.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = Util.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create DiskCacheEvictionPolicy on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;

def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DiskCacheEvictionPolicy resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "algorithm", roleProperties.optString("websphere.diskcacheevictionpolicy.algorithm", None));
  Util.addIfNotNone(properties, "lowThreshold", roleProperties.optString("websphere.diskcacheevictionpolicy.lowthreshold", None));
  Util.addIfNotNone(properties, "highThreshold", roleProperties.optString("websphere.diskcacheevictionpolicy.highthreshold", None));
  print "Creating DiskCacheEvictionPolicy with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("DiskCacheEvictionPolicy", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DiskCacheEvictionPolicy resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.diskcacheevictionpolicy.algorithm", None), "algorithm","DiskCacheEvictionPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.diskcacheevictionpolicy.lowthreshold", None), "lowThreshold","DiskCacheEvictionPolicy");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.diskcacheevictionpolicy.highthreshold", None), "highThreshold","DiskCacheEvictionPolicy");
  if len(atts) != 0:
    print "Modifying DiskCacheEvictionPolicy with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "DiskCacheEvictionPolicy configuration up to date.";

