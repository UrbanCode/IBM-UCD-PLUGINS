from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util
from Property import Property

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereJ2CResourceAdapter");
  exportedObject.put("roleName", "WebSphereJ2CResourceAdapter");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.providertype", objid, "providerType","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.archivepath", objid, "archivePath","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.hacapability", objid, "hACapability","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.isolatedclassloader", objid, "isolatedClassLoader","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.isenablehasupport", objid, "isEnableHASupport","J2CResourceAdapter");
  Util.addAttributePathPropertyToJson(roleProperties, "websphere.j2cresourceadapter.classpath", objid, "classpath","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.threadpoolalias", objid, "threadPoolAlias","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.singleton", objid, "singleton","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.description", objid, "description","J2CResourceAdapter");
  Util.addAttributePathPropertyToJson(roleProperties, "websphere.j2cresourceadapter.nativepath", objid, "nativepath","J2CResourceAdapter");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.j2cresourceadapter.name", objid, "name","J2CResourceAdapter");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  extraObjects = Property.exportProperties(objid, respath, extraObjects, typeFolders, 'properties',"J2CResourceAdapter");
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("J2CResourceAdapter resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "providerType", roleProperties.optString("websphere.j2cresourceadapter.providertype", None));
  Util.addIfNotNone(properties, "archivePath", roleProperties.optString("websphere.j2cresourceadapter.archivepath", None));
  Util.addIfNotNone(properties, "hACapability", roleProperties.optString("websphere.j2cresourceadapter.hacapability", None));
  Util.addIfNotNone(properties, "isolatedClassLoader", roleProperties.optString("websphere.j2cresourceadapter.isolatedclassloader", None));
  Util.addIfNotNone(properties, "isEnableHASupport", roleProperties.optString("websphere.j2cresourceadapter.isenablehasupport", None));
  Util.addPathProperty(properties, "classpath", roleProperties.optString("websphere.j2cresourceadapter.classpath", None));
  Util.addIfNotNone(properties, "threadPoolAlias", roleProperties.optString("websphere.j2cresourceadapter.threadpoolalias", None));
  Util.addIfNotNone(properties, "singleton", roleProperties.optString("websphere.j2cresourceadapter.singleton", None));
  Util.addIfNotNone(properties, "description", roleProperties.optString("websphere.j2cresourceadapter.description", None));
  Util.addPathProperty(properties, "nativepath", roleProperties.optString("websphere.j2cresourceadapter.nativepath", None));
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.j2cresourceadapter.name", None));
  print "Creating J2CResourceAdapter with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("J2CResourceAdapter", parentid, properties);
  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("J2CResourceAdapter resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.providertype", None), "providerType","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.archivepath", None), "archivePath","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.hacapability", None), "hACapability","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.isolatedclassloader", None), "isolatedClassLoader","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.isenablehasupport", None), "isEnableHASupport","J2CResourceAdapter");
  Util.addPathAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.classpath", None), "classpath","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.threadpoolalias", None), "threadPoolAlias","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.singleton", None), "singleton","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.description", None), "description","J2CResourceAdapter");
  Util.addPathAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.nativepath", None), "nativepath","J2CResourceAdapter");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.j2cresourceadapter.name", None), "name","J2CResourceAdapter");
  if len(atts) != 0:
    print "Modifying J2CResourceAdapter with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "J2CResourceAdapter configuration up to date.";

  Property.removeProperties(objid, 'properties',"J2CResourceAdapter");

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");
      propertyObject = Property.createObjIfRole(objid, curjsonobject, currole);
