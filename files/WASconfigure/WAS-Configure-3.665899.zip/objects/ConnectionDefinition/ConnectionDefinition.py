from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereConnectionDefinition");
  exportedObject.put("roleName", "WebSphereConnectionDefinition");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.connectiondefinition.connectionfactoryinterface", objid, "connectionFactoryInterface","ConnectionDefinition");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.connectiondefinition.connectionimplclass", objid, "connectionImplClass","ConnectionDefinition");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.connectiondefinition.connectioninterface", objid, "connectionInterface","ConnectionDefinition");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.connectiondefinition.connectionfactoryimplclass", objid, "connectionFactoryImplClass","ConnectionDefinition");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.connectiondefinition.managedconnectionfactoryclass", objid, "managedConnectionFactoryClass","ConnectionDefinition");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ConnectionDefinition resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  Util.addIfNotNone(properties, "connectionFactoryInterface", roleProperties.optString("websphere.connectiondefinition.connectionfactoryinterface", None));
  Util.addIfNotNone(properties, "connectionImplClass", roleProperties.optString("websphere.connectiondefinition.connectionimplclass", None));
  Util.addIfNotNone(properties, "connectionInterface", roleProperties.optString("websphere.connectiondefinition.connectioninterface", None));
  Util.addIfNotNone(properties, "connectionFactoryImplClass", roleProperties.optString("websphere.connectiondefinition.connectionfactoryimplclass", None));
  Util.addIfNotNone(properties, "managedConnectionFactoryClass", roleProperties.optString("websphere.connectiondefinition.managedconnectionfactoryclass", None));
  print "Creating ConnectionDefinition with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("ConnectionDefinition", parentid, properties);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("ConnectionDefinition resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.connectiondefinition.connectionfactoryinterface", None), "connectionFactoryInterface","ConnectionDefinition");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.connectiondefinition.connectionimplclass", None), "connectionImplClass","ConnectionDefinition");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.connectiondefinition.connectioninterface", None), "connectionInterface","ConnectionDefinition");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.connectiondefinition.connectionfactoryimplclass", None), "connectionFactoryImplClass","ConnectionDefinition");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.connectiondefinition.managedconnectionfactoryclass", None), "managedConnectionFactoryClass","ConnectionDefinition");
  if len(atts) != 0:
    print "Modifying ConnectionDefinition with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "ConnectionDefinition configuration up to date.";

