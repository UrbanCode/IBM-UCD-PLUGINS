from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util

__name_att__ = "websphere.dynamiccluster.name"

def export(objid, parentcontainmentpath, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'DynamicCluster');

  containmentpath = "%(parentconpath)sDynamicCluster:%(name)s/" % {'parentconpath':parentcontainmentpath, 'name':name }
  if not containmentpath.startswith("/"):
    containmentpath = "/" + containmentpath;

  dict = _export(objid, parentrespath);
  dict['conpath'] = containmentpath;
  return dict

def _export(objid, parentrespath):

  name = Util.getRequiredAttribute(objid, "name", 'DynamicCluster');


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereDynamicCluster");
  exportedObject.put("roleName", "WebSphereDynamicCluster");

  roleProperties = JSONObject();

  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.minnodes", objid, "minNodes","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.name", objid, "name","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.membershippolicy", objid, "membershipPolicy","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.mininstances", objid, "minInstances","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.isolationgroup", objid, "isolationGroup","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.maxinstances", objid, "maxInstances","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.strictisolationenabled", objid, "strictIsolationEnabled","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.servertype", objid, "serverType","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.serverinactivitytime", objid, "serverInactivityTime","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.operationalmode", objid, "operationalMode","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.maxnodes", objid, "maxNodes","DynamicCluster");
  Util.addAttributeToJsonIfNotNone(roleProperties, "websphere.dynamiccluster.numverticalinstances", objid, "numVerticalInstances","DynamicCluster");
  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;



def import(containmentpath, roleName, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DynamicCluster resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");
  if not roleProperties.has("websphere.dynamiccluster.name"):
    raise Exception("Resource role properties does not contain websphere.dynamiccluster.name!");

  objid = Util.getid(containmentpath);
  if objid == None or len(objid) == 0:
    index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
    parentconpath = containmentpath[0:index];
    parentid = Util.getid(parentconpath);
    if parentid == None or len(parentid) == 0:
      raise Exception("Parent does not exist to create DynamicCluster on.");
    objid = create(parentid, jsonobject);
  else:
    update(objid,jsonobject);
  return objid;



def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DynamicCluster resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.dynamiccluster.name"):
    raise Exception("Resource role properties does not contain websphere.dynamiccluster.name!");

  properties = [];
  Util.addIfNotNone(properties, "minNodes", roleProperties.optString("websphere.dynamiccluster.minnodes", None));
  Util.addIfNotNone(properties, "name", roleProperties.optString("websphere.dynamiccluster.name", None));
  Util.addIfNotNone(properties, "membershipPolicy", roleProperties.optString("websphere.dynamiccluster.membershippolicy", None));
  Util.addIfNotNone(properties, "minInstances", roleProperties.optString("websphere.dynamiccluster.mininstances", None));
  Util.addIfNotNone(properties, "isolationGroup", roleProperties.optString("websphere.dynamiccluster.isolationgroup", None));
  Util.addIfNotNone(properties, "maxInstances", roleProperties.optString("websphere.dynamiccluster.maxinstances", None));
  Util.addIfNotNone(properties, "strictIsolationEnabled", roleProperties.optString("websphere.dynamiccluster.strictisolationenabled", None));
  Util.addIfNotNone(properties, "serverType", roleProperties.optString("websphere.dynamiccluster.servertype", None));
  Util.addIfNotNone(properties, "serverInactivityTime", roleProperties.optString("websphere.dynamiccluster.serverinactivitytime", None));
  Util.addIfNotNone(properties, "operationalMode", roleProperties.optString("websphere.dynamiccluster.operationalmode", None));
  Util.addIfNotNone(properties, "maxNodes", roleProperties.optString("websphere.dynamiccluster.maxnodes", None));
  Util.addIfNotNone(properties, "numVerticalInstances", roleProperties.optString("websphere.dynamiccluster.numverticalinstances", None));
  print "Creating DynamicCluster with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("DynamicCluster", parentid, properties);
  return objid;

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("DynamicCluster resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  if not roleProperties.has("websphere.dynamiccluster.name"):
    raise Exception("Resource role properties does not contain websphere.dynamiccluster.name!");

  atts = [];
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.minnodes", None), "minNodes","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.name", None), "name","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.membershippolicy", None), "membershipPolicy","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.mininstances", None), "minInstances","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.isolationgroup", None), "isolationGroup","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.maxinstances", None), "maxInstances","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.strictisolationenabled", None), "strictIsolationEnabled","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.servertype", None), "serverType","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.serverinactivitytime", None), "serverInactivityTime","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.operationalmode", None), "operationalMode","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.maxnodes", None), "maxNodes","DynamicCluster");
  Util.addAttIfChanged(objid, atts, roleProperties.optString("websphere.dynamiccluster.numverticalinstances", None), "numVerticalInstances","DynamicCluster");
  if len(atts) != 0:
    print "Modifying DynamicCluster with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "DynamicCluster configuration up to date.";

