#- Licensed Materials - Property of IBM Corp.
#- IBM UrbanCode Deploy
#- (c) Copyright IBM Corporation 2014, 2015. All Rights Reserved.
#-
#- U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
#- GSA ADP Schedule Contract with IBM Corp.

from org.codehaus.jettison.json import JSONObject, JSONArray
import sys;
from utilities import Util
from AuditPolicy import AuditPolicy
from AuditSpecification import AuditSpecification

__name_att__ = None;

def _export(objid, parentrespath, name = ""):


  if parentrespath == "/":
    parentrespath = "";
  respath = "%(parentrespath)s/%(name)s" % { 'parentrespath':parentrespath, 'name':name }
  if not respath.startswith("/"):
    respath = "/" + respath;

  exportedObject = JSONObject();
  exportedObject.put("name", name);
  exportedObject.put("path", respath);
  exportedObject.put("teamMappings", JSONArray());
  exportedObject.put("inheritTeam", "true");
  exportedObject.put("description", "Discovered WebSphereAudit");
  exportedObject.put("roleName", "WebSphereAudit");

  roleProperties = JSONObject();

  exportedObject.put("roleProperties", roleProperties);
  result = { 'object': exportedObject, 'respath':respath }
  extraObjects = [];
  typeFolders = {};
  
  auditPolicy = Util.getOptionalAttribute(objid, 'auditPolicy',"Audit");
  if auditPolicy is not None and len(auditPolicy) > 0:
    returndict = Util.createTypeFolder(respath, "AuditPolicy", typeFolders);
    currespath = returndict['path'];
    if returndict.has_key('object'):
      extraObjects.append(returndict['object']);
    Util.addAllFromExport(extraObjects, AuditPolicy._export(auditPolicy, currespath, "AuditPolicy"));    
  
  i = 0;
  auditSpecs = Util.parseConfigIdListAttribute(objid, 'auditSpecifications', 'Audit');
  for auditSpec in auditSpecs:
    if len(auditSpec) > 0:
      returndict = Util.createTypeFolder(respath, "AuditSpecification", typeFolders);
      currespath = returndict['path'];
      if returndict.has_key('object'):
        extraObjects.append(returndict['object']);
      specName = Util.getOptionalAttribute(auditSpec, "name", "AuditSpecification");
      if specName is not None and len(specName) > 0:
        resourceName = specName;
      else:
        resourceName = "AuditSpecification%s" % i;
      Util.addAllFromExport(extraObjects, AuditSpecification._export(auditSpec, currespath, resourceName));
      i = i + 1;

  if len(extraObjects) != 0:
    result['extraObjects'] = extraObjects;
  return result;

def create(parentid, jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("Audit resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  properties = [];
  print "Creating Audit with attributes";
  for prop in properties:
    print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };
  objid = Util.create("Audit", parentid, properties);
  
  auditPolicy = Util.getOptionalAttribute(objid, 'auditPolicy',"Audit");
  if auditPolicy is not None and len(auditPolicy) > 0:
    Util.remove(auditPolicy);

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");  
      if currole == "WebSphereAuditPolicy":
        AuditPolicy.create(objid, curjsonobject);
      elif currole == "WebSphereAuditSpecification":
        AuditSpecification.create(objid, curjsonobject);

def update(objid,jsonobject):
  if not jsonobject.has("roleProperties"):
    raise Exception("Audit resource has no role properties!");

  roleProperties = jsonobject.getJSONObject("roleProperties");

  atts = [];
  if len(atts) != 0:
    print "Modifying Audit with attributes:"
    for prop in atts:
      print "%(name)s = %(value)s" % { 'name': prop[0], 'value': prop[1] };

    Util.modify(objid, atts);
  else:   
    print "Audit configuration up to date.";
    
  auditPolicy = Util.getOptionalAttribute(objid, 'auditPolicy',"Audit");
  if auditPolicy is not None and len(auditPolicy) > 0:
    Util.remove(auditPolicy);

  auditSpecs = Util.parseConfigIdListAttribute(objid, 'auditSpecifications', 'Audit');
  for auditSpec in auditSpecs:
    if len(auditSpec) > 0:
      Util.remove(auditSpec);

  if jsonobject.has('children'):
    for curjsonobject in Util.getHighestChildrenWithRole(jsonobject.getJSONArray('children')):
      currole = curjsonobject.getString("roleName");  
      if currole == "WebSphereAuditPolicy":
        AuditPolicy.create(objid, curjsonobject);
      elif currole == "WebSphereAuditSpecification":
        AuditSpecification.create(objid, curjsonobject);
