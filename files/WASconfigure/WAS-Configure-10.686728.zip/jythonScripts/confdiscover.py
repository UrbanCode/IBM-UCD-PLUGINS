###
# Licensed Materials - Property of IBM Corp.
# @product.name.full@
# (c) Copyright IBM Corporation 2003, 2014. All Rights Reserved.
# 
# U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
# GSA ADP Schedule Contract with IBM Corp.
# 
# Filename: confdiscover.py
# 
# 
###

from java.io import File, FileInputStream;
from java.lang import Boolean;
from java.util import HashMap, Properties, TreeMap;
from org.codehaus.jettison.json import JSONObject, JSONArray;
import sys;
import os;
import Queue;

import javaos
if javaos._osType == 'posix' and java.lang.System.getProperty('os.name').startswith('Windows'):
  sys.registry.setProperty('python.os', 'nt');
  reload(javaos);

sys.modules['AdminConfig'] = AdminConfig
sys.modules['AdminControl'] = AdminControl
sys.modules['AdminApp'] = AdminApp
sys.modules['AdminTask'] = AdminTask

def isValidType(type):
  return Util.isValidType(type);

configurationTypes = {};
stack = [];

def handleType(type):
  if len(configurationTypes) == 0:
    return 1;

  if configurationTypes.has_key(type):
    return 1

  for item in stack:
    if configurationTypes.has_key(item):
      return 1;

  return 0

def getDescendentsFromTreeMap(map, path):
  return map.subMap(path + "/", Boolean.FALSE, path + "0", Boolean.FALSE);

def findHighestNoneApplicablePath(path, map, appTypes):
  #remove training slash because i don't trust people
  while path.endswith("/"):
    path = path[0:-1];

  #ensure it starts with a slash
  if not path.startswith("/"):
    path = "/" + path;

  prev = path;
  found = None;
  while len(path) > 0 and found is None:
    slashindex = path.rfind("/");
    path = path[0:slashindex];
    if len(path) > 0:
      resource = map.get(path);
      if resource is None:
        Log.debug("No resource in map for path %s" % path);
      else:
        if resource.has("roleName"):
          rolename = resource.getString("roleName");
          type = Util.roleNameToType(rolename);
          if appTypes.has_key(type):
            found = prev;
          else:
            prev = path;
  return found;

def getAncestorsFromTreeMap(map, path):
  returnlist = [];
  #remove training slash because i don't trust people
  while path.endswith("/"):
    path = path[0:-1];

  #ensure it starts with a slash
  if not path.startswith("/"):
    path = "/" + path;

  #note we dont want this method to return the passed in resource
  while len(path) > 0:
    slashindex = path.rfind("/");
    path = path[0:slashindex];
    if len(path) > 0:
      resource = map.get(path);
      if resource is None:
        Log.debug("No resource in map for path %s" % path);
      else:
        returnlist.append(resource);

  return returnlist;

def filterForTypes(resourceJSONArray, applicableTypes):
  if len(configurationTypes) == 0:
    return resourceJSONArray;
  filteredArray = JSONArray();
  treemap = TreeMap();
  typemap = HashMap();
  addedpaths = {};
  for i in range(resourceJSONArray.length()):
    resourceJSONObject = resourceJSONArray.getJSONObject(i);
    thispath = resourceJSONObject.getString('path');
    Log.debug("Path in export json '%s'" % thispath);
    treemap.put(thispath, resourceJSONObject);
    reslist = None;
    if resourceJSONObject.has('roleName'):
      thisrole = resourceJSONObject.getString('roleName');
      thistype = Util.roleNameToType(thisrole);
      if typemap.containsKey(thistype):
        reslist = typemap.get(thistype);
      else:
        reslist = [];
        typemap.put(thistype, reslist);
      reslist.append(thispath);

  for configType in configurationTypes.keys():
    if typemap.containsKey(configType):
      reslist = typemap.get(configType);
      for resourcepath in reslist:
        resourceToExportPath = findHighestNoneApplicablePath(resourcepath, treemap, applicableTypes);
        if not addedpaths.has_key(resourceToExportPath):
          filteredArray.put(treemap.get(resourceToExportPath));
          addedpaths[resourceToExportPath] = resourceToExportPath;

        for resourceJSON in getDescendentsFromTreeMap(treemap, resourceToExportPath).values():
          curpath = resourceJSON.getString("path");
          if not addedpaths.has_key(curpath):
            filteredArray.put(resourceJSON);
            addedpaths[curpath] = curpath;

        for resourceJSON in getAncestorsFromTreeMap(treemap, resourceToExportPath):
          curpath = resourceJSON.getString("path");
          if not addedpaths.has_key(curpath):
            filteredArray.put(resourceJSON);
            addedpaths[curpath] = curpath;
  return filteredArray;

#returns a JSONArray
def exportObjectToResources(objdir, objid, respath, containmentpath, roleName):
  stack.append(roleName);
  mod = Util.getRoleModule(roleName);
  finalResult = JSONArray();
  hasChildren = 0;
  if mod is not None:
    if 'export' in dir(mod):
      #some objects are reliant on their parents to export them, so they don't implement an export method
      execFileDict = mod.export(objid, containmentpath, respath);
      dictKeys = execFileDict.keys();
      if 'object' in dictKeys:
        exportedObject = execFileDict['object']
        curcontainmentpath = execFileDict['conpath'];
        Log.debug("Exported %s" % curcontainmentpath)
        currespath = execFileDict['respath'];
        if exportedObject != None:
          typeFolders = {}
          for childtype in Util.getChildrenTypesFromDirectory(objdir):
            folderadded = 0;
            folderobject = None;
            if childtype != "" and isValidType(childtype):
              childdir = Util.findObjectDir(childtype, objectsDir);
              childsearchpath = "%(curpath)s%(type)s:/" % { 'curpath': curcontainmentpath, 'type':childtype }
              Log.debug("Checking child searchpath %s" % childsearchpath);
              for x in Util.getid(childsearchpath).splitlines():
                returndict = Util.createTypeFolder(currespath, childtype, typeFolders);
                if returndict.has_key('object'):
                  folderobject = returndict['object'];
                curchildrespath = returndict['path'];
                Log.debug("Exporting %s" % x);
                curresources = exportObjectToResources(childdir, x, curchildrespath, curcontainmentpath, childtype)
                if curresources is not None:
                  if not folderadded and folderobject is not None:
                    folderadded = 1;
                    Util.addFromExport(finalResult, folderobject);
                  for y in range(curresources.length()):
                    hasChildren = 1;
                    Util.addFromExport(finalResult, curresources.get(y));
          Util.addAllFromExport(finalResult, execFileDict);
  stack.pop();
  return finalResult


def mainmethod():
  inputPropsFile = File(sys.argv[0]);
  logDir = inputPropsFile.getParentFile();
  inputProps = Properties();
  inStream = FileInputStream(inputPropsFile);
  inputProps.load(inStream);
  inStream.close();


  logFile = open("%s/debugLog.txt" % logDir.getAbsolutePath(),'w');
  redoFile = open("%s/redoLog.txt" % logDir.getAbsolutePath(),'w');
  Log.setLogFile(logFile);
  Log.setRedoFile(redoFile);


  resourceJSONObject = JSONObject(inputProps.getProperty("fullResourceConfiguration"));
  configurationTypesInput = inputProps.getProperty("configurationTypes");

  adminConfigTypes = Util.getAdminConfigTypes();

  if configurationTypesInput is not None and len(configurationTypesInput) > 0:
    for line in configurationTypesInput.splitlines():
      line = line.strip();
      if len(line) > 0:
        if line in adminConfigTypes:
          configurationTypes[line] = line;

  Util.setConfigurationTypes(configurationTypes);

  roleName = resourceJSONObject.getString("roleName");
  roleName = Util.roleNameToType(roleName);
  topObjectDir = Util.findObjectDir(roleName, objectsDir);

  finalResources = JSONArray();
  respath = "/"
  containmentpath = Util.findContainmentPath(resourceJSONObject);

  index = containmentpath.rindex('/',0,len(containmentpath)-2)+1;
  parentcontainmentpath = containmentpath[0:index];
  if parentcontainmentpath == "/":
    parentcontainmentpath="";
  Log.debug("Initial Containment path %s" % containmentpath);
  scope = None 
  if containmentpath != "":
    objid = Util.getid(containmentpath);
  else:
    objid = Util.getid("/Cell:/");
  Log.debug("Fin Containment path %s" % containmentpath);
  Log.debug("Parent Containment path %s" % parentcontainmentpath);
  Log.debug(roleName);
  Log.debug(respath)
  Log.debug(objid)
  curresources = exportObjectToResources(topObjectDir, objid, respath, parentcontainmentpath, roleName)
  if curresources is not None:
    for y in range(curresources.length()):
      finalResources.put(curresources.get(y));

  applicableTypes = Util.getApplicableTypes("%s/plugin.xml" % PLUGIN_HOME);
  finalResources = filterForTypes(finalResources, applicableTypes);

  logFile.close();
  redoFile.close();
  print "\nConfiguration Discovery Complete.";
  print finalResources.toString(4);

PLUGIN_HOME=os.environ['PLUGIN_HOME'];
objectsDir = "%(plugHome)s%(fileSep)sobjects" % { 'plugHome': PLUGIN_HOME, 'fileSep': os.sep };
sys.path.insert(0,objectsDir);
Util = __import__("utilities.Util").Util;
Log = __import__("WASConfLog.Log").Log;

#we put everything possible in a method due to python global versus function scoping.
#repeatadly had issues with name collisions causing refactoring to pick up  a global variable with the same name as a local variable that was removed
mainmethod();
