#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2017. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import org.apache.tools.ant.taskdefs.SQLExecWithCall

final def workDir = new File('.').canonicalFile
def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()

final def autocommit = props['autocommit'].trim()
final def connectionString = props['connectionString'].trim()
final def delimiter = props['delimiter']
final def encoding = props['encoding'].trim()
final def excludes = props['excludes'].trim()
final def files = props['files'].trim()
final def includes = props['includes'].trim()
final def jdbcDriver = props['jdbcDriver'].trim()
final def onerror = props['onerror'].trim()
final def keepformat = props['keepformat']
final def passScript = props['passScript']
final def password = props['password']?:passScript
final def print = props['print'].trim()
final def username = props['username']
final def showWarnings = props['showWarnings']
final def treatWarningsAsErrors = props['treatWarningsAsErrors']

try {
    def ant = new AntBuilder()

    ant.taskdef(name:"sqlwithcall", classname:"org.apache.tools.ant.taskdefs.SQLExecWithCall")
    def antArgs = [
        driver: jdbcDriver,
        url: connectionString,
        userid: username,
        password: password,
        delimiter: delimiter,
        autocommit: autocommit,
        print: print,
        onerror: onerror,
        keepformat: keepformat,
        showWarnings: showWarnings,
        treatWarningsAsErrors: treatWarningsAsErrors
    ]
    if (encoding) {
        antArgs.encoding = encoding
    }
    ant.sqlwithcall(antArgs) {
        if (files != null && files.trim() != "") {
            filelist(
                    dir:'.',
                    'files':files
            )
        }
        else {
            if (excludes) {
                fileset(
                        dir: '.',
                        defaultexcludes: 'no',
                        'includes': includes.split('\n').join(','),
                        'excludes': excludes.split('\n').join(',')
                )
            }
            else {
                fileset(
                        dir: '.',
                        defaultexcludes: 'no',
                        'includes': includes.split('\n').join(',')
                )
            }
        }
    }
}
catch (Exception e) {
    println "Error Executing SQL Scripts: ${e.message}"
    System.exit(1)
}

System.exit(0)
