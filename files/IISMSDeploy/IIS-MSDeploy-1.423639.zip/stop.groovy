import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper


final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

def name = props['appName'];
def commandPath = props['commandPath'];


def ch = new CommandHelper(new File('.'));

def args = [];
args = [commandPath+'msdeploy.exe', '-verb:sync', '-source:recycleApp', '-dest:recycleApp='+name+',recycleMode=StopAppPool'];
ch.runCommand(args.join(' '), args);
