import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

final def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def commandPath = props['commandPath']
def argStrings = props['argString']?.split('\n')
def providerType = props['providerType']
def path = props['path']

def ch = new CommandHelper(new File('.'))

def args = []
args = [commandPath+'msdeploy.exe', '-verb:delete', '-dest:'+ providerType+'='+path]
argStrings.each { arg ->
    args << arg
}
ch.runCommand(args.join(' '), args)
