/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

final def apTool = new AirPluginTool(this.args[0], this.args[1])
def stepProps = apTool.getStepProperties();

def commandPath = stepProps['commandPath'];
def sourceProviderType = stepProps['sourceProviderType'];
def destProviderType = stepProps['destProviderType'];
def sourcePath = stepProps['sourcePath'];
def destPath = stepProps['destPath'];
def argStrings = stepProps['argString']?.split('\n')

def ch = new CommandHelper(new File('.'));
def args = [];
args = [commandPath+'msdeploy.exe', '-verb:sync', '-source:'+sourceProviderType+'='+sourcePath];
if(destPath) {
    args <<'-dest:'+destProviderType+'='+destPath;
} else {
    args << '-dest:'+destProviderType;
}
argStrings.each { arg ->
    args << arg;
}
ch.runCommand(args.join(' '), args);
