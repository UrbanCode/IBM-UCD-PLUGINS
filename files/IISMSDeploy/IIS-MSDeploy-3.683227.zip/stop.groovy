/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * IBM UrbanCode Deploy
 * IBM UrbanCode Release
 * IBM AnthillPro
 * (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.iismsdeploy.MSDeployCmdLineHelper

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

def cmdPath = props['commandPath']
def verb = 'sync'
def srcType = 'recycleApp'
def destType = 'recycleApp'
def destPath = '\'' + props['destPath'] + '\'' + ',recycleMode=\'StopAppPool\''
def argStrings = props['argString']?.split('\n')

mshelper = new MSDeployCmdLineHelper()
mshelper.runMSDeployScript(cmdPath, verb, srcType, destType, null, destPath, argStrings)