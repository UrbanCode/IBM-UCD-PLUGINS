/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.aspera.AsperaHelper

final def apTool   = new AirPluginTool(args[0], args[1])
AsperaHelper helper = new AsperaHelper()
def props          = apTool.getStepProperties()
def sourceFilePath = helper.text2StringList(props['sourceFilePath'])
def sourceTextFile = helper.fileText2List(props['sourceTextFile'])
def asperaFilePath = props['asperaFilePath']
def asperaHost     = helper.text2HostnameList(props['asperaHost'])[0]
def asperaUsername = props['asperaUsername']
def overwrite      = props['overwrite']
def maxRate        = props['maxRate'] as int
def additionalArgs = helper.text2StringList(props['additionalArgs'])
def envPassword    = props['envPassword']
def envToken       = props['envToken']
def envCookie      = props['envCookie']
def envFilePass    = props['envFilePass']
def envProxyPass   = props['envProxyPass']
def scriptLocation = props['scriptLocation']

def exitCode = 1

// Confirm file input for sourceTextFile and additionalArgs
def filePaths = sourceFilePath + sourceTextFile
filePaths.unique()
if (filePaths.size() == 0) {
    println "ERROR  No files were given to upload."
    println "POSSIBLE SOLUTION  Enter input for the Source File Paths or Source Text File properties."
    System.exit(1)
}

def workDir = new File(".").canonicalFile
def ch = new CommandHelper(workDir)
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
def ascp = "ascp"
if (isWindows){
    ascp += ".exe"
}

// Concat file and path
def fullScriptPath = scriptLocation
if (!fullScriptPath.endsWith(File.separator)) {
    fullScriptPath += File.separator
}
fullScriptPath += ascp

File f = new File(fullScriptPath)
if (!f.isFile()) {
    throw new Exception ("ERROR  ${fullScriptPath} does not exist!")
}

// Construct ascp Command
def args = []

// Set all environment variables
if (envPassword) {
    helper.addEnvVars("ASPERA_SCP_PASS", envPassword, ch)
}
if (envToken) {
    helper.addEnvVars("ASPERA_SCP_TOKEN", envToken, ch)
}
if (envCookie) {
    helper.addEnvVars("ASPERA_SCP_COOKIE", envCookie, ch)
}
if (envFilePass) {
    helper.addEnvVars("ASPERA_SCP_FILEPASS", envFilePass, ch)
}
if (envProxyPass) {
    helper.addEnvVars("ASPERA_PROXY_PASS", envProxyPass, ch)
}

// ascp Script Location
args << fullScriptPath

// Extra Arguments
args << "--overwrite=" + overwrite

if (maxRate > -1) {
    args << "-l " + maxRate
}

for (addArg in additionalArgs) {
    args << addArg
}

// Local Source Paths
for (file in filePaths) {
    args << file
}

// Aspera Login, Host, and Destination information
def login = ""
if (asperaUsername) {
    login += asperaUsername + "@"
}
login += asperaHost.toString() + ":"
login += asperaFilePath

args << login

exitCode = ch.runCommand("ACTION  Uploading files to Aspera Server..." , args)

System.exit(exitCode)