<?php
// Supported uDeploy version
$ver['ucd'] = array('6.1.0.2.552082','6.1.0.2.ifix01.558150', '6.1.0.3.568411');

// Current uCommand version
$ver['ucommand'] = file_get_contents('VERSION.txt');