<?php
// Log file
$config['log'] = 'Ucommand.log';

// Stdout redirect. Leave empty if no log is required
$config['stdout'] = 'output_' . date('Ymd-Hi') . '.log';

// Enable debug options
$config['debug'] = false;