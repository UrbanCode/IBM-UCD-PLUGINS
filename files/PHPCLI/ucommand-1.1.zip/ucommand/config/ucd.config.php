<?php
// Urban Code Deploy settings
$config['alias'] = 'template';

/*
 * Path where to save the results
* If NOT Set, will be defaulted to: %path_to_current_working_directory%/backups
*/
$config['output'] = '';

// Path for JAVA HOME
$config['java_home'] = '/usr/lib/j2sdk1.6-ibm/';

// Silent mode for outputs
$config['silent'] = false;

// Run a scan of exported files and verify that are valid json
$config['json_check'] = false;

// CURL settings for secure connection
$config['insecure'] = true;
$config['certificate'] = '';