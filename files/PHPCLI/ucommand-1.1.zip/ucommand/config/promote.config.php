<?php
$config = array();
$config['origin_alias'] = '';
$config['destination_alias'] = '';