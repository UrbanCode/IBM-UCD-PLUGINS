<?php
// TODO: an array with all component => version and component => description
/*
$components = array(
    array (
        'name' => 'component_name',
        'version' => 'new_version',
        'description' => 'description',
    ),
);
*/