<?php
// Log file
$config['log'] = 'UrbanCodeClient.log';

// Enable debug options
$config['debug'] = false;