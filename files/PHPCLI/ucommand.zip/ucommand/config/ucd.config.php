<?php
// Urban Code Deploy settings
$config['weburl'] = 'https://scdevucd.rtp.raleigh.ibm.com:8443';
$config['username'] = '';
$config['password'] = ''; // Deprecated
// AuthToken for udclient
$config['authtoken'] = '';
// Path to the file where cookies for curl are saved (includes UCD_SESSION_KEY)
$config['cookie_file'] = ''; // Deprecated
// Default Application and evironment
$config['application'] = 'SalesConnect';
$config['environment'] = '';

// Path where Urban Code Deploy client is saved 
$config['udcpath'] = '';

/*
 * Path where to save the results
* If NOT Set, will be defaulted to: %path_to_current_working_directory%/backups
*/
$config['output'] = '';

// Path for JAVA HOME
$config['java_home'] = '/opt/java/ibm-java-i386-60/';

// Silent mode for outputs
$config['silent'] = false;

// Run a scan of exported files and verify that are valid json
$config['json_check'] = false;

// CURL settings for secure connection
$config['insecure'] = true;
$config['certificate'] = '';

/* 
 * Implement Component::Process Steps - Impersonation
 * Impersonation actions configuration is set up in: /udclient/config/ucd.impersonation.config.php
 */
$config['apply_impersonation'] = false;