<?php
$config = array();
$config['origin_weburl'] = '';
$config['origin_username'] = '';
$config['origin_password'] = ''; // Deprecated
$config['origin_authtoken'] = '';
$config['destination_weburl'] = '';
$config['destination_username'] = '';
$config['destination_password'] = ''; // Deprecated
$config['destination_authtoken'] = '';
$config['application'] = '';
$config['insecure'] = '';
$config['origin_certificate'] = '';
$config['destination_certificate'] = '';