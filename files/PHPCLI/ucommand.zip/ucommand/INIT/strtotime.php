<?php
$date = $argv[1];
echo strtotime($date);
?>
