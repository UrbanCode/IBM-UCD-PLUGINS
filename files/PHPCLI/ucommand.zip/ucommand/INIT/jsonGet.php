<?php
$key = $argv[1];
$output = $argv[2];
$result = json_decode($output, true);
if (array_key_exists($key,$result)) {
	echo $result[$key];
} else {
	exit(1);
}
?>
