<?php
/****************************************************************
 * IBM Confidential
 *
 * SFA100-Collaboration Source Materials
 *
 * (C) Copyright IBM Corp. 2014
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office
 *
 ***************************************************************/
/**
 * Layer for rest Apis calls in entryPoint of Ucommand
 *
 * @author Felice Geracitano.......feliecege@ie.ibm.com
 *
 */

require_once ('ucdclient/AgentUdclientApi.php');
require_once ('ucdclient/ApplicationUdclientApi.php');
require_once ('ucdclient/ComponentUdclientApi.php');
require_once ('ucdclient/EnvironmentUdclientApi.php');
require_once ('ucdclient/ResourceUdclientApi.php');
require_once ('ucdclient/SnapshotUdclientApi.php');
require_once ('ucdclient/SystemUdclientApi.php');


class Udclient implements ApiInterface {
    protected $alias;
    protected $config;
    protected $dir;
    protected $objects;
    protected $logout;
    protected $return;
    protected $server;
    
    public function __construct() {
        $this->objects = array (
            'agent' => null,
            'application' => null,
            'component' => null,
            'environment' => null,
            'resource' => null,
            'snapshot' => null,
            'system' => null
        );
    }
    
    /**
     *  Get Agent Udclient APIs
     *  @return object
     */
    public function agent() {
        if (empty( $this->objects['agent'] )) {
            $this->objects['agent'] = new AgentUdclientApi();
            $this->set($this->objects['agent']);
        }
        return $this->objects['agent'];
    }
    
    /**
     *  Get Application Udclient APIs
     *  @return object
     */
    public function application() {
        if (empty( $this->objects['application'] )) {
            $this->objects['application'] = new ApplicationUdclientApi();
            $this->set($this->objects['application']);
        }
        return $this->objects['application'];
    }
    
    /**
     *  Get Component Udclient APIs
     *  @return object
     */
    public function component() {
        if (empty( $this->objects['component'] )) {
            $this->objects['component'] = new ComponentUdclientApi();
            $this->set($this->objects['component']);
        }
        return $this->objects['component'];
    }
    
    /**
     * Get environment Udclient APIs
     * @return object
     */
    public function environment() {
        if (empty( $this->objects ['environment'] )) {
            $this->objects ['environment'] = new EnvironmentUdclientApi();
            $this->set( $this->objects ['environment'] );
        }
        return $this->objects ['environment'];
    }
    
    /**
     *  Get resource Udclient APIs
     *  @return object
     */
    public function resource() {
        if (empty( $this->objects ['resource'] )) {
            $this->objects ['resource'] = new ResourceUdclientApi();
            $this->set($this->objects ['resource']);
        }
        return $this->objects ['resource'];
    }
    
    /**
     *  Set Api objcet with father parameters if needed
     *  @return object
     */
    public function set($api) {
        if (isset( $this->server ) && isset( $this->config )) {
            $api->setupServer( $this->server, $this->config, false, $this->logout);
        }
        // setupAlias set alias parameter in Api object
        // and return a config array unuseful here
        if (isset( $this->alias )) {
            $api->setup( $this->alias );
        }
        
        if (isset( $this->output )) {
            $api->setOutput( $this->output );
        }
        if (isset( $this->return )) {
            $api->setReturn( $this->return );
        }
    }
    
    /**
     *  Set output for all Apis object already created
     *  and set dir value in the layer class
     */
    public function setOutput( $dir, $message = false) {
        $this->output = $dir;
        foreach ( $this->objects as $key => $value ) {
            if ( !empty ($this->objects[$key] )) {
            $this->objects[$key]->setOutput($this->output, $message);
            }
        }
    }
    
    /**
     *  Set Return for all Apis object already created
     *  and set return value in the layer class
     */
    public function setReturn($type) {
        $this->return = $type;
        foreach ( $this->objects as $key => $value ) {
            if (! empty( $this->objects [$key] )) {
                $this->objects [$key]->setReturn( $this->return );
            }
        }
    }
    
    /**
     *  Set Alias for all Apis object already created
     *  and set alias value in the layer class
     */
    public function setupAlias($alias) {
        $this->alias = $alias;
        foreach ( $this->objects as $key => $value ) {
            if (! empty( $this->objects [$key] )) {
                // setupAlias set alias parameter in Api object
                // and return a config array unuseful here
                // to connect to alias sever need setupServer
                $this->objects[$key]->setup( $this->alias );
            }
        }
    }
    
    /**
     *  Set Server for all Apis object already created
     *  and set alias value in the layer class
     */
    public function setupServer($server, $config, $message = false, $logout) {
        $return = null;
        $this->server = $server;
        $this->config = $config;
        $this->logout = $logout;
        foreach ( $this->objects as $key => $value ) {
            if (! empty( $this->objects [$key] )) {
                $this->objects [$key]->setupServer( $this->server, $this->config, $message, $this->logout );
            }
        }
        
        if ($return === null){
            // create an api to test connection
            $return = $this->application()->setupServer($this->server, $this->config, $message, $this->logout);
        }
        return $return;
    }
    
    /**
     *  Get snapshot Udclient APIs
     *  @return object
     */
    public function snapshot() {
        if (empty( $this->objects ['snapshot'] )) {
            $this->objects ['snapshot'] = new SnapshotUdclientApi();
            $this->set($this->objects ['snapshot']);
        }
        return $this->objects ['snapshot'];
    }
    
    /**
     *  Get system Udclient APIs
     *  @return object
     */
    public function system() {
        if (empty( $this->objects ['system'] )) {
            $this->objects ['system'] = new SystemUdclientApi();
            $this->set($this->objects ['system']);
        }
        return $this->objects ['system'];
    }

}