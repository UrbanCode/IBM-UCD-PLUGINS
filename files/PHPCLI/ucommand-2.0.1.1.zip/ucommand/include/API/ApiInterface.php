<?php
interface ApiInterface {
    public function setOutput($dir, $message);
    public function setReturn($type);
    public function setupAlias($alias);
    public function setupServer($server, $config, $message, $logout);
}