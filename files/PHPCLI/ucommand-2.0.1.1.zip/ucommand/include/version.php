<?php
// Supported uDeploy version
$ver['ucd'] = array('6.1.1.5.671927');

// Current uCommand version
$ver['ucommand'] = file_get_contents('VERSION.txt');