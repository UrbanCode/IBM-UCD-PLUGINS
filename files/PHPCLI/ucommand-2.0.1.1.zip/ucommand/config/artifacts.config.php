<?php
$PLUGIN_DIR = '<PLUGIN_DIR>';
$SFA_SETUP = '<SFA_SETUP>';
$SUGAR_ZIP = basename('<SUGAR_ZIP>');

/* Plugins */
$COMMONSCUTILS = basename('<COMMONSCUTILS>','.zip');
$CONNECTIONS = basename('<CONNECTIONS>','.zip');
$DB2 = basename('<DB2>','.zip');
$LOGICHOOKS = basename('<LOGICHOOKS>','.zip');
$LPDESERVICE = basename('<LPDESERVICE>','.zip');
$MOBILE = basename('<MOBILE>','.zip');
$NOTES = basename('<NOTES>','.zip');
$SANITY = basename('<SANITY>','.zip');
$SOCIALANALYTICS = basename('<SOCIALANALYTICS>','.zip');
$TEST = basename('<TEST>','.zip');

$artifacts = array(
                'DownloadDeploymentDirectory' => array(
                                'base' => $SFA_SETUP,
                                'include'  => array(
                                                "Sugar\/**",
                                                "deployment\/**"
                                )
                ),
                'DownloadandUnzipSugarUltandSugarInstanceManager' => array(
                                'base' => $SFA_SETUP,
                                'include' => $SUGAR_ZIP,
                ),
                'ibmsugarplugin.commonscutils' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $COMMONSCUTILS . '.zip',
                ),
                'ibmsugarplugin.connections' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $CONNECTIONS . '.zip',
                ),
                'ibmsugarplugin.db2' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $DB2 . '.zip',
                ),
                'ibmsugarplugin.logichooks' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $LOGICHOOKS . '.zip',
                ),
                'ibmsugarplugin.lpdeservice' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $LPDESERVICE . '.zip',
                ),
                'ibmsugarplugin.mobile' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $MOBILE . '.zip',
                ),
                'ibmsugarplugin.notes' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $NOTES . '.zip',
                ),
                'ibmsugarplugin.sanity-check' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $SANITY . '.zip',
                ),
                'ibmsugarplugin.socialanalytics' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $SOCIALANALYTICS . '.zip',
                ),
                'ibmsugarplugin.test' => array(
                                'base' => $PLUGIN_DIR,
                                'include' => $TEST . '.zip',
                ),
);