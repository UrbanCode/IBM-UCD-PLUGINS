<?php
$config['alias'] = 'template';
$config['weburl'] = '';
$config['username'] = '';
$config['authtoken'] = '';
$config['application'] = '';
$config['environment'] = '';