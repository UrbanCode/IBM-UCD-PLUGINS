<?php
$shortopts = "";

// "abc:"		Required value
// "abc::"	Optional value
// "abc"	No value
$longopts = array(
    "action:", 
    "alias:",
    "application:",
    "base:",
    "clean:",
    "component:",
    "componentTemplate:",
    "description:",
    "destination:",
    "dir:",
    "environment:",
    "environments:",
    "exclude:",
    "file:",
    "force:",
    "include:",
    "help::",
    "new:",
    "old:",
    "origin:",
    "process:",
    "resource:",
    "snapshot:",
    "source:",
    "status:",
    "team:",
    "template:",
    "timeout:",
    "upgradeProcess:",
    "upgradeTemplate:",
    "version:"
);