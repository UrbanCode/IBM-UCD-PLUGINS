<?php
// Log file name
$config['log'] = 'Ucommand.log';

// Stdout redirect. Leave empty if no log is required
$config['stdout'] = 'output_' . date('Ymd-His-u') . '.log';

// Enable debug options
$config['debug'] = false;

// Clean tmp folder options - Clean every X days files older than X days
$config['tmp_clean_time'] = 7;