<?php
$key = $argv [1];
$output = $argv [2];
$result = json_decode( $output, true );

if (is_array( $result ) && array_key_exists( $key, $result )) {
    echo $result [$key];
    exit( 0 );
} else {
    exit( 1 );
}
?>