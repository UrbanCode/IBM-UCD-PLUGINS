/**
* Licensed Materials - Property of IBM* and/or HCL**
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2002, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;
import com.urbancode.air.plugin.webspheremq.helper.MQScriptHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1]) //assuming that args[0] is input props file and args[1] is output props file

def props = apTool.getStepProperties();

// Topic Properties
def channelName    = props["channelName"];
def batchint       = props["batchint"];
def batchlim       = props["batchlim"];
def batchsz        = props["batchsz"];
def conName        = props["conName"];
def description    = props["description"];
def discint        = props["discint"];
def maxmsgl        = props["maxmsgl"];
def npmspeed       = props["npmspeed"];
def trptype        = props["trptype"];
def xmitq          = props["xmitq"];
def additionalArgs = props["additionalArgs"].split('\n').join(',').split(',')
                            .findAll{it && it.trim().size() > 0} as String[];
println "Additional Arguments: " + additionalArgs

def helper         = MQScriptHelper.newInstance(props)

helper.startCommand("ALTER");
helper.addKeyValueToCommand("CHANNEL", channelName);
helper.addUnquotedKeyValueToCommand("CHLTYPE", "SDR");

if (batchint) {
    helper.addUnquotedKeyValueToCommand("BATCHINT", batchint);
}
if (batchlim) {
    helper.addUnquotedKeyValueToCommand("BATCHLIM", batchlim);
}
if (batchsz) {
    helper.addUnquotedKeyValueToCommand("BATCHSZ", batchsz);
}
if (description) {
    helper.addKeyValueToCommand("DESCR", description);
}
if (conName) {
    helper.addKeyValueToCommand("CONNAME", conName);
}
if (discint) {
    helper.addUnquotedKeyValueToCommand("DISCINT", discint);
}
if (maxmsgl) {
    helper.addUnquotedKeyValueToCommand("MAXMSGL", maxmsgl);
}
if (npmspeed != "NONE") {
    helper.addUnquotedKeyValueToCommand("NPMSPEED", npmspeed);
}
if (trptype != "NONE") {
    helper.addUnquotedKeyValueToCommand("TRPTYPE", trptype);
}
if (xmitq) {
    helper.addKeyValueToCommand("XMITQ", xmitq);
}
for (def arg : additionalArgs) {
    helper.addSingletonElementToCommand(arg);
}

helper.writeCommand();
helper.execute();
