package com.urbancode.air.plugin.webspheremq.helper;
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;

public class MQHelper {
    def workDir = new File(".").canonicalFile
    final def cmdHelper = new CommandHelper(workDir)
    def cmdArgs = []
    def scriptData
    def out = System.out
    
    public MQHelper(def cmdArgsIn) {
        cmdArgs = cmdArgsIn;
    }
    
    public MQHelper(def cmdArgsIn, def scriptDataIn) {
        cmdArgs = cmdArgsIn
        scriptData = scriptDataIn
    }
    
    def runCommand(def message) {
        cmdHelper.runCommand(message, cmdArgs);
    }
    
    def runCommandScript(def message) {
        cmdHelper.runCommand(message, cmdArgs) {proc ->
            proc.withWriter{it << scriptData};
            proc.consumeProcessOutput(out, out);
        }
    }
}