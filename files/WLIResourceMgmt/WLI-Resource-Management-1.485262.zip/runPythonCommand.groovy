import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper
import java.lang.Runtime

def apTool = new AirPluginTool(this.args[0], this.args[1])
def pythonScript = this.args[2]
def isWindows = apTool.isWindows

def props = apTool.getStepProperties()
def domainEnvPath = props['weblogicDomainPath']
def pythonPath = props['weblogicPythonPath']

def wlCommand = "wlst"
def domainCommand = "setDomainEnv"

if (isWindows) {
    wlCommand = wlCommand + ".cmd"
    domainCommand = domainCommand + ".cmd"
}
else {
    wlCommand = wlCommand + ".sh"
    domainCommand = domainCommand + ".sh"
}

while (pythonPath.endsWith(File.separator)) {
    pythonPath = pythonPath.substring(0, pythonPath.length() - 1);
}

wlCommand = pythonPath + File.separator + wlCommand

while (domainEnvPath.endsWith(File.separator)) {
    domainEnvPath = domainEnvPath.substring(0, domainEnvPath.length() - 1);
}

domainCommand = domainEnvPath + File.separator + domainCommand

String[] cmdArgs = [wlCommand, pythonScript, this.args[0], this.args[1]]
String[] domainCmdArgs = [domainCommand]

Runtime runtime = Runtime.getRuntime();

CommandHelper ch = new CommandHelper(new File(pythonPath))

ch.runCommand("Running Weblogic domain env script", domainCmdArgs)

ch.runCommand("Running WLST command", cmdArgs)
