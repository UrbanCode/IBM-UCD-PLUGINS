
# Script that configures the base resources for a standalone host processing server.

from java.util import Date
from java.text import SimpleDateFormat
from java.lang import Integer

import weblogic.Deployer
import com.bea.wli.mbconnector.jms as jmsegen 
import com.bea.wli.management.configuration as wlicfg
import java.lang.Boolean as bool
import java.util as util
import java.io as io
import jarray
import sys
import wlst

print 'Starting the JMS Event Generation Configuration script .... '

pFile = io.FileInputStream(sys.argv[2])
properties = util.Properties()
properties.load(pFile)
jmsEgName = properties.getProperty('JMSEGName')
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
adminServerName=properties.getProperty('adminServerName')

if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

print 'Getting server MBean .... '
serverMBean = getMBean("Servers/" + adminServerName);

if serverMBean is None:
  print 'ERROR: Local Admin Server ' + adminServerName + ' Not Exist'
  exit()

# Note for created resources

now = Date()
df = SimpleDateFormat( "EEE, d MMM yyyy HH:mm:ss" )
theNotes = "Created by JMS Event Generation configuration script. "+ \
           df.format( now )

try:

    print "Deleting JMS EG :", jmsEgName    
    wlst.config()
    
    fEventGen = getTarget("JMSEventGenerators/JMSEventGenerators")
    
    fEventConfigs = fEventGen.getJMSEventGenConfigurationMBeans()
    for fconf in fEventConfigs:
      fname = fconf.getEventGeneratorName()
      if fname == jmsEgName:
        fEventGen.deleteJMSEventGenConfigurationMBean(fconf)
        break
    
#    appName = "WLIJmsEG_" + jmsEgName
#    wlst.deploy( appName, domaindir + "/" + appName + ".jar", adminServerName, "nostage" )
#    wlst.cd("Applications/" + appName)
#    wlst.set("LoadOrder", 1500)
#    wlst.cd("../..")

    print "script returns SUCCESS"   
except:
    print "ERROR: configuration"
    dumpStack()

# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
