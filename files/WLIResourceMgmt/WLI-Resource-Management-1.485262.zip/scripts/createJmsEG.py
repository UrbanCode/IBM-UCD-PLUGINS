
# Script that configures the base resources for a standalone host processing server.

from java.util import Date
from java.text import SimpleDateFormat
from java.lang import Integer

#import weblogic.Deployer
import com.bea.wli.mbconnector.jms as jmsegen 
import com.bea.wli.management.configuration as wlicfg
import java.lang.Boolean as bool
import java.util as util
import java.io as io
import jarray
import sys
import wlst

print 'Starting the JMS Event Generation Configuration script .... '

pFile = io.FileInputStream(sys.argv[1])
properties = util.Properties()
properties.load(pFile)
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
adminServerName=properties.getProperty('adminServerName')
propFile=properties.getProperty('PropFile')
jmsFileProps = io.FileInputStream(propFile)
properties.load(jmsFileProps)
domaindir=properties.getProperty('domaindir')
jmsEgName=properties.getProperty('jmsEgName')
jndiName=properties.getProperty('jndiName')
destinationType=properties.getProperty('destinationType')
connectionFactoryJndiName=properties.getProperty('connectionFactoryJndiName')
appName=properties.getProperty('appName')
channel=properties.getProperty('channel')
jmsPropertyName=properties.getProperty('jmsPropertyName')
jmsPropertyValue=properties.getProperty('jmsPropertyValue')

if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

print 'Getting server MBean .... '
serverMBean = getMBean("Servers/" + adminServerName);

if serverMBean is None:
  print 'ERROR: Local Admin Server ' + adminServerName + ' Not Exist'
  exit()

# Note for created resources

now = Date()
df = SimpleDateFormat( "EEE, d MMM yyyy HH:mm:ss" )
theNotes = "Created by JMS Event Generation configuration script. "+ \
           df.format( now )

try:

    print "Creating JMS EG :", jmsEgName
    jmsegen.JmsConnGenerator.main(["-inName", jmsEgName,"-outfile", domaindir + "/" + "WLIJmsEG_" + jmsEgName + ".jar","-destJNDIName", jndiName,"-destType", destinationType,"-connectionFactoryJndiName", connectionFactoryJndiName])
    wlst.config()
    egCfgMBean = getTarget("JMSEventGenerators/JMSEventGenerators")
    cData = jarray.zeros( 1, wlicfg.JMSEventGenChannelConfiguration )
    egMBean = egCfgMBean.newJMSEventGenConfigurationMBean(jmsEgName)
	
    cData[0] = wlicfg.JMSEventGenChannelConfiguration()
    cData[0].setChannel(channel)
    cData[0].setMatchJmsPropertyName(jmsPropertyName)
    cData[0].setMatchJmsPropertyValue(jmsPropertyValue)

    egMBean.setChannels(cData)
    
    appName = "WLIJmsEG_" + jmsEgName
    wlst.deploy( appName, domaindir + "/" + appName + ".jar", adminServerName, "nostage" )
    wlst.cd("Applications/" + appName)
    wlst.set("LoadOrder", 1500)
    wlst.cd("../..")


    print "script returns SUCCESS"   
except:
    print "ERROR: configuration"
    dumpStack()

# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
