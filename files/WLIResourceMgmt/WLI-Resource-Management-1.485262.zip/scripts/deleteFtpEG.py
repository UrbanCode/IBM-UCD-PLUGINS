
# Script that creates a File Event Generator

from java.util import Date
from java.text import SimpleDateFormat
from java.lang import Integer

import com.bea.wli.mbconnector.file as fileeggen
import com.bea.wli.management.configuration as wlicfg
import java.lang.Boolean as bool
import java.util as util
import java.io as io
import jarray
import sys
import wlst

print 'Starting the File Event Generation Configuration script .... '

pFile = io.FileInputStream(sys.argv[1])
properties = util.Properties()
properties.load(pFile)
fileEgName = properties.getProperty('FTPEGName')
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
adminServerName=properties.getProperty('adminServerName')

if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

print 'Getting server MBean .... '
serverMBean = getMBean("Servers/" + adminServerName);

if serverMBean is None:
  print 'ERROR: Local Admin Server ' + adminServerName + ' Not Exist'
  exit()

# Note for created resources

now = Date()
df = SimpleDateFormat( "EEE, d MMM yyyy HH:mm:ss" )
theNotes = "Created by File Event Generation configuration script. "+ \
           df.format( now )

try:
	
    print "Deleting File EG ", fileEgName
    
    print("config")
    wlst.config()
    
    print("getTarget")
    fEventGen = getTarget("FileEventGenerators/FileEventGenerators")
    
    print("get file config")
    fEventConfigs = fEventGen.getFileEventGenConfigurationMBeans()
    
    for fconf in fEventConfigs:
      fname = fconf.getEventGeneratorName()
      if fname == fileEgName:
        fEventGen.deleteFileEventGenConfigurationMBean(fconf)
        break
    
#    appName = "WLIFileEG_" + fileEgName
#    wlst.deploy( appName, domaindir + "/" + appName + ".jar", adminServerName, "nostage" )
#    wlst.cd("Applications/" + appName)
#    wlst.set("LoadOrder", 1500)
#    wlst.cd("../..")

    print "script returns SUCCESS"   

except:
    print "ERROR: configuration"
    dumpStack()

# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
