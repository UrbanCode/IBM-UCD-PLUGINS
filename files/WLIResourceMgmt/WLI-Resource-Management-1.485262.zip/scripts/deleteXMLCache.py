
# Script that deletes an XML file from a XML Cache for WLI

import com.bea.wli.management.configuration as wlicfg
import org.apache.xmlbeans as xmlbeans
import java.lang.Boolean as bool
import java.util as util
import java.io as io
import jarray
import sys
import wlst

print 'Starting the XML Cache Configuration script .... '

pFile = io.FileInputStream(sys.argv[1])
properties = util.Properties()
properties.load(pFile)
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
key = properties.getProperty('key')
	
if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

try:

    print "Deleting file in XML Cache with key ", key
    
    wlst.config()
    xmlcache = getTarget('XMLCache/SingletonXMLCache')
    
    xmlcache.delete(key)

    print "script returns SUCCESS"   

except:
    print "ERROR: configuration"
    dumpStack()

# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
