#!/bin/sh
##############################################################################
##                                                                          ##
##  JVM Launcher for zOS                                                    ##
##                                                                          ##
##############################################################################

# Added /usr/lib directory to LIBPATH to include
# RACF Libraries libIRRRacf.so, libIRRRacf64.so
export LIBPATH=$LIBPATH:/usr/lib

echo "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$@"
echo '================================================================================'
exec "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$@"