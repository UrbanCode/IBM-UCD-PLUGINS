/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Deploy
 * IBM Urbancode Release
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
package com.urbancode.air.plugin.appscan

import java.io.StringWriter
import java.net.URLEncoder
import java.util.Iterator

import javax.xml.XMLConstants
import javax.xml.namespace.NamespaceContext
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.xpath.XPath
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathFactory

import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPost
import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.entity.StringEntity
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.util.EntityUtils
import org.w3c.dom.Document

import com.urbancode.air.XTrustProvider
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder


public class AppScanRestHelper {

    def user
    def password
    def baseUrl
    def reportsFIID
    def disableCerts
    def client

    // Run Scan parameters
    def startUrl
    def scanUser
    def scanPassword
    def scanFIID
    def timeout


    // AppScan Enterprise Configuration
    /**
     * Persist cookies across requests
     */
    def cookieContainer

    public AppScanRestHelper(props) {
        this.baseUrl = props['baseUrl']
        this.disableCerts = props['disableCerts']
        this.password = props['password']
        this.reportsFIID = props['reportsFIID']
        this.scanFIID = props['scanFIID']
        this.scanPassword = props['scanPassword']
        this.scanUser = props['scanUser']
        this.startUrl = props['startUrl']
        if(props['timeout']) {
            this.timeout = (props['timeout'] as int) * 12
        }
        this.user = props['user']
        this.cookieContainer = ""

        HttpClientBuilder builder = new HttpClientBuilder()

        if (disableCerts) {
            XTrustProvider.install()
            builder.setTrustAllCerts(true)
        }

        builder.setUsername(user)
        builder.setPassword(password)
        builder.setPreemptiveAuthentication(true)

        this.client = builder.buildClient()
    }

    def retrieveReportInfo() {
        System.setProperty("https.protocols", "TLSv1")

        try {
            authenticate()
            println "Logged in."
            getReportInfo()
            println "Retrieved Reports successfully."
        } catch (Exception e) {
            e.printStackTrace()
            System.exit(1)
        }
    }

    def runScan() {
        System.setProperty("https.protocols", "TLSv1")

        try {
            authenticate()
            println "Logged in."
            runScanByFIID()
            println "Scan and Report Pack finished successfully."
        } catch (Exception e) {
            e.printStackTrace()
            System.exit(1)
        }
    }

    public void runScanByFIID() {

        // Initialization of XPath utilities
        XPathFactory xfactory = XPathFactory.newInstance()
        XPath xpath = xfactory.newXPath()
        xpath.setNamespaceContext(_nsContext)

        // Set scan URL for later use and pull out some information about the scan
        String scanURL = "folderitems/" + scanFIID
        Document doc = sendGetRequest(baseUrl + scanURL)

        String optionsURL = (String) xpath.evaluate("//content-scan-job/options/@href", doc, XPathConstants.STRING)
        String scanLastRunDateTime = (String) xpath.evaluate("//content-scan-job/last-run/text()", doc, XPathConstants.STRING)
        println "Scan last run: " + scanLastRunDateTime

        // Set report URL for later use and pull out some information about the report pack
        if(reportsFIID) {
            String reportPackURL = "folderitems/" + reportsFIID
            doc = sendGetRequest(baseUrl + reportPackURL)

            String reportsURL = (String) xpath.evaluate("//report-pack/reports/@href", doc, XPathConstants.STRING)
            println "Reports URL: " + reportsURL
            def reportPackLastRunDateTime = xpath.evaluate("//report-pack/last-run/text()", doc, XPathConstants.STRING)
            println "Reports last run: " + reportPackLastRunDateTime
        }

        def postData
        // Set the starting URL
        if(startUrl) {
            println "Updating the starting URL of the newly created scan."
            postData = "value=" + URLEncoder.encode(startUrl, "UTF-8")
            sendPostRequest(optionsURL + "/" + OptionType.STARTING_URLS, postData)
        }
        // Set the autoform username
        if(scanUser) {
            println "Updating the username."
            postData = "value=" + URLEncoder.encode(scanUser, "UTF-8")
            sendPostRequest(optionsURL + "/" + OptionType.AUTOMATIC_LOGIN_USERNAME, postData)
        }
        // Set the autoform password
        if(scanPassword) {
            println "Updating the password."
            postData = "value=" + URLEncoder.encode(scanPassword, "UTF-8")
            sendPostRequest(optionsURL + "/" + OptionType.AUTOMATIC_LOGIN_PASSWORD, postData)
        }

        // Run the scan by setting the action
        println "Running the scan."
        postData = "action=" + ScanAction.RUN
        sendPostRequest(baseUrl + scanURL, postData)

        // Wait for scan completion
        waitForCompletion(baseUrl + scanURL, scanLastRunDateTime)
        // Wait for report pack completion
        if(reportsFIID) {
            println "Waiting for report pack completion."
            waitForCompletion(baseUrl + reportPackURL, reportPackLastRunDateTime)
        }
    }

    public void getReportInfo() {

        // Initialization of XPath utilities
        XPathFactory xfactory = XPathFactory.newInstance()
        XPath xpath = xfactory.newXPath()
        xpath.setNamespaceContext(_nsContext)

        // Set report URL for later use and pull out some information about the report pack
        String reportPackURL = "folderitems/" + reportsFIID
        Document doc = sendGetRequest(baseUrl + reportPackURL)

        String reportsURL = (String) xpath.evaluate("//report-pack/reports/@href", doc, XPathConstants.STRING)
        println reportsURL
        def reportPackLastRunDateTime = xpath.evaluate("//report-pack/last-run/text()", doc, XPathConstants.STRING)
        println reportPackLastRunDateTime

        // Get report
        println "Retrieving report summary information..."
        doc = sendGetRequest(reportsURL)

        String secIssuesCount = (String) xpath.evaluate("//report[name='Security Issues']/summary/sentence/text()", doc, XPathConstants.STRING)
        println "Security Issues:" + secIssuesCount

        String secIssuesDataURL = (String) xpath.evaluate("//report[name='Security Issues']/data/@href", doc, XPathConstants.STRING)
        println secIssuesDataURL

        // Retrieve all data
        String secIssuesAllDataURL = secIssuesDataURL + "?mode=all"
        println "Retrieving report detail information..."
        doc = sendGetRequest(secIssuesAllDataURL)
        printOuterXml(doc)

        // Get the schema for this report
        String secIssuesSchemaURL = secIssuesDataURL + "?metadata=schema"
        println "Retrieving report schema information..."
        doc = sendGetRequest(secIssuesSchemaURL)
        printOuterXml(doc)
    }

    private static void printOuterXml(Document response) throws Exception {
        Transformer transformer = TransformerFactory.newInstance().newTransformer()
        transformer.setOutputProperty("omit-xml-declaration", "yes")

        StringWriter writer = new StringWriter()
        transformer.transform(new DOMSource(response.getDocumentElement()), new StreamResult(writer))
        println writer.toString()
    }

    private static Document convertToDOM(HttpResponse response) {
        HttpEntity r_entity = response.getEntity()
        def ent = EntityUtils.toString(r_entity)
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new StringBufferInputStream(ent))
        return doc
    }

    // creates a new LW-SSO token
    public void authenticate() {
        // Authentication headers tacked on by HttpClientBuilder
        def loginPostData = "userid=" + user + "&password=" + password
        HttpPost loginRequest = new HttpPost(baseUrl + "login")
        HttpResponse response = doRequest(loginRequest, loginPostData)
        def statusLine = response.getStatusLine()
        def statusCode = statusLine.getStatusCode()

        if (statusCode != 200) {
            println("Authentication failed with an Http response code of ${statusCode}: ${statusLine.getReasonPhrase()}")
            throw new RuntimeException("${response.entity?.content?.text}")
        }
        else {
            println("Authentication was successful.")
        }
    }

    // Execute a general http request
    private HttpResponse doRequest(HttpUriRequest request) {
        return doRequest(request, null)
    }

    // Specify a json string to provide a string entity to the http request
    private HttpResponse doRequest(HttpUriRequest request, String contentString) {
        request.addHeader("Content-Type", "application/x-www-form-urlencoded")
        request.addHeader("Accept", "application/json,application/xml")

        if (contentString) {
            StringEntity input

            try {
                input = new StringEntity(contentString)
            }
            catch(UnsupportedEncodingException ex) {
                println("Unsupported characters in http request content: ${contentString}")
                throw new Exception(ex)
            }

            request.setEntity(input)
        }

        HttpResponse response = client.execute(request)

        return response
    }

    public Document sendGetRequest(String url) {
        HttpGet getRequest = new HttpGet(url)
        def response = doRequest(getRequest)
        Document doc = convertToDOM(response)
        checkForError(doc)
        return doc
    }

    public void sendPostRequest(String url, def postData) {
        HttpPost postRequest = new HttpPost(url)
        def response = doRequest(postRequest, postData)
        Document doc = convertToDOM(response)
        checkForError(doc)
    }

    private void waitForCompletion(String url, String lastRunDate) throws Exception {

        XPathFactory factory = XPathFactory.newInstance()
        XPath xpath = factory.newXPath()
        xpath.setNamespaceContext(_nsContext)

        int retries = 0
        while (retries < timeout) {
            Document doc = sendGetRequest(url)

            // Get the status and print it
            String status = (String) xpath.evaluate("//state/name/text()", doc, XPathConstants.STRING)
            println status

            Double scanState = (Double) xpath.evaluate("//state/id/text()", doc, XPathConstants.NUMBER)
            if (scanState.intValue() == ScanState.READY) {
                // If scan marked ready, check last run time to verify completion
                String lastRunDateTime = (String) xpath.evaluate("//last-run/text()", doc, XPathConstants.STRING)

                if (lastRunDateTime.compareTo(lastRunDate) != 0) {
                    println "Completed successfully."
                    return
                }

            } else if (scanState.intValue() == ScanState.SUSPENDED) {
                // An error has occurred
                println "Object has suspended. Check AppScan Enterprise Console for more information on the scan: "
                if(baseUrl.endsWith('ase/services/')) {
                    print baseUrl.substring(0,baseUrl.length()-9) + "Jobs/JobStatistics.aspx?fiid=" + scanFIID
                }
                System.exit(1)
            } else if (scanState.intValue() == ScanState.CANCELING) {
                // The scan was cancelled
                println "Object is canceling."
                System.exit(1)
            }

            println "Continue to wait for completion..."
            retries++
            Thread.sleep(5000)
        }

        // Exceeded wait threshold
        throw new Exception("Wait threshold exceeded.")
    }

    private static void checkForError(Document doc) throws Exception {
        XPathFactory factory = XPathFactory.newInstance()
        XPath xpath = factory.newXPath()
        xpath.setNamespaceContext(_nsContext)

        if((String) xpath.evaluate("//error/text()", doc, XPathConstants.STRING)) {
            println "*** Error Occurred ***"

            String code = (String) xpath.evaluate("//code/text()", doc, XPathConstants.STRING)
            if(code) {
                println code
            }
            String message = (String) xpath.evaluate("//message/text()", doc, XPathConstants.STRING)
            if(message) {
                println message
            }
            String help = (String) xpath.evaluate("//error/help/@weblink", doc, XPathConstants.STRING)
            if(help) {
                println help
            }
            throw new Exception("Unexpected error.")
        }
    }

    private static NamespaceContext _nsContext
    static {
        _nsContext = new NamespaceContext() {
            public String getNamespaceURI(String prefix) {
                if (prefix.equalsIgnoreCase("ase"))
                    return "http://www.ibm.com/Rational/AppScanEnterprise"
                return XMLConstants.NULL_NS_URI
            }

            public String getPrefix(String arg0) {
                return null
            }

            public Iterator<?> getPrefixes(String arg0) {
                return null
            }
        }
    }

    public class ScanAction {
        public static int RUN = 2
        public static int SUSPEND = 3
        public static int CANCEL = 4
        public static int END = 5
    }
    public class OptionType {
        public static String STARTING_URLS = "epcsCOTListOfStartingUrls"
        public static String AUTOMATIC_LOGIN_USERNAME = "esCOTAutoFormFillUserNameValue"
        public static String AUTOMATIC_LOGIN_PASSWORD = "esCOTAutoFormFillPasswordValue"
    }

    public class ScanState {
        public static int READY = 1
        public static int STARTING = 2
        public static int RUNNING = 3
        public static int RESUMING = 6
        public static int CANCELING = 7
        public static int SUSPENDING = 8
        public static int SUSPENDED = 9
        public static int POSTPROCESSING = 10
        public static int ENDING = 12
    }
}