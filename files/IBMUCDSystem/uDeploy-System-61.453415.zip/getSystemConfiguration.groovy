import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.udeploy.system.SystemHelper

SystemHelper helper = new SystemHelper(new AirPluginTool(this.args[0], this.args[1]))

helper.getSystemConfiguration()