/**
* Licensed Materials - Property of IBM* and/or HCL**
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2010, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

/**
 *
 */
package com.urbancode.air.plugin.jira.addcomments


/**
 * @author jwa
 *
 */
public enum FailMode {

    //**************************************************************************
    // CLASS
    //**************************************************************************
    WARN_ONLY,
    FAIL_FAST,
    FAIL_ON_NO_UPDATES,
    FAIL_ON_ANY_FAILURE

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
}
