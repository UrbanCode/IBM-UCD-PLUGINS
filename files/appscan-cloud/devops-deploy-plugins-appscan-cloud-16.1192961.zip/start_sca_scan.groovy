/**
 * (c) Copyright IBM Corporation 2015.
 * (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
 * This is licensed under the following license.
 * The Eclipse Public 1.0 License (http://www.eclipse.org/legal/epl-v10.html)
 * U.S. Government Users Restricted Rights:  Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.AppScanSaaS.SCXRestClient
import com.urbancode.air.plugin.AppScanSaaS.SastScanHelper
import com.urbancode.air.plugin.AppScanSaaS.ScanType

import java.io.*

final def airHelper = new AirPluginTool(args[0], args[1])
final Properties props = airHelper.getStepProperties()

String appId = props["applicationId"]
String parentjobid = props["parentScanId"]
String scaFileLocation = props['scaFileLocation']
String issueCountString = props['reportIssueCountValidation']
long scanTimeout = props["scanTimeout"] ? Long.parseLong(props["scanTimeout"]) : -1
boolean mailNotification = props['mailNotification']
boolean failOnPause = Boolean.parseBoolean(props['failOnPause'])
boolean validateReport = issueCountString != null && !issueCountString.isEmpty()
int exitCode = 0

SCXRestClient restClient = new SCXRestClient(props)
SastScanHelper scanHelper = new SastScanHelper()

if (!scaFileLocation) {
    println "[Error] Scan file/directory has not been specified."
    System.exit 1
}

File scanFile = new File(scaFileLocation)
if (!scanFile.exists()) {
    println "[Error] SCA file $scanFile doesn't exist."
    System.exit 1
}

boolean isGenerateARSA = !(scanFile.name.endsWith('.irx') || scanFile.name.endsWith('.arsa'))

if (isGenerateARSA) {
    String scaToolDir = props['scaToolDir']

    if (!scaToolDir) {
        println "[Error] Static Analyzer Client Tool location has not been specified."
        System.exit 1
    }

    String encryptArsa = props['encryptArsa']
    boolean encrypt = true

    if (encryptArsa) {
        encrypt = Boolean.parseBoolean(encryptArsa)
    }

    scanFile = scanHelper.generateARSA(scaToolDir, scanFile, props["scaConfigFile"], encrypt)

    if (!scanFile.exists()) {
        println("[Error] IRX file generation failed.")
        System.exit(1)
    }
}

String scanId = restClient.startScaScan(scanFile, parentjobid, appId, mailNotification)
String scanExecutionId = restClient.getLastScanExecutionId()

if (isGenerateARSA) {
    scanFile.delete()
}

airHelper.setOutputProperty("ScanId", scanId)
if (scanExecutionId != null && !scanExecutionId.trim().isEmpty()) {
    airHelper.setOutputProperty("ScanExecutionId", scanExecutionId)
}

long startTime = System.currentTimeMillis()
def scan = restClient.waitForScan(scanId, ScanType.SCA, startTime, scanTimeout, failOnPause, scanExecutionId)
String sbomId = restClient.getLastSbomId()

if (sbomId != null && !sbomId.trim().isEmpty()) {
    airHelper.setOutputProperty("SbomId", sbomId)
}

airHelper.storeOutputProperties()

if (validateReport) {
    def issuesJson = scan.LatestExecution

    exitCode = restClient.validateScanIssues(issuesJson, scan.Name, scanId, issueCountString)
}

if (exitCode) {
    println("[Error] Scan has failed validation.")
}
else {
    println("[OK] Scan has completed successfully.")
}

System.exit(exitCode)
