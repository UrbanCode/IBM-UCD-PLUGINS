import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.udeploy.applications.ApplicationHelper

ApplicationHelper helper = new ApplicationHelper(new AirPluginTool(this.args[0], this.args[1]))

helper.addApplicationToTeam()