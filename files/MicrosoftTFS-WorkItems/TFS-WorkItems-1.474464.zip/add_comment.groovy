import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String serverUrl = props['tfsUrl']
final String serverUserName = props['tfsUsername']
final String serverPassword = props['tfsPassword']
final String tfsVersion = props['tfsVersion']

final String workItemId = props['workItemId'] ?: ".*"
final String comment = props['comment']

AddComment ac = new AddComment()
ac.serverUrl = serverUrl
ac.serverUserName = serverUserName
ac.serverPassword = serverPassword
ac.tfsVersion = tfsVersion

ac.workItemId = workItemId
ac.comment = comment

ac.execute()