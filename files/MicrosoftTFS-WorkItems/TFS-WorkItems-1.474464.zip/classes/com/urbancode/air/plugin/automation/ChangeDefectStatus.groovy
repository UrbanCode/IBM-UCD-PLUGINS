package com.urbancode.air.plugin.automation

import com.urbancode.air.*


public class ChangeDefectStatus extends AutomationBase {
    
    //*********************************************************************************************
    // CLASS
    //*********************************************************************************************
    
    //*********************************************************************************************
    // INSTANCE
    //*********************************************************************************************
    
    String workItemId
    String state
    String reason
    
    public void execute() {
        changeDefectStatus()
    }
    
    public void changeDefectStatus() {
        def exe = System.getenv("PLUGIN_HOME") + "${fileSep}lib${fileSep}tftool" + tfsVersion + ".exe"
        def command = [exe, 'resolve', "/server:$serverUrl"]

        if (serverUserName && serverPassword) {
            command << "/user:$serverUserName"
            command << "/password:$serverPassword"
        }

        command << "/id:${workItemId.trim()}"
        command << "/state:$state"
        command << "/reason:$reason"
        ch.runCommand("Changing state for work item ${workItemId}", command)
    }
}