import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String serverUrl = props['tfsUrl']
final String serverUserName = props['tfsUsername']
final String serverPassword = props['tfsPassword']
final String tfsVersion = props['tfsVersion']

final String workItemIds = props['workItemIds']

ViewDefectStatus vds = new ViewDefectStatus()
vds.serverUrl = serverUrl
vds.serverUserName = serverUserName
vds.serverPassword = serverPassword
vds.tfsVersion = tfsVersion

vds.workItemIds = workItemIds

vds.execute()