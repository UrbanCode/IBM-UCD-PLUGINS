package com.urbancode.air.plugin.automation

import org.apache.commons.httpclient.*
import org.apache.commons.httpclient.methods.*
import org.apache.commons.httpclient.protocol.*
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.util.IO


public class ViewDefectStatus extends AutomationBase {
    
    //=============================================================================================
    // CLASS
    //=============================================================================================
    
    //=============================================================================================
    // INSTANCE
    //=============================================================================================
    
    String workItemProperty = "workItems"
    String workItemIds

    public void execute() {
        viewStatus()
    }
    
    public void viewStatus() {
        def exe = System.getenv("PLUGIN_HOME") + "${fileSep}lib${fileSep}tftool" + tfsVersion + ".exe"
        def command = [exe, 'report', "/server:$serverUrl"]

        if (serverUserName && serverPassword) {
            command << "/user:$serverUserName"
            command << "/password:$serverPassword"
        }

        command << workItemIds

        ch.runCommand('Getting Work Item Status', command)
    }
    
}