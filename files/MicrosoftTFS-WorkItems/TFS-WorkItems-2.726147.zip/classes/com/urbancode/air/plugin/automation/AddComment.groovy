package com.urbancode.air.plugin.automation

import org.apache.commons.httpclient.*
import org.apache.commons.httpclient.methods.*
import org.apache.commons.httpclient.protocol.*
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.util.IO


public class AddComment extends AutomationBase {
    
    //*********************************************************************************************
    // CLASS
    //*********************************************************************************************
    
    //*********************************************************************************************
    // INSTANCE
    //*********************************************************************************************
        
    String workItemId
    String comment
    
    public void execute() {
        addComment();
    }
    
    public void addComment() {
            comment = comment.replace("\n", "<br>")
            def exe = System.getenv("PLUGIN_HOME") + "${fileSep}lib${fileSep}tftool" + tfsVersion + ".exe"
            def command = [exe, 'comment', "/server:$serverUrl"]

            if (serverUserName && serverPassword) {
                command << "/user:$serverUserName"
                command << "/password:$serverPassword"
            }

            command << "/id:${workItemId}"
            command << "/comment:${comment}"

            new CommandHelper(workDir).runCommand('Adding Work Item Comment', command)
    }
    
}