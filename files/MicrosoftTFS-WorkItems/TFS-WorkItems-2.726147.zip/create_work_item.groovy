import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String serverUrl = props['tfsUrl']
final String serverUserName = props['tfsUsername']
final String serverPassword = props['tfsPassword']
final String tfsVersion = props['tfsVersion']

final String issueProject = props['issueProject']
final String type = props['type']
final String title = props['title']
final String assignedTo = props['assignedTo']
final String description = props['description']


CreateWorkItem cwi = new CreateWorkItem()
cwi.serverUrl = serverUrl
cwi.serverUserName = serverUserName
cwi.serverPassword = serverPassword
cwi.tfsVersion = tfsVersion

cwi.issueProject = issueProject
cwi.type = type
cwi.title = title
cwi.assignedTo = assignedTo
cwi.description = description

cwi.execute()