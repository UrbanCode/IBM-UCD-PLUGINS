#   Licensed Materials - Property of IBM 
#   5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
#   US Government Users Restricted Rights - Use, duplication or
#   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.  
   
#!/usr/bin/bash

platform='unknown'
unamestr=$(uname)
if [[ "$unamestr" == 'Linux' ]]; then
   platform='linux'
fi

echo "platform is $platform"

if [[ $platform == 'linux' ]]; then
	echo "Platform is linux.  Boot2docker is not required"
else
	boot2docker init
	boot2docker restart
	boot2docker shellinit
	eval "$(boot2docker shellinit)"
fi

mfplocation="$(which mfp)"
if [ -z "$mfplocation" ]
then
  echo "MobileFirst Platform CLI is not installed"
  exit 1
fi