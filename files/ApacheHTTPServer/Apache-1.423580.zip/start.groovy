import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

final def workDir = new File('.').canonicalFile
final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()
def path = props['path']?:'apachectl'
def winServiceName = props['winServiceName']

println "Executable path: $path"
println "Windows Service Name: $winServiceName"

try {
    if (System.properties['os.name'].toLowerCase().contains('windows')) {
        if(winServiceName) {
            println "Detected Windows OS, starting Apache via $winServiceName Windows service"
            def cmdHelper = new CommandHelper(workDir)
            cmdHelper.runCommand("Starting apache server", ['net', 'start', winServiceName])
        }
        else {
            println "Invalid Windows service name specified: $winServiceName"
            System.exit 1
        }
    }
    else {
        println "Detected *nix OS, starting Apache via apachectl"
        def cmdHelper = new CommandHelper(workDir)
        cmdHelper.runCommand("Starting apache server", [path, 'start'])
    }
}
catch (Exception e) {
    println "Error starting Apache: ${e.message}"
    System.exit 1
}

System.exit 0
     
