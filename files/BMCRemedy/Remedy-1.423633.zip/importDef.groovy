import com.bmc.arsys.api.*;
import java.util.*;
import java.lang.*;


def user = props['user'];
def password = props['password'];
def server = props['server'] 
def port = Integer.valueOf(props['port']);
def filePath = props['filePath'];

ARServerUser arUser = new ARServerUser(user, password, "", "", server, port);
arUser.login();
println "Connected to ${server} as user ${user}";

arUser.importDefFromFile(filePath);