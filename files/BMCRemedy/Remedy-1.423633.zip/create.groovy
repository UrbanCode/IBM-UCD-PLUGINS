import com.bmc.arsys.api.*;
import java.util.*;
import java.lang.*;


def user = props['user'];
def password = props['password'];
def server = props['server'] 
def port = Integer.valueOf(props['port']);
def form = props['form'];
def fieldValues = props['fieldValues'];

ARServerUser arUser = new ARServerUser(user, password, "", "", server, port);
arUser.login()
println "Connected to ${server} as user ${user}";

def fields = arUser.getListFieldObjects(form);

def fieldMap = [:];
def fieldTypes = [:];
fields.each { it ->
   fieldMap[it.name] = it.fieldID;
   fieldTypes[it.name] = it.fieldLimit;
}

Entry entry = new Entry();
def fieldValueList = fieldValues.split('\n');
fieldValueList.each { fieldValueString ->
    if (fieldValueString != null && fieldValueString.trim().length() != 0) {
        def fieldName = fieldValueString.split('->')[0];
        def fieldValue = fieldValueString.split('->', 2)[1];

        if (fieldTypes[fieldName] == null) {
            throw new Exception("Field ${fieldName} does not exist in form ${form}");
        }

        if (fieldTypes[fieldName] instanceof IntegerFieldLimit) {
            fieldValue = Integer.valueOf(fieldValue);
        }
        else if (fieldTypes[fieldName] instanceof RealFieldLimit) {
            fieldValue = Double.valueOf(fieldValue);
        }
        else if (fieldTypes[fieldName] instanceof SelectionFieldLimit) {
            def enumItems = fieldTypes[fieldName].getValues();
            def enumValue = fieldValue;
            fieldValue = enumItems.find { enumIt -> enumIt.enumItemName.equals(enumValue)}?.enumItemNumber;
        }

        println "${fieldName} -> ${fieldTypes[fieldName].class.name} : ${fieldValue} -> ${fieldValue.class.name}"
        entry.put(fieldMap[fieldName], new Value(fieldValue));
    }
}

def id = arUser.createEntry(form, entry);
outProps.setProperty("entryId", id);
