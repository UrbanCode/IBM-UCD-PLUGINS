#!/usr/bin/env groovy

import groovy.io.FileType;
import groovy.util.GroovyScriptEngine;
import com.urbancode.air.AirPluginTool;


final def workDir = new File('.').canonicalFile
final def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def pluginStepScript = new File(args[2]);
final def props = apTool.getStepProperties();
final def outProps = new Properties();

Binding binding = new Binding();
binding.setVariable("outProps", apTool.outProps);
binding.setVariable("props", props);

// Recursively Add jars to class loader
def jarFolder = props['jarFolder'];
File jarDirectory = new File(jarFolder);
jarDirectory.traverse(
    type        : FileType.FILES,
    nameFilter  : ~/.*.jar/
) {File jarFile ->
    println jarFile.toString();
    this.class.classLoader.rootLoader.addURL(jarFile.toURI().toURL());
}

GroovyShell shell = new GroovyShell(this.class.classLoader.rootLoader, binding);
try {
    shell.evaluate(pluginStepScript);
}
finally {
    apTool.storeOutputProperties();
}
