import com.urbancode.air.CommandHelper;

final def inputPropsFile = new File(args[0])
final def outputPropsFile = new File(args[1])

final def props = new Properties()
try {
    props.load(new FileInputStream(inputPropsFile))
}
catch (IOException e) {
    throw new RuntimeException(e)
}

final def cwd = new File('.');
final def cmdHelper = new CommandHelper(cwd);

def exePath = props['exePath'];

//--------------------------------------------------------------------------------------------------
def getAbsPath(def file) {
    def tempFile = null;
    if (file != null && file != "") {
        File temporaryFile = new File(file);
        tempFile = temporaryFile.getAbsolutePath();
    }
    return tempFile;
}
//path properties
def licenseFile = getAbsPath(props['licenseFile']);
def profile = getAbsPath(props['profile']);
def output = getAbsPath(props['output']);

def cmdArgs = [exePath, '-license', licenseFile, '-mode', 'snapshot', '-profile', profile, 
               '-output', output, '-logLevel', 'DEBUG'];
cmdHelper.runCommand("Snapshoting Server", cmdArgs);
