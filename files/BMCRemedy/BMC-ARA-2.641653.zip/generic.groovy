import com.urbancode.air.CommandHelper;

final def inputPropsFile = new File(args[0])
final def outputPropsFile = new File(args[1])

final def props = new Properties()
try {
    props.load(new FileInputStream(inputPropsFile))
}
catch (IOException e) {
    throw new RuntimeException(e)
}

final def cwd = new File('.');
final def cmdHelper = new CommandHelper(cwd);

def exePath = props['exePath'];//
def tokens = props['tokens'];//
def filter = props['filter'];//
def mode = props['mode'];//
def captureMetadata = props['captureMetadata']

//--------------------------------------------------------------------------------------------------
def getAbsPath(def file) {
    def tempFile = null;
    if (file != null && file != "") {
        File temporaryFile = new File(file);
        tempFile = temporaryFile.getAbsolutePath();
    }
    return tempFile;
}

//--------------------------------------------------------------------------------------------------
def addArg(def cmdArgs, def argValue, def argPrefix) {
    if (argValue != null && argValue != "") {
        cmdArgs << argPrefix;
        cmdArgs << argValue;
    }
}

//path properties
def profile = getAbsPath(props['profile']);//
def output = getAbsPath(props['output']);//
def config = getAbsPath(props['config']);//
def report = getAbsPath(props['report']);//
def properties = getAbsPath(props['properties']);//
def rollbackDir = getAbsPath(props['rollbackDir']);//
def licenseFile = getAbsPath(props['licenseFile']);//

def cmdArgs = [exePath, '-license', licenseFile, '-mode', mode, '-logLevel', 'DEBUG'];

//add the rest of the commandLine Args
addArg(cmdArgs, tokens, '-tokens');
addArg(cmdArgs, filter, '-filter');
addArg(cmdArgs, output, '-output');
addArg(cmdArgs, profile, '-profile');
addArg(cmdArgs, properties, '-properties');
addArg(cmdArgs, report, '-report');
addArg(cmdArgs, rollbackDir, '-rollbackDir');
addArg(cmdArgs, config, '-config');

if (captureMetadata) {
    cmdArgs << "-captureSnapshotMetaData";
}

cmdHelper.runCommand("Executing rundeliver", cmdArgs);

//report conversion to html stuff
def reportConvPath = props['reportConvPath'];//
def reportHtml = getAbsPath(props['reportHtml']);
if (report != null && report != "") {
    if (reportHtml != null && reportHtml != "") {
        def convertReport = [reportConvPath, '-report', report, '-output', reportHtml];
        cmdHelper.runCommand("Converting report file to html", convertReport);
    }
}
