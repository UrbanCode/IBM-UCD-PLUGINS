/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2013, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018, 2019. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.onetest.OneTestRestHelper

final def apTool = new AirPluginTool(args[0], args[1]);
final def props = apTool.getStepProperties();

println '[Action] Starting job...';
OneTestRestHelper helper = new OneTestRestHelper(apTool);
helper.startJob();

//Set output properties
apTool.setOutputProperties();

//write the output properties to the file
apTool.storeOutputProperties();

