/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.plugin.integration.*
import com.urbancode.air.AirPluginTool

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

final String url                = props['url'];
final String username           = props['username'];
final String password           = props['password'];

final String projectName        = props['projectName']
final String workItemId         = props['workItemId']
final String action             = props['action'];
final String newState           = props['newState']

ChangeDefectStatus cds = new ChangeDefectStatus()
cds.url = url
cds.username = username
cds.password = password

cds.projectName = projectName
cds.workItemId = workItemId
cds.action = action
cds.newState = newState
cds.props = props

cds.execute()
