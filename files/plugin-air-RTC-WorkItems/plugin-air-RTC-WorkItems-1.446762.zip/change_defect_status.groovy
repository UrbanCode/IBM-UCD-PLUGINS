import com.urbancode.air.plugin.integration.*
import com.urbancode.air.AirPluginTool

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

final String url                = props['url'];
final String username           = props['username'];
final String password           = props['password'];

final String projectName        = props['projectName']
final String workItemId         = props['workItemId']
final String action             = props['action'];
final String newState           = props['newState']

ChangeDefectStatus cds = new ChangeDefectStatus()
cds.url = url
cds.username = username
cds.password = password

cds.projectName = projectName
cds.workItemId = workItemId
cds.action = action
cds.newState = newState
cds.props = props

cds.execute()
