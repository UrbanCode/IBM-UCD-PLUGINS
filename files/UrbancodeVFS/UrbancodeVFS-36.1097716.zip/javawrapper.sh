#!/bin/sh
# shellcheck disable=SC2086
eval exec "${JAVA_HOME}/bin/java" $JAVA_OPTS "$@"