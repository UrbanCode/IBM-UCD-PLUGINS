/**
* Licensed Materials - Property of IBM* and/or HCL**
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2002, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.f5.F5iRule

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

def exitVal = 1
try {
    F5iRule iRule = new F5iRule(props)
    def iRuleName = props['iRuleName']
    iRuleName = iRule.appendFolderNames(iRuleName)[0]

    // Delete the iRule
    exitVal = iRule.deleteiRule(iRuleName)
}
catch (Exception e) {
    e.printStackTrace()
    System.exit(1)
}

// Crash if failStrategy == 'FAIL_FAST'
def failStrategy = props['failStrategy']
println "If the iRule already does not exist, the selected fail strategy is: ${failStrategy}"
if (exitVal == 1 && failStrategy == 'FAIL') {
    System.exit(1)
}
