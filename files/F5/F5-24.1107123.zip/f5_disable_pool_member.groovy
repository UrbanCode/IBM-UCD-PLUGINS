/**
* Licensed Materials - Property of IBM* and/or HCL**
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2002, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.f5.F5PoolMember

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props  = apTool.getStepProperties()
final def doWait = Boolean.valueOf(props['doWaitForConnectionClose'])
final def forceOffline  = Boolean.valueOf(props['forceOffline'])
final def sleepInterval = (props['sleepInterval'])?Long.valueOf(props['sleepInterval']):5

try {
    F5PoolMember poolMember = new F5PoolMember(props)
    poolMember.disablePoolMember()
    if (forceOffline) {
        poolMember.forcePoolMemberOffline()
        // All connections are terminated immediately. No need to wait for connections.
    } else {
        if (doWait) {
            def currentConnections = poolMember.getPoolMemberActiveConnections()
            while(currentConnections > 0) {
                println("Waiting for $currentConnections to close, sleep for $sleepInterval second(s)")
                sleep(sleepInterval * 1000, {println("Waiting aborted!"); return true})
                currentConnections = poolMember.getPoolMemberActiveConnections()
            }
            println("All connections closed, done waiting.")
        }
    }
}
catch (Exception e) {
    e.printStackTrace()
    System.exit(1)
}
