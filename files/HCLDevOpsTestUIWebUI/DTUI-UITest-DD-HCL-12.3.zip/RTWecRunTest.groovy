import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.rtw.RTWProduct
import com.urbancode.air.plugin.rtw.RTWProductHelper


def apTool = new AirPluginTool(args[0], args[1])
final def props = apTool.getStepProperties()

RTWProductHelper rtwhelper = new RTWProductHelper(props,RTWProduct.RTWec);
rtwhelper.runTest(this.args[1]);;
