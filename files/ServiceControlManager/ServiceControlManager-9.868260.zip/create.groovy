/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicecontrolmanager.ServiceControlManagerHelper;

final def airHelper = new AirPluginTool(args[0], args[1])

final def props = airHelper.getStepProperties()

def sch = new ServiceControlManagerHelper(props);

sch.createService(props['Service']);
