import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicecontrolmanager.ServiceControlManagerHelper;

final def airHelper = new AirPluginTool(args[0], args[1])

final def props = airHelper.getStepProperties()

def sch = new ServiceControlManagerHelper(props);

sch.startServices();
