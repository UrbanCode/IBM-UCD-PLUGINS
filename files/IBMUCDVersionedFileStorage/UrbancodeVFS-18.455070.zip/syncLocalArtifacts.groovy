#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import java.nio.charset.Charset;

import com.urbancode.air.AirPluginTool
import com.urbancode.commons.fileutils.filelister.FileType
import com.urbancode.commons.fileutils.FileUtils
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.commons.util.IO;
import com.urbancode.vfs.client.Client
import com.urbancode.vfs.client.PatternPathFilter
import com.urbancode.vfs.common.ClientChangeSet
import com.urbancode.vfs.common.ClientChangeSetDelta
import com.urbancode.vfs.common.ClientPathEntry
import com.urbancode.vfs.common.Hash

import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger
import org.apache.log4j.PatternLayout
import org.apache.log4j.ConsoleAppender
import org.apache.log4j.Level;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;


def props = new Properties();
def inputPropsFile = new File(args[0]);
inputPropsFile.withInputStream {
    props.load(it);
}

def apTool = new AirPluginTool(args[0], args[1])

def repositoryUrl = props['repositoryUrl']
def repositoryId = props['repositoryId']
def fileIncludePatterns = props['fileIncludePatterns']
def fileExcludePatterns = props['fileExcludePatterns']
def resId = props['resId'];
def compId = props['compId'];
def serverURL = props['serverUrl'];

def baseDirectory = new File("").canonicalFile

def includesArray = fileIncludePatterns?.readLines().toArray(new String[0])
def excludesArray = fileExcludePatterns?.readLines().toArray(new String[0])

def proxyHost = System.env['PROXY_HOST'] ? System.env['PROXY_HOST'] : null
def proxyPort = System.env['PROXY_PORT'] ? Integer.valueOf(System.env['PROXY_PORT']) : null

def charset
if (props['charset']) {
    charset = Charset.forName(props['charset'])
}
else {
    File AGENT_HOME = new File(System.getenv().get("AGENT_HOME"))
    def agentInstalledProps = new File(AGENT_HOME, "conf/agent/installed.properties")
    def agentProps = new Properties();
    def agentInputStream = null;
    try {
        agentInputStream = new FileInputStream(agentInstalledProps);
        agentProps.load(agentInputStream);
    }
    catch (IOException e) {
        throw new RuntimeException(e);
    }
    if (agentProps['system.default.encoding']){
        charset = Charset.forName(agentProps['system.default.encoding'])
    }
}

def setFileExecuteBits = (props['setFileExecuteBits'] != null && Boolean.valueOf(props['setFileExecuteBits']));
def verifyFileIntegrity = (props['verifyFileIntegrity'] != null && props['verifyFileIntegrity'] == "true");


//
// Validation
//

if (baseDirectory.isFile()) {
    throw new IllegalArgumentException("Base directory ${baseDirectory} is a file!")
}

//
// Configure logging to get rid of logging warning messages
//
Logger logger = Logger.getRootLogger();

PatternLayout layout = new PatternLayout("%m%n");
ConsoleAppender appender = new ConsoleAppender(layout);

logger.removeAllAppenders();
logger.addAppender(appender);
logger.setLevel(Level.ERROR);


while (serverURL.endsWith("/")) {
    serverURL = serverURL.substring(0, serverURL.length-1);
}

def restUrl = "${serverURL}/rest/inventory/resourceInventory/table"
restUrl += "?rowsPerPage=100000&pageNumber=1"+
           "&orderField=dateCreated&sortType=desc"+
           "&filterFields=resourceId&filterValue_resourceId=${resId}"+
           "&filterType_resourceId=eq&filterClass_resourceId=String"

HttpClientBuilder builder = new HttpClientBuilder()
builder.setTrustAllCerts(true)
builder.setPreemptiveAuthentication(true)
builder.setUsername(apTool.getAuthTokenUsername())
builder.setPassword(apTool.getAuthToken())
DefaultHttpClient httpClient = builder.buildClient()

if (proxyHost) {
    httpClient.getHostConfiguration().setProxy(proxyHost, proxyPort);
}

//helper method
def getBody(HttpResponse response) throws IOException {
    StringBuilder builder = new StringBuilder();
    InputStream body = response.getEntity().getContent();
    if (body != null) {
        Reader reader = IO.reader(body, IO.utf8());
        try {
            IO.copy(reader, builder);
        }
        finally {
            reader.close();
        }
    }
    return builder.toString();
}

def getVersionsMethod = new HttpGet(restUrl);
def getVersionsResponse = httpClient.execute(getVersionsMethod);
def getVersionsResponseCode = getVersionsResponse.getStatusLine().getStatusCode();
def getVersionsMethodResult = getBody(getVersionsResponse);

if (getVersionsResponseCode != 200) {
    println "Unexpected HTTP status getting resource inventory: ${getVersionsResponseCode} ("+getVersionsResponse.getStatusLine().getReasonPhrase()+")"
    println getVersionsMethodResult
    System.exit(1)
}

JSONObject inventoryResultJson = new JSONObject(getVersionsMethodResult);
JSONArray inventoryRecordsJson = inventoryResultJson.getJSONArray("records")

// Get the list of version names in the resource's inventory, in the order in which they were applied
def versionNames = []
for (def i = inventoryRecordsJson.length()-1; i >= 0; i--) {
    def inventoryRecordJson = inventoryRecordsJson.getJSONObject(i);
    def versionJson = inventoryRecordJson.getJSONObject("version")
    def versionName = versionJson.getString("name")

    versionNames.add(versionName)
}

println "Syncing for versions: "+versionNames




def client = new Client(repositoryUrl, proxyHost, proxyPort)
client.setSetFileExecuteBitsOnly(setFileExecuteBits);
client.setVerifyFileIntegrity(verifyFileIntegrity);
client.setCharset(charset)

println "Syncing files in ${baseDirectory}"
println "Including ${fileIncludePatterns}"
println "Excluding ${fileExcludePatterns}"
println ""
println ""

def newestPathEntryMap = [:]
def pathsToVersions = [:]
def filter = new PatternPathFilter(includesArray, excludesArray)

// Go through all versions and collect the cumulative list of files by location
versionNames.each { versionName ->
    ClientChangeSet curChangeSet = client.getChangeSetByLabel(repositoryId, versionName);
    ClientPathEntry[] curEntries = curChangeSet.getEntries();
    
    curEntries.each {
        if (filter.includes(it.path)) {
            newestPathEntryMap.put(it.path, it)
            pathsToVersions.put(it.path, versionName)
        }
    }
}

// Look for existing files which are not in the full set of desired files
def rmFiles = []
baseDirectory.eachFileRecurse() { curFile ->
    def curFilePath = curFile.path.substring(baseDirectory.getPath().length() + 1)
    def keepFile = (pathsToVersions.get(curFilePath) != null)

    if (!keepFile && filter.includes(curFile.path.substring(baseDirectory.getPath().length() + 1))) {
        rmFiles.add(curFile)
    }
}
rmFiles.each() {
    def curFilePath = it.path.substring(baseDirectory.getPath().length() + 1)
    println "Deleting \""+curFilePath+"\""
    FileUtils.deleteFile(it)
}


// Look for missing files or files with unexpected content and download the good version from the server
newestPathEntryMap.each() { path, pathEntry ->
    def file = new File(baseDirectory, path)
    
    def pathEntryAlgorithm = null;
    if (pathEntry.contentHash != null) {
        pathEntryAlgorithm = pathEntry.contentHash.algorithm;
    }
    
    if (pathEntryAlgorithm && pathEntry.type.equals(FileType.REGULAR)) {
        def download = false;
        
        if (file.exists()) {
            def hash = null
            try {
                hash = Hash.hashForFile(file, pathEntryAlgorithm)
                if (hash && hash.equals(pathEntry.contentHash)) {
                    println "Verified file \"${path}\" ("+pathsToVersions.get(path)+")"
                }
                else {
                    download = true;
                    println "File \"${path}\" ("+pathsToVersions.get(path)+") did not have the expected contents. Downloading..."
                }
            }
            catch (Exception e) {
                failureList << "Error calculating hash for ${path}: ${e.message}"
            }
        }
        else {
            download = true;
            println "File \"${path}\" ("+pathsToVersions.get(path)+") was not found. Downloading..."
        }
        
        if (download) {
            def changeSetEntries = new ArrayList<ClientPathEntry>()
            changeSetEntries.add(pathEntry)
            ClientChangeSetDelta changeSetDelta = new ClientChangeSetDelta(repositoryId, changeSetEntries)
            
            client.downloadChangeSetDeltaRemovingPathPrefix(
                    changeSetDelta,
                    baseDirectory,
                    includesArray,
                    excludesArray,
                    "")
            println "Done."
        }
    }
}
