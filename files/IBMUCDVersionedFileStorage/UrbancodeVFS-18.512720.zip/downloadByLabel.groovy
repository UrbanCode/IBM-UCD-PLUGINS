#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.commons.fileutils.filelister.FileType
import com.urbancode.commons.fileutils.FileUtils
import com.urbancode.vfs.client.Client
import com.urbancode.vfs.client.PatternPathFilter
import com.urbancode.vfs.common.ClientChangeSet
import com.urbancode.vfs.common.ClientChangeSetDelta
import com.urbancode.vfs.common.ClientPathEntry
import com.urbancode.vfs.common.Hash
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.commons.util.IO;
import java.nio.charset.Charset;

import org.codehaus.jettison.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder

def workDir = new File('.').canonicalFile
def props = new Properties();
def inputPropsFile = new File(args[0]);
inputPropsFile.withInputStream {
    props.load(it);
}

def charset
if (props['charset']) {
    charset = Charset.forName(props['charset'])
}
else {
    File AGENT_HOME = new File(System.getenv().get("AGENT_HOME"))
    def agentInstalledProps = new File(AGENT_HOME, "conf/agent/installed.properties")
    def agentProps = new Properties();
    def agentInputStream = null;
    try {
        agentInputStream = new FileInputStream(agentInstalledProps);
        agentProps.load(agentInputStream);
    }
    catch (IOException e) {
        throw new RuntimeException(e);
    }
    if (agentProps['system.default.encoding']){
        charset = Charset.forName(agentProps['system.default.encoding'])
    }
}

def MAX_TRIES=3;
def repositoryUrl = props['repositoryUrl']
def repositoryId = props['repositoryId']
def artifactSetBaseDir = props['artifactSetBaseDir']
def label = props['label']
def directoryOffset = props['directoryOffset']
def fileIncludePatterns = props['fileIncludePatterns']
def fileExcludePatterns = props['fileExcludePatterns']

def baseDirectory = workDir
if (directoryOffset) {
    baseDirectory = new File(workDir, directoryOffset).canonicalFile
}

def includesArray = fileIncludePatterns?.readLines().toArray(new String[0])
def excludesArray = fileExcludePatterns?.readLines().toArray(new String[0])

def proxyHost = System.env['PROXY_HOST'] ? System.env['PROXY_HOST'] : null
def proxyPort = System.env['PROXY_PORT'] ? Integer.valueOf(System.env['PROXY_PORT']) : null

def outputFilePath = props['outputFile']
def changeSetId

def verbose = false

def syncMode = props['syncMode']
def useSync = syncMode != 'false'
def fullClean = syncMode == 'FULL'
def fullVerification = props['fullVerification'] == 'true'

def syncCleanup = useSync
def resId = props['resId'];
def compId = props['compId'];
def serverURL = props['serverUrl'];
def setFileExecuteBits = (props['setFileExecuteBits'] != null && Boolean.valueOf(props['setFileExecuteBits']));
def verifyFileIntegrity = (props['verifyFileIntegrity'] != null && props['verifyFileIntegrity'] == "true");
def stagedFiles = []
def currentDirs = []

def done = false;
def tries = 0;
def finalException = null;

def getLabelForResourceAndComponent = {

    def result = null;

    while (serverURL.endsWith("/")) {
        serverURL = serverURL.substring(0, serverURL.length-1);
    }

    def restUrl = "${serverURL}/rest/inventory/versionByResourceAndComponent/"+resId+"/"+compId

    HttpClientBuilder builder = new HttpClientBuilder()

    if (proxyHost) {
        builder.setProxyHost(proxyHost);
        builder.setProxyPort(proxyPort);
    }
    builder.setTrustAllCerts(true);

    DefaultHttpClient httpClient = builder.buildClient()
    def methodResult = null;
    def code = null;

    HttpGet method = null;
    tries = 0;
    done = false;
    finalException = null;
    while (!done && tries < MAX_TRIES) {
        try {
            method = new HttpGet(restUrl);
            def response = httpClient.execute(method);
            code = response.getStatusLine().getStatusCode();
            methodResult = getBody(response);
            done = true;
        }
        catch (Exception e) {
            tries++;
            finalException = e;
            println "Error getting label for resource : " + e.getMessage();
            done = false;
        }
    }

    if (!done) {
        if (finalException != null) {
            throw finalException;
        }
        else {
            throw new Exception("Unknown error retrieving label");
        }
    }

    switch (code) {

        case HttpStatus.SC_OK:
            JSONObject responseObject = new JSONObject(methodResult)
            if (!responseObject.isNull("version")) {
                JSONObject versionObject = responseObject.getJSONObject("version")
                if (!versionObject.isNull("name")) {
                    result = versionObject.getString("name")
                }
            }
            break;

        case HttpStatus.SC_NOT_FOUND:
            println "Server returned 404 for getting the previous label!";
            break;

        case HttpStatus.SC_INTERNAL_SERVER_ERROR:
            println "Server error retrieving previous label : " + methodResult;
            break;
        default:
            println "Could not get previous label! Method returned code : " + code;
            break;
    }

    return result;
}

//helper method
def getBody(HttpResponse response)
throws IOException {
    StringBuilder builder = new StringBuilder();
    InputStream body = response.getEntity().getContent();
    if (body != null) {
        Reader reader = IO.reader(body, IO.utf8());
        try {
            IO.copy(reader, builder);
        }
        finally {
            reader.close();
        }
    }
    return builder.toString();
}


//
// Validation
//

if (baseDirectory.isFile()) {
    throw new IllegalArgumentException("Base directory ${baseDirectory} is a file!")
}
if (!artifactSetBaseDir.equals("")) {
    while (artifactSetBaseDir.startsWith("/")) {
        artifactSetBaseDir = artifactSetBaseDir.substring(1, artifactSetBaseDir.size());
    }
    
    while (artifactSetBaseDir.endsWith("/")) {
        artifactSetBaseDir = artifactSetBaseDir.substring(0, artifactSetBaseDir.size()-1);    
    }
    
    artifactSetBaseDir += "/";
}
//
// Configure logging
//
new com.urbancode.vfs.client.Logging().configureConsoleLogging()

//
// Download the files
//

def client = new Client(repositoryUrl, proxyHost, proxyPort)
client.setSetFileExecuteBitsOnly(setFileExecuteBits);
client.setVerifyFileIntegrity(verifyFileIntegrity);
//client.setUseCompression(useCompression);
client.setCharset(charset)
String prevLabel = null;
if (useSync) {
    try {
        prevLabel = getLabelForResourceAndComponent();
    }
    catch (Exception e) {
        println "Could not get label for the previous version! Will not be able to sync!";
        println "${e.message}"
        prevLabel = null;
    }

    if (prevLabel == null) {
        syncCleanup = false;
        println "Could not get label for the previous version.";
    }
}

ClientChangeSet baseChangeSet = null;
def filter = null;

println "Working directory: ${baseDirectory.path}"
println "Including ${fileIncludePatterns}"
println "Excluding ${fileExcludePatterns}"
println "Offset ${directoryOffset}"
println "Artifact base directory ${artifactSetBaseDir}"
println "Set file bits are ${setFileExecuteBits}"
println ""

def getChangeSetByLabel = { labelToGet ->
    def curChangeSet = null;
    done = false;
    tries = 0;
    while (!done && tries < MAX_TRIES) {
        try { 
            curChangeSet = client.getChangeSetByLabel(repositoryId, labelToGet);
            done = true;
        }
        catch (Exception e) {
            tries ++;
            done = false;
            finalException = e;
        }
    }

    if (!done) {
        if (finalException != null) {
            throw finalException;
        }
        else {
            throw new Exception("Unknown error retrieving changeset by label");
        }
    }
    return curChangeSet;
}



def downloadNoSync = {
    println "Downloading files..."

    done = false;
    tries = 0;
    finalException = null;
    while (!done && tries < MAX_TRIES) {
        try {
            client.downloadChangeSetFilesByLabelRemovingPathPrefix(
                    repositoryId,
                    label,
                    baseDirectory,
                    includesArray,
                    excludesArray,
                    artifactSetBaseDir)
            done = true;
        }
        catch (Exception e) {
            tries ++;
            done = false;
            finalException = e;
            println "Error trying to Download Change Set : " +e.getMessage();
        }
    }

    if (!done) {
        if (finalException != null) {
            throw finalException;
        }
        else {
            throw new Exception("Unknown error downloading change set");
        }
    }

    println "Download complete"
}

def doFullClean = { filterToUse, newEntriesList, newFilesList ->
    def rmDirs = []
    //Remove files not in current ChangeSet
    baseDirectory.eachFileRecurse() { curFile ->
        def keepFile = newFilesList.find { it.equals(curFile) }
        if (!keepFile && filterToUse.includes(curFile.path.substring(baseDirectory.getPath().length() + 1))) {
            if (!curFile.isDirectory()) {
                println "Deleting '"+curFile.path+"'"
                curFile.delete()
            }
            else {
                rmDirs << curFile
            }
        }
    }

    rmDirs.each { directory ->
        if (directory.exists()) {
            new AntBuilder().delete(dir: directory.canonicalPath)
        }
    }

    //Remove files with different type than in ChangeSet
    newEntriesList.each { newEntry ->
        def curFile = new File(baseDirectory, newEntry.path)
        if (curFile.isDirectory() && !(newEntry.type == FileType.DIRECTORY)) {
            println "Deleting '"+curFile.path+"'"
            curFile.delete()
        }
        else if (curFile.isFile() && !(newEntry.type == FileType.REGULAR)) {
            println "Deleting '"+curFile.path+"'"
            curFile.delete()
        }
    }
}

def doDiffClean = { filterToUse, newFilesList ->
    ClientChangeSet curChangeSet = null;
    done = false;
    tries =0;
    finalException = null;

    curChangeSet = getChangeSetByLabel(prevLabel);

    ClientPathEntry[] previousEntries = curChangeSet.getEntries();
    def previousFiles = previousEntries.findAll { 
        boolean result = true;
        if (artifactSetBaseDir) {
            result = it.path.startsWith(artifactSetBaseDir);
        }
        return result;
    }.collect { 
        def newPath = it.path;
        
        if (artifactSetBaseDir) {
            newPath = newPath.substring(artifactSetBaseDir.size());
        }
        new File(baseDirectory, newPath).canonicalFile 
    };

    previousFiles.each { curFile ->
        if (!newFilesList.contains(curFile) && filterToUse.includes(curFile.getPath())) {
            println "Deleting '"+curFile.getPath()+"'"
            File deletable = new File(curFile.getPath());
            if (deletable.exists()) {
                deletable.delete();
            }
        }
    }
}

def doCleaning = { filterToUse ->
        println ""
        if (fullClean) {
            println "Removing files that do not exist in the current changeset..."
        } else {
            println "Removing files from the previous changeset which no longer exist in the current one..."
        }

        tries = 0;
        done = false;
        finalException = null;
         
        ClientChangeSet newChangeSet = null;
        newChangeSet = getChangeSetByLabel(label);

        ClientPathEntry[] newEntries = newChangeSet.getEntries();

        def newPathEntries = newEntries.findAll { it.getPath().startsWith(artifactSetBaseDir) };
        def newPaths = newPathEntries.collect { it.getPath() };
        def newFiles = newPaths.collect { new File(baseDirectory, it.substring(artifactSetBaseDir.length())) }
       
        if (fullClean) { 
            doFullClean(filterToUse, newEntries, newFiles);
        }
        else {
            doDiffClean(filterToUse, newFiles);
        }
}

if (useSync) {
    
    for (def include:includesArray) {
        println "My includes are ${include}"
    }
    
    filter = new PatternPathFilter(includesArray, excludesArray)

    if (fullClean || syncCleanup && prevLabel != null) {
        doCleaning(filter);
    }

    baseChangeSet = getChangeSetByLabel(label);


    List<ClientPathEntry> changeSetEntries = Arrays.asList(baseChangeSet.getEntries())
    ClientChangeSetDelta changeSetDelta = new ClientChangeSetDelta(repositoryId, changeSetEntries)

    def hashedCount = 0
    def unhashedCount = 0
    println ""
    println "Calculating hashes..."
    
    //make a new filter with the artifact set base directory
    if (artifactSetBaseDir != null) {
        for (int i = 0; i < includesArray.length; i++) {
            includesArray[i] = artifactSetBaseDir + includesArray[i]
        }

        for (int i = 0; i < excludesArray.length; i++) {
            excludesArray[i] = artifactSetBaseDir + excludesArray[i]
        }
        
        filter = new PatternPathFilter(includesArray, excludesArray)
    }
    
    changeSetEntries.each {
        def path;
        if (filter.includes(it.path)) {
            if (artifactSetBaseDir != null) {
                path = it.path.substring(artifactSetBaseDir.length())
            }
            else {
                path = it.path
            }
            if (it.type.equals(FileType.REGULAR)) {
                def existingFile = new File(baseDirectory, path)
                if (it.contentHash && it.contentHash.algorithm) {
                    if (existingFile.exists() && !existingFile.isDirectory()) {
                        def hash = null
                        try {
                            boolean matchesDate = false;
                            if (!fullVerification) {
                                matchesDate = it.lastModified == existingFile.lastModified() &&
                                        it.length == existingFile.length()
                            }

                            if (!matchesDate) {
                                hash = Hash.hashForFile(existingFile, it.contentHash.algorithm)
                                hashedCount ++
                            } else {
                                unhashedCount ++
                            }

                            if (matchesDate || hash && hash.equals(it.contentHash)) {
                                changeSetDelta.removeEntry(it)
                                stagedFiles << path
                            }
                        }
                        catch (Exception e) {
                            throw new RuntimeException(
                                    "Error calculating hash for ${it.path}: ${e.message}")
                        }
                    }
                }
                else {
                    throw new RuntimeException(
                            "Could not determine hash algorithm for file ${it.path}: ${it.contentHash}")
                }
            }
            else if (it.type.equals(FileType.DIRECTORY)) {
                def existingFile = new File(baseDirectory, path)
                if (existingFile.isDirectory()) {
                    changeSetDelta.removeEntry(it)
                    currentDirs << path
                }
            }
        }
    }

    println "Computed hashes for ${hashedCount} files."

    if (!fullVerification) {
        println "Skipped hashing on ${unhashedCount} files that matched size and date modified."
    }

    def downloadCount = changeSetDelta.entries.length
    def msg = "\nDownloading "+downloadCount+" file"
    msg += downloadCount == 1 ? "..." : "s..."
    println msg

    done =false;
    tries = 0;
    finalException = null;
    while (!done && tries < MAX_TRIES) {
        try {
            client.downloadChangeSetDeltaRemovingPathPrefix(
                    changeSetDelta,
                    baseDirectory,
                    includesArray,
                    excludesArray,
                    artifactSetBaseDir)
            done =true;
        }
        catch (Exception e) {
            done = false;
            finalException = e;
            tries++;
            println "Error Trying to download files : " + e.getMessage();
        }
    }
            
    if (!done) {
        if (finalException != null) {
            throw finalException;
        }
        else {
            throw new Exception("Unknown error downloading change set delta");
        }
    }

    println "Download complete\n"
    stagedFiles.sort()
    stagedFiles.each {
        println "Not changed: '${directoryOffset}${File.separator}${it}'"
    }
}
else {
    downloadNoSync();
}
