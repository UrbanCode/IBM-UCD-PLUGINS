
# Script that adds or updates a valid XML file to a XML Cache for WLI

import com.bea.wli.management.configuration as wlicfg
import org.apache.xmlbeans as xmlbeans
import java.util as util
import java.io as io
import java.io as io2
import jarray
import sys
import wlstModule as wlst
import traceback

print 'Starting the XML Cache Configuration script .... '

pFile = io.FileInputStream(sys.argv[1])
properties = util.Properties()
properties.load(pFile)
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
xmlConfigFile=properties.getProperty('xmlConfigFile')
key=properties.getProperty('key')

if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

try:
    
    print "Creating/Updating file in XML Cache ", xmlConfigFile, " with key ", key
    wlst.config()
    xmlcache = getTarget('XMLCache/SingletonXMLCache')
    xmlFile = io2.FileInputStream(xmlConfigFile)
    xdoc = xmlbeans.XmlObject.Factory.parse(xmlFile)
    xmlcache.add (key, xdoc)
    
    print "script returns SUCCESS"   

except:
    print "ERROR: configuration"
    traceback.print_exc()
    sys.exit(1)

# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
