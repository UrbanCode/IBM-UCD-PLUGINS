#!/bin/bash

#Move to the python directory
cd $1

#Executing the script to set up environment
$2

#Execute the desired python script
$3 $4 $5 $6 $7

Exit $?