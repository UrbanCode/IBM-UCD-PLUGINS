In order to run steps that that create or update objects, you'll need to specify a properties file that determine the properties of the object to be created/updated. 
Examples are provided in the plugin under <pluginZip>/ExampleFiles. 
Some of these properties are file paths. You will need to update these properties before attempting to use them. 
All other properties should be valid to run as-is, though you will probably want to modify them to fit your configuration needs.