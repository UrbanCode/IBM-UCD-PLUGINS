
# Script that configures the base resources for a standalone host processing server.

from java.util import Date
from java.text import SimpleDateFormat
from java.lang import Integer

import weblogic.Deployer
import com.bea.wli.mbconnector.jms as jmsegen 
import com.bea.wli.management.configuration as wlicfg
import java.lang.Boolean as bool
import java.util as util
import java.io as io
import jarray
import sys
import wlstModule as wlst
import traceback

print 'Starting the JMS Event Generation Configuration script .... '

EGdeleted = false

jmsEgName = sys.argv[3]

pFile = io.FileInputStream(sys.argv[1])
properties = util.Properties()
properties.load(pFile)
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
target=properties.getProperty('target')

if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

print 'Getting server MBean .... '
serverMBean = getMBean("Targets/" + target);

if serverMBean is None:
  print 'ERROR: Target Server ' + target + ' Does Not Exist'
  sys.exit(1)

# Note for created resources

now = Date()
df = SimpleDateFormat( "EEE, d MMM yyyy HH:mm:ss" )
theNotes = "Created by JMS Event Generation configuration script. "+ \
           df.format( now )

try:

    print "Deleting JMS EG :", jmsEgName    
    wlst.config()
    
    fEventGen = getTarget("JMSEventGenerators/JMSEventGenerators")
    
    fEventConfigs = fEventGen.getJMSEventGenConfigurationMBeans()
    for fconf in fEventConfigs:
      fname = fconf.getEventGeneratorName()
      if fname == jmsEgName:
        fEventGen.deleteJMSEventGenConfigurationMBean(fconf)
        EGdeleted = true
        break
        
    if EGdeleted == false:
        raise Exception(fileEgName + ' does not exist. It cannot be deleted.')
        
    
#    appName = "WLIJmsEG_" + jmsEgName
#    wlst.deploy( appName, domaindir + "/" + appName + ".jar", adminServerName, "nostage" )
#    wlst.cd("Applications/" + appName)
#    wlst.set("LoadOrder", 1500)
#    wlst.cd("../..")

except:
    print "ERROR: configuration"
    traceback.print_exc()
    sys.exit(1)
    
print "script returns SUCCESS"   
# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
