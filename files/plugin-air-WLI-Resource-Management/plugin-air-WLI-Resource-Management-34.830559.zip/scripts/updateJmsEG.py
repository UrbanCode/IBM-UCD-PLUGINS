
# Script that configures the base resources for a standalone host processing server.

from java.util import Date
from java.text import SimpleDateFormat
from java.lang import Integer

#import weblogic.Deployer
import com.bea.wli.mbconnector.jms as jmsegen 
import com.bea.wli.management.configuration as wlicfg
import java.lang.Boolean as bool
import java.util as util
import java.io as io
import jarray
import sys
import wlstModule as wlst
import traceback

print 'Starting the JMS Event Generation Configuration script .... '

EGupdated = false

jmsEgName = sys.argv[3]

pFile = io.FileInputStream(sys.argv[1])
properties = util.Properties()
properties.load(pFile)
userName=properties.getProperty('userName')
passWord=properties.getProperty('passWord')
URL=properties.getProperty('URL')
target=properties.getProperty('target')
propFile=properties.getProperty('PropFile')
jmsFileProps = io.FileInputStream(propFile)
properties.load(jmsFileProps)
domaindir=properties.getProperty('domaindir')
#jmsEgName=properties.getProperty('jmsEgName')
jndiName=properties.getProperty('jndiName')
destinationType=properties.getProperty('destinationType')
connectionFactoryJndiName=properties.getProperty('connectionFactoryJndiName')
appName=properties.getProperty('appName')
channel=properties.getProperty('channel')
jmsPropertyName=properties.getProperty('jmsPropertyName')
jmsPropertyValue=properties.getProperty('jmsPropertyValue')

if connected != 'true':
   print 'Connecting to weblogic server .... '
   connect(userName,passWord,URL)
else:
   print 'Connected'

print 'Getting server MBean .... '
serverMBean = getMBean("Targets/" + target);

if serverMBean is None:
  print 'ERROR: Target Server ' + target + ' Does Not Exist'
  sys.exit(1)

# Note for created resources

now = Date()
df = SimpleDateFormat( "EEE, d MMM yyyy HH:mm:ss" )
theNotes = "Created by JMS Event Generation configuration script. "+ \
           df.format( now )

try:

    print "Updating JMS EG :", jmsEgName   

    wlst.config()
    
    fEventGen = getTarget("JMSEventGenerators/JMSEventGenerators")
    fEventConfigs = fEventGen.getJMSEventGenConfigurationMBeans()
    
    for fconf in fEventConfigs:
      fname = fconf.getEventGeneratorName()
      if fname == jmsEgName:
        channels = fconf.getChannels()
        channels[0].setMatchJmsPropertyName(jmsPropertyName)
        channels[0].setMatchJmsPropertyValue(jmsPropertyValue)
        fconf.setChannels(channels)
        EGupdated = true
        break
        
    if EGupdated == false:
        raise Exception(fileEgName + ' does not exist. It cannot be updated.')


except:
    print "ERROR: configuration"
    traceback.print_exc()
    sys.exit(1)
    
print "script returns SUCCESS"   
# Finished
print 'Disconnecting from server...'
disconnect('y')
print 'Finished.'
exit()
