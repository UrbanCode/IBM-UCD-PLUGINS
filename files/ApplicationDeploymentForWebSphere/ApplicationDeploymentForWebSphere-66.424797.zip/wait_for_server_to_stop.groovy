final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
out = System.out;
def wsadmin = isWindows ? "wsadmin.bat" : "wsadmin.sh"

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cell = props['cell']
def server = props['server']
def commandPath = (props['commandPath']!=null?props['commandPath']:"");
def node = props['node']
def user = props['user']
def password = (props['password'] != null && props['password'] != "")? props['password'] : props['passScript']
def cluster = props['cluster']
def timeout = props['timeout']

def connType = props['connType']
def host = props['host'];
def port = props['port'];
def additionalArgs = props['additionalArgs'];

File tempFile = new File("temp.py")
tempFile.deleteOnExit();
BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))
def cellarg = cell ? " -cell " + cell : "";

if (server == null || server.startsWith('${p:') || server.trim() == "") {
    invoke = "object = AdminControl.queryNames('type=Cluster,name="+cluster+",*');\n"
}
else {
    invoke = "object = AdminControl.queryNames('type=Server,process=" + server+",*')\n";
}
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);

invoke = "if object == None or object.strip() == '':\n";
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);
invoke = "\tprint 'Object not found... either it does not exist or is not running'\n";
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);
invoke = "\tsys.exit(0);\n";
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);
invoke = "\nstatus = AdminControl.invoke(object, 'getState').strip().lower();\n"
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);
invoke = "if status.find('run') == -1 and status.find('start') == -1 and status.find('partial') == -1:\n"
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);
invoke = "\tprint 'Status not in running state: ' + status;\n";
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);
invoke = "\tsys.exit(0);\n\nprint 'Object in running state' + status;\nsys.exit(1);\n"
temp.write(invoke, 0, invoke.length());
System.out.print(invoke);

temp.close();
boolean done = false;
def timedOut = false;
try {
    timeout = Integer.valueOf(timeout);
}
catch (NumberFormatException e) {
    println("Timeout must be a valid integer!");
    println("Using default timeout of " + 5 * 60 + " seconds.");
}

def startTime = System.currentTimeMillis();
def endTime = startTime + timeout*1000;
while (!done) {
    def commandArgs = [commandPath + wsadmin, "-lang", "jython"];
    commandArgs << "-conntype"
    commandArgs << connType.trim();

    if (host) {
        commandArgs << "-host";
        commandArgs << host;
    }

    if (port) {
        commandArgs << "-port";
        commandArgs << port;
    }

    if (user) {
        commandArgs << "-user"
        commandArgs <<  user
        commandArgs << "-password"
        commandArgs << password
    }

    commandArgs << "-f";
    commandArgs << "temp.py";

    if (additionalArgs) {
        additionalArgs.split('\n').each { arg ->
            commandArgs << arg;
        }
    }

    def procBuilder = new ProcessBuilder(commandArgs);

    if (isWindows) {
        def envMap = procBuilder.environment();
        envMap.put("PROFILE_CONFIG_ACTION","true");
    }

    System.out.println("Checking status...");
    println commandArgs.join(' ');

    def statusProc = procBuilder.start();
    def outPrint = new PrintStream(out, true);
    statusProc.waitForProcessOutput(outPrint, outPrint);
    if (statusProc.exitValue() == 0) {
        done = true;
    }
    else if (endTime < System.currentTimeMillis()) {
        done = true;
        timedOut = true;
    }
    else {
        Thread.sleep(10000);
    }
}

if (timedOut) {
    println("Timed out waiting for server/cluster to stop!");
    System.exit(1);
}
else {
    System.exit(0);
}
