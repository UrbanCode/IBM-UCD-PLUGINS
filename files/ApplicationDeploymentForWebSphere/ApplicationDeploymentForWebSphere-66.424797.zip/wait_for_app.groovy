import java.io.*;
import java.util.*;



final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
out = System.out;
def wsadmin = isWindows ? "wsadmin.bat" : "wsadmin.sh"

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cell = props['cell']
def server = props['server']
def commandPath = (props['commandPath']!=null?props['commandPath']:"");
def node = props['node']
def user = props['user']
def password = (props['password'] != null && props['password'] != "")? props['password'] : props['passScript']
def cluster = props['cluster']

def connType = props['connType']
def host = props['host'];
def port = props['port'];
def additionalArgs = props['additionalArgs'];
def appName = props['appName']
def timeout = props['timeout']
    

File tempFile = new File("temp.py")
tempFile.deleteOnExit();
BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))


def invoke = "if AdminApp.isAppReady('" + appName + "') == 'true':"
temp.write(invoke, 0, invoke.length())
System.out.print invoke
invoke = "\n\tprint \"App Ready\""
temp.write(invoke, 0, invoke.length())
System.out.print invoke
invoke = "\n\tsys.exit(0)"
temp.write(invoke, 0, invoke.length())
System.out.print invoke
invoke = "\nelse:"
temp.write(invoke, 0, invoke.length())
System.out.print invoke
invoke = "\n\tprint \"App Not Ready\""
temp.write(invoke, 0, invoke.length())
System.out.print invoke
invoke = "\n\tsys.exit(1)"
temp.write(invoke, 0, invoke.length())
System.out.print invoke
temp.close()

def exitValue=1;

def commandArgs = [commandPath + wsadmin, "-lang", "jython"];
commandArgs << "-conntype"
commandArgs << connType.trim();

if (host) {
    commandArgs << "-host";
    commandArgs << host;
}

if (port) {
    commandArgs << "-port";
    commandArgs << port;
}

if (user) {
    commandArgs << "-user"
    commandArgs <<  user
    commandArgs << "-password"
    commandArgs << password
}

commandArgs << "-f";
commandArgs << "temp.py";

if (additionalArgs) {
    additionalArgs.split('\n').each { arg ->
        commandArgs << arg;
    }
}

try {
    timeout = Integer.valueOf(timeout);
}
catch (NumberFormatException e) {
    timeout = 5 * 60;
    println("Timeout must be a valid integer");
    println("Using default of " + 5 * 60 + " seconds");
}

def startTime = System.currentTimeMillis();
def endTime = startTime + (timeout * 1000);
def timedOut = false;
System.out.println("")
println commandArgs.join(' ');
def outPrint = new PrintStream(out, true);
while(exitValue==1) {
    println "Checking application is ready..."
    def procBuilder = new ProcessBuilder(commandArgs);

    if (isWindows) {
        def envMap = procBuilder.environment();
        envMap.put("PROFILE_CONFIG_ACTION","true");
    }

    uninstallAppProc = procBuilder.start()
    uninstallAppProc.waitForProcessOutput(outPrint, outPrint);
    exitValue = uninstallAppProc.exitValue();
    println "ExitValue = $exitValue";
    if (exitValue == 1 && endTime < System.currentTimeMillis()) {
        timedOut = true;
        exitValue = 0;
    }
    else if (exitValue == 1) {
        Thread.sleep(10000);
    }
}
if (timedOut){
    println "Timed out waiting for application to achieve the ready state!"
    System.exit(1);
} else {
    System.exit(0);
}
