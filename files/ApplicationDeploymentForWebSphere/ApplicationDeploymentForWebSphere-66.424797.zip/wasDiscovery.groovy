import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();
def overridePath = props['pathOverride']
def agent = props['agent'];
def roleName = "WebSphereCell";

//pole file paths for standard wsadmin path
def foundPath=null;
def standardInstallPath = [];
if (overridePath != null && overridePath != "" && overridePath != '${p:agent/wsadmin.path}') {
    standardInstallPath << overridePath; 
}
else if (apTool.isWindows) {
    standardInstallPath << "C:\\Program Files\\IBM\\WebSphere\\AppServer\\bin\\wsadmin.bat";
    standardInstallPath << "C:\\IBM\\WebSphere\\AppServer\\bin\\wsadmin.bat";
}
else {
    standardInstallPath << "/opt/IBM/WebSphere/AppServer/bin/wsadmin.sh";
}

for (path in standardInstallPath) {
    File file = new File(path);
    if (file.exists()) {
       foundPath = path;
       break;
    }
}

if (foundPath) {
    def path = "";
    if (apTool.isWindows) {
      path = foundPath.substring(0, foundPath.lastIndexOf("\\")+1);
    }
    else {
      path = foundPath.substring(0, foundPath.lastIndexOf("/")+1);
    }
    apTool.setOutputProperty("roleName", roleName);
    apTool.setOutputProperty("websphere.commandPath", path);
    apTool.setOutputProperties();
    println "Found WebSphere install at " + path;
}
else {
    println "WebSphere Install Not Found";
    System.exit(1);
}
