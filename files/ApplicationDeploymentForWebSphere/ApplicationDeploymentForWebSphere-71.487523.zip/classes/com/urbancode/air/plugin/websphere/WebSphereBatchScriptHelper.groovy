/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
package com.urbancode.air.plugin.websphere;

public class WebSphereBatchScriptHelper extends WebSphereCmdLineHelper {

    def libFile = new File(scriptsDir, "wsadminLib.jython");
    def scriptFile;
    def batch= false;

    public WebSphereBatchScriptHelper(def props) {
        super(props);
        scriptFile = new File(props['scriptFile'])
        batch = Boolean.valueOf(props['batch'])
    }
   
    public void execute(def command) {
        if (!scriptFile.isFile()) {
            println "Beginning batch script...";
            scriptFile << 'execfile(\"' + libFile.absolutePath + '\")';
        }
        println "Writing command to script";
        println command
        scriptFile.append("\n" + command);
        if (!batch) {
            commitAndRun();
        }
    }

    public void commitAndRun() {
        try {
            scriptFile.append("\nAdminConfig.save()");
            println "Running Script";
            println "********************************************"
            println scriptFile.getText()
            println "********************************************"
            runWSAdminScript(scriptFile.absolutePath, "Run Script");
        }
        finally {
            scriptFile.delete();
        }
    }
}
