/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONArray;
import com.urbancode.ud.client.UDRestClient;
import com.urbancode.ud.client.ResourceClient;
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.XTrustProvider;
def MAX_RETRIES = 3;

XTrustProvider.install();

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def weburl = System.getenv("AH_WEB_URL");
def user = apTool.getAuthTokenUsername();
def password = apTool.getAuthToken();
def rootResourcePath = props['resourcePath'];
def webSphereUser = props['wasuser'];
def webSpherePassword = props['waspassword'];
def profilePath = props['profilePath'];
def wsadminPath = props['commandPath'];
def wasPort = props['port'];
def wasHost = props['host'];
def wasConnType = props['connType'];


def WSDISC_HOME = System.getenv("PLUGIN_HOME");

def finalURI = new URI(weburl);
def udClient = new ResourceClient(finalURI, user, password);

def createPath = { parentPath, childName ->
    while (parentPath.endsWith("/")) {
        parentPath = parentPath.substring(0, parentPath.size() - 1);
    }
    if (!parentPath.startsWith("/")) {
        parentPath = "/" + parentPath;
    }
    parentPath = parentPath + "/";
    while (childName.startsWith("/")) {
        childName = childName.substring(1);
    }

    def finalPath = parentPath + childName;
    return finalPath;
}

def getOrCreateSubResource = { resourcePath, parentUUID, description ->
    def resourceName = resourcePath.substring(resourcePath.lastIndexOf("/") + 1);
    def resource = null;
    def tries = 0;
    def done = false;
    while (!done && tries < MAX_RETRIES) {
        try {
            try {
                resource = udClient.getResourceByPath(resourcePath);
            }
            catch (IOException e) {
                //resource does not exist(i hope)
                resource = null;
            }
            if (resource == null) {
                def nodeId = udClient.createSubResource(parentUUID, resourceName, description);
                resource = udClient.getResourceByPath(resourcePath);
            }
            done = true;
        }
        catch (IOException e) {
            tries++;
            done = false;
            println("Got IOException in getOrCreateSubResource for ${resourcePath}");
            if (tries < MAX_RETRIES) {
                println ("Retrying...")
            }
            else {
                throw e;
            }
        }
    }

    return UUID.fromString(resource.getString("id"));
}

def addRoleToResource = { resource, role, properties ->
    def tries = 0;
    def done = false;
    while (!done && tries < MAX_RETRIES) {
        try {
            udClient.setRoleOnResource(resource.toString(), role, properties);
            done = true;
        }
        catch (IOException e) {
            tries++;
            done = false;
            println("Got IOException in addRoleToResource for ${resource}");
            if (tries < MAX_RETRIES) {
                println ("Retrying...")
            }
            else {
                throw e;
            }
        }
    }
}

def addChildrenToQueue;
addChildrenToQueue = { rootResource, queue ->
    if (rootResource.has("children")) {
        JSONArray children = rootResource.getJSONArray("children");
        for (int i = 0 ; i < children.length(); i ++ ) {
            JSONObject child = children.getJSONObject(i);
            queue.offer(child.getString("name"));
            addChildrenToQueue(child, queue);
        }
    }
}

/*
 def removeOldSubResources = { resourcesToHave ->
 JSONArray resourceTree = udClient.getResourceTree();
 //first we need to find the root resource in the tree
 Queue<JSONObject> queue = new LinkedList<JSONObject>();
 for (int i = 0 ; i < resourceTree.length(); i ++ ) {
 queue.offer(resourceTree.get(i));
 }
 JSONObject current = null;
 JSONObject rootResource = null;
 while ((current = queue.poll()) != null) {
 if (current.getString("name") == rootResourceName) {
 rootResource = current;
 break;
 }
 if (current.has("children")) {
 JSONArray children = current.getJSONArray("children");
 for (int i = 0 ; i < children.length(); i ++ ) {
 queue.offer(children.get(i));
 }
 }
 }
 if (rootResource == null) {
 throw new Exception("Root resource not found in resource tree for cleanup");
 }
 //flatten into Queue
 Queue<String> resQueue = new LinkedList<String>();
 addChildrenToQueue(rootResource, resQueue);
 for (def resToHave : resourcesToHave) {
 println "\"${resToHave}\" : ${resToHave.class.name}";
 }
 //remove res no longer needed
 def curResName = null;
 while((curResName = resQueue.poll()) != null) {
 if (!resourcesToHave.contains(curResName)) {
 System.out.println("Removing unneeded resource ${curResName}");
 udClient.deleteResource(curResName);
 }
 }
 
 */

//this code parses the json that represents a resource and creates the resources
List<String> resourceToHave = new ArrayList<String>();
def createOrUpdateResources = { data ->
    JSONObject cellObject = new JSONObject(data);
    String cellName = cellObject.getString("cell");
    String port = cellObject.getString("port");
    String connType = cellObject.getString("connType");
    String host = cellObject.getString("host");
    JSONArray nodeJSONs = cellObject.getJSONArray("nodes");
    JSONArray clusterJSONs = cellObject.getJSONArray("clusters");

    JSONArray portalJSONs = cellObject.getJSONArray("portalservers");

    nodes = [:];
    clusters = [:];
    
    portalservers = [:];
        
    for (int i = 0 ; i < nodeJSONs.length(); i++) {
        JSONObject node = nodeJSONs.getJSONObject(i);
        String nodeName = node.getString("node");
        nodes[nodeName] = [];
        JSONArray serverJSONs = node.getJSONArray("servers");

        for (int j = 0; j < serverJSONs.length(); j++) {
            JSONObject server = serverJSONs.get(j);
            if (server.has("was")) {
                nodes[nodeName] << ["type":"was", "name":server.getString("was")];                
            }
            else if (server.has("portal")) {
                nodes[nodeName] << ["type":"portal", "name":server.getString("portal")];
            }
        }
    }

    for (int i =0 ; i < clusterJSONs.length(); i ++) {
        JSONObject cluster = clusterJSONs.getJSONObject(i);
        String clusterName = cluster.getString("cluster");
        clusters[clusterName] = [];

        JSONArray memberJSONs = cluster.getJSONArray("members");

        for (int j = 0 ; j < memberJSONs.length(); j++) {
            JSONObject member = memberJSONs.get(j);
            String nodeName =  member.getString("node");
            String memberName = member.getString("member");

            //nodes[nodeName].remove(memberName);

            clusters[clusterName] << ["node":nodeName, "member":memberName];
        }
    }
    
    for (int i =0 ; i < portalJSONs.length(); i ++) {
        JSONObject portal = portalJSONs.getJSONObject(i);
        String portalId = portal.getString("portalserver");
        portalservers[portalId] = [];

        JSONArray attrJSONs = portal.getJSONArray("attributes");

        for (int j = 0 ; j < attrJSONs.length(); j++) {
            JSONObject attr = attrJSONs.get(j);
            String serverName =  attr.getString("server_name");
            String portalHome = attr.getString("portal_home");
            String profileHome =  attr.getString("profile_home");
            String configPort = attr.getString("config_port");
            String serverHost = attr.getString("server_host");

            portalservers[portalId] << ["server_name":serverName, "portal_home":portalHome, 
                                        "profile_home":profileHome, "config_port":configPort,
                                        "server_host":serverHost];
        }
    }
    

    def rootResource = udClient.getResourceByPath(rootResourcePath);
    def rootResourceIdString = rootResource.getString("id");
    def rootResourceId = UUID.fromString(rootResourceIdString);
    def cellProps = new HashMap<String, String>();

    cellProps.put("websphere.cell", cellName);
    cellProps.put("websphere.port", port);
    cellProps.put("websphere.host", host);
    cellProps.put("websphere.profilePath", profilePath);
    cellProps.put("websphere.commandPath", wsadminPath);
    cellProps.put("websphere.user", webSphereUser);
    cellProps.put("websphere.password", webSpherePassword);
    cellProps.put("websphere.connType", connType);
    addRoleToResource(rootResourceIdString, "WebSphereCell", cellProps);
    
    for (node in nodes) {
        println "Adding node: " + node.key.toString();
        resourceToHave << node.key.toString();

        def nodePath = createPath(rootResourcePath, node.key);
        def nodeId = getOrCreateSubResource(nodePath, rootResourceId, "Node ${node.key} on cell ${cellName}");
        def nodeProps = new HashMap<String, String>();
        nodeProps.put("websphere.node", node.key);
        addRoleToResource(nodeId, "WebSphereNode", nodeProps);

        for (server in node.value) {
            println "Adding server: " + node.key.toString();
            def type = server.get("type");
            switch (type) {
                case "was": 
                    def servername = server.get("name");
                    resourceToHave << "${node.key} - ${servername}".toString();
                    def serverPath = createPath(nodePath, "${servername}");
                    def serverId = getOrCreateSubResource(serverPath, nodeId, "Server ${servername} on node ${node.key}");
                    def serverProps = new HashMap<String, String>();
                    serverProps.put("websphere.server", servername);
                    addRoleToResource(serverId, "WebSphereServer", serverProps);
                    break;
                case "portal":
                    def portalIndex = server.get("name");
                    JSONObject portalAttrs = portalservers.get(portalIndex);    
                    def servername = portalAttrs.get("server_name");
                    def portalHome = portalAttrs.get("portal_home");
                    def profileHome = portalAttrs.get("profile_home");
                    def configPort = portalAttrs.get("config_port");
                    def serverHost = portalAttrs.get("server_host");
                    
                    resourceToHave << "${node.key} - ${servername}".toString();
                    def wasPath = createPath(nodePath, "${servername}");
                    def wasId = getOrCreateSubResource(wasPath, nodeId, "Server ${servername} on node ${node.key}");
                    def wasProps = new HashMap<String, String>();
                    wasProps.put("websphere.server", servername);
                    addRoleToResource(wasId, "WebSphereServer", wasProps);

                    resourceToHave << "${node.key} - ${servername}(Portal)".toString();
                    def portalPath = createPath(wasPath, "${servername}(Portal)");
                    def portalId = getOrCreateSubResource(portalPath, wasId, "Portal Server ${servername} on node ${node.key}");
                    def portalProps = new HashMap<String, String>();
                    portalProps.put("websphere.server", servername);
                    portalProps.put("portal.host",serverHost);
                    portalProps.put("portal.home", portalHome);
                    portalProps.put("portal.profile.home", profileHome);
                    portalProps.put("portal.admin.user", "");
                    portalProps.put("portal.admin.password", "");
                    portalProps.put("portal.config.port", configPort);
                    portalProps.put("websphere.password", webSpherePassword);

                    addRoleToResource(portalId, "PortalServer", portalProps);
                    break;            
            }
        }
    }

    for (cluster in clusters) {
        def clusterResourceName = cluster.key.toString();
        println "Adding cluster: " + clusterResourceName;
        
        resourceToHave << clusterResourceName;
        def clusterPath = createPath(rootResourcePath, clusterResourceName);
        def clusterId = getOrCreateSubResource(clusterPath, rootResourceId, "Cluster ${cluster.key} on cell ${cellName}");
        def clusterProps = new HashMap<String, String>();
        clusterProps.put("websphere.cluster", cluster.key);
        addRoleToResource(clusterId, "WebSphereCluster", clusterProps);
    }
    
    apTool.setOutputProperty("websphere.cell", cellName);
    apTool.setOutputProperties();

    //removeOldSubResources(resourceToHave);
}


//this stuff all handles the create of resource roles on the properties for the resource roles
def getRole = { roleName ->
    def role = udClient.getResourceRoleByName(roleName);
    return role;
}

def getPropSheetDefUUIDStringFromRole = { role ->
    JSONObject object = role.getJSONObject("propSheetDef");
    return object.getString("id");
}

def getPropSheetDefs = { propSheetDefId ->
    def propSheetDefPropDefs = udClient.getPropSheetDefPropDefs(propSheetDefId);
    return propSheetDefPropDefs;
}

def findOrCreatePropNameInPropSheet = { propSheetId, propDefs, name, type, label, description ->
    boolean found = false;
    def prop;
    for (int i = 0 ; i < propDefs.length(); i++) {
        if (propDefs.getJSONObject(i).getString("name") == name) {
            found = true;
            prop = UUID.fromString(propDefs.getJSONObject(i).getString("id"));
            break;
        }
    }

    return prop;
}

def getDataFromWsadmin = {
    def wsadminExe = wsadminPath;

    while (wsadminExe.endsWith(File.separator)) {
        wsadminExe = wsadminExe.substring(0, wsadminExe.length()-1);
    }

    if (File.separator == "\\") {//windows platform
        wsadminExe = wsadminExe + File.separator + "wsadmin.bat";
    }
    else {
        wsadminExe = wsadminExe + File.separator + "wsadmin.sh";
    }


    def cmdArgs = [wsadminExe];    

    if (wasHost?.trim() && !wasHost.startsWith("p:")) {
        cmdArgs << "-host";
        cmdArgs << wasHost.trim();
    }

    if (wasPort?.trim() && !wasPort.startsWith("p:")) {
        cmdArgs << "-port";
        cmdArgs << wasPort.trim();
    }

    if (wasConnType?.trim() && !wasConnType.startsWith("p:")) {
        cmdArgs << "-conntype";
        cmdArgs << wasConnType.trim();
    }
   
    if ( webSphereUser?.trim() && !webSphereUser.trim().startsWith("p:")) {
        println "Using credentials";
        cmdArgs << "-user" << webSphereUser << "-password" << webSpherePassword;
    }
 
    cmdArgs << "-f" << "${WSDISC_HOME}/jythonScripts/discover.py";

    Process proc = cmdArgs.execute();
    proc.out.close();
    OutputStream oStream = new ByteArrayOutputStream();
    OutputStream eStream = new ByteArrayOutputStream();
    proc.waitForProcessOutput(oStream, eStream);
    String output = oStream.toString();
    println output
    int start = output.indexOf("{");
    output = output.substring(start-1, output.length());
    return output;
}

def cellRole;
def nodeRole;
def serverRole;
def clusterRole;

cellRole = getRole("WebSphereCell");
nodeRole = getRole("WebSphereNode");
serverRole = getRole("WebSphereServer");
clusterRole = getRole("WebSphereCluster");

def cellRoleId = getPropSheetDefUUIDStringFromRole(cellRole);
def nodeRoleId = getPropSheetDefUUIDStringFromRole(nodeRole);
def serverRoleId = getPropSheetDefUUIDStringFromRole(serverRole);
def clusterRoleId = getPropSheetDefUUIDStringFromRole(clusterRole);

def portalRole;
portalRole = getRole("PortalServer");
def portalRoleId = getPropSheetDefUUIDStringFromRole(portalRole);

//needs to call wsadmin
//get the output
//create the resources with roles and property values


def data = getDataFromWsadmin();

createOrUpdateResources(data);
