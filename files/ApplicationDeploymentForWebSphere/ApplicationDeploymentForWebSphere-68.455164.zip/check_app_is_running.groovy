final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
out = System.out;
def wsadmin = isWindows ? "wsadmin.bat" : "wsadmin.sh"

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cell = props['cell']
def server = props['server']
def commandPath = (props['commandPath']!=null?props['commandPath']:"");
def node = props['node']
def user = props['user']
def password = (props['password'] != null && props['password'] != "")? props['password'] : props['passScript']
def cluster = props['cluster']
def appName = props['appName']
def appType = props['appType']

def connType = props['connType']
def host = props['host'];
def port = props['port'];
def additionalArgs = props['additionalArgs'];


    
File tempFile = new File("temp.py")
BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))
def cellarg = cell ? " -cell " + cell : ""

def invoke = "";
if (server == null || server.startsWith('${p:') || server.trim() == "") {
    invoke = "AdminConfig.getid('/ServerCluster:"+cluster+"/')"
    invoke = "clusterMembers = AdminConfig.list('ClusterMember', "+invoke+").splitlines()\n"
    temp.write(invoke, 0, invoke.length())
    System.out.print(invoke);
    invoke = "for member in clusterMembers:\n"
    temp.write(invoke, 0, invoke.length())
    System.out.print(invoke);
    invoke = "\tmemberName = AdminConfig.showAttribute(member, 'memberName').strip();\n"
    temp.write(invoke, 0, invoke.length())
    System.out.print(invoke);
    invoke = "\tappRun = None;\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tnames = AdminControl.queryNames('type=" + appType + ",name=" + appName.trim() + ",*').splitlines();\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tif len(names) == 0 or (len(names) == 1 and names[0] == ''):\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tprint 'App not running on any server';\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tsys.exit(1);\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\telse:\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tfor app in names:\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\t\tserver = AdminControl.getAttributes(app, ['server']).split(' ')[1][:-1];\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\t\tserverName = AdminControl.getAttributes(server, ['name']).split(' ')[1][:-1];\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\t\tif serverName.strip() == memberName:\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\t\t\tappRun=app;\n\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tif appRun == None:\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tprint 'App not running on server ' + memberName;\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\telse:\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tprint 'App is running on server ' + memberName;\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
}
else {
    invoke = "appRun = None;\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "names = AdminControl.queryNames('type=" + appType + ",name=" + appName.trim() + ",*').splitlines();\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "if len(names) == 0 or (len(names) == 1 and names[0] == ''):\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tprint 'App not running on any server " + server + "';\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tsys.exit(1);\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "else:\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tfor app in names:\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tserver = AdminControl.getAttributes(app, ['server']).split(' ')[1][:-1];\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tserverName = AdminControl.getAttributes(server, ['name']).split(' ')[1][:-1];\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\tif serverName.strip() == '" + server.trim() + "':\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\t\t\tappRun=app;\n\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "if appRun == None:\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tprint 'App not running on server " + server.trim() + "';\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "\tsys.exit(1);\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "print 'App is running on server " + server.trim() + "';\n";
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
    invoke = "sys.exit(0);\n"
    temp.write(invoke,0,invoke.length());
    System.out.print(invoke);
}

temp.close();
def commandArgs = [commandPath + wsadmin, "-lang", "jython"];
commandArgs << "-conntype"
commandArgs << connType.trim();

if (host) {
    commandArgs << "-host";
    commandArgs << host;
}

if (port) {
    commandArgs << "-port";
    commandArgs << port;
}

if (user) {
    commandArgs << "-user"
    commandArgs <<  user
    commandArgs << "-password"
    commandArgs << password
}
commandArgs << "-f"
commandArgs << "temp.py";

if (additionalArgs) {
    additionalArgs.split('\n').each { arg ->
        commandArgs << arg;
    }
}

println commandArgs.join(' ');
def procBuilder = new ProcessBuilder(commandArgs);

if (isWindows) {
    def envMap = procBuilder.environment();
    envMap.put("PROFILE_CONFIG_ACTION","true");
}

def statusProc = procBuilder.start();
def outPrint = new PrintStream(out, true);
statusProc.waitForProcessOutput(outPrint, outPrint);
System.exit(statusProc.exitValue());
