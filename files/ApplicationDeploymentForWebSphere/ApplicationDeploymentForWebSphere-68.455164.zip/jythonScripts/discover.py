###
# Licensed Materials - Property of IBM Corp.
# @product.name.full@
# (c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.
# 
# U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
# GSA ADP Schedule Contract with IBM Corp.
# 
# Filename: discover.py
# 
# 
###

from java.util import HashMap
from java.util import ArrayList
cell = AdminControl.getCell();
port = AdminControl.getPort();
connType = AdminControl.getType();
host = AdminControl.getHost();

newline = java.lang.System.getProperty("line.separator")

node2Servers = HashMap();
cluster2Servers = HashMap();

nodes = AdminConfig.list("Node").split(newline);
print nodes
if (nodes != None and nodes != ''):
  for node in nodes:
    if (node != None and node != ''):
      nodeName = AdminConfig.showAttribute(node, "name");
      if not node2Servers.containsKey(nodeName):
        node2Servers.put(nodeName, ArrayList());
      #endif

      servers = AdminConfig.list("Server", node).split(newline);
      print servers
      if (servers != None and servers != ''):
        for server in servers:
          if (server != None and server != ''):
            serverName = AdminConfig.showAttribute(server, "name")
            node2Servers.get(nodeName).add(serverName);
          #endif
      #endif
  #endif
#endif

clusters = AdminConfig.list("ServerCluster").split(newline);
print clusters
if (clusters != None and clusters != ''):
  for cluster in clusters:
    if (cluster != None and cluster != ''):
      clusterName = AdminConfig.showAttribute(cluster, "name");
      if not cluster2Servers.containsKey(clusterName):
        cluster2Servers.put(clusterName, ArrayList())

      members = AdminConfig.list("ClusterMember", cluster).split(newline);
      print members
      if (members != None and members != ''):
        for member in members:
          if (member.strip() != "") :
            memberName = AdminConfig.showAttribute(member,"memberName");
            memberNodeName = AdminConfig.showAttribute(member, "nodeName");
            memberMap = HashMap();
            memberMap.put("node", memberNodeName);
            memberMap.put("member", memberName);
            cluster2Servers.get(clusterName).add(memberMap);
          #endif
      #endif
    #endif
#endif

print "{"
print "  \"cell\":\"" + cell + "\","
print "  \"port\":\"" + port + "\","
print "  \"connType\":\"" + connType + "\","
print "  \"host\":\"" + host + "\","
print "  \"nodes\":["

isFirstNode = 1;
for key in node2Servers.keySet():
  if isFirstNode == 1:
    print "    {"
    isFirstNode = 0;
  else:
    print "    ,{"

  print "    \"node\":\"" + key + "\","
  print "    \"servers\":["

  isFirstServer = 1;
  for server in node2Servers.get(key):
    if isFirstServer == 1:
      print "      {"
      isFirstServer = 0
    else:
      print "      ,{"

    print "      \"server\":\"" + server + "\""
    
    print "      }"

  print "    ]"
  print "    }"
print "  ],"
print "  \"clusters\":["

isFirstCluster = 1;
for key in cluster2Servers.keySet():
  if isFirstCluster == 1:
    isFirstCluster=0;
    print "    {"
  else:
    print "    ,{"

  print "    \"cluster\":\"" + key + "\","
  print "    \"members\": ["

  isFirstMember = 1;
  for memberMap in cluster2Servers.get(key):
    if isFirstMember==1:
      isFirstMember=0;
      print "      {"
    else:
      print "      ,{"

    print "      \"member\":\"" + memberMap.get("member") + "\","
    print "      \"node\":\"" + memberMap.get("node") + "\""
    print "        }"
  print "    ]"
  print "    }"
print "  ]"
print "}"
   

