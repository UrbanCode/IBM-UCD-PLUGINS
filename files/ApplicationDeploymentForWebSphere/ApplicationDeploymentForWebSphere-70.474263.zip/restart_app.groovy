/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
out = System.out;
def wsadmin = isWindows ? "wsadmin.bat" : "wsadmin.sh"

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cell = props['cell']
def server = props['server']
def commandPath = (props['commandPath']!=null?props['commandPath']:"");
def node = props['node']
def user = props['user']
def password = (props['password'] != null && props['password'] != "")? props['password'] : props['passScript']
def cluster = props['cluster']

def connType = props['connType']
def host = props['host'];
def port = props['port'];
def additionalArgs = props['additionalArgs'];
def appName = props['appName']
/////////////////////////////////////
//Stop App
/////////////////////////////////////
File tempFile = File.createTempFile("temp", ".py", new File("."))
tempFile.deleteOnExit();
BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))
def cellarg = cell ? " -cell " + cell : ""
def queryNames =""
if (server == null || server.startsWith('${p:') || server.trim() == "") 
{
  queryNames = "AdminConfig.getid('/ServerCluster:"+cluster+"/')"
  queryNames = "clusterMembers = AdminConfig.list('ClusterMember', "+queryNames+").splitlines()\n"
  temp.write(queryNames, 0, queryNames.length())
  System.out.println queryNames
  def startapp = "for member in clusterMembers:\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tserver = AdminConfig.showAttribute(member, 'memberName')\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tnode = AdminConfig.showAttribute(member, 'nodeName')\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tappMan=AdminControl.queryNames('node='+node+',type=ApplicationManager,process='+server+',*')\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tAdminControl.invoke(appMan, 'stopApplication', '" + appName + "')\n\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  temp.close()
} else {
  queryNames = "AdminControl.queryNames('type=ApplicationManager,process=" + server + ",node=" + node + ",*')"
  def invoke = "AdminControl.invoke(" + queryNames + ", \"stopApplication\", \"" + appName + "\")"
  temp.write(invoke, 0, invoke.length())
  System.out.println invoke
  temp.close()
}

def commandArgs = [commandPath + wsadmin, "-lang", "jython"];
commandArgs << "-conntype"
commandArgs << connType.trim();

if (host) {
    commandArgs << "-host";
    commandArgs << host;
}

if (port) {
    commandArgs << "-port";
    commandArgs << port;
}

if (user) {
    commandArgs << "-user"
    commandArgs <<  user
    commandArgs << "-password"
    commandArgs << password
}

commandArgs << "-f";
commandArgs << tempFile.getName();

if (additionalArgs) {
    additionalArgs.split('\n').each { arg ->
        commandArgs << arg;
    }
}

println commandArgs.join(' ');
def procBuilder = new ProcessBuilder(commandArgs);

if (isWindows) {
    def envMap = procBuilder.environment();
    envMap.put("PROFILE_CONFIG_ACTION","true");
}


def stopAppProc = procBuilder.start();
def outPrint = new PrintStream(out, true);
stopAppProc.waitForProcessOutput(outPrint, outPrint);
if (stopAppProc.exitValue() != 0) {
    throw new Exception("Failed to stop the Application: " + appName + " on the server: " + server + "on Node: " + node)
}
tempFile.delete()

/////////////////////////////////////
//Start App
/////////////////////////////////////
temp = new BufferedWriter(new FileWriter(tempFile))
if (server == null || server.startsWith('${p:') || server.trim() == "")
{
  queryNames = "AdminConfig.getid('/ServerCluster:"+cluster+"/')"
  queryNames = "clusterMembers = AdminConfig.list('ClusterMember', "+queryNames+").splitlines()\n"
  temp.write(queryNames, 0, queryNames.length())
  System.out.println(queryNames)
  def startapp = "for member in clusterMembers:\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tserver = AdminConfig.showAttribute(member, 'memberName')\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tnode = AdminConfig.showAttribute(member, 'nodeName')\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tappMan=AdminControl.queryNames('node='+node+',type=ApplicationManager,process='+server+',*')\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  startapp = "\tAdminControl.invoke(appMan, 'startApplication', '" + appName + "')\n\n"
  temp.write(startapp,0,startapp.length())
  System.out.println startapp
  temp.close()
} else {
  queryNames = "AdminControl.queryNames('type=ApplicationManager,process=" + server + ",node=" + node + ",*')"
  def invoke = "AdminControl.invoke(" + queryNames + ", \"startApplication\", \"" + appName + "\")"
  temp.write(invoke, 0, invoke.length())
  System.out.println invoke
  temp.close()
}

commandArgs = [commandPath + wsadmin, "-lang", "jython"];
commandArgs << "-conntype"
commandArgs << connType.trim();

if (host) {
    commandArgs << "-host";
    commandArgs << host;
}

if (port) {
    commandArgs << "-port";
    commandArgs << port;
}

if (user) {
    commandArgs << "-user"
    commandArgs <<  user
    commandArgs << "-password"
    commandArgs << password
}

commandArgs << "-f";
commandArgs << tempFile.getName();

if (additionalArgs) {
    additionalArgs.split('\n').each { arg ->
        commandArgs << arg;
    }
}

println commandArgs.join(' ');
procBuilder = new ProcessBuilder(commandArgs);

if (isWindows) {
    def envMap = procBuilder.environment();
    envMap.put("PROFILE_CONFIG_ACTION","true");
}

def statusProc = procBuilder.start();
statusProc.waitForProcessOutput(outPrint, outPrint);
System.exit(statusProc.exitValue());

