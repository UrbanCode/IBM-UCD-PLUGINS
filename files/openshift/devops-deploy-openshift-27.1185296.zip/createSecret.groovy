/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.plugin.openshift.OpenShiftRestHelper
import com.urbancode.air.AirPluginTool

// Get step properties
def apTool   = new AirPluginTool(args[0], args[1])
def props  = apTool.getStepProperties()

def helper = new OpenShiftRestHelper(props)
try {
    println("Creating Secret(s)...")
    helper.createSecret()
}
catch (Exception ee) {
    throw new Exception("Command failed with message: " + ee.message)
}