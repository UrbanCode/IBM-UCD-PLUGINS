package com.urbancode.air.plugin.tririga.date

import org.apache.commons.lang3.time.DateUtils

class DateParser {
    private static String[] datePatterns = ["MM/dd/yyyy", "MM/dd/yyyy HH:mm:ss",
        "MM/dd/yyyy HH:mm:ss ZZ", "MM/dd/yyyy HH:mm:ss XXX"]

    /**
     * Get milliseconds from a String representation of a date.
     */
    public static long parseDate(String input) {
        Date date = DateUtils.parseDate(input, datePatterns)
        return date.getTime()
    }
}
