/*
* Licensed Materials - Property of HCL
* UrbanCode Deploy
* (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
*/
/* This is an example step groovy to show the proper use of APTool
 * In order to use import these utilities, you have to use the "pluginutilscripts" jar
 * that comes bundled with this plugin example.
 */
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.tririga.date.DateParser
import com.urbancode.air.plugin.tririga.http.TririgaClient
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.codehaus.jettison.json.JSONObject

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()

/* We acquire the specified log4j level from the input properties and set the root logger level.
 * This will set the logger level for all loggers retrieved in this step.
 * If the logger level specified is invalid, we default to INFO.
 */
String logLevel = props['loggerLevel']
Logger.getRootLogger().setLevel(Level.toLevel(logLevel, Level.INFO))
Logger logger = Logger.getLogger(getClass())

String serverUrl = props['serverUrl'].trim()
String username = props['username'].trim()
String password = props['password'].trim()
String packageId = props['packageId'].trim()
Boolean waitForCompletion = Boolean.valueOf(props['waitForCompletion'])
long timeout = Long.parseLong(props['timeout'].trim())

logger.info("Exporting package '${packageId}' to userFiles/ObjectMigration.")
TririgaClient client = new TririgaClient(serverUrl, username, password)

try {
    JSONObject packageObject = client.exportPackage(packageId)
    logger.info("A package export has been requested.")

    if (waitForCompletion) {
        String status = ""
        long startTime = System.currentTimeMillis()

        while (!status.equalsIgnoreCase("Exported")) {
            status = client.getPackageStatus(packageId).trim()

            if (timeout > -1) {
                long elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000

                if (elapsedSeconds > timeout) {
                    logger.error("Max timeout exceeded while waiting for export to complete. For a " +
                        "longer max timeout increase the Timeout field.")
                    System.exit(1)
                }
            }

            logger.info("Waiting for package export to complete...")
            Thread.sleep(5000) // Wait 5 seconds then try again.
        }

        println("The package has fully completed exporting.")
    }

    /* Set packageId and packageName output properties to be used in subsequent steps. */
    if (packageObject.has("packageId")) {
        String pkgId = packageObject.get("packageId")
        apTool.setOutputProperty("packageId", pkgId)
        logger.info("Set the 'packageId' output property from Tririga.")
    }
    if (packageObject.has("packageName")) {
        String pkgName = packageObject.get("packageName")
        apTool.setOutputProperty("packageName", pkgName)
        logger.info("Set the 'packageName' output property from Tririga.")
    }
    apTool.storeOutputProperties()
}
finally {
    client.cleanUp()
}
