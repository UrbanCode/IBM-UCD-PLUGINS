/*
* Licensed Materials - Property of HCL
* UrbanCode Deploy
* (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
*/
/* This is an example step groovy to show the proper use of APTool
 * In order to use import these utilities, you have to use the "pluginutilscripts" jar
 * that comes bundled with this plugin example.
 */
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.tririga.date.DateParser
import com.urbancode.air.plugin.tririga.http.TririgaClient
import org.apache.log4j.Level
import org.apache.log4j.Logger

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()

/* We acquire the specified log4j level from the input properties and set the root logger level.
 * This will set the logger level for all loggers retrieved in this step.
 * If the logger level specified is invalid, we default to INFO.
 */
String logLevel = props['loggerLevel']
Logger.getRootLogger().setLevel(Level.toLevel(logLevel, Level.INFO))
Logger logger = Logger.getLogger(getClass())

String serverUrl = props['serverUrl'].trim()
String username = props['username'].trim()
String password = props['password'].trim()
String packageName = props['packageName'].trim()
File workDir = new File(".")

logger.info("Downloading package '${packageName}' from userFiles/ObjectMigration.")
TririgaClient client = new TririgaClient(serverUrl, username, password)

try {
    File packageFile = client.downloadPackage(packageName, workDir)
    logger.info("The package has been downloaded to the '${workDir.getAbsolutePath()}' directory.")

    /* Set packageFile output property to be used in subsequent steps. */
    apTool.setOutputProperty("packageFile", packageFile.getAbsolutePath())
    apTool.storeOutputProperties()
    logger.info("Set the 'packageFile' output property.")
}
finally {
    client.cleanUp()
}
