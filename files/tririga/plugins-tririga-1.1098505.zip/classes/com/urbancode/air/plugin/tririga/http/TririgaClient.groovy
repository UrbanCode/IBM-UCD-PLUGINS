/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
 /* This is an example step groovy to show the proper use of APTool
  * In order to use import these utilities, you have to use the "pluginutilscripts" jar
  * that comes bundled with this plugin example.
  */
package com.urbancode.air.plugin.tririga.http

import org.apache.log4j.Logger
import org.codehaus.jettison.json.JSONObject

class TririgaClient {
    private final LOGGER = Logger.getLogger(getClass())
    private final String CREATE_PACKAGE_ENDPOINT = "/api/p/v1/om/createPackageByDate"
    private final String EXPORT_PACKAGE_ENDPOINT = "/api/p/v1/om/export/%s"
    private final String DOWNLOAD_PACKAGE_ENDPOINT = "/api/p/v1/om/downloadPackageFromUserFiles"
    private final String PACKAGE_STATUS_ENDPOINT = "/api/p/v1/om/packageStatus/%s"
    private final String ADD_OBJECT_ENDPOINT = "/api/p/v1/om/addObjectToPackage/%s"
    private RestClientHelper restHelper

    public TririgaClient(String serverUrl, String username, String password) {
        restHelper = new RestClientHelper(serverUrl, username, password, true)
    }

    /**
     * Create the package in the Tririga server and return its ID.
     */
    public JSONObject createPackage(
        String packageName,
        String packageDesc,
        long dateInMillis,
        boolean includeDependents)
    {
        String endpoint = CREATE_PACKAGE_ENDPOINT +"?packageName=${encode(packageName)}" +
            "&packageDescription=${encode(packageDesc)}&dateInMillis=${dateInMillis}" +
            "&includeDependents=${includeDependents}"

        return new JSONObject(restHelper.doGetRequest(endpoint))
    }

    /**
     * Add an object to a package.
     */
    public JSONObject addObjectToPackage(String packageId, String objectName, String objectType)
    {
        String endpoint = String.format(ADD_OBJECT_ENDPOINT, packageId) +
        "?objectType=${encode(objectType)}&objectName=${encode(objectName)}"

        return new JSONObject(restHelper.doGetRequest(endpoint))
    }

    /**
     * Export a package zip to the userFiles/ObjectMigration directory of the Tririga server.
     */
    public JSONObject exportPackage(String packageId)
    {
        String endpoint = String.format(EXPORT_PACKAGE_ENDPOINT, packageId)

        return new JSONObject(restHelper.doGetRequest(endpoint))
    }

    /**
     * Get the status of a package by its ID.
     */
    public String getPackageStatus(String packageId)
    {
        String endpoint = String.format(PACKAGE_STATUS_ENDPOINT, packageId)

        JSONObject responseObject = new JSONObject(restHelper.doGetRequest(endpoint))
        return responseObject.get("status")
    }

    /**
     * Download a package from the userFiles/ObjectMigration directory of the Tririga server.
     */
    public File downloadPackage(String packageName, File workDir)
    {
        String endpoint = DOWNLOAD_PACKAGE_ENDPOINT + "?packageName=${encode(packageName)}"

        return restHelper.doFileRequest(endpoint, workDir, packageName + ".zip")
    }

    public void cleanUp() {
        restHelper.closeClient()
    }

    private String encode(String queryParam) {
        return URLEncoder.encode(queryParam, "UTF-8")
    }
}
