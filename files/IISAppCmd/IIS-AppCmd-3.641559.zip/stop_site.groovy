/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.CommandHelper

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def siteName = props['siteName'];
def commandPath = props['commandPath']
def argStrings = (props['argString']?props['argString'].split('\n'):null);

def ch = new CommandHelper(new File('.'));

def args = [];
args = [commandPath + 'appcmd.exe', 'stop', 'site', siteName];
argStrings.each { arg ->
     args << arg;
}
ch.runCommand(args.join(' '), args);
