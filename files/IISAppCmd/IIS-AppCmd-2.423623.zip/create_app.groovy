import com.urbancode.air.CommandHelper

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def site = props['site'];
def vpath = props['vpath'];
def commandPath = props['commandPath']
def argStrings = (props['argString']?props['argString'].split('\n'):null);

def ch = new CommandHelper(new File('.'));

def args = [];
args = [commandPath + 'appcmd.exe', 'add', 'app', '/site.name:'+site, '/path:'+vpath];
argStrings.each { arg ->
     args << arg;
}
ch.runCommand(args.join(' '), args);
