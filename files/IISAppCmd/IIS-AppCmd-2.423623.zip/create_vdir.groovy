import com.urbancode.air.CommandHelper

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def appName = props['appName'];
def commandPath = props['commandPath']
def vpath = props['vpath'];
def path = props['path'];
def argStrings = (props['argString']?props['argString'].split('\n'):null);

def ch = new CommandHelper(new File('.'));

def args = [];
args = [commandPath + 'appcmd.exe', 'add', 'vdir', '/app.name:'+appName, '/path:'+vpath];
if(path) {
	args << '/physicalPath:'+path;
}
argStrings.each { arg ->
     args << arg;
}
ch.runCommand(args.join(' '), args);
