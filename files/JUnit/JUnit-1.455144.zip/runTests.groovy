import com.urbancode.air.*


def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()
def sourceDir = props['sourceDir']
def sourceDirFile = new File(sourceDir)
def outputDir = props['outputDir']
def includes = props['includes'].split("\n")
def excludes = props['excludes']?.split("\n")
def classpathDirs = props['classDirs']?.split("\n")
def classJarDir = props['classJarDir']
def classJarDirFile = new File(classJarDir)
def includesJars = props['includesJars']?.split("\n")
def excludesJars = props['excludesJars']?.split("\n")

def ant = new AntBuilder();

ant.junit(printsummary:"on", 
          haltonfailure:"false", 
          fork:"true", 
          forkmode:"once",
          showoutput:"true",
          failureproperty:"unittests.failed",
          dir:sourceDir,
          tempdir:System.getProperty("java.io.tmpdir"),
          timeout:"20000") {
    classpath() {
        fileset(dir:classJarDirFile) {
            includesJars.each { includeJar ->
                include(name:includeJar)
            }
            excludesJars.each { excludeJar ->
                exclude(name:excludeJar)
            }
        }
        classpathDirs.each { classpathDir ->
            pathelement(path:classpathDir)
        }
    }  
    formatter(type:"brief",usefile:"false")
    formatter(type:"xml")
    batchtest(todir:outputDir) {
        fileset(dir:sourceDirFile) {
            includes.each { includeName ->
                include(name:includeName)
            }
            excludes.each { excludeName ->
                exclude(name:excludeName)
            }
        }
    }
}


if (ant.project.properties.'unittests.failed') {
    println "One or more unit tests failed. If you are getting ClassNotFound errors, check your classpath."
    System.exit(1)
}