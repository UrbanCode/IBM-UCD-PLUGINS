/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.odm.OdmHelper

// Get step properties
def apTool  = new AirPluginTool(args[0], args[1])
def inProps = apTool.getStepProperties()

String hostname = (inProps['hostname']!=null && inProps['hostname'].length()>0) ? inProps['hostname'].trim() : inProps['hostname']
String port     = inProps['port'].trim()
String username = (inProps['username']!=null && inProps['username'].length()>0) ? inProps['username'].trim() : inProps['username']
String password = inProps['password']
String resource = (inProps['resource']!=null && inProps['resource'].length()>0) ? inProps['resource'].trim() : inProps['resource']
String tokenUrl = inProps['tokenUrl']
String scope = (inProps['scope']!=null && inProps['scope'].length()>0) ? inProps['scope'].trim() : inProps['scope']
String grantType = (inProps['grantType']!=null && inProps['grantType'].length()>0) ? inProps['grantType'].trim() : inProps['grantType']
String clientID = inProps['clientID']
String clientSecret = inProps['clientSecret']
String oAuthusername = inProps['oAuthusername']
String oAuthpassword = inProps['oAuthpassword']
String proxyHost = inProps['proxyHost']
String proxyPortString = inProps['proxyPort']
String proxyUsername = inProps['proxyUsername']
String proxyPassword = inProps['proxyPassword']

final def workDir = new File('.').canonicalFile

def path = 'res/api/v1/'
String downloadName
if (resource.split('/').size() == 2) {    // XOM Resource
    path += "xoms/${resource}"
}
else {
    println ('[Error] Resource format invalid.')
    println ('[Possible Solution] Please update the step configuration with a valid resource definition supplied in the ' +
             'Resource property description.')
    System.exit(1)
}

OdmHelper oh = new OdmHelper(username, password, tokenUrl, scope, grantType, clientID, clientSecret, oAuthusername, oAuthpassword, proxyHost, proxyPortString, proxyUsername, proxyPassword )
if (!oh.setUri(hostname, port, path)) {
    println ('[Error] Could not set URI.')
    System.exit(1)
}
println ('[Action] Deleting XOM...')
def deployed = oh.deleteResource()
if (deployed) {
    println ("[Ok] ${resource} deleted.")
    System.exit(0)
}
else {
    println ('[Error] Could not delete resource.')
    System.exit(1)
}
