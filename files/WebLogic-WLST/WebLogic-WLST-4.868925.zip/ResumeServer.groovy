import com.urbancode.air.plugin.wlst.helper.WLSTCmdHelper
import com.urbancode.air.AirPluginTool

def apTool = new AirPluginTool(this.args[0], this.args[1])
def helper = new WLSTCmdHelper(apTool)
helper.runServerStateCommand('resume')