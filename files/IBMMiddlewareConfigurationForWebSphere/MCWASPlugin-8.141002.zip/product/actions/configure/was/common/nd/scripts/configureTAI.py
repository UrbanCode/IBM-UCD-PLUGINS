"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: configureTAI.py
	TODO: description
"""

import sys
from org.python.modules import re
from org.python.modules import sre
from java.util import Properties
from java.io import FileInputStream

def wsadminToList(inStr):
        outList=[]
        if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
                tmpList = inStr[1:-1].split(" ")
        else:
                tmpList = inStr.split("\n")  #splits for Windows or Linux
        for item in tmpList:
                item = item.rstrip();        #removes any Windows "\r"
                if (len(item)>0):
                        outList.append(item)
        return outList
#endDef

def configTA ( trust_assocEnabled, trust_interceptorClassName, customProps ):
        global AdminConfig

        trustAssocConfigId = AdminConfig.list("TrustAssociation" )
        trust_attrib = []
        interceptor_attrib = []
		

        if (trust_assocEnabled != []):
                if (SystemUtils.regexp(trust_assocEnabled, "y") ):
                        trust_attrib.append(["enabled", "true"])
                else:
                        trust_attrib.append(["enabled", "false"])
                #endElse 
                print "Enabling Trust Association"
                AdminConfig.modify(trustAssocConfigId, trust_attrib )
        #endIf 
        print "Removing existing interceptors"
        if (trust_interceptorClassName != []):
                listOfTAI = AdminConfig.list("TAInterceptor" )
                for tai in listOfTAI.split("\n"):
                        AdminConfig.remove(tai )
                #endFor 
        #endIf 
        print "Adding "+trust_interceptorClassName
        interceptor_attrib.append(["interceptorClassName", trust_interceptorClassName])
        AdminConfig.create("TAInterceptor", trustAssocConfigId, interceptor_attrib )
        interceptorConfigId = AdminConfig.list("TAInterceptor" )

        ## Read the file
        fid = open( customProps )
        ## Iterate over the records
        for line in fid.readlines():
                properties_attrib = []
                _J2J_bracket_ = SystemUtils.regexp("^#", line)
                if (_J2J_bracket_ == 0):
                        i = 0
                        fields = line.split( )
                        propName = ""
                        propValue = ""
                        for field in fields:
                                if (i == 0):
                                        print "Name: "+field
                                        properties_attrib.append(["name", field])
                                else:
                                        print "Value: "+field
                                        properties_attrib.append(["value", field])
                                #endElse
                                i = i+1
                        #endFor
                if (properties_attrib != []):
                        AdminConfig.modify(interceptorConfigId, [["trustProperties", [properties_attrib]]] )
                #endIf
        #endFor
        fid.close()

        print "Saving Config"
        AdminConfig.save( )
#endDef 
propFile=sys.argv[0]
nodes=sys.argv[1]
customProps=sys.argv[2]
tamProperties=Properties();

try:
    tamProperties.load(FileInputStream(propFile))
    print "Succesfully read property file "+propFile
except:
    raise "Cannot read property file "+propFile

trust_assocEnabled = str(tamProperties.getProperty("TRUST_ASSOC_ENABLED"))
trust_interceptorClassName = str(tamProperties.getProperty("TRUST_INTERCEPTOR_CLASSNAME"))

# configure TAI
configTA ( trust_assocEnabled, trust_interceptorClassName, customProps )

AdminHelper.saveAndSyncCell()

