--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to drop tablespaces for Oracle 9i and Oracle 10g
-- Start this script with SQL*Plus.
-- example: sqlplus scott/tiger@mydb @dropTablespace_Observer.sql


----------------------
-- Drop tablespaces --
----------------------

DROP TABLESPACE OBSVRTS INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE OBSVRLOB INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE OBSVRIDX INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

--
--
--
QUIT
