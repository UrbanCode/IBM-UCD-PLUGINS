--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
--
-- Scriptfile to create tablespaces for Oracle 9i and Oracle 10g
-- Start this script with SQL*Plus and pass the container location as a parameter
-- example: sqlplus scott/tiger@mydb @createTablespace_Observer.sql d:\mydb\ts
-- Or, replace parameters '&1' with the desired location and run the script
-- without any parameter
--

------------------------
-- Create tablespaces --
------------------------


CREATE TABLESPACE OBSVRTS
  DATAFILE '&1/OBSVRTS.dbf' SIZE 100M AUTOEXTEND ON NEXT 20M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE OBSVRLOB
  DATAFILE '&1/OBSVRLOB.dbf' SIZE 200M AUTOEXTEND ON NEXT 40M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE OBSVRIDX
  DATAFILE '&1/OBSVRIDX.dbf' SIZE 250M AUTOEXTEND ON NEXT 50M MAXSIZE UNLIMITED LOGGING;
--
--
--
QUIT
