#!/bin/sh
#
# BEGIN COPYRIGHT
# *************************************************************************
# Licensed Materials - Property of IBM 
# 5724-L01, 5655-N53, 5724-I82, 5655-R15
# (C) Copyright IBM Corporation 2006. All rights reserved. 
# US Government Users Restricted Rights - Use, duplication, or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# *************************************************************************
# END COPYRIGHT
# Usage: 
#      db2cmd createDBTables.sh  <db_user>  <dbName> [createDB]
# Example:
#      db2cmd createDBTables.sh db2admin WPRCSDB createDB     --create a new db
#      db2cmd createDBTables.sh db2admin WPRCSDB              --use an existing db
#------------------------------------------------------------------------------
# expect inputs as DB_USER:DB_PASSWORD

DB_USERID=$1
DB_NAME=$2
DB_CREATE=$3

CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi


if [ "$DB_CREATE" = "createDB" ] ; then 
	createDB=true
else
    createDB=false	
fi

if [ "$createDB" = "true" ]; then
	echo "db2 create database $DB_NAME automatic storage yes using codeset UTF-8 territory US"
    db2 create database $DB_NAME using codeset UTF-8 territory US 
fi

#Connect to the database specifying the id and the password
rc=0
db2 connect to $DB_NAME user $DB_USERID 
rc=$?

if [ $rc -eq 0 ] ; then
	db2 set current schema=$DB_USERID
	
	for i  in `ls | egrep "[create][insert]Table"`
	do
		db2 -s -t -f $i
	done
else 
    echo 
    echo "username/password/dbname is wrong. Please re-enter correct username/password/dbName"
	echo
fi

exit $?


