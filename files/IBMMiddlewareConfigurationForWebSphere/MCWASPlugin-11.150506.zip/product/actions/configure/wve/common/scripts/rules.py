"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: rules.py
"""

import sys
import string

lineSeparator = java.lang.System.getProperty('line.separator')

nodes = AdminConfig.list('Node').split(lineSeparator)

def configRoutingRules(expression, cluster, priority):
	for node in nodes:
		nodeName = AdminConfig.showAttribute(node, "name" )
		serverEntries = AdminConfig.list( "ServerEntry" , node).split(lineSeparator)    
		for serverEntry in serverEntries:
			serverName = AdminConfig.showAttribute(serverEntry, "serverName" )
			if serverName != 'dmgr' and serverName != 'nodeagent':
				attrs = "-odrname " + serverName + " -nodename " + nodeName + " -protocol HTTP -priority " + priority + " -expression " + '\'' + expression + '\'' + " -actionType permit -routingLocations cluster=" + cluster + " -multiclusterAction Failover"
				print "attrs",attrs
				AdminTask.addRoutingRule(attrs)

optDict, args = SystemUtils.getopt( sys.argv, 'scope:;hostname:;properties:;nodename:;scopename:;mode:;cellProperties:;command:;celltype:;cellname:;rule:')

rule = optDict['rule']
rule = rule.split('#')

exprs = rule[0] + "," + rule[1]
target = rule[2]
prio = rule[3]

expr='uri LIKEIN "' + exprs + '"'

print expr

# apply
configRoutingRules(expr, target, prio)
AdminConfig.save()

#ROUTING_RULE=/cisco/psn/web%#/cisco/pub/web%#intwp1/portal#0