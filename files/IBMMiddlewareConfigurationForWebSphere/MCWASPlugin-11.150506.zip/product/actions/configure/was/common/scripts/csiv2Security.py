"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: csiv2Security.py
	
	This script configures CSIV 2 security configuration
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
	sys.modules['AdminControl'] = AdminControl
except:
	pass
import AdminConfig
import AdminTask
import AdminControl
import java

from AdminHelper import AdminHelper
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigReaderException import ConfigReaderException
from ConfigFileWriter import GenericConfigFileWriter

LOGGER = _Logger("Security", MessageManager.RB_WEBSPHERE_WAS)


def importSecurity(scopeId, scopeType, typeNames, excludedTypes, marker, xmlFile):
	
	myConfigReader = ConfigReader()
	data = []
	
	for typeName in typeNames:
		#print "Gathering data for: " + typeName
		LOGGER.log("CRWWA1011I",[typeName])
		data.extend(myConfigReader.readConfigDataUsingParentId(scopeId, scopeType, typeName, excludedTypes))
	# write XML file
	GenericConfigFileWriter.processBasicFile(xmlFile, data, marker)
#endDef

##------------------------------------------------------------------------------
##	 scope								   = /Cell:cell/
##	 scopeType							   = cell
##	 AdminConfig.getid(scope + "Security:/") = (cells/cell|security.xml#Security_1)
##	 scopeId = AdminConfig.getid(scope)	  = cell(cells/cell|cell.xml#Cell_1)
##------------------------------------------------------------------------------
def compareSecurity(scope, scopeType, configTypes, xmlFile, marker):
	myConfigReader = ConfigReader()
	# get wasConfig
	wasConfig = []
	for configType in configTypes:
		#print "Gathering data for: " + configType
		LOGGER.log("CRWWA1011I",[configType])
		wasConfig.extend(myConfigReader.readConfigDataUsingParentId(scopeId, scopeType, configType, excludedTypes))
	#endfor
	
	# get rafwConfig
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	
	xmlConfigReader = XMLConfigReader()
	rafwConfig = []
	for configType in configTypes:
		filteredNodes = xmlProp.getFilteredNodeArray(configType)
		rafwConfig.extend(xmlConfigReader.readXmlConfig(filteredNodes))
		
	ConfigComparor.compare(configType, wasConfig, rafwConfig)
	#endfor
#endDef

def executeSecurity(scopeType, xmlFile, typeNames, scopeId, marker, excludedTypes, save="1"):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	
	myConfigWriter = ConfigWriter()

	for typeName in typeNames:
		LOGGER.info("Processing config type: " + typeName)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
		for xmlNode in nodeArray:
			myConfigWriter.createWASObject(xmlNode, scopeId)
		#endFor
	#endFor
	if (save is not None):
		AdminHelper.saveAndSyncCell( )
	#endIf
#endDef

def augmentSecurity(scopeType, xmlFile, typeNames, scopeId, marker, excludedTypes):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	
	myConfigWriter = ConfigWriter()

	for typeName in typeNames:
		LOGGER.info("Processing config type: " + typeName)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		typeScopeId = AdminConfig.list(typeName, scopeId).split(newline)[0]
		for xmlNode in nodeArray:
			myConfigWriter.modify(typeScopeId, xmlNode, [])
		#endFor
	#endFor
	AdminHelper.saveAndSyncCell( )
#endDef

def getIdForDirection(direction, scope):
	securityScopeId = AdminConfig.getid(scope + "Security:/")
	csiIds = AdminHelper.extractWASIdsFromList(AdminConfig.showAttribute(securityScopeId, "CSI"))
	LOGGER.debug("Found CSI attribute under security with value:" + str(csiIds))
	if (len(csiIds) == 1):
		# config data is valid in WAS, continue with the script
		csiId = csiIds[0]
		if (direction == "inbound"):
			csiAttr = "claims"
			marker="inboundCSIV2"
		else:
			## direction is outbound
			csiAttr = "performs"
			marker="outboundCSIV2"
		#endIf
		scopeIds = AdminHelper.extractWASIdsFromList(AdminConfig.showAttribute(csiId, csiAttr))
		LOGGER.debug("Found " + csiAttr + " attribute under CSI with value:" + str(scopeIds))
		if (len(scopeIds) == 1):
			# ok
			return (scopeIds[0], marker)
		else:
			## fail no claims or performs configured
			msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0182E", [csiIds, scopeIds])
			raise ConfigReaderException(msg)
		#endIf
	else:
		#fail, no CSI configured
		msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0182E", [csiIds])
		raise ConfigReaderException(msg)
	#endIf
#endIf

def export(optDict=None):
	version = optDict['version']
	
	# Used for ALL config type
	configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg']
	
	# scopeName = optDict['scopename']
	## since scope for this action is always necessarily cell, and the cell name may differ
	## between RAFW and the actual profile for standalone scenarios.
	## read the cell name from the profile
	scopeName = AdminControl.getCell()
	
	scopeType = optDict['scope']
	direction = 'inbound'
	if optDict['marker'].find('inbound') == -1:
		direction = 'outbound'
	scope = optDict['wasscopetype']
	(scopeId, marker) = getIdForDirection(direction, scope)
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	typeNames = [optDict['type']]
	excludedTypes=optDict['excludedtypes']
	
	executeSecurity(scopeType, xmlFile, typeNames, scopeId, marker, excludedTypes, None)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	##################################################################################
	##
	## Main
	##
	##################################################################################
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;direction:;scopename:;properties:;mode:;config_type:' )
	
	
	version = optDict['version']
	
	# Used for ALL config type
	configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg']
	
	# scopeName = optDict['scopename']
	## since scope for this action is always necessarily cell, and the cell name may differ
	## between RAFW and the actual profile for standalone scenarios.
	## read the cell name from the profile
	scopeName = AdminControl.getCell()
	
	scopeType = optDict['scope']
	direction = optDict['direction']
	scope = AdminHelper.buildScope( optDict )
	(scopeId, marker) = getIdForDirection(direction, scope)
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	typeNames = ["IdentityAssertionLayer", "MessageLayer", "TransportLayer"]
	excludedTypes=[]
	
	if (mode == MODE_EXECUTE):
		LOGGER.info("Configuring "+direction+" CSIV2 security in scope: " + scope)
		executeSecurity(scopeType, xmlFile, typeNames, scopeId, marker, excludedTypes)
	
	elif (mode == MODE_IMPORT):
		LOGGER.info("Importing "+direction+" CSIV2 security in scope: " + scope)
		importSecurity(scopeId, scopeType, typeNames, excludedTypes, marker, xmlFile)
		
	elif (mode == MODE_COMPARE):
		LOGGER.info("Comparing "+direction+" CSIV2 security in scope: " + scope)
		compareSecurity(scope, scopeType, typeNames, xmlFile, marker)
	
	elif (mode == MODE_AUGMENT):
		#print "Augmenting "+ direction + "CSIV2 security in scope: " + scope
		LOGGER.info("CRWWA1012I",[direction,scope])
		augmentSecurity(scopeType, xmlFile, typeNames, scopeId, marker, excludedTypes)
	
	else:
		#print "Unsupported MODE supplied: " + mode
		LOGGER.log("CRWWA0008W",[mode])
	#endIf
#endIf