"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: personalCertificates.py
"""

import java.util as util
import java.io as javaio


class personalCertificates:
    
    """ creates a self-signed certificate in the specified key store """
    def createSelfSignedCertificate(self, keyStoreName, certificateAlias, certificateSize, certificateCommonName, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        #commandOptions = self.appendCommandOptions(commandOptions, '-certificateVersion')
        #certificateSize
        commandOptions.append('-certificateSize')
        commandOptions.append(certificateSize)
        #certificateCommonName
        commandOptions.append('-certificateCommonName')
        commandOptions.append(certificateCommonName)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        if(self.getProperty('Security.Cert.CertificateOrganization') != None):
            commandOptions.append('-certificateOrganization')
            commandOptions.append(self.getProperty('Security.Cert.CertificateOrganization'))
        if(self.getProperty('Security.Cert.CertificateOrganizationalUnit') != None):
            commandOptions.append('-certificateOrganizationalUnit')
            commandOptions.append(self.getProperty('Security.Cert.CertificateOrganizationalUnit'))
        if(self.getProperty('Security.Cert.CertificateLocality') != None):
            commandOptions.append('-certificateLocality')
            commandOptions.append(self.getProperty('Security.Cert.CertificateLocality'))
        if(self.getProperty('Security.Cert.CertificateState') != None):
            commandOptions.append('-certificateState')
            commandOptions.append(self.getProperty('Security.Cert.CertificateState'))
        if(self.getProperty('Security.Cert.CertificateZip') != None):
            commandOptions.append('-certificateZip')
            commandOptions.append(self.getProperty('Security.Cert.CertificateZip'))
        if(self.getProperty('Security.Cert.CertificateCountry') != None):
            commandOptions.append('-certificateCountry')
            commandOptions.append(self.getProperty('Security.Cert.CertificateCountry'))
        if(self.getProperty('Security.Cert.CertificateValidDays') != None):
            commandOptions.append('-certificateValidDays')
            commandOptions.append(self.getProperty('Security.Cert.CertificateValidDays'))
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)

        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate == None):
            AdminTask.createSelfSignedCertificate(commandOptions)
        else:
            personalCertificateLogger.error("Certificate alias: " + certificateAlias + " already exists in keyStore.")
    
    """ deletes a certificate from the specified key store"""
    def deleteCertificate(self, keyStoreName, certificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
            
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        # Delete certificate if it exists
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate != None):
            AdminTask.deleteCertificate(commandOptions)
        else:
            personalCertificateLogger.log('Certificate not in keystore.')
            
    """ Exports a certificate from one keyStore to another """
    def exportCertificate(self, keyStoreName, certificateAlias, keyStorePassword, keyFilePath, keyFilePassword, keyFileType, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        commandOptions.append('-keyStorePassword')
        commandOptions.append(keyStorePassword)
        commandOptions.append('-keyFilePath')
        commandOptions.append(keyFilePath)
        commandOptions.append('-keyFilePassword')
        commandOptions.append(keyFilePassword)
        commandOptions.append('-keyFileType')
        commandOptions.append(keyFileType)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        if(self.getProperty('Security.Cert.AliasInKeyStore') != None):
            commandOptions.append('-aliasInKeyStore')
            commandOptions.append(self.getProperty('Security.Cert.AliasInKeyStore'))
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        # Export certificate if it exists
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate != None):
            AdminTask.exportCertificate(commandOptions)
        else:
            personalCertificateLogger.info('Certificate not in keystore.')
        
    """ Extracts the signer portion of a personal certificate to a file """
    def extractCertificate(self, keyStoreName, certificateAlias, certificateFilePath, base64Encoded, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        commandOptions.append('-certificateFilePath')
        commandOptions.append(certificateFilePath)
        commandOptions.append('-base64Encoded')
        commandOptions.append(base64Encoded)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        # Extract certificate if it exists
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate != None):
            AdminTask.extractCertificate(commandOptions)
        else:
            personalCertificateLogger.info('Certificate not in keystore.')
        
    """ Get information about a certificate from the keyStore """
    def getCertificate(self, keyStoreName, certificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        certificate = None
        try:
            certificate = AdminTask.getCertificate(commandOptions)
        except:
            personalCertificateLogger.log("CRWWA2016I",[certificateAlias,keyStoreName])
        return certificate
        
    """ Imports a certificate from a keyStore file. """
    def importCertificate(self, keyStoreName, certificateAlias, keyStorePassword, keyFilePath, keyFilePassword, keyFileType, certificateAliasFromKeyFile, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        commandOptions.append('-keyStorePassword')
        commandOptions.append(keyStorePassword)
        commandOptions.append('-keyFilePath')
        commandOptions.append(keyFilePath)
        commandOptions.append('-keyFilePassword')
        commandOptions.append(keyFilePassword)
        commandOptions.append('-keyFileType')
        commandOptions.append(keyFileType)
        commandOptions.append('-certificateAliasFromKeyFile')
        commandOptiosn.append(certificateAliasFromKeyFile)

        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)

        #need to check to see if certificate request is in keyStore first
        #then check for certificate
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate == None):
            AdminTask.importCertificate(commandOptions)
        else:
            personalCertificateLogger.error("CRWWA2017I" ,[certificateAlias])
    
    """ list certificates in the specified key store """
    def listPersonalCertificates(self, keyStoreName, keyStoreScope):
        # required parameters
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        return AdminTask.listPersonalCertificates(commandOptions)
    
    """ Receives a signer certificate from a file to a personal certificate """
    def receiveCertificate(self, keyStoreName, certificateAlias, certificateFilePath, base64Encoded, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        commandOptions.append('-certificateFilePath')
        commandOptions.append(certificateFilePath)
        commandOptions.append('-base64Encoded')
        commandOptions.append(base64Encoded)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        certificate = None
        
        try:
            certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        except:
            personalCertificateLogger.error('Bob')
            
        if(certificate == None):
            AdminTask.receiveCertificate(commandOptions)
        else:
            personalCertificateLogger.error("CRWWA2017I" ,[certificateAlias])

        #AdminTask.receiveCertificate(commandOptions)

    """ Replaces a personal certificate with a new one.  Replaces all signer certificates from the personal certificate. """
    def replaceCertificate(self, keyStoreName, certificateAlias, replacementCertificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        #replacementCertificateAlias
        commandOptions.append('-replacementCertificateAlias')
        commandOptions.append(replacementCertificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        if(self.getProperty('Security.Cert.DeleteOldCert') != None):
            commandOptions.append('-deleteOldCert')
            commandOptions.append(self.getProperty('Security.Cert.DeleteOldCert'))
        if(self.getProperty('Security.Cert.DeleteOldSigners') != None):
            commandOptions.append('-deleteOldSigners')
            commandOptions.append(self.getProperty('Security.Cert.DeleteOldSigners'))
        
        for option in commandOptions:
            personalCertificateLogger.debug(option)
            
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate != None):
            AdminTask.replaceCertificate(commandOptions)
        else:
            personalCertificateLogger.log('CRWWA2018I')
        
        
    def appendCommandOptions(self, commandString, command, key):
        certificateRequestLogger.debug("commandString: " + commandString + " command: " + command + " key: " + key)
        value = self.getProperty(key)
        
        if(value == None):
            return commandString          
        else:
            commandString = commandString + ' ' + command + ' ' + thisCertificateRequest.getProperty(key)
            return commandString
    
    def getProperty(self, key):
        value = properties.get(key)
        if(value == None):
            return
        else:
            return value
        
    def readProperties(self, aFile):
        personalCertificateLogger.debug("Reading certificate properties file.")
        properties = util.Properties()
        propertiesFileInputStream =javaio.FileInputStream(aFile)
        properties.load(propertiesFileInputStream)
        return properties
        
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;cellName:;nodeName:;certificateAlias:' )

# get scope
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties'] 
scopeType = optDict['scope']
action = optDict['action']
mode = optDict['mode']
cellName = optDict['cellName']
nodeName = optDict['nodeName']

personalCertificateLogger = _Logger("personalCertificates", MessageManager.RB_WEBSPHERE_WAS)
thisPersonalCertificates = personalCertificates()

properties = thisPersonalCertificates.readProperties(xmlFile)
 
certificateAlias = properties.get('Security.Cert.CertificateAlias')
keyStoreName = properties.get('Security.Cert.KeyStoreName')
keyStoreScope = properties.get('Security.Cert.KeyStoreScope')

if(mode == MODE_EXECUTE):
    if(action == "CREATE_SELF_SIGNED_CERTIFICATE"):
        certificateCommonName = properties.get('Security.Cert.CertificateCommonName')
        certificateSize = properties.get('Security.Cert.CertificateSize')
        thisPersonalCertificates.createSelfSignedCertificate(keyStoreName, certificateAlias, certificateSize, certificateCommonName, keyStoreScope)
        
    elif(action == "DELETE_CERTIFICATE"):
        thisPersonalCertificates.deleteCertificate(keyStoreName, certificateAlias, keyStoreScope)
        
    elif(action == "EXPORT_CERTIFICATE"):
        keyStorePassword = properties.get('Security.Cert.KeyStorePassword')
        keyFilePath = properties.get('Security.Cert.KeyFilePath')
        keyFilePassword = properties.get('Security.Cert.KeyFilePassword')
        keyFileType = properties.get('Security.Cert.KeyFileType')
        thisPersonalCertificates.exportCertificate(keyStoreName, certificateAlias, keyStorePassword, keyFilePath, keyFilePassword, keyFileType, keyStoreScope)
        
    elif(action == "EXTRACT_CERTIFICATE"):
        certificateFilePath = properties.get('Security.Cert.CertificateFilePath')
        base64Encoded = properties.get('Security.Cert.Base64Encoded')
        thisPersonalCertificates.extractCertificate(keyStoreName, certificateAlias, certificateFilePath, base64Encoded, keyStoreScope)
        
    elif(action == "IMPORT_CERTIFICATE"):
        keyStorePassword = properties.get('Security.Cert.KeyStorePassword')
        keyFilePath = properties.get('Security.Cert.KeyFilePath')
        keyFilePassword = properties.get('Security.Cert.KeyFilePassword')
        keyFileType = properties.get('Security.Cert.KeyFileType')
        certificateAliasFromKeyFile = properties('Security.Cert.CertificateAliasFromKeyFile')
        thisPersonalCertificates.importCertificate(keyStoreName, certificateAlias, keyStorePassword, keyFilePath, keyFilePassword, keyFileType, certificateAliasFromKeyFile, keyStoreScope)
        
    elif(action == "RECEIVE_CERTIFICATE"):
        base64Encoded = properties.get('Security.Cert.Base64Encoded')
        certificateFilePath = properties.get('Security.Cert.CertificateFilePath')
        thisPersonalCertificates.receiveCertificate(keyStoreName, certificateAlias, certificateFilePath, base64Encoded, keyStoreScope)
        
    elif(action == "REPLACE_CERTIFICATE"):
        replacementCertificateAlias = properties.get('Security.Cert.ReplacementCertificateAlias')
        thisPersonalCertificates.replaceCertificate(keyStoreName, certificateAlias, replacementCertificateAlias, keyStoreScope)
        
    else:
        #print "Unsupported ACTION supplied: %s " % optDict['action']
        personalCertificatesLogger.log("CRWWA5000I",[optDict['action']])
        personalCertificatesLogger
    AdminHelper.saveAndSyncCell()
else:
    #print "Unsupported MODE supplied: %s " % optDict['mode']
    personalCertificatesLogger.log("CRWWA5001I",[optDict['mode']])