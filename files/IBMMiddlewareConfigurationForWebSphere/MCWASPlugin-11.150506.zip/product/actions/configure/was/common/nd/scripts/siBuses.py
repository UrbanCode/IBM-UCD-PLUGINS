"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: siBuses.py
	
	Script to manage SIBuses, SIBBootstrapMembers, SIBusMembers, SIBMessagingEngines,  
	SIBForeignBuses, SIBMediations and SIBDestinations.
"""
from XmlProperty import SkipNamedAttribute
import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
	sys.modules['AdminControl'] = AdminControl
except:
	pass
import AdminConfig
import AdminControl
import AdminTask
import java
import Globals

from com.ibm.rational.rafw.wsadmin.websphere.config import WsadminConfig
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import XmlConfigFileWriter

from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigValidator import ConfigValidator
from java.util import ArrayList
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigFileWriter import GenericConfigFileWriter

newline = java.lang.System.getProperty("line.separator")
ATTRS = 'attrs'
ID = 'id'
CHILDREN = 'children'

class SIBMediator:
	
	def printMessage(self, type, attrName, attrValue):
		print "Warning: An object of type " + type + " with " + attrName
		print "         '" + attrValue + "' already exists."
		print "         You must use a unique value for " + attrName
		print "         when creating objects of type " + type;
	#endDef
	
	#######################################################################
	## Coverts the value to empty string it its None or 'null' as returned
	## by WIM AdminTask command, so that whle writing data to RAFW config
	## it will be a blank string "" instead of 'null'
	#######################################################################
	
	def evaluateNullVal(self, val):
		if (val is not None):
			val = val.strip()
		#endIf
		if (val == 'null'):
			val = ''
		#endIf
		if (val is None):
			val = ''
		#endIf
		
		return val
	#endDef
		
	########################################################################
	## This method convers the value of an attribute in the form a = { ...}
	## /a = [..] to a hash map or to a list based on specific value
	########################################################################
	
	def evaluateAttributeValues(self, values, fieldsToIgnore=[]):
		SCRIPT_LOGGER.traceEnter([str(values)])
		values = values.strip()
		data = values
		if (values.startswith('[') and values.endswith(']')):
			data = self.convertToList(values, fieldsToIgnore)
		elif (values.startswith('{') and values.endswith('}')):
			data = self.convertToDict(values, fieldsToIgnore)
		#endIf
		
		SCRIPT_LOGGER.traceExit([str(data)])
		return data
	#endDef
	
	## This method converts all attributes read from the RAF xml file
	## into format that could be passed to AdminTask command
	## Certain attributes would have different names when listed
	## and to be used when creating configuration
	## Eg: When listed attribute for bus name is '-busName', however
	## while creating using AdminTask we need to use '-bus'
	def modifyAttrNamesForSIB(self, attrList):
		for index in range(0, len(attrList)):
			if (attrList[index] == "-busName"):
				attrList[index] = "-bus"
			#endIf
			if (attrList[index] == "-secure"):
				attrList[index] = "-busSecurity"
			#endIf
		#endFor
		
		return attrList
	#endDef
	
	
	## Creates a jython list that can be used with AdminTask
	## Wraps attribute values that contain white spaces, with quotes
	## Eg: '-busName My Bus' => '-busName "My Bus"' 
	def processAdminTaskArgs(self, cmdString):
		
		cmdArgs = []
		# cmdString is a string, parse for keys and values
		attrList = cmdString.split(' -')
		for attr in attrList:
			attr = attr.strip()
			index = attr.find(' ')
			if (index != -1):
				attrName = attr[0:index]
				if (not attr.startswith('-')):
					attrName = '-' + attrName
				#endIf
				attrValue = attr[index+1:len(attr)]
				cmdArgs.append(attrName)
				cmdArgs.append(attrValue)
			#endIf
		#endFor
		
		return cmdArgs
	#endDef
	
	#############################################################
	## Converts a string in the form [[a b][c d] [e]] into a dict
	#############################################################
	def convertToList(self, values, fieldsToIgnore=[]):
		SCRIPT_LOGGER.traceEnter([str(values)])
		data = {}
		values = values.strip()
		#listAttrPattern = java.util.regex.Pattern.compile('(\\[\\s*(\\w+)\\s+"?\\s*([\\w\\s\\/\\,\\.\\-\\$]*)"?\\s*\\])+')
		listAttrPattern = java.util.regex.Pattern.compile('(\\[\\s*(\\w+)\\s+\"?\\s*\\[*\\s*(.*?)\\s*\"?\\s*\\])+')
		listAttrMatcher = listAttrPattern.matcher(java.lang.String(values))
		while (listAttrMatcher.find() > 0):
			key = self.evaluateNullVal(listAttrMatcher.group(2))
			val = self.evaluateNullVal(listAttrMatcher.group(3))
			if (key not in fieldsToIgnore):
				data[key] = val
		#endWhile
		
		SCRIPT_LOGGER.traceExit([str(data)])
		
		return data
	#endDef
		
	##########################################################
	## Converts a string in the form {a=1, b=2} into a Dict
	##########################################################
	def convertToDict(self, values, fieldsToIgnore=[]):
		
		data = {}
		values = values.strip()
		dictAttrPattern = java.util.regex.Pattern.compile('(\\w+)\\s*=\\s*\\[*([\\w\\s\\/\\,\\.\\-\\$]*)\\]*\\s*[,\\}]')
		dictAttrMatcher = dictAttrPattern.matcher(java.lang.String(values))
		while (dictAttrMatcher.find() > 0):
			key = self.evaluateNullVal(dictAttrMatcher.group(1))
			val = self.evaluateNullVal(dictAttrMatcher.group(2))
			if (val.find(',') > -1):
				newVal = ''
				for aVal in val.split(','):
					if (newVal == ''):
						newVal = newVal + aVal.strip()
					else:
						newVal = newVal + ":" + aVal.strip()
				#endFor
				val = self.evaluateNullVal(newVal)
			#endIf
			if (key not in fieldsToIgnore):
				data[key] = val

		SCRIPT_LOGGER.traceExit([str(data)])        
		return data
	#endDef
	
	##########################################################
	## Reads config IDs of custom properties from a string of the form 
	## [CustProp1(/nodes/node|sibus.xml) "CustProp1 with space(/nodes/node|sibus.xml)"]
	##########################################################
	def readPropConfigId(self, propStr):
		props = []
		propIdPattern = java.util.regex.Pattern.compile('[\\[?\\s*](.+?\\(.+?\\)\"?)')
		propIdMatcher = propIdPattern.matcher(java.lang.String(propStr))
		while (propIdMatcher.find() > 0):
			props.append(propIdMatcher.group(1))
		#endWhile
		
		return props
	#endDef
	
	"""
		Finds object ids which are of the same type as the supplied xmlNode
		and contains same value for the 'name' (or equivalent) attribute in 
		the xmlNode.
		
		The WAS objectId is returned if found, else None
	"""
	
	def _findObjectId(self, xmlNode, parentConfigId=None):
		SCRIPT_LOGGER.traceEnter([xmlNode, parentConfigId])
		
		configType = xmlNode.getNodeNameFixed()
		if (configType == "SIBus"):
			adminTaskAttrName = "busName"
			adminConfigAttrName = "name"
		else:
			adminTaskAttrName = "name"
			adminConfigAttrName = "name"
		#endIf
		
		SCRIPT_LOGGER.debug("Looking up for the configType = " + str(configType))
		if (parentConfigId is None):
			typeList = AdminConfig.list(configType).split(newline)
		else:
			typeList = AdminConfig.list(configType, parentConfigId).split(newline)
		for objId in typeList:
			if (len(objId) > 0):
				wasAttrValue = AdminConfig.showAttribute(objId, adminConfigAttrName)
				if (xmlNode.hasAttr(adminTaskAttrName)):
					if (xmlNode.getAttrValue(adminTaskAttrName) == wasAttrValue):
						SCRIPT_LOGGER.traceExit(objId)
						return objId
					#endIf
				#endIf
			#endIf
		#endFor
				
		SCRIPT_LOGGER.traceExit(None)
		return None
	#endDef
	
	def removeChildren(self, objType, parentId):
		SCRIPT_LOGGER.traceEnter([objType, parentId])
		
		## Find and remove all objects of type 'objType' under the given 'parentId'
		if (parentId is not None):
			objIds = AdminConfig.list(objType, parentId).split(newline)
			for obj in objIds:
				if (len(obj) > 0):
					SCRIPT_LOGGER.debug("Removing object: " + obj)
					AdminConfig.remove(obj)
				#endIf
			#endFor
		else:
			SCRIPT_LOGGER.debug("Invalid parent configId '" + parentId + "' supplied")
		#endIf
		
		SCRIPT_LOGGER.traceEnter(None)
	#endDef
	
	## Finds the name of the configuration object using the configId 
	def getName(self, configId):
		name = None
		if (configId.find('"') >=0):
			# Eg: '"My Bus(cells/cell/buses/My Bus|sib-bus.xml)"'
			name = configId.split('"')[1].split('(')[0]
		else:
			# Eg: 'Bus1(cells/cell/buses/Bus1|sib-bus.xml)'
			name = configId.split('(')[0]
		#endIf
		
		return name
	#endDef
	
	def createConfigData(self, attrList, typeName, fieldsToIgnore=[], childList=None):
		SCRIPT_LOGGER.traceExit(str([attrList, typeName, childList]))
		data = []
		for attr in attrList:
			parent = {}
			parent[ID] = typeName
			parent[ATTRS] = {}
			parent[CHILDREN] = []
			
			parentAttr = self.evaluateAttributeValues(attr, fieldsToIgnore)
			for key in parentAttr.keys():
				parent[ATTRS][key] = self.evaluateNullVal(parentAttr[key])
			#endFor
			if (childList is not None):
				for child in childList:
					parent[CHILDREN].append(child)
				#endFor
			#endIf
			data.append(parent)
		#endFor
		SCRIPT_LOGGER.traceExit(str(data))
		return data
	#endDef
	
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter([typeName])
		SCRIPT_LOGGER.traceExit([typeName])
	#endDef
	
	## Imports SIBus configuration from WebSphere
	def importConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		data = self.readConfig(typeName)
		GenericConfigFileWriter.processBasicFile(xmlFile, data, marker)
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def executeConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def augmentConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def compareConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		xmlConfigReader = XMLConfigReader()
		rafwConfig = xmlConfigReader.readXmlConfig(nodeArray)
		wasConfig = self.readConfig(typeName)
		
		## Compare WebSphere and RAF configuration
		SCRIPT_LOGGER.debug("WebSphere config: " + str(wasConfig) + ", RAF config: " + str(rafwConfig)) 
		ConfigComparor.compare(typeName, wasConfig, rafwConfig)
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
#endClass

class Bus(SIBMediator):
	
	# Custom property config type name
	propertyType = 'Property'
	
	## Reads SIBus configuration from WebSphere
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		
		siBuses = AdminTask.listSIBuses().split(newline)
		data = []
		for bus in siBuses:
			if ((bus is None) or (bus == '')):
				continue
			#endIf
			parent = {}
			parent[ID] = typeName
			parent[ATTRS] = {}
			parent[CHILDREN] = []
			
			busName = self.getName(bus)
			busAttrs = AdminTask.showSIBus(self.processAdminTaskArgs('-bus ' + busName))
			
			parentAttrList = self.evaluateAttributeValues(busAttrs)
			for keyName in parentAttrList.keys():
				parent[ATTRS][keyName] = self.evaluateNullVal(parentAttrList[keyName])
			#endFor
		
			propStr = AdminConfig.showAttribute(bus, "properties")
			if(propStr == "[]"):
				propList = []
			else:
				propList = self.readPropConfigId(propStr)
			#endIf
			
			for prop in propList:
				child = {}
				child[ID] = self.propertyType
				child[ATTRS] = {}
				child[CHILDREN] = []
				propKeyValList = AdminConfig.showall(prop).split(newline)
				childAttrDict = self.convertToList(str(propKeyValList))
				for key in childAttrDict.keys():
					child[ATTRS][key] = self.evaluateNullVal(childAttrDict[key])
				#endFor
				parent[CHILDREN].append(child)
			#endFor
			
			data.append(parent)
		#endFor
		
		SCRIPT_LOGGER.debug("Bus config data: " + str(data))
		SCRIPT_LOGGER.traceExit(typeName)
		return data
	#endDef
	
	def executeConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, typeName])
				
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		buses = AdminTask.listSIBuses().split(newline)
		busNames = []        
		for bus in buses:
			if (bus == ''):
				continue
			#endIf
			busNames.append(self.getName(bus))
		#endFor
		
		siBusesToRemove = []
		for bName in busNames:
			bNamesInXml = ""
			for xmlNode in nodeArray:
				if(xmlNode.hasAttr("busName")):
					bNamesInXml =  bNamesInXml + xmlNode.getAttrValue("busName") + " "
				#endIf
			#endFor
			if ( bNamesInXml.find(bName) == -1 ):
				siBusesToRemove.append(bName)
			#endIf
		#endFor
		
		## Remove buses available in WebSphere, but not in RAF data file
		for rBus in siBusesToRemove:
			print "Removing bus: " + rBus
			AdminTask.deleteSIBus(self.processAdminTaskArgs('-bus ' + rBus))
		#endFor
		
		for xmlNode in nodeArray:
			if(xmlNode.hasAttr("busName")):
				siBusName = xmlNode.getAttrValue("busName")
				attrs = self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList())
				if (siBusName not in busNames):
					## Create new SIBuses as defined in the data file
					print "Creating bus: " + siBusName
					busId = AdminTask.createSIBus(self.processAdminTaskArgs('-bus ' + siBusName))
					AdminTask.modifySIBus(attrs)
					for child in xmlNode.getChildrenArray():
						if ( (not child.hasAttr("name")) or (not child.hasAttr("value")) ):
							raise "Attributes 'name' and/or 'value' missing in 'Property' child element for bus " + siBusName
						else:
							propAttrs = child.buildNodeAttrsAsJyString()
							print "Creating Custom property '" + child.getAttrValue("name") + "' in bus '" + siBusName + "'"
							SCRIPT_LOGGER.debug("AdminConfig.create(" + self.propertyType + ", " + busId + ", " + str(propAttrs) + ")")
							AdminConfig.create(self.propertyType, busId, propAttrs)
						#endIf
					#endFor
				else:
					## Modify the bus attributes for existing SIBuses
					print "Modifying configuration for bus: " + siBusName
					SCRIPT_LOGGER.debug("AdminTask.modifySIBus(" + str(attrs) + ")")
					AdminTask.modifySIBus(attrs)					
					
					## Remove all existing Property child nodes and re-create
					busId = self._findObjectId(xmlNode)
					SCRIPT_LOGGER.debug("Bus config id: " + str(busId))
					self.removeChildren(self.propertyType, busId)
					if (busId is not None):
						for child in xmlNode.getChildrenArray():
							if ( (not child.hasAttr("name")) or (not child.hasAttr("value")) ):
								raise "Attributes 'name' and/or 'value' missing in 'Property' child element for bus " + siBusName
							else:
								propAttrs = child.buildNodeAttrsAsJyString()
								print "Creating Custom property '" + child.getAttrValue("name") + "' in bus '" + siBusName + "'"
								SCRIPT_LOGGER.debug("AdminConfig.create(" + self.propertyType + ", " + busId + ", " + str(propAttrs) + ")")
								AdminConfig.create(self.propertyType, busId, propAttrs)
							#endIf
						#endFor
					else:
						raise ("Unable to find config id for bus: " + siBusName)
					#endIf
				#endIf
			else:
				raise ("Error: XML node for SIBus doesn't contain the required attribute 'busName'")
			#endIf
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, typeName])
	#endDef
	
	def augmentConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		buses = AdminTask.listSIBuses().split(newline)
		busNames = []
		for bus in buses:
			if (bus == ''):
				continue
			#endIf
			busNames.append(self.getName(bus))
		#endFor
		
		for xmlNode in nodeArray:
			if(xmlNode.hasAttr("busName")):
				siBusName = xmlNode.getAttrValue("busName")
				attrs = self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList())
				if (siBusName in busNames):
					if(not SystemUtils.updateOnAugment()):
						## Bus with similar value for 'busName' attribute already exists
						## in the WebSphere. Skip creation of this bus and continue
						self.printMessage(typeName, "busName", siBusName)
					else:
						print "Updating configuration for bus '" + siBusName + "'"
						SCRIPT_LOGGER.debug("AdminTask.modifySIBus(" + str(attrs) + ")")
						AdminTask.modifySIBus(attrs)
					#endIf
				else:
					## SIBus doesn't exist, create it newly
					print "Creating bus: " + siBusName
					busId = AdminTask.createSIBus(self.processAdminTaskArgs('-bus ' + siBusName))
					AdminTask.modifySIBus(attrs)
					for child in xmlNode.getChildrenArray():
						if ( (not child.hasAttr("name")) or (not child.hasAttr("value")) ):
							raise "Attributes 'name' and/or 'value' missing in 'Property' child element for bus " + siBusName
						else:
							propAttrs = child.buildNodeAttrsAsJyString()
							print "Creating Custom property '" + child.getAttrValue("name") + "' in bus '" + siBusName + "'"
							SCRIPT_LOGGER.debug("AdminConfig.create(" + self.propertyType + ", " + busId + ", " + str(propAttrs) + ")")
							AdminConfig.create(self.propertyType, busId, propAttrs)
						#endIf
					#endFor
				#endIf
			else:
				raise ("Error: XML node for SIBus doesn't contain the required attribute 'busName'")
			#endIf
		#endFor
		
		SCRIPT_LOGGER.traceExit([xmlFile, typeName])
	#endDef
#endClass

class BusMember(SIBMediator):
	def __init__(self, version):
		#super(BusMember,self).__init__()
		self.version = version
	#endDef
	
	def createBusMembers(self, nodeArray, busMemberList ):
		## Create Bus members
		for xmlNode in nodeArray:
			xmlNode.xmlProperty.clearSkipAttributeOnWriteFilters()
			## Obtain bus name from the child node (of type SIBus)
			child = xmlNode.getChildrenArray()[0]
			siBusName = child.getAttrValue("name")
			busMemberArgs = ['-bus', siBusName]
			if (xmlNode.hasAttr("server")):
				bMember = siBusName + "{node=" + xmlNode.getAttrValue("node") + ", server=" + xmlNode.getAttrValue("server") + "}"
			elif (xmlNode.hasAttr("cluster")):
				bMember = siBusName + "{cluster=" + xmlNode.getAttrValue("cluster") + "}"
				## Cluster bus members require attribute 'datasourceJndiName' attribute
				if ( xmlNode.hasAttr("datasourceJndiName") and xmlNode.getAttrValue("datasourceJndiName") != "" ):
					busMemberArgs.extend(['-datasourceJndiName', xmlNode.getAttrValue("datasourceJndiName")])
				else:
					raise "Attribute 'datasourceJndiName' is missing or empty for SIBusMember '" + bMember + "'"
				#endIf
			elif (xmlNode.hasAttr("wmqServer")):
				bMember = siBusName + "{wmqServer=" + xmlNode.getAttrValue("wmqServer") + "}"
			#endIf
			
			if (bMember not in busMemberList):
				## Bus member doesn't exist in WebSphere, create it
				print "Creating Bus member '" + bMember + "' in bus '" + siBusName + "'"
				busMemberArgs.extend(self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList()))
				SCRIPT_LOGGER.debug("AdminTask.addSIBusMember(" + str(busMemberArgs) + ")")
				AdminTask.addSIBusMember(busMemberArgs)
			else:
				print "Bus member '" + bMember + "' already exists"
				busMemberArgs = ['-bus', siBusName]
				
				## Exclude attribute 'wmqServer' from the attribute list, since its handled separately for WMQ 
				xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('wmqServer'))
				xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('datasourceJndiName'))
				busMemberArgs.extend(self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList()))
				if (xmlNode.hasAttr("cluster")):
					## Modify policy assistance settings is applicable for WAS 7.0 and higher
					if (self.version != "61"):
						print "   Modifying policy assistance settings for cluster bus member '" + bMember + "'"
						SCRIPT_LOGGER.debug("AdminTask.modifySIBusMemberPolicy(" + str(busMemberArgs) + ")")
						AdminTask.modifySIBusMemberPolicy(busMemberArgs)
					#endIf
				elif (xmlNode.hasAttr("wmqServer")):
					mqAttrs = ['-name', xmlNode.getAttrValue("wmqServer") + "-" + siBusName]
					mqAttrs.extend(busMemberArgs)
					print "   Modifying configuration for WebSphere MQ server bus member '" + bMember + "'"
					SCRIPT_LOGGER.debug("AdminTask.modifySIBWMQServerBusMember(" + str(mqAttrs) + ")")
					AdminTask.modifySIBWMQServerBusMember(mqAttrs)
				#endIf
			#endIf
		#endFor
	#endDef
	
	def getBusMembers(self):
		## Obtain list of bus members available in WebSphere 
		buses = AdminTask.listSIBuses().split(newline)
		busMembersList = []        
		for bus in buses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			busMembers = AdminTask.listSIBusMembers(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for member in busMembers:
				if (member != ""):
					clusterName = AdminConfig.showAttribute(member, "cluster")
					nodeName = AdminConfig.showAttribute(member, "node")
					serverName = AdminConfig.showAttribute(member, "server")
					wmqServerName = AdminConfig.showAttribute(member, "mqServer")
					if ( (serverName is not None) and (nodeName is not None) ):
						busMembersList.append(busName + "{node=" + nodeName + ", server=" + serverName + "}")
					elif ( clusterName is not None ):
						busMembersList.append(busName + "{cluster=" + clusterName + "}")
					elif ( wmqServerName is not None ):
						busMembersList.append(busName + "{wmqServer=" + wmqServerName + "}")
					#endIf
				#endIf
			#endFor
		#endFor
		
		return busMembersList
	#endDef
	
	def removeBusMembers(self, busMemberNames, nodeArray):
		
		## Initialize list of bus members to be removed same as 
		## busMemberNames (list available in WebSphere)		
		removeBusMembersList = []
		removeBusMembersList.extend(busMemberNames)
		
		for xmlNode in nodeArray:
			child = xmlNode.getChildrenArray()[0]
			siBusName = child.getAttrValue("name")
			if (xmlNode.hasAttr("server")):
				bMember = siBusName + "{node=" + xmlNode.getAttrValue("node") + ", server=" + xmlNode.getAttrValue("server") + "}"
			elif (xmlNode.hasAttr("cluster")):
				bMember = siBusName + "{cluster=" + xmlNode.getAttrValue("cluster") + "}"
			elif (xmlNode.hasAttr("wmqServer")):
				bMember = siBusName + "{wmqServer=" + xmlNode.getAttrValue("wmqServer") + "}"
			#endIf
			
			if (bMember in busMemberNames):
				## Remove bus members not in RAF xml but in WAS
				removeBusMembersList.remove(bMember)
			#endIf
		#endFor
		
		
		## Remove bus members
		for rMember in removeBusMembersList:
			bName = rMember.split("{")[0]
			attrDict = self.evaluateAttributeValues(rMember.split(bName)[1])
			extAtrrs = ""
			for key in attrDict.keys():
				extAtrrs = extAtrrs + " -" + key + " " + attrDict[key]
			#endFor
			print "Removing bus member: " +  rMember
			AdminTask.removeSIBusMember(self.processAdminTaskArgs('-bus ' + bName + extAtrrs))
		#endFor
	#endDef
	
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		
		busMemberAttrs = []
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			child = {}
			child[ID] = 'SIBus'
			child[ATTRS] = { "name" : busName, "RAFW_TYPE" : "reference" }
			child[CHILDREN] = []
			busMembers = AdminTask.listSIBusMembers(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for member in busMembers:
				if (member != ""):
					memberAttr = str(AdminConfig.show(member).split(newline))
					attrDict = self.convertToList(memberAttr, ['target'])
					if ( memberAttr.find("[server ") >=0 ):
						attrs = AdminTask.showSIBusMember(self.processAdminTaskArgs('-bus ' + busName + ' -node ' + attrDict["node"] + ' -server ' + attrDict["server"]))
					elif ( memberAttr.find("[cluster ") >=0 ):
						attrs = AdminTask.showSIBusMember(self.processAdminTaskArgs('-bus ' + busName + ' -cluster ' + attrDict["cluster"]))
						dsJndiName = "/"
						dataSourceList = AdminConfig.list('SIBDatastore').split(newline)
						for dataSource in dataSourceList:
							if (dataSource != "" and (dataSource.find("/clusters/" + attrDict["cluster"]) >= 0)):
								dsJndiName = AdminConfig.showAttribute(dataSource, 'dataSourceName')
								break
							#endIf
						#endFor
						extraAttrs = ""
						if (attrDict.has_key("assistanceEnabled")):
							extraAttrs = extraAttrs + ", enableAssistance=" + attrDict["assistanceEnabled"]
						#endIf
						if (attrDict.has_key("policyName")):
							extraAttrs = extraAttrs + ", policyName=" + attrDict["policyName"]
						#endIf
						attrs = attrs.split("}")[0] + ", datasourceJndiName=" + dsJndiName + extraAttrs + "}"
					else:
						## Find the attributes of MQ bus member
						attrs = AdminTask.showSIBWMQServerBusMember(self.processAdminTaskArgs('-bus ' + busName + ' -name ' + attrDict["mqServer"] + '-' + busName))
						attrs = attrs.replace("name=" + attrDict["mqServer"] + "-" + busName, "wmqServer=" + attrDict["mqServer"])
					#endIf
					busMemberAttrs.extend(self.createConfigData([attrs], typeName, ['wmqServerUuid', 'uuid'], [child]))
				#endIf
			#endFor
		#endFor
		
		SCRIPT_LOGGER.debug("Bus member config data: " + str(busMemberAttrs))
		SCRIPT_LOGGER.traceExit(typeName)
		return busMemberAttrs
	#endDef
	
	def executeConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		## Get the list of bus members available in WebSphere
		busMemberNames = self.getBusMembers()
		SCRIPT_LOGGER.debug("Bus members in WebSphere: " + str(busMemberNames))
		
		## Remove bus members NOT specified in RAF xml
		self.removeBusMembers(busMemberNames, nodeArray)
		
		## Create new bus members as specifed in RAF xml
		self.createBusMembers(nodeArray, busMemberNames)
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def augmentConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		## Bus members can only be created or removed, not modified
		## Hence invoke createBusMembers() to create newly, if any 
		busMemberNames = self.getBusMembers()
		SCRIPT_LOGGER.debug("Bus members in WebSphere: " + str(busMemberNames))
		self.createBusMembers(nodeArray, busMemberNames)
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
#endClass

class MsgEngine(SIBMediator):
	def __init__(self, version):
		#super(BusMember,self).__init__()
		self.version = version
	#endDef

	## Modifies MsgEngine configuration from WebSphere
	def executeConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'true')
	#endDef	
	
	## Modifies MsgEngine configuration from WebSphere
	def augmentConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'false')
	#endDef	
	
	def writeConfig(self, xmlFile, marker, typeName, isExecute):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		rafMsgEngines = []
		for xmlNode in nodeArray:
			if (xmlNode.hasAttr("name")):
				rafMsgEngines.append(xmlNode.getAttrValue("name"))
			#endIf
		#endFor
		wasEngineBusMap = [] #[engine1 bus1 scope1 engine2 bus1 scope2 engine1 bus2 scope1.......]
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			engines = self.getSIBEnginesForBus(busName)
			for engine in engines:
				if ((engine is None) or (engine == '')):
					continue
				eName = self.getName(engine)
				wasEngineBusMap.append(eName)
				wasEngineBusMap.append(busName)
				wasEngineBusMap.append(self.buildScope(engine)[2])
			#endFor
		#endFor
		if (isExecute == 'true'):
			for i in range(0, len(wasEngineBusMap), 3): #Delete engines in WAS that are not in the data file
				if (wasEngineBusMap[i] not in rafMsgEngines):
					print "Removing messaging engine: " + wasEngineBusMap[i]
					AdminTask.deleteSIBEngine(self.processAdminTaskArgs('-bus ' + wasEngineBusMap[i + 1] + wasEngineBusMap[i + 2] + ' -engine ' + wasEngineBusMap[i]))
				#endIf
			#endFor
		#endIf
		
		for xmlNode in nodeArray:
			xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('messageStoreType'))
			xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipEmptyAttributes('targetGroups'))
			attrs = self.modifyAttrNames(xmlNode.buildNodeAttrsList())
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			if (len(sibusArr) < 1):
				raise "SIBus information missing for a given ME: " + engine
			#endIf
			busName = ""
			if (sibusArr[0].hasAttr('name')):
				busName = sibusArr[0].getAttrValue('name')
				if (busName is None or busName == ''):
					raise "Empty bus name provided in XML for the ME: " + engine
			else:
				raise "Bus name not provided in XML for the ME: " + engine
			#endIf
			attrs.append("-bus")
			attrs.append(busName)
			scopeNode = xmlNode.getFilteredChildrenArray('RAF_MessagingEngineScope')[0]
			scopeString = ''
			if (scopeNode.hasAttr('server')):
				nodeName = scopeNode.getAttrValue('node')
				serverName = scopeNode.getAttrValue('server')
				scopeString = ' -node ' + nodeName + ' -server ' + serverName
				attrs.append("-node")
				attrs.append(nodeName)
				attrs.append("-server")
				attrs.append(serverName)
			elif (scopeNode.hasAttr('cluster')):
				clusterName = scopeNode.getAttrValue('cluster')
				scopeString = ' -cluster ' + clusterName 
				attrs.append("-cluster")
				attrs.append(clusterName)
			#endIf
			engine = ""
			if (xmlNode.hasAttr("name")):
				engine = xmlNode.getAttrValue("name")
			#endIf
			if (engine in wasEngineBusMap): #modify engines in WAS that are in the data file
				if ((isExecute == 'false') and (not SystemUtils.updateOnAugment())):
					self.printMessage(typeName, "name", engine)
					continue
				#endIf
				engineId = self._findObjectId(xmlNode)
				SCRIPT_LOGGER.debug("AdminTask.modifySIBEngine(" + str(attrs) + ")")
				print "Modifying configuration for messaging engine '" + engine + "' in bus '" + busName + "'"
				AdminTask.modifySIBEngine(attrs)
				self.editSIBLinks(xmlNode, engine, busName, scopeString, isExecute, 'false')
				self.editMQLinks(xmlNode, engine, busName, scopeString, isExecute, 'false')
				self.editCustomProperty(xmlNode, engineId)
			else: #Create engines in WAS that are in the data file
				cmdArgs = self.prepareAttrsForEngineCreation(xmlNode, attrs)
				SCRIPT_LOGGER.debug("AdminTask.createSIBEngine(" + str(cmdArgs) + ")")
				print "Creating Messaging engine '" + engine + "' in bus '" + busName + "'"
				engineId = AdminTask.createSIBEngine(cmdArgs)
				self.editSIBLinks(xmlNode, engine, busName, scopeString, isExecute, 'true')
				self.editMQLinks(xmlNode, engine, busName, scopeString, isExecute, 'true')
				self.editCustomProperty(xmlNode, engineId)
			#endIf
		#endFor
	#endDef
	
	## Obtains the list of MEs for a given service integration bus
	def getSIBEnginesForBus(self, bus):
		engines = AdminConfig.list("SIBMessagingEngine").split(newline)
		meBusList = []
		for engine in engines:
			if(engine != ""):
				if(AdminConfig.showAttribute(engine, "busName") == bus):
					meBusList.append(engine)
				#endIf
			#endIf
		#endFor
		return meBusList
	#endDef
	
	## Reads ME configuration from WebSphere
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		data = []
		fieldsToIgnore = ['busUuid', 'uuid', 'busName', 'targetGroups']
		
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			sibEngines = self.getSIBEnginesForBus(busName)
			for sibEngine in sibEngines:
				if ((sibEngine is None) or (sibEngine == '')):
					continue
				parent = {}
				parent[ID] = typeName
				parent[ATTRS] = {}
				parent[CHILDREN] = []
				scope = self.buildScope(sibEngine)
				engineName = self.getName(sibEngine)
				sibEngineAttr = AdminTask.showSIBEngine(self.processAdminTaskArgs('-bus ' + busName + scope[2] + ' -engine ' + engineName))
				parentAttr = self.evaluateAttributeValues(sibEngineAttr, fieldsToIgnore)
				for key in parentAttr.keys():
					parent[ATTRS][key] = self.evaluateNullVal(parentAttr[key])
				#endFor
				scopeChild = {}
				scopeChild[ID] = 'RAF_MessagingEngineScope'
				scopeChild[ATTRS] = {}
				scopeChild[CHILDREN] = []
				if (scope[3] == 'server'): #scopeType
					scopeChild[ATTRS]['node'] = scope[0] #nodeName
					scopeChild[ATTRS]['server'] = scope[1] #scopeName
				else:
					scopeChild[ATTRS]['cluster'] = scope[1] #scopeName
				#endIf
				scopeChild[ATTRS]['RAFW_TYPE'] = 'reference'
				parent[CHILDREN].append(scopeChild)
				
				child = {}
				child[ID] = 'SIBus'
				child[ATTRS] = {}
				child[CHILDREN] = []
				child[ATTRS]['name'] = busName
				child[ATTRS]['RAFW_TYPE'] = 'reference'
				parent[CHILDREN].append(child)
				
				dataStoreConfig = ""
				fileStoreConfig = ""
				engineProps = AdminConfig.show(sibEngine).split(newline)
				for engineProp in engineProps:
					engineProp = engineProp.split('[')[1].split(']')[0]
					propName = engineProp.split(' ')[0]
					propValue = engineProp.split(' ')[1]
					if (propName == 'dataStore'):
						dataStoreConfig = propValue
					elif (propName == 'fileStore'):
						fileStoreConfig = propValue
					#endIf
				#endFor
				if (dataStoreConfig != ""):
					child = {}
					child[ID] = 'SIBDatastore'
					child[ATTRS] = {}
					child[CHILDREN] = []
					dataStore = self.convertToList(AdminConfig.show(dataStoreConfig).replace(newline, ' '), ['uuid'])
					for key in dataStore.keys():
						child[ATTRS][key] = dataStore[key]
					#endFor
					child[ATTRS]['WASKey'] = 'dataStore'
					parent[CHILDREN].append(child)
				#endIf
				if (fileStoreConfig != ""):
					child = {}
					child[ID] = 'SIBFilestore'
					child[ATTRS] = {}
					child[CHILDREN] = []
					fileStore = self.convertToList(AdminConfig.show(fileStoreConfig).replace(newline, ' '), ['uuid'])
					for key in fileStore.keys():
						child[ATTRS][key] = fileStore[key]
					#endFor
					child[ATTRS]['WASKey'] = 'fileStore'
					parent[CHILDREN].append(child)
				#endIf
				
				sibLinks = AdminTask.listSIBLinks(self.processAdminTaskArgs('-bus ' + busName + scope[2] + ' -messagingEngine ' + engineName)).split(newline)
				for sibLink in sibLinks:
					if (sibLink is None or sibLink == ''):
						continue
					child = {}
					child[ID] = 'SIBGatewayLink'
					child[ATTRS] = {}
					child[CHILDREN] = []
					sibLinkAttr={}
					if (self.version == '61'):
						sibLinkAttr = self.processWAS61SibLinkAttr(AdminTask.showSIBLink(self.processAdminTaskArgs('-bus ' + busName + ' -messagingEngine ' + engineName + ' -sibLink ' + sibLink)).split(newline)[1], bus)
					elif (self.version == '70' or self.version == '80'):	
						sibLink = self.getName(sibLink)
						sibLinkAttr = self.processWAS70SibLinkAttr(AdminTask.showSIBLink(self.processAdminTaskArgs('-bus ' + busName + ' -messagingEngine ' + engineName + ' -sibLink ' + sibLink)), bus)
					#endIf
					for key in sibLinkAttr.keys():
						child[ATTRS][key] = sibLinkAttr[key]
					#endFor
					parent[CHILDREN].append(child)
				#endFor
				
				mqLinks = AdminTask.listSIBMQLinks(self.processAdminTaskArgs('-bus ' + busName + scope[2] + ' -messagingEngine ' + engineName)).split(newline)
				for mqLink in mqLinks:
					if (mqLink is None or mqLink == ''):
						continue
					child = {}
					child[ID] = 'SIBMQLink'
					child[ATTRS] = {}
					child[CHILDREN] = []
					mqLinkName = self.getName(mqLink)
					mqLinkAttr = self.processMQLinkAttr(AdminTask.showSIBMQLink(self.processAdminTaskArgs('-bus ' + busName + ' -messagingEngine ' + engineName + ' -mqLink ' + mqLinkName)), mqLink, bus)
					for key in mqLinkAttr.keys():
						child[ATTRS][key] = mqLinkAttr[key]
					#endFor
					parent[CHILDREN].append(child)
				#endFor
				
				propList = []
				propStr = AdminConfig.showAttribute(sibEngine, "properties")
				if (propStr == "[]"):
					propList = []
				else:
					propList = self.readPropConfigId(propStr)
				#endIf
				
				for prop in propList:
					child = {}
					child[ID] = 'Property'
					child[ATTRS] = {}
					child[CHILDREN] = []
				
					propKeyValList = AdminConfig.showall(prop).split(newline)
					childAttrDict = self.convertToList(str(propKeyValList))
					for key in childAttrDict.keys():
						child[ATTRS][key] = self.evaluateNullVal(childAttrDict[key])
					#endFor
					parent[CHILDREN].append(child)
				#endFor
				
				data.append(parent)
			#endFor
		#endFor
		SCRIPT_LOGGER.debug("Messaging engine config data: " + str(data))		
		return data
	#endDef
	
	def processMQLinkAttr(self, values, mqLinkId, busId):
		data = {}
		if (values == '' or values == ' ' or values is None):
			return data
		data = self.convertToDict(values, ['uuid', 'targetUuid', '_WEBSPHERE_CONFIG_SESSION', '_Websphere_Config_Data_Type', 'brokerProfile'])
		
		if (self.version == '70' or self.version == '80'):
			senderChannelId = AdminConfig.list('SIBMQLinkSenderChannel', mqLinkId)
			if ((senderChannelId is not None) and (senderChannelId != '')):
				senderChannel = self.convertToList(AdminConfig.show(senderChannelId).replace(newline, ' '), ['sendStream'])
				for key in senderChannel.keys():
					data[key] = senderChannel[key]
			#endIf
			receiverChannelId = AdminConfig.list('SIBMQLinkReceiverChannel', mqLinkId)
			if ((receiverChannelId is not None) and (receiverChannelId != '')):
				receiverChannel = self.convertToList(AdminConfig.show(receiverChannelId).replace(newline, ' '))
				for key in receiverChannel.keys():
					data[key] = receiverChannel[key]
			#endIf
		#endIf
		if (data.has_key('qmName')):
			data['queueManagerName'] = data['qmName']
			del data['qmName']
		#endIf
		if (data.has_key('protocolName')):
			data['senderChannelTransportChain'] = data['protocolName']
			del data['protocolName']
		#endIf

		#Lets find the foreign bus for this MQLink
		foreignBusName = ""
		mqLinkName = data['name']
		virtualLinks = AdminConfig.list('SIBVirtualMQLink', busId).split(newline)
		for virtualLink in virtualLinks:
			if (foreignBusName == ""):
				virtualLinkAttrs = self.convertToList(AdminConfig.show(virtualLink), ['uuid'])
				linkRefs = virtualLinkAttrs['linkRef'].split(',')
				for linkRef in linkRefs:
					linkName = self.getName(linkRef)
					if (linkName == mqLinkName):
						foreignBusName = virtualLinkAttrs['name'].split(':')[1]
						if (foreignBusName == self.getName(busId)):
							foreignBusName = virtualLinkAttrs['name'].split(':')[0]
						break
					#endIf
				#endFor
			else:
				break
			#endIf 
		#endFor
		data['foreignBusName'] = foreignBusName
		
		return data
	#endDef	
	
	def processWAS61SibLinkAttr(self, values, busId):
		sibLinkAttrNameMap = {}
		sibLinkAttrNameMap['Name'] = 'name'
		sibLinkAttrNameMap['Description'] = 'description'
		sibLinkAttrNameMap['Remote Messaging Engine Name'] = 'remoteMessagingEngineName'
		sibLinkAttrNameMap['Protocol Name'] = 'protocolName'
		sibLinkAttrNameMap['Bootstrap Endpoints'] = 'bootstrapEndpoints'
		sibLinkAttrNameMap['Authentication Alias'] = 'authAlias'
		sibLinkAttrNameMap['Initial State'] = 'initialState'
	    
		data = {}
		if (values == '' or values == ' ' or values is None):
			return data
		for entry in values.split(', '):
			elements = entry.split('=')
			if (elements[0].find("uid") > -1):
				continue
			key = sibLinkAttrNameMap[elements[0].strip()]
			val = self.evaluateNullVal(elements[1])
			data[key] = val
		#endFor
		#Lets find the foreign bus for this SIBLink
		foreignBusName = ""
		sibLinkName = data['name']
		virtualLinks = AdminConfig.list('SIBVirtualGatewayLink', busId).split(newline)
		for virtualLink in virtualLinks:
			if (foreignBusName == ""):
				virtualLinkAttrs = self.convertToList(AdminConfig.show(virtualLink), ['uuid'])
				linkRefs = virtualLinkAttrs['linkRef'].split(',')
				for linkRef in linkRefs:
					linkName = self.getName(linkRef)
					if (linkName == sibLinkName):
						foreignBusName = virtualLinkAttrs['name'].split(':')[1]
						if (foreignBusName == self.getName(busId)):
							foreignBusName = virtualLinkAttrs['name'].split(':')[0]
						break
					#endIf
				#endFor
			else:
				break
			#endIf 
		#endFor
		data['foreignBusName'] = foreignBusName
		
		return data
	#endDef	

	def processWAS70SibLinkAttr(self, values, busId):
		data = {}
		if (values == '' or values == ' ' or values is None):
			return data
		values = values.split('{')[1].split('}')[0]
		for entry in values.split(', '):
			elements = entry.split('=')
			if (elements[0].find("uid") > -1):
				continue
			key = elements[0].strip()
			val = self.evaluateNullVal(elements[1])
			data[key] = val
		#endFor
		#Lets find the foreign bus for this SIBLink
		foreignBusName = ""
		sibLinkName = data['name']
		virtualLinks = AdminConfig.list('SIBVirtualGatewayLink', busId).split(newline)
		for virtualLink in virtualLinks:
			if (foreignBusName == ""):
				virtualLinkAttrs = self.convertToList(AdminConfig.show(virtualLink), ['uuid'])
				linkRefs = virtualLinkAttrs['linkRef'].split(',')
				for linkRef in linkRefs:
					linkName = self.getName(linkRef)
					if (linkName == sibLinkName):
						foreignBusName = virtualLinkAttrs['name'].split(':')[1]
						if (foreignBusName == self.getName(busId)):
							foreignBusName = virtualLinkAttrs['name'].split(':')[0]
						break
					#endIf
				#endFor
			else:
				break
			#endIf 
		#endFor
		data['foreignBusName'] = foreignBusName
		
		return data
	#endDef	

	def modifyAttrNames(self, attrList):
		for index in range(0, len(attrList)):
			if (attrList[index] == "-name"):
				attrList[index] = "-engine"
			#endIf
			if (attrList[index] == "-dataSourceName"):
				attrList[index] = "-datasourceJndiName"
			#endIf
		#endFor
		
		return attrList
	#endDef
	
	def prepareAttrsForEngineCreation(self, xmlNode, attrs):
		if ('-engine' in attrs):
			del attrs[attrs.index('-engine') + 1]
			attrs.remove('-engine')
		#endIf
		
		dataStorageAttrs = []
		dataStoreArr = xmlNode.getFilteredChildrenArray('SIBDatastore')
		if (len(dataStoreArr) > 0):
			dataStoreNode = dataStoreArr[0]
			dataStoreNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('permanentTables'))
			dataStoreNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('temporaryTables'))
			dataStorageAttrs = self.modifyAttrNames(dataStoreNode.buildNodeAttrsList())
			dataStorageAttrs.append('-dataStore')
		#endIf
		for entry in dataStorageAttrs:
			attrs.append(entry)

		fileStorageAttrs = []
		fileStoreArr = xmlNode.getFilteredChildrenArray('SIBFilestore')
		if (len(fileStoreArr) > 0):
			fileStoreNode = fileStoreArr[0]
			if (fileStoreNode.hasAttr('unlimitedTemporaryStoreSize') and (fileStoreNode.getAttrValue('unlimitedTemporaryStoreSize') == 'true')):
				fileStoreNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('maxTemporaryStoreSize'))
			if (fileStoreNode.hasAttr('unlimitedPermanentStoreSize') and (fileStoreNode.getAttrValue('unlimitedPermanentStoreSize') == 'true')):
				fileStoreNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('maxPermanentStoreSize'))
			fileStorageAttrs = fileStoreNode.buildNodeAttrsList()
			fileStorageAttrs.append('-fileStore')
		#endIf
		for entry in fileStorageAttrs:
			attrs.append(entry)
		
		return attrs
	#endDef
	
	def editSIBLinks(self, xmlNode, engineName, busName, scopeString, isExecute, onlyCreate):
		wasSIBLinks = []
		if (onlyCreate == 'false'):
			if (self.version == '61'):
				wasSIBLinks = AdminTask.listSIBLinks(self.processAdminTaskArgs('-bus ' + busName + scopeString + ' -messagingEngine ' + engineName)).split(newline)
			else:
				wasSIBLinkIds = AdminTask.listSIBLinks(self.processAdminTaskArgs('-bus ' + busName + scopeString + ' -messagingEngine ' + engineName)).split(newline)
				for wasSIBLinkId in wasSIBLinkIds:
					wasSIBLinks.append(self.getName(wasSIBLinkId))
			#endIf
		#endIf
		for sibLinkNode in xmlNode.getFilteredChildrenArray('SIBGatewayLink'):
			if (not sibLinkNode.hasAttr('name')):
				raise "Attribute 'name' missing in 'SIBGatewayLink' element for engine: " + engineName
			sibLinkName = sibLinkNode.getAttrValue('name')
			sibLinkAttrs = sibLinkNode.buildNodeAttrsList()
			sibLinkAttrs.append('-bus')
			sibLinkAttrs.append(busName)
			sibLinkAttrs.append('-messagingEngine')
			sibLinkAttrs.append(engineName)
			if (sibLinkName in wasSIBLinks):
				foreignBusIndex = sibLinkAttrs.index('-foreignBusName')
				del sibLinkAttrs[foreignBusIndex + 1]
				sibLinkAttrs.remove('-foreignBusName')
				SCRIPT_LOGGER.debug("AdminTask.modifySIBLink(" + str(sibLinkAttrs) + ")")
				AdminTask.modifySIBLink(sibLinkAttrs)
				wasSIBLinks.remove(sibLinkName) #if we see any items remaining in wasSIBLinks delete them in execute mode
			else:
				if (not (sibLinkNode.hasAttr('foreignBusName') and 
						sibLinkNode.hasAttr('bootstrapEndpoints') and 
						sibLinkNode.hasAttr('remoteMessagingEngineName'))):
					raise "Some of required attributes missing in 'SIBGatewayLink' element for engine: " + engineName
				SCRIPT_LOGGER.debug("AdminTask.createSIBLink(" + str(sibLinkAttrs) + ")")
				AdminTask.createSIBLink(sibLinkAttrs)
			#endIf
		#endFor
		if (isExecute and (onlyCreate == 'false')):
			for wasSIBLink in wasSIBLinks:
				if (wasSIBLink == '' or wasSIBLink is None):
					continue
				AdminTask.deleteSIBLink(self.processAdminTaskArgs('-bus ' + busName + ' -messagingEngine ' + engineName + ' -sibLink ' + wasSIBLink))
		#endIf
	#endDef
	
	def editMQLinks(self, xmlNode, engineName, busName, scopeString, isExecute, onlyCreate):
		wasMQLinks = []
		if (onlyCreate == 'false'):
			if (self.version == '61'):
				wasMQLinks = AdminTask.listSIBMQLinks(self.processAdminTaskArgs('-bus ' + busName + scopeString + ' -messagingEngine ' + engineName)).split(newline)
			else:
				wasMQLinkIds = AdminTask.listSIBMQLinks(self.processAdminTaskArgs('-bus ' + busName + scopeString + ' -messagingEngine ' + engineName)).split(newline)
				for wasMQLinkId in wasMQLinkIds:
					wasMQLinks.append(self.getName(wasMQLinkId))
			#endIf
		#endIf
		for mqLinkNode in xmlNode.getFilteredChildrenArray('SIBMQLink'):
			if (not mqLinkNode.hasAttr('name')):
				raise "Attribute 'name' missing in 'SIBMQLink' element for engine: " + engineName
			mqLinkNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipEmptyAttributes('receiverChannel'))
			mqLinkNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipEmptyAttributes('senderChannel'))
			mqLinkName = mqLinkNode.getAttrValue('name')
			mqLinkAttrs = mqLinkNode.buildNodeAttrsList()
			mqLinkAttrs.append('-bus')
			mqLinkAttrs.append(busName)
			mqLinkAttrs.append('-messagingEngine')
			mqLinkAttrs.append(engineName)
			if (mqLinkName in wasMQLinks):
				foreignBusIndex = mqLinkAttrs.index('-foreignBusName')
				del mqLinkAttrs[foreignBusIndex + 1]
				mqLinkAttrs.remove('-foreignBusName')
				if ('-senderChannelTransportChain' in mqLinkAttrs):
					protocolIndex = mqLinkAttrs.index('-senderChannelTransportChain')
					del mqLinkAttrs[protocolIndex + 1]
					mqLinkAttrs.remove('-senderChannelTransportChain')
				#endIf
				SCRIPT_LOGGER.debug("AdminTask.modifySIBMQLink(" + str(mqLinkAttrs) + ")")
				AdminTask.modifySIBMQLink(mqLinkAttrs)
				wasMQLinks.remove(mqLinkName) #if we see any items remaining in wasMQLinks delete them in execute mode
			else:
				if (not (mqLinkNode.hasAttr('foreignBusName') and 
						mqLinkNode.hasAttr('queueManagerName') and 
						mqLinkNode.hasAttr('senderChannelTransportChain'))):
					raise "Some of required attributes missing in 'SIBMQLink' element for engine: " + engineName
				SCRIPT_LOGGER.debug("AdminTask.createSIBMQLink(" + str(mqLinkAttrs) + ")")
				AdminTask.createSIBMQLink(mqLinkAttrs)
			#endIf
		#endFor
		if (isExecute and (onlyCreate == 'false')):
			for wasMQLink in wasMQLinks:
				if (wasMQLink == '' or wasMQLink is None):
					continue
				AdminTask.deleteSIBMQLink(self.processAdminTaskArgs('-bus ' + busName + ' -messagingEngine ' + engineName + ' -mqLink ' + wasMQLink))
		#endIf
	#endDef
	
	def editCustomProperty(self, xmlNode, engineId):
		engineName = self.getName(engineId)
		self.removeChildren('Property', engineId)
		for property in xmlNode.getFilteredChildrenArray('Property'):
			if ((not property.hasAttr("name")) or (not property.hasAttr("value")) ):
				raise "Attributes 'name' and/or 'value' missing in 'Property' element for engine: " + engineName
			else:
				propAttrs = property.buildNodeAttrsAsJyString()
				print "Creating Custom property '" + property.getAttrValue("name") + "' for engine '" + engineName + "'"
				SCRIPT_LOGGER.debug("AdminConfig.create('Property', "  + engineId + ", " + str(propAttrs) + ")")
				AdminConfig.create('Property', engineId, propAttrs)
			#endIf
		#endFor
	#endDef
	
	def buildScope(self, engineId):
		nodeName = ''
		scopeName = ''
		scopeString = ''
		scopeType = ''
		engineId = engineId.split('(')[1].split('|')[0].strip()
		if (engineId.find('/servers/') > -1):
			scopeType = 'server'
			scopeName = engineId.split('/servers/')[1].split('/')[0]
			nodeName = engineId.split('/nodes/')[1].split('/')[0]
		elif (engineId.find('/clusters/') > -1):
			scopeType = 'cluster'
			scopeName = engineId.split('/clusters/')[1].split('/')[0]
		#endIf	
		scopeString = ''
		if (scopeType == 'server'):
			scopeString = ' -node ' + nodeName + ' -server ' + scopeName
		elif (scopeType == 'cluster'):
			scopeString = ' -cluster ' + scopeName
		#endIf
		return [nodeName, scopeName, scopeString, scopeType]
	#endDef
	
#endClass

class Mediation(SIBMediator):
	## Reads Mediation configuration from WebSphere
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		data = []
		fieldsToIgnore = ['contextInfo', 'uuid']
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			mediations = AdminTask.listSIBMediations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for mediation in mediations:
				if ((mediation is None) or (mediation == '')):
					continue
				parent = {}
				parent[ID] = typeName
				parent[ATTRS] = {}
				parent[CHILDREN] = []
				mediationName = AdminConfig.showAttribute(mediation, "mediationName")
				mediationAttrs = AdminTask.showSIBMediation(self.processAdminTaskArgs('-bus ' + busName + ' -mediationName ' + mediationName))
				parentAttr = self.evaluateAttributeValues(mediationAttrs, fieldsToIgnore)
				for key in parentAttr.keys():
					parent[ATTRS][key] = self.evaluateNullVal(parentAttr[key])
				#endFor
				child = {}
				child[ID] = 'SIBus'
				child[ATTRS] = {}
				child[CHILDREN] = []
				child[ATTRS]['name'] = busName
				child[ATTRS]['RAFW_TYPE'] = 'reference'
				parent[CHILDREN].append(child)
				data.append(parent)
			#endFor
		#endFor
		SCRIPT_LOGGER.debug("Mediation config data: " + str(data))
		SCRIPT_LOGGER.traceExit(typeName)
		return data
	#endDef	

	## Modifies Mediation configuration from WebSphere
	def executeConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'false')
	#endDef	
	
	## Modifies Mediation configuration from WebSphere
	def augmentConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'true')
	#endDef	
	
	def writeConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		rafMediations = []
		for xmlNode in nodeArray:
			if (xmlNode.hasAttr("mediationName")):
				rafMediations.append(xmlNode.getAttrValue("mediationName"))
			#endIf
		#endFor
		wasMediationBusMap = [] #[mediation1 bus1 mediation2 bus2 mediation3 bus3.......]
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus) 
			mediations = AdminTask.listSIBMediations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for mediation in mediations:
				if ((mediation is None) or (mediation == '')):
					continue
				mName = AdminConfig.showAttribute(mediation, "mediationName")
				wasMediationBusMap.append(mName)
				wasMediationBusMap.append(busName)
			#endFor
		#endFor
		if (isAugment == 'false'):
			#Delete mediations in WAS that are not in the data file
			for i in range(0, len(wasMediationBusMap), 2):
				if (wasMediationBusMap[i] not in rafMediations):
					print "Removing mediation: " + wasMediationBusMap[i]
					AdminTask.deleteSIBMediation(self.processAdminTaskArgs('-bus ' + wasMediationBusMap[i + 1] + ' -mediationName ' + wasMediationBusMap[i]))
				#endIf
			#endFor
		#endIf
		for xmlNode in nodeArray:
			attrs = xmlNode.buildNodeAttrsList()
			mediation = xmlNode.getAttrValue("mediationName")
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			if (len(sibusArr) < 1):
				raise "SIBus information missing for the Mediation: " + mediation
			#endIf
			busName = ""
			if (sibusArr[0].hasAttr('name')):
				busName = sibusArr[0].getAttrValue('name')
				if (busName is None or busName == ''):
					raise "Empty bus name provided in XML for the Mediation: " + mediation
			else:
				raise "Bus name not provided in XML for the Mediation: " + mediation
			#endIf
			attrs.append("-bus")
			attrs.append(busName)
			if (mediation is None or mediation == ''):
				continue
			if (mediation not in wasMediationBusMap): #Create mediations in WAS that are in the data file
				if (xmlNode.hasAttr('mediationName') and xmlNode.hasAttr('handlerListName')):
					SCRIPT_LOGGER.debug("AdminTask.createSIBMediation(" + str(attrs) + ")")
					print "Creating Mediation '" + mediation + "' in bus '" + busName + "'"
					AdminTask.createSIBMediation(attrs)
				else:
					raise "Not all required parameters supplied for creating new Mediation: " + mediation
			else: #Modify mediations in WAS that are in the data file
				if (xmlNode.hasAttr('mediationName')):
					if ((isAugment == 'true') and (not SystemUtils.updateOnAugment())):
						self.printMessage(typeName, "mediationName", xmlNode.getAttrValue("mediationName"))
						continue
					#endIf
					SCRIPT_LOGGER.debug("AdminTask.modifySIBMediation(" + str(attrs) + ")")
					print "Modifying configuration for mediation '" + mediation + "' in bus '" + busName + "'"
					AdminTask.modifySIBMediation(attrs)
				else:
					raise "Not all required parameters supplied for modifying existing Mediation: " + mediation
				#endIf
			#endIf
		#endFor
	#endDef
	
#endClass

class Destination(SIBMediator):

	## Modifies Destination configuration from WebSphere
	def executeConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'false')
	#endDef	
	
	## Modifies Destination configuration from WebSphere
	def augmentConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'true')
	#endDef	
	
	def writeConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		rafDestinations = []
		for xmlNode in nodeArray:
			if (xmlNode.hasAttr("name")):
				rafDestinations.append(xmlNode.getAttrValue("name"))
			#endIf
		#endFor
		wasDestinations = [] 
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			destinations = AdminTask.listSIBDestinations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for destination in destinations:
				if ((destination is None) or (destination == '')):
					continue
				destinationName = AdminConfig.showAttribute(destination, "identifier")
				wasDestinations.append(destinationName)
				destType = self.findDestinationType(destination)
				if (destType == 'Foreign'):
					foreignBus = AdminConfig.showAttribute(destination, 'bus')
					if ((isAugment == 'false') and (destinationName not in rafDestinations)):
						if (destinationName.startswith('_')):
							print "Cannot delete destination '" + destinationName + "' as it is a system destination."
							continue
						#endIf
						print "Removing destination: " + destinationName
						AdminTask.deleteSIBDestination(self.processAdminTaskArgs('-bus ' + busName + ' -name ' + destinationName + ' -foreignBus ' + foreignBus))
					#endIf
				elif (destType == 'Alias'):
					aliasBus = AdminConfig.showAttribute(destination, 'bus')
					if ((isAugment == 'false') and (destinationName not in rafDestinations)):
						if (destinationName.startswith('_')):
							print "Cannot delete destination '" + destinationName + "' as it is a system destination."
							continue
						#endIf
						print "Removing destination: " + destinationName
						AdminTask.deleteSIBDestination(self.processAdminTaskArgs('-bus ' + busName + ' -name ' + destinationName + ' -aliasBus ' + aliasBus))
					#endIf
				else:
					if ((isAugment == 'false') and (destinationName not in rafDestinations)):
						if (destinationName.startswith('_')):
							print "Cannot delete destination '" + destinationName + "' as it is a system destination."
							continue
						#endIf
						print "Removing destination: " + destinationName
						AdminTask.deleteSIBDestination(self.processAdminTaskArgs('-bus ' + busName + ' -name ' + destinationName))
					#endIf
				#endIf
			#endFor
		#endFor
		for xmlNode in nodeArray:
			xmlNode.xmlProperty.clearSkipAttributeOnWriteFilters()
			destination = xmlNode.getAttrValue("name")
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			if (len(sibusArr) < 1):
				raise "SIBus information missing for the Destination: " + destination
			#endIf
			busName = ""
			if (sibusArr[0].hasAttr('name')):
				busName = sibusArr[0].getAttrValue('name')
				if (busName is None or busName == ''):
					raise "Empty bus name provided in XML for the Destination: " + destination
			else:
				raise "Bus name not provided in XML for the Destination: " + destination
			#endIf
			if(xmlNode.getAttrValue("type") != "TopicSpace"):
				xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('auditAllowed'))
			#endIf
			if ( (xmlNode.hasAttr("blockedRetryTimeout")) and (xmlNode.getAttrValue("blockedRetryTimeout") == "-1") ):
				xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('blockedRetryTimeout'))
			#endIf
			if ( (xmlNode.hasAttr("defaultPriority")) and (xmlNode.getAttrValue("defaultPriority") == "-1") ):
				xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('defaultPriority'))
			#endIf
			xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipEmptyAttributes('defaultForwardRoutingPath'))
			xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipEmptyAttributes('mediationPoints'))
			xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipEmptyAttributes('queuePoints'))
			if (destination not in wasDestinations): #Create destinations in WAS that are in the data file
				if (xmlNode.hasAttr('name') and xmlNode.hasAttr('type')):
					if (destination.startswith('_')):
						print "Cannot create destination '" + destination + "' as it is a system destination."
						continue
					#endIf
					print "Creating Destination '" + destination + "' in bus '" + busName + "'"
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('useAllMediationPoints'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('useAllQueuePoints'))
					attrs = xmlNode.buildNodeAttrsList()
					attrs.append("-bus")
					attrs.append(busName)
					if ('-defaultForwardRoutingPath' in attrs):
						routingPathIndex = attrs.index('-defaultForwardRoutingPath')
						routingPath = attrs[routingPathIndex + 1]
						attrs[routingPathIndex + 1] = '[[' + routingPath.split(':')[0] + ' ' + routingPath.split(':')[1] + ']]'
					#endIf
					SCRIPT_LOGGER.debug("AdminTask.createSIBDestination(" + str(attrs) + ")")
					AdminTask.createSIBDestination(attrs)
				else:
					raise "Not all required parameters supplied for creating new Destination: " + destination
			else: #Modify destinations in WAS that are in the data file
				if (xmlNode.hasAttr('name')):
					if ((isAugment == 'true') and (not SystemUtils.updateOnAugment())):
						self.printMessage(typeName, "name", xmlNode.getAttrValue("name"))
						continue
					#endIf
					print "Modifying configuration for destination '" + destination + "' in bus '" + busName + "'"
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('type'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('cluster'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('node'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('server'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('wmqServer'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('aliasBus'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('targetBus'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('targetName'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('foreignBus'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('nonPersistentReliability'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('persistentReliability'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('wmqQueueName'))
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('useRFH2'))
					attrs = xmlNode.buildNodeAttrsList()
					
					if ('-defaultForwardRoutingPath' in attrs):
						routingPathIndex = attrs.index('-defaultForwardRoutingPath')
						routingPath = attrs[routingPathIndex + 1]
						attrs[routingPathIndex + 1] = '[[' + routingPath.split(':')[0] + ' ' + routingPath.split(':')[1] + ']]'
					#endIf
					attrs.append("-bus")
					attrs.append(busName)
					SCRIPT_LOGGER.debug("AdminTask.modifySIBDestination(" + str(attrs) + ")")
					AdminTask.modifySIBDestination(attrs)
				else:
					raise "Not all required parameters supplied for modifying existing Destination: " + destination
				#endIf
			#endIf
		#endFor
		
	#endDef	

	## Reads Destination configuration from WebSphere
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		data = []
		fieldsToIgnore = ['uuid']
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			destinations = AdminTask.listSIBDestinations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for destination in destinations:
				if ((destination is None) or (destination == '')):
					continue
				parent = {}
				parent[ID] = typeName
				parent[ATTRS] = {}
				parent[CHILDREN] = []
				destinationName = AdminConfig.showAttribute(destination, "identifier")
				destinationAttrs = AdminTask.showSIBDestination(self.processAdminTaskArgs('-bus ' + busName + ' -name ' + destinationName))
				parentAttr = self.evaluateAttributeValues(destinationAttrs, fieldsToIgnore)
				
				parentAttr['type'] = self.findDestinationType(destination)
				if (parentAttr['type'] == 'Alias'):
					parentAttr['aliasBus'] = parentAttr['bus']
				#endIf
				if (parentAttr['type'] == 'Foreign'):
					parentAttr['foreignBus'] = parentAttr['bus']
					del parentAttr['bus']
				#endIf
				if (parentAttr['type'] == 'Queue'):
					qPointId = AdminConfig.list('SIBLocalizationPointRef', destination).split(newline)[0]
					wmqServer = AdminConfig.showAttribute(qPointId, 'mqServer')
					if (wmqServer is None):
						cluster = AdminConfig.showAttribute(qPointId, 'cluster')
						if (cluster is None):
							parentAttr['node'] = AdminConfig.showAttribute(qPointId, 'node')
							parentAttr['server'] = AdminConfig.showAttribute(qPointId, 'server')
						else:
							parentAttr['cluster'] = cluster
						#endIf
					else:
						parentAttr['wmqServer'] = wmqServer
					#endIf
				#endIf
				if (parentAttr.has_key('replyDestinationBusName')):
					parentAttr['replyDestinationBus'] = parentAttr['replyDestinationBusName']
					del parentAttr['replyDestinationBusName']
				#endIf
				if (parentAttr.has_key('replyDestinationName')):
					parentAttr['replyDestination'] = parentAttr['replyDestinationName']
					del parentAttr['replyDestinationName']
				#endIf
				if (parentAttr.has_key('identifier')):
					parentAttr['name'] = parentAttr['identifier']
					del parentAttr['identifier']
				#endIf
				if (parentAttr.has_key('targetIdentifier')):
					parentAttr['targetName'] = parentAttr['targetIdentifier']
					del parentAttr['targetIdentifier']
				#endIf

				for key in parentAttr.keys():
					parent[ATTRS][key] = self.evaluateNullVal(parentAttr[key])
				#endFor
				child = {}
				child[ID] = 'SIBus'
				child[ATTRS] = {}
				child[CHILDREN] = []
				child[ATTRS]['name'] = busName
				child[ATTRS]['RAFW_TYPE'] = 'reference'
				parent[CHILDREN].append(child)
				data.append(parent)
			#endFor
		#endFor
		SCRIPT_LOGGER.debug("Destination config data: " + str(data))
		SCRIPT_LOGGER.traceExit(typeName)
		return data
	#endDef
	
	def findDestinationType(self, destination):
		if (destination.find('SIBQueue_') > -1):
			return 'Queue'
		if (destination.find('SIBTopicSpace_') > -1):
			return 'TopicSpace'
		if (destination.find('SIBDestinationForeign_') > -1):
			return 'Foreign'
		if (destination.find('SIBDestinationAlias_') > -1):
			return 'Alias'
	#endDef
#endClass

class ForeignBus(SIBMediator):
	
	def getForeignBusAttrValue(self, fBus, attrName):
		attrValue = ""
		if (fBus.find("(") >=0 ):
			## fBus is a configId, obtain the required attribute value directly
			attrValue = AdminConfig.showAttribute(fBus, attrName)
		else:
			## fBus is the name of the foreign bus
			fBuses = AdminConfig.list("SIBForeignBus").split(newline)
			for bus in fBuses:
				fbName = AdminConfig.showAttribute(bus, "name")
				if (fbName == fBus):
					## Found the matching foreign bus, obtain the required attribute value using its configId
					attrValue = AdminConfig.showAttribute(bus, attrName)
					break
				#endIf
			#endFor
		#endIf
		
		return attrValue
	#endDef
	
	def getForeignBusAttrs(self, fBus, bName, fbRoutingType, fbType=None):
		
		fBusName = self.getName(fBus)
		fBAttrs = AdminTask.showSIBForeignBus(self.processAdminTaskArgs('-bus ' + bName + ' -name ' + fBusName))
		
		if (fBAttrs.find(newline) >= 0):
			fBAttrs = fBAttrs.replace(newline, ",")
		else:
			fBAttrs = fBAttrs.replace("\n", ",")
		#endIf
		
		if (fbRoutingType == "Direct" and fbType == "MQ"):
			extraAttrs = ", routingType=Direct, type=MQ"
		elif (fbRoutingType == "Direct" and fbType == "SIBus"):
			extraAttrs = ", routingType=Direct, type=SIBus"
		else:
			extraAttrs = ", routingType=Indirect"
		#endIf
		nextHop = self.getForeignBusAttrValue(fBus, "nextHop")
		if (nextHop is not None):
			## Bus2(cells/cell/buses/Bus1|sib-bus.xml#SIBForeignBus_1317362446621)
			nextHopBusName = self.getName(nextHop)
		else:
			nextHopBusName = ""
		#endIf
		extraAttrs = extraAttrs + ", inboundUserid="", outboundUserid="", nextHopBus=" + nextHopBusName
		fBAttrs = "{" + fBAttrs + extraAttrs + "}"
				
		return self.processForeignBusAttrs(fBAttrs)
	#endDef
	
	## The foreign bus attributes returned by AdminTask.showSIBForeignBus()
	## command contains string output of the form
	## Foreign Bus Name=ForeignBus_Direct_1, Foreign Bus Description=null, etc..
	## Convert these key strings to actual attributes which can be stored in the 
	## RAF xml, such as: name=ForeignBus_Direct_1, description=null, etc..
	
	def processForeignBusAttrs(self, fBusAttrs):		
		attrKeyMap = {"Foreign Bus Name":"name", "Foreign Bus Uuid":"uuid", "Foreign Bus Description":"description", "Foreign Bus Send Allowed":"sendAllowed", "mqRfh2 Allowed": "mqRfh2Allowed"}
		for key in attrKeyMap.keys():
			fBusAttrs = fBusAttrs.replace(key, attrKeyMap[key])
		#endFor
		
		attrsToExclude = ['mqRfh2Allowed', 'uuid']
		
		data = self.evaluateAttributeValues(fBusAttrs, attrsToExclude)
		return data
	#endFor
			
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		
		data = []
		
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			siBusRef = { "name" : busName, "RAFW_TYPE" : "reference" }
			directMQForeignBuses = AdminTask.listSIBForeignBuses(self.processAdminTaskArgs('-bus ' + busName + ' -routingType Direct -type MQ')).split(newline)
			directSIBForeignBuses = AdminTask.listSIBForeignBuses(self.processAdminTaskArgs('-bus ' + busName + ' -routingType Direct -type SIBus')).split(newline)
			indirectForeignBuses = AdminTask.listSIBForeignBuses(self.processAdminTaskArgs('-bus ' + busName + ' -routingType Indirect')).split(newline)
			
			SCRIPT_LOGGER.debug("Direct MQ Foreign Buses : " + busName + str(directMQForeignBuses))
			SCRIPT_LOGGER.debug("Direct SIBus Foreign Buses : " + busName + str(directSIBForeignBuses))
			SCRIPT_LOGGER.debug("Indirect Foreign Buses : " + busName + str(indirectForeignBuses))
			
			child = {}
			child[ID] = 'SIBus'
			child[ATTRS] = siBusRef
			child[CHILDREN] = []
			
			for fBus in directMQForeignBuses:
				if (fBus != ""):
					parent = {}
					parent[ID] = typeName
					parent[ATTRS] = self.getForeignBusAttrs(fBus, busName, "Direct", "MQ")
					parent[CHILDREN] = [child]
					data.append(parent)
				#endIf
			#endFor
			for fBus in directSIBForeignBuses:
				if (fBus != ""):
					parent = {}
					parent[ID] = typeName
					parent[ATTRS] = self.getForeignBusAttrs(fBus, busName, "Direct", "SIBus")
					parent[CHILDREN] = [child]
					data.append(parent)
				#endIf
			#endFor
			for fBus in indirectForeignBuses:
				if (fBus != ""):
					parent = {}
					parent[ID] = typeName
					parent[ATTRS] = self.getForeignBusAttrs(fBus, busName, "Indirect")
					parent[CHILDREN] = [child]
					data.append(parent)
				#endIf
			#endFor
		#endFor
		
		SCRIPT_LOGGER.debug("Foreign Bus config data: " + str(data))
		SCRIPT_LOGGER.traceExit(typeName)
		return data
	#endDef
	
	def executeConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		## Obtain the list of foreign buses available in WebSphere, in the form: [bus_name:foreignbus_name]
		## Eg: [Bus1:Foreign1, Bus2:Indirect_FB1]
		foreignBusList = []
		buses = AdminTask.listSIBuses().split(newline)		
		for bus in buses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			foreignBuses = AdminTask.listSIBForeignBuses(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for fBus in foreignBuses:
				if (fBus != ""):
					fBusName = self.getName(fBus)
					foreignBusList.append(busName + ":" + fBusName)
				#endIf
			#endFor
		#endFor
		
		## Remove foreign buses not in RAF xml but in WebSphere
		removeforeignBusList = []
		removeforeignBusList.extend(foreignBusList)
		for xmlNode in nodeArray:
			child = xmlNode.getChildrenArray()[0]
			fBusName = xmlNode.getAttrValue("name")
			siBusName = child.getAttrValue("name")
			
			if ((siBusName + ":" + fBusName) in foreignBusList):
				removeforeignBusList.remove(siBusName + ":" + fBusName)
			#endIf
		#endFor
		for fBus in removeforeignBusList:
			siBusName = fBus.split(":")[0]
			fBusName = fBus.split(":")[1]
			
			print "Removing foreign bus: " + fBusName
			AdminTask.deleteSIBForeignBus(self.processAdminTaskArgs('-bus ' + siBusName + ' -name ' + fBusName))
		#endFor
				
		## Create or modify foreign buses as in RAF XML
		for xmlNode in nodeArray:
			## Foreign bus has one children of type SIBus
			## Obtain SIBus name from the child node
			fBusName = None
			siBusName = None
			child = xmlNode.getChildrenArray()[0]
			if (child.hasAttr("RAFW_TYPE") and (child.getAttrValue("RAFW_TYPE") == "reference")):
				fBusName = xmlNode.getAttrValue("name")
				siBusName = child.getAttrValue("name")
			#endIf			
			if ((siBusName is not None) and (fBusName is not None)):
				if ((siBusName + ":" + fBusName) not in foreignBusList):
					# Foreign bus doesn't exist, create newly
					foreignBusAttrs = ['-bus', siBusName]
					foreignBusAttrs.extend(self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList()))
					print "Creating Foreign Bus '" + fBusName + "' in bus '" + siBusName + "'"
					SCRIPT_LOGGER.debug("AdminTask.createSIBForeignBus(" + str(foreignBusAttrs) + ")")
					AdminTask.createSIBForeignBus(foreignBusAttrs)
				else:
					## Foreign bus exists, modify the attributes
					foreignBusAttrs = ''
					if (xmlNode.getAttrValue("description") != ""):
						foreignBusAttrs = foreignBusAttrs + ' -description ' + xmlNode.getAttrValue("description")
					#endIf
					if (xmlNode.getAttrValue("sendAllowed") != ""):
						foreignBusAttrs = foreignBusAttrs + ' -sendAllowed ' + xmlNode.getAttrValue("sendAllowed")
					#endIf
					if (xmlNode.getAttrValue("inboundUserid") != ""):
						foreignBusAttrs = foreignBusAttrs + ' -inboundUserid ' + xmlNode.getAttrValue("inboundUserid")
					#endIf
					if (xmlNode.getAttrValue("outboundUserid") != ""):
						foreignBusAttrs = foreignBusAttrs + ' -outboundUserid ' + xmlNode.getAttrValue("outboundUserid")
					#endIf
					if (xmlNode.getAttrValue("nextHopBus") != ""):
						foreignBusAttrs = foreignBusAttrs + ' -nextHopBus ' + xmlNode.getAttrValue("nextHopBus")
					#endIf
					foreignBusAttrs = '-bus ' + siBusName + ' -name ' + fBusName + foreignBusAttrs
					
					print "Modifying configuration for foreign bus '" + fBusName + "' in bus '" + siBusName + "'"
					SCRIPT_LOGGER.debug("AdminTask.modifySIBForeignBus(" + str(foreignBusAttrs) + ")")
					AdminTask.modifySIBForeignBus(self.processAdminTaskArgs(foreignBusAttrs))
				#endIf
			#endIf
		#endFor
				
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def augmentConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		## Obtain the list of foreign buses available in WebSphere, in the form: [bus_name:foreignbus_name]
		## Eg: [Bus1:Foreign1, Bus2:Indirect_FB1]
		foreignBusList = []
		buses = AdminTask.listSIBuses().split(newline)		
		for bus in buses:
			busName = self.getName(bus)
			foreignBuses = AdminTask.listSIBForeignBuses(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for fBus in foreignBuses:
				if (fBus != ""):
					fBusName = self.getName(fBus)
					foreignBusList.append(busName + ":" + fBusName)
				#endIf
			#endFor
		#endFor
		
		## Create or modify foreign buses as in RAF XML
		for xmlNode in nodeArray:
			## Foreign bus has one children of type SIBus
			## Obtain SIBus name from the child node
			fBusName = None
			siBusName = None
			child = xmlNode.getChildrenArray()[0]
			if (child.hasAttr("RAFW_TYPE") and (child.getAttrValue("RAFW_TYPE") == "reference")):
				fBusName = xmlNode.getAttrValue("name")
				siBusName = child.getAttrValue("name")
			#endIf			
			if ((siBusName is not None) and (fBusName is not None)):
				if ((siBusName + ":" + fBusName) not in foreignBusList):
					# Foreign bus doesn't exist, create newly
					foreignBusAttrs = ['-bus', siBusName]
					foreignBusAttrs.extend(self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList()))
					print "Creating Foreign Bus '" + fBusName + "' in bus '" + siBusName + "'"
					SCRIPT_LOGGER.debug("AdminTask.createSIBForeignBus(" + str(foreignBusAttrs) + ")")
					AdminTask.createSIBForeignBus(foreignBusAttrs)
				else:
					if(not SystemUtils.updateOnAugment()):
						## Foreign bus with similar value for 'name' attribute already exists
						## in the WebSphere. Skip creation of this foreign bus and continue
						self.printMessage(typeName, "name", fBusName)
					else:
						## Foreign bus exists, modify the attributes
						foreignBusAttrs = ''
						if (xmlNode.getAttrValue("description") != ""):
							foreignBusAttrs = foreignBusAttrs + ' -description ' + xmlNode.getAttrValue("description")
						#endIf
						if (xmlNode.getAttrValue("sendAllowed") != ""):
							foreignBusAttrs = foreignBusAttrs + ' -sendAllowed ' + xmlNode.getAttrValue("sendAllowed")
						#endIf
						if (xmlNode.getAttrValue("inboundUserid") != ""):
							foreignBusAttrs = foreignBusAttrs + ' -inboundUserid ' + xmlNode.getAttrValue("inboundUserid")
						#endIf
						if (xmlNode.getAttrValue("outboundUserid") != ""):
							foreignBusAttrs = foreignBusAttrs + ' -outboundUserid ' + xmlNode.getAttrValue("outboundUserid")
						#endIf
						if (xmlNode.getAttrValue("nextHopBus") != ""):
							foreignBusAttrs = foreignBusAttrs + ' -nextHopBus ' + xmlNode.getAttrValue("nextHopBus")
						#endIf
						foreignBusAttrs = '-bus ' + siBusName + ' -name ' + fBusName + foreignBusAttrs
						
						print "Modifying configuration for foreign bus '" + fBusName + "' in bus '" + siBusName + "'"
						SCRIPT_LOGGER.debug("AdminTask.modifySIBForeignBus(" + str(foreignBusAttrs) + ")")
						AdminTask.modifySIBForeignBus(self.processAdminTaskArgs(foreignBusAttrs))
					#endIf
				#endIf
			#endIf
		#endFor
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
#endClass

class BootstrapMember(SIBMediator):
	
	def createBootstrapMembers(self, nodeArray, bootstrapMemberList ):
		## Create Bootstrap members
		for xmlNode in nodeArray:
			## Obtain bus name from the child node (of type SIBus) 
			child = xmlNode.getChildrenArray()[0]
			siBusName = child.getAttrValue("name")
			bootstrapMemberArgs = ['-bus', siBusName]
			if (xmlNode.hasAttr("server")):
				bMember = siBusName + "{node=" + xmlNode.getAttrValue("node") + ", server=" + xmlNode.getAttrValue("server") + "}"
			else:
				bMember = siBusName + "{cluster=" + xmlNode.getAttrValue("cluster") + "}"
			#endIf
			
			## Obtain list of available bus members on the bus, since servers or clusters
			## configured as bus members cannot be  nominated for bootstrapping
			busMembersList = []
			buses = AdminTask.listSIBuses().split(newline)
			for bus in buses:
				if (bus == ''):
					continue
				#endIf
				busName = self.getName(bus)
				busMembers = AdminTask.listSIBusMembers(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
				for member in busMembers:
					if (member != ""):
						clusterName = AdminConfig.showAttribute(member, "cluster")
						nodeName = AdminConfig.showAttribute(member, "node")
						serverName = AdminConfig.showAttribute(member, "server")						
						if ( (serverName is not None) and (nodeName is not None) ):
							busMembersList.append(busName + "{node=" + nodeName + ", server=" + serverName + "}")
						elif ( clusterName is not None ):
							busMembersList.append(busName + "{cluster=" + clusterName + "}")
						#endIf
					#endIf
				#endFor
			#endFor
			
			if (bMember not in bootstrapMemberList):
				if (bMember not in busMembersList):
					## Bootstrap member doesn't exist in WebSphere, create it
					print "Creating Bootstrap Member '" + bMember + "' in bus '" + siBusName + "'"
					bootstrapMemberArgs.extend(self.modifyAttrNamesForSIB(xmlNode.buildNodeAttrsList()))
					SCRIPT_LOGGER.debug("AdminTask.addSIBBootstrapMember(" + str(bootstrapMemberArgs) + ")")
					AdminTask.addSIBBootstrapMember(bootstrapMemberArgs)
				else:
					print "Member '" + bMember + "' is already a Bus member, cannot add as bootstrap member"
				#endIf
			else:
				print "Bootstrap member '" + bMember + "' already exists for bus '" + siBusName + "'"
			#endIf
		#endFor
	#endDef
	
	def getBootstrapMembers(self):
		
		## Obtain list of all bootstrap members available in WebSphere
		buses = AdminTask.listSIBuses().split(newline)
		bootstrapMembersList = []        
		for bus in buses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			bootstrapMembers = AdminTask.listSIBNominatedBootstrapMembers(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for member in bootstrapMembers:
				if (member != ""):
					name = self.getName(member)
					if (member.find("/clusters/") >=0):
						# Bootstrap member is a cluster
						attrs = busName + "{cluster=" + name + "}"
					else:
						# Bootstrap member is a server
						# Eg: dynclusterB_node01(cells/cell/nodes/node01/servers/dynclusterB_node01|server.xml)
						server = member.split('/servers/')[1].split('|')[0]
						node = member.split('/nodes/')[1].split('/servers')[0]
						attrs = busName + "{node=" + node + ", server=" + server + "}"
					#endIf
					bootstrapMembersList.append(attrs)
				#endIf
			#endFor
		#endFor
		
		return bootstrapMembersList
	#endDef
	
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		
		buses = AdminTask.listSIBuses().split(newline)
		bootstrapMembers = []        
		for bus in buses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			siBusRef = { "name" : busName, "RAFW_TYPE" : "reference" }
			child = {}
			child[ID] = 'SIBus'
			child[ATTRS] = siBusRef
			child[CHILDREN] = []
			bMembers = AdminTask.listSIBNominatedBootstrapMembers(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for member in bMembers:
				if (member != ""):
					name = self.getName(member)
					if (member.find("clusters") >=0):
						# Bootstrap member is a cluster
						attrs = "{cluster=" + name + "}"
					elif (member.find("servers") >=0):
						# Bootstrap member is a server
						# dynclusterB_node01(cells/cell/nodes/node01/servers/dynclusterB_node01|server.xml)
						server = member.split('/servers/')[1].split('|')[0]
						node = member.split('/nodes/')[1].split('/servers')[0]
						attrs = "{node=" + node + ", server=" + server + "}"
					#endIf
					bootstrapMembers.extend(self.createConfigData([attrs], typeName, [], [child]))
			#endFor
		#endFor
		
		SCRIPT_LOGGER.debug("Bootstrap member config data: " + str(bootstrapMembers))
		SCRIPT_LOGGER.traceExit(typeName)		
		return bootstrapMembers
	#endDef
	
	def removeBootstrapMembers(self, bootstrapMemberNames, nodeArray):
		
		## Initialize list of bootstrap members to be removed same as 
		## bootstrapMemberNames (list available in WebSphere)		
		removeBootstrapMembersList = []
		removeBootstrapMembersList.extend(bootstrapMemberNames)
		
		for xmlNode in nodeArray:
			child = xmlNode.getChildrenArray()[0]
			siBusName = child.getAttrValue("name")
			if (xmlNode.hasAttr("server")):
				bMember = siBusName + "{node=" + xmlNode.getAttrValue("node") + ", server=" + xmlNode.getAttrValue("server") + "}"
			else:
				bMember = siBusName + "{cluster=" + xmlNode.getAttrValue("cluster") + "}"
			#endIf
			
			if (bMember in bootstrapMemberNames):
				## Remove bootstrap members not in RAF xml but in WAS
				removeBootstrapMembersList.remove(bMember)
			#endIf
		#endFor
		
		
		## Remove bus members
		for rMember in removeBootstrapMembersList:
			bName = rMember.split("{")[0]
			attrDict = self.evaluateAttributeValues(rMember.split(bName)[1])
			extAtrrs = ""
			for key in attrDict.keys():
				extAtrrs = extAtrrs + " -" + key + " " + attrDict[key]
			#endFor
			print "Removing bootstrap member: " +  rMember
			AdminTask.removeSIBBootstrapMember(self.processAdminTaskArgs('-bus ' + bName + extAtrrs))
		#endFor
	#endDef
	
	def executeConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		## Get the list of bootstrap members available in WebSphere
		bootstrapMemberNames = self.getBootstrapMembers()
		SCRIPT_LOGGER.debug("Bootstrap members in WebSphere: " + str(bootstrapMemberNames))
		
		## Remove bootstrap members NOT specified in RAF xml
		self.removeBootstrapMembers(bootstrapMemberNames, nodeArray)
		
		## Create new bootstrap members as specifed in RAF xml
		self.createBootstrapMembers(nodeArray, bootstrapMemberNames)
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def augmentConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		## Bootstrap members can only be created or removed, not modified
		## Hence invoke createBootstrapMembers() to create newly, if any 
		bootstrapMemberNames = self.getBootstrapMembers()
		SCRIPT_LOGGER.debug("Bus members in WebSphere: " + str(bootstrapMemberNames))
		self.createBootstrapMembers(nodeArray, bootstrapMemberNames)
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef	
	
#endClass

class Security(SIBMediator):

	destinationSecurityRole = 'RAF_SIB_DestinationRole'
	topicSecurityRole = 'RAF_SIB_TopicRole'
	foreignBusSecurityRole = 'RAF_SIB_ForeignBusRole'
	busConnectorRole = 'RAF_SIB_BusConnectorRole'
	defaultRole = 'RAF_SIB_DefaultRole'
	
	destinationTypes = ['Queue', 'TopicSpace', 'ForeignDestination', 'Alias', 'Port', 'Webservice']
	queueRoleTypes = ['Sender', 'Receiver', 'Browser', 'Creator', 'IdentityAdopter']
	topicRoleTypes = ['Sender', 'Receiver', 'IdentityAdopter']
	foreignRoleTypes = ['Sender', 'IdentityAdopter']
	aliasRoleTypes = ['Sender', 'Receiver', 'Browser', 'IdentityAdopter']
		
	foreignBusName = ''
	
	def readDestinationRole(self, parentID, busName, destinationType, roleTypes):
		SCRIPT_LOGGER.traceEnter([busName, destinationType])
		data = []
		destinationsWithRoles = AdminTask.listAllDestinationsWithRoles(self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destinationType)).split(newline)
		if ((destinationsWithRoles is None) or (destinationsWithRoles[0] == '')):
			return data
		for destinationWithRole in destinationsWithRoles:
			parent = {}
			parent[ID] = parentID
			parent[ATTRS] = {}
			parent[CHILDREN] = []
			parent[ATTRS]['type'] = destinationType
			parent[ATTRS]['destination'] = destinationWithRole
			
			child = {}
			child[ID] = 'SIBus'
			child[ATTRS] = {}
			child[CHILDREN] = []
			child[ATTRS]['name'] = busName
			child[ATTRS]['RAFW_TYPE'] = 'reference'
			parent[CHILDREN].append(child)
			
			if (destinationType == 'TopicSpace'):
				topicData = self.readTopicRole(self.topicSecurityRole, busName, destinationWithRole, roleTypes)
				parent[CHILDREN].extend(topicData)
				#endIf
			#endIf
			if (destinationType == 'ForeignDestination'):
				destinations = AdminTask.listSIBDestinations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
				for destination in destinations:
					if ((destination is None) or (destination == '')):
						continue
					destinationName = AdminConfig.showAttribute(destination, "identifier")
					if (destinationName == destinationWithRole):
						parent[ATTRS]['foreignBus'] = AdminConfig.showAttribute(destination, "bus")
						break
					#endIf
				#endFor
			#endIf
			
			for role in roleTypes:
				if (destinationType == 'ForeignDestination'):
					users = AdminTask.listUsersInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destinationType + ' -destination ' + destinationWithRole + ' -foreignBus ' + parent[ATTRS]['foreignBus'] + ' -role ' + role)).split(newline)
					groups = AdminTask.listGroupsInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destinationType + ' -destination ' + destinationWithRole + ' -foreignBus ' + parent[ATTRS]['foreignBus'] + ' -role ' + role)).split(newline)
				else:
					users = AdminTask.listUsersInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destinationType + ' -destination ' + destinationWithRole + ' -role ' + role)).split(newline)
					groups = AdminTask.listGroupsInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destinationType + ' -destination ' + destinationWithRole + ' -role ' + role)).split(newline)
				if ((users is not None) and (users[0] != '')):
					for user in users:
						child = {}
						child[ID] = 'SIBAuthUser'
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS]['name'] = user
						child[ATTRS]['role'] = role
						parent[CHILDREN].append(child)
					#endFor
				#endIf
				if ((groups is not None) and (groups[0] != '')):
					for group in groups:
						child = {}
						child[ID] = 'SIBAuthGroup'
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS]['name'] = group
						child[ATTRS]['role'] = role
						parent[CHILDREN].append(child)
					#endFor
				#endIf
			#endFor
			data.append(parent)
		#endFor
		SCRIPT_LOGGER.debug("Destination security config data: " + str(data))
		SCRIPT_LOGGER.traceExit([busName, destinationType])
		return data
	#endDef
	
	def readForeignBusRole(self, parentID, busName, roleTypes):
		SCRIPT_LOGGER.traceEnter(busName)
		data = []
		foreignBusesWithRoles = AdminTask.listAllForeignBusesWithRoles(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
		if ((foreignBusesWithRoles is None) or (foreignBusesWithRoles[0] == '')):
			return data
		for foreignBusWithRole in foreignBusesWithRoles:
			parent = {}
			parent[ID] = parentID
			parent[ATTRS] = {}
			parent[CHILDREN] = []
			parent[ATTRS]['foreignBus'] = foreignBusWithRole
			
			child = {}
			child[ID] = 'SIBus'
			child[ATTRS] = {}
			child[CHILDREN] = []
			child[ATTRS]['name'] = busName
			child[ATTRS]['RAFW_TYPE'] = 'reference'
			parent[CHILDREN].append(child)
			
			for role in roleTypes:
				users = AdminTask.listUsersInForeignBusRole(self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + parent[ATTRS]['foreignBus'] + ' -role ' + role)).split(newline)
				groups = AdminTask.listGroupsInForeignBusRole(self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + parent[ATTRS]['foreignBus'] + ' -role ' + role)).split(newline)
				if ((users is not None) and (users[0] != '')):
					for user in users:
						child = {}
						child[ID] = 'SIBAuthUser'
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS]['name'] = user
						child[ATTRS]['role'] = role
						parent[CHILDREN].append(child)
					#endFor
				#endIf
				if ((groups is not None) and (groups[0] != '')):
					for group in groups:
						child = {}
						child[ID] = 'SIBAuthGroup'
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS]['name'] = group
						child[ATTRS]['role'] = role
						parent[CHILDREN].append(child)
					#endFor
				#endIf
			#endFor
			data.append(parent)
		#endFor
		SCRIPT_LOGGER.debug("Foreign bus security config data: " + str(data))
		SCRIPT_LOGGER.traceExit(busName)
		return data
	#endDef
	
	def readTopicRole(self, parentID, busName, topicSpace, roleTypes):
		SCRIPT_LOGGER.traceEnter([busName, topicSpace])
		data = []
		topicsWithRoles = AdminTask.listAllTopicsWithRoles(self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpace)).split(newline)
		if ((topicsWithRoles is None) or (topicsWithRoles[0] == '')):
			return data
		for topicWithRole in topicsWithRoles:
			parent = {}
			parent[ID] = parentID
			parent[ATTRS] = {}
			parent[CHILDREN] = []
			parent[ATTRS]['topic'] = topicWithRole
		
			for role in roleTypes:
				users = AdminTask.listUsersInTopicRole(self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpace + ' -topic ' + topicWithRole + ' -role ' + role)).split(newline)
				groups = AdminTask.listGroupsInTopicRole(self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpace + ' -topic ' + topicWithRole + ' -role ' + role)).split(newline)
				if ((users is not None) and (users[0] != '')):
					for user in users:
						child = {}
						child[ID] = 'SIBAuthUser'
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS]['name'] = user
						child[ATTRS]['role'] = role
						parent[CHILDREN].append(child)
					#endFor
				#endIf
				if ((groups is not None) and (groups[0] != '')):
					for group in groups:
						child = {}
						child[ID] = 'SIBAuthGroup'
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS]['name'] = group
						child[ATTRS]['role'] = role
						parent[CHILDREN].append(child)
					#endFor
				#endIf
			#endFor
			data.append(parent)
		#endFor
		SCRIPT_LOGGER.debug("Topic security config data: " + str(data))
		SCRIPT_LOGGER.traceExit([busName, topicSpace])
		return data
	#endDef

	def readBusConnectorRole(self, parentID, busName):
		SCRIPT_LOGGER.traceEnter(busName)
		data = []
		parent = {}
		parent[ID] = parentID
		parent[ATTRS] = {}
		parent[ATTRS]['busName'] = busName
		parent[CHILDREN] = []
	
		child = {}
		child[ID] = 'SIBus'
		child[ATTRS] = {}
		child[CHILDREN] = []
		child[ATTRS]['name'] = busName
		child[ATTRS]['RAFW_TYPE'] = 'reference'
		parent[CHILDREN].append(child)
			
		users = AdminTask.listUsersInBusConnectorRole(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
		groups = AdminTask.listGroupsInBusConnectorRole(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
		if ((users is not None) and (users[0] != '')):
			for user in users:
				child = {}
				child[ID] = 'SIBAuthUser'
				child[ATTRS] = {}
				child[CHILDREN] = []
				child[ATTRS]['name'] = user
				parent[CHILDREN].append(child)
			#endFor
		#endIf
		if ((groups is not None) and (groups[0] != '')):
			for group in groups:
				child = {}
				child[ID] = 'SIBAuthGroup'
				child[ATTRS] = {}
				child[CHILDREN] = []
				child[ATTRS]['name'] = group
				parent[CHILDREN].append(child)
			#endFor
		#endIf
		data.append(parent)
		SCRIPT_LOGGER.debug("Bus connector security config data: " + str(data))
		SCRIPT_LOGGER.traceExit(busName)
		return data
	#endDef
	
	def readDefaultRole(self, parentID, busName, roleTypes):
		SCRIPT_LOGGER.traceEnter(busName)
		data = []
		parent = {}
		parent[ID] = parentID
		parent[ATTRS] = {}
		parent[ATTRS]['busName'] = busName
		parent[CHILDREN] = []
			
		child = {}
		child[ID] = 'SIBus'
		child[ATTRS] = {}
		child[CHILDREN] = []
		child[ATTRS]['name'] = busName
		child[ATTRS]['RAFW_TYPE'] = 'reference'
		parent[CHILDREN].append(child)
			
		for role in roleTypes:
			users = AdminTask.listUsersInDefaultRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role)).split(newline)
			groups = AdminTask.listGroupsInDefaultRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role)).split(newline)
			if ((users is not None) and (users[0] != '')):
				for user in users:
					child = {}
					child[ID] = 'SIBAuthUser'
					child[ATTRS] = {}
					child[CHILDREN] = []
					child[ATTRS]['name'] = user
					child[ATTRS]['role'] = role
					parent[CHILDREN].append(child)
				#endFor
			#endIf
			if ((groups is not None) and (groups[0] != '')):
				for group in groups:
					child = {}
					child[ID] = 'SIBAuthGroup'
					child[ATTRS] = {}
					child[CHILDREN] = []
					child[ATTRS]['name'] = group
					child[ATTRS]['role'] = role
					parent[CHILDREN].append(child)
				#endFor
			#endIf
		#endFor
		data.append(parent)
		SCRIPT_LOGGER.debug("Default security config data: " + str(data))
		SCRIPT_LOGGER.traceExit(busName)
		return data
	#endDef

	## Reads Security configuration from WebSphere
	
	def readConfig(self, typeName):
		SCRIPT_LOGGER.traceEnter(typeName)
		data = []
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)

			busConnectorData = self.readBusConnectorRole(self.busConnectorRole, busName)
			data.extend(busConnectorData)
			
			defaultRoleData = self.readDefaultRole(self.defaultRole, busName, self.queueRoleTypes)
			data.extend(defaultRoleData)
			
			for destinationType in self.destinationTypes:
				destData = []
				if (destinationType == 'Queue' or destinationType == 'Port' or destinationType == 'Webservice'):
					destData = self.readDestinationRole(self.destinationSecurityRole, busName, destinationType, self.queueRoleTypes)
				elif (destinationType == 'TopicSpace'):
					destData = self.readDestinationRole(self.destinationSecurityRole, busName, destinationType, self.topicRoleTypes)
				elif (destinationType == 'ForeignDestination'):
					destData = self.readDestinationRole(self.destinationSecurityRole, busName, destinationType, self.foreignRoleTypes)
				elif (destinationType == 'Alias'):
					destData = self.readDestinationRole(self.destinationSecurityRole, busName, destinationType, self.aliasRoleTypes)
				else:
					raise "Invalid Destination type specified: " + str(destinationType)
				#endIf
				data.extend(destData)
			#endFor
			
			foreignBusData = self.readForeignBusRole(self.foreignBusSecurityRole, busName, self.foreignRoleTypes)
			data.extend(foreignBusData)
			
		#endFor
		SCRIPT_LOGGER.debug("Security config data: " + str(data))
		SCRIPT_LOGGER.traceExit(typeName)
		return data
	#endDef	

	## Modifies Mediation configuration from WebSphere
	
	def executeConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'false')
	#endDef	
	
	## Modifies Mediation configuration from WebSphere
	
	def augmentConfig(self, xmlFile, marker, typeName):
		self.writeConfig(xmlFile, marker, typeName, 'true')
	#endDef	

	def compareConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		xmlConfigReader = XMLConfigReader()
		nodeArray = []

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray.append(xmlProp)
		rafwConfig = xmlConfigReader.readXmlConfig(nodeArray)
		if (rafwConfig[0].has_key(CHILDREN)):
			rafwConfig = rafwConfig[0][CHILDREN]
		#endIf 
		wasConfig = self.readConfig(typeName)
		
		## Compare WebSphere and RAF configuration
		SCRIPT_LOGGER.debug("WebSphere config: " + str(wasConfig) + ", RAF config: " + str(rafwConfig)) 
		ConfigComparor.compare(typeName, wasConfig, rafwConfig)
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def writeConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		self.writeBusConnectorConfig(xmlFile, marker, self.busConnectorRole, isAugment)
		self.writeDefaultRoleConfig(xmlFile, marker, self.defaultRole, isAugment)
		self.writeDestinationRoleConfig(xmlFile, marker, self.destinationSecurityRole, isAugment)
		self.writeTopicRoleConfig(xmlFile, marker, self.topicSecurityRole, isAugment)
		self.writeForeignBusRoleConfig(xmlFile, marker, self.foreignBusSecurityRole, isAugment)
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def writeForeignBusRoleConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])

		GROUPS = 'GROUPS'
		USERS = 'USERS'

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		rafFBConfig = {}
		for xmlNode in nodeArray:
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			busName = sibusArr[0].getAttrValue('name')
			foreignBusName = xmlNode.getAttrValue('foreignBus')
			if (not rafFBConfig.has_key(busName)):
				rafFBConfig[busName] = {}
			rafFBConfig[busName][foreignBusName] = {}
			rafFBConfig[busName][foreignBusName][GROUPS] = []
			rafFBConfig[busName][foreignBusName][USERS] = []
			sibAuthGroupArr = xmlNode.getFilteredChildrenArray('SIBAuthGroup')
			if ((sibAuthGroupArr is not None) and (len(sibAuthGroupArr) > 0)):
				for sibAuthGroup in sibAuthGroupArr:
					rafFBConfig[busName][foreignBusName][GROUPS].append(sibAuthGroup.getAttrValue('name'))
					rafFBConfig[busName][foreignBusName][GROUPS].append(sibAuthGroup.getAttrValue('role'))
				#endFor
			#endIf
			sibAuthUserArr = xmlNode.getFilteredChildrenArray('SIBAuthUser')
			if ((sibAuthUserArr is not None) and (len(sibAuthUserArr) > 0)):
				for sibAuthUser in sibAuthUserArr:
					rafFBConfig[busName][foreignBusName][USERS].append(sibAuthUser.getAttrValue('name'))
					rafFBConfig[busName][foreignBusName][USERS].append(sibAuthUser.getAttrValue('role'))
				#endFor
			#endIf
		#endFor
		
		wasFBConfig = {}
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			wasFBConfig[busName] = {}
			foreignBusesWithRoles = AdminTask.listAllForeignBusesWithRoles(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			if (foreignBusesWithRoles is not None and (foreignBusesWithRoles[0] != '')):
				for foreignBus in foreignBusesWithRoles:
					wasFBConfig[busName][foreignBus] = {}
					wasFBConfig[busName][foreignBus][GROUPS] = []
					wasFBConfig[busName][foreignBus][USERS] = []
					for role in self.foreignRoleTypes:
						groups = AdminTask.listGroupsInForeignBusRole(self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + foreignBus + ' -role ' + role)).split(newline)
						if (groups is not None and (groups[0] != '')):
							for group in groups:
								wasFBConfig[busName][foreignBus][GROUPS].append(group)	
								wasFBConfig[busName][foreignBus][GROUPS].append(role)
							#endFor
						#endIf
						users = AdminTask.listUsersInForeignBusRole(self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + foreignBus + ' -role ' + role)).split(newline)
						if (users is not None and (users[0] != '')):
							for user in users:
								wasFBConfig[busName][foreignBus][USERS].append(user)	
								wasFBConfig[busName][foreignBus][USERS].append(role)
							#endFor
						#endIf
					#endFor
				#endFor
			#endIf
		#endFor

		SCRIPT_LOGGER.debug("RAF config for foreign bus security: " + str(rafFBConfig))
		SCRIPT_LOGGER.debug("WAS config for foreign bus security: " + str(wasFBConfig))
		
		if (isAugment == 'false'):
			for busName in wasFBConfig.keys():
				for wasForeignBus in wasFBConfig[busName].keys():
					wasGroupArr = wasFBConfig[busName][wasForeignBus][GROUPS]
					wasUserArr = wasFBConfig[busName][wasForeignBus][USERS]
					if ((rafFBConfig.has_key(busName)) and (rafFBConfig[busName].has_key(wasForeignBus))):
						rafGroupArr = rafFBConfig[busName][wasForeignBus][GROUPS]
						for i in range(0, len(wasGroupArr), 2):
							wasGroup = wasGroupArr[i]
							wasRole = wasGroupArr[i + 1]
							if (wasGroup in rafGroupArr):
								groupRoleFound = 'false'
								for j in range(0, len(rafGroupArr), 2):
									rafGroup = rafGroupArr[j]
									rafRole = rafGroupArr[j + 1]
									if ((rafGroup == wasGroup) and (rafRole == wasRole)):
										groupRoleFound = 'true'
										break
									#endIf
								#endFor
								if (groupRoleFound == 'false'):
									SCRIPT_LOGGER.debug("Role: " + wasRole + "for Group: " + wasGroup + " not found in RAF config")
									cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + wasForeignBus + ' -group ' + wasGroup + ' -role ' + wasRole)
									print "Removing Group from foreign bus security: " + str(cmdArr)
									AdminTask.removeGroupFromForeignBusRole(cmdArr)
								#endIf
							else:
								SCRIPT_LOGGER.debug("Group: " + wasGroup + " not found in RAF config")
								cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + wasForeignBus + ' -group ' + wasGroup + ' -role ' + wasRole)
								print "Removing Group from foreign bus security: " + str(cmdArr)
								AdminTask.removeGroupFromForeignBusRole(cmdArr)
							#endIf
						#endFor
						rafUserArr = rafFBConfig[busName][wasForeignBus][USERS]
						for i in range(0, len(wasUserArr), 2):
							wasUser = wasUserArr[i]
							wasRole = wasUserArr[i + 1]
							if (wasUser in rafUserArr):
								userRoleFound = 'false'
								for j in range(0, len(rafUserArr), 2):
									rafUser = rafUserArr[j]
									rafRole = rafUserArr[j + 1]
									if ((rafUser == wasUser) and (rafRole == wasRole)):
										userRoleFound = 'true'
										break
									#endIf
								#endFor
								if (userRoleFound == 'false'):
									SCRIPT_LOGGER.debug("Role: " + wasRole + "for User: " + wasUser + " not found in RAF config")
									cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + wasForeignBus + ' -user ' + wasUser + ' -role ' + wasRole)
									print "Removing User from foreign bus security: " + str(cmdArr)
									AdminTask.removeUserFromForeignBusRole(cmdArr)
								#endIf
							else:
								SCRIPT_LOGGER.debug("User: " + wasUser + " not found in RAF config")
								cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + wasForeignBus + ' -user ' + wasUser + ' -role ' + wasRole)
								print "Removing User from foreign bus security: " + str(cmdArr)
								AdminTask.removeUserFromForeignBusRole(cmdArr)
							#endIf
						#endFor
					else:
						for i in range(0, len(wasGroupArr), 2):
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + wasForeignBus + ' -group ' + wasGroupArr[i] + ' -role ' + wasGroupArr[i + 1])
							print "Removing Group from foreign bus security: " + str(cmdArr)
							AdminTask.removeGroupFromForeignBusRole(cmdArr)
						#endFor
						for i in range(0, len(wasUserArr), 2):
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + wasForeignBus + ' -user ' + wasUserArr[i] + ' -role ' + wasUserArr[i + 1])
							print "Removing User from foreign bus security: " + str(cmdArr)
							AdminTask.removeUserFromForeignBusRole(cmdArr)
						#endFor
					#endIf
				#endFor
			#endFor		
		#endIf
		
		#Now add all Foreign Bus configuration present in RAF data file to WAS
		for busName in rafFBConfig.keys():
			for foreignBus in rafFBConfig[busName].keys():
				rafGroupArr = rafFBConfig[busName][foreignBus][GROUPS]
				for i in range(0, len(rafGroupArr), 2):
					cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + foreignBus + ' -group ' + rafGroupArr[i] + ' -role ' + rafGroupArr[i + 1])
					print "Adding Group to foreign bus security: " + str(cmdArr)
					AdminTask.addGroupToForeignBusRole(cmdArr)
				#endFor
				rafUserArr = rafFBConfig[busName][foreignBus][USERS]
				for i in range(0, len(rafUserArr), 2):
					cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -foreignBus ' + foreignBus + ' -user ' + rafUserArr[i] + ' -role ' + rafUserArr[i + 1])
					print "Adding User to foreign bus security: " + str(cmdArr)
					AdminTask.addUserToForeignBusRole(cmdArr)
				#endFor
			#endFor
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def writeTopicRoleConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])

		GROUPS = 'GROUPS'
		USERS = 'USERS'

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(self.destinationSecurityRole)
		
		rafTopicConfig = {}
		for xmlNode in nodeArray:
			destType = xmlNode.getAttrValue('type')
			destName = xmlNode.getAttrValue('destination')
			if (destType == 'TopicSpace'):
				sibTopicNodeArr = xmlNode.getFilteredChildrenArray(self.topicSecurityRole)
				if (sibTopicNodeArr is not None and (len(sibTopicNodeArr) > 0)):
					sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
					busName = sibusArr[0].getAttrValue('name')
					rafTopicConfig[busName] = {}
					rafTopicConfig[busName][destName] = {}
					for sibTopicNode in sibTopicNodeArr:
						topicName = sibTopicNode.getAttrValue('topic') 
						rafTopicConfig[busName][destName][GROUPS] = []
						rafTopicConfig[busName][destName][USERS] = []
						sibAuthGroupArr = sibTopicNode.getFilteredChildrenArray('SIBAuthGroup')
						if ((sibAuthGroupArr is not None) and (len(sibAuthGroupArr) > 0)):
							for sibAuthGroup in sibAuthGroupArr:
								rafTopicConfig[busName][destName][GROUPS].append(topicName)
								rafTopicConfig[busName][destName][GROUPS].append(sibAuthGroup.getAttrValue('name'))
								rafTopicConfig[busName][destName][GROUPS].append(sibAuthGroup.getAttrValue('role'))
							#endFor
						#endIf
						sibAuthUserArr = sibTopicNode.getFilteredChildrenArray('SIBAuthUser')
						if ((sibAuthUserArr is not None) and (len(sibAuthUserArr) > 0)):
							for sibAuthUser in sibAuthUserArr:
								rafTopicConfig[busName][destName][USERS].append(topicName)
								rafTopicConfig[busName][destName][USERS].append(sibAuthUser.getAttrValue('name'))
								rafTopicConfig[busName][destName][USERS].append(sibAuthUser.getAttrValue('role'))
							#endFor
						#endIf
					#endFor
				#endIf
			#endIf
		#endFor
		
		wasTopicConfig= {}
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			wasTopicConfig[busName] = {}
			topicSpacesWithRoles = AdminTask.listAllDestinationsWithRoles(self.processAdminTaskArgs('-bus ' + busName + ' -type TopicSpace')).split(newline)
			if (topicSpacesWithRoles is not None and (topicSpacesWithRoles[0] != '')):
				for topicSpaceWithRole in topicSpacesWithRoles:
					topicsWithRoles = AdminTask.listAllTopicsWithRoles(self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceWithRole)).split(newline)
					if (topicsWithRoles is not None and (topicsWithRoles[0] != '')):
						for topic in topicsWithRoles:
							wasTopicConfig[busName][topicSpaceWithRole] = {}
							wasTopicConfig[busName][topicSpaceWithRole][GROUPS] = []
							wasTopicConfig[busName][topicSpaceWithRole][USERS] = []
							for role in self.topicRoleTypes:
								groups = AdminTask.listGroupsInTopicRole(self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceWithRole + ' -topic ' + topic + ' -role ' + role)).split(newline)
								if (groups is not None and (groups[0] != '')):
									for group in groups:
										wasTopicConfig[busName][topicSpaceWithRole][GROUPS].append(topic)
										wasTopicConfig[busName][topicSpaceWithRole][GROUPS].append(group)
										wasTopicConfig[busName][topicSpaceWithRole][GROUPS].append(role)
									#endFor
								#endIf
								users = AdminTask.listUsersInTopicRole(self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceWithRole + ' -topic ' + topic + ' -role ' + role)).split(newline)
								if (users is not None and (users[0] != '')):
									for user in users:
										wasTopicConfig[busName][topicSpaceWithRole][USERS].append(topic)
										wasTopicConfig[busName][topicSpaceWithRole][USERS].append(user)
										wasTopicConfig[busName][topicSpaceWithRole][USERS].append(role)
									#endFor
								#endIf
							#endFor
						#endFor
					#endIf
				#endFor
			#endIf
		#endFor

		SCRIPT_LOGGER.debug("RAF config for topic security: " + str(rafTopicConfig))
		SCRIPT_LOGGER.debug("WAS config for topic security: " + str(wasTopicConfig))
		
		if (isAugment == 'false'):
			for busName in wasTopicConfig.keys():
				for topicSpaceName in wasTopicConfig[busName].keys():
					wasGroupArr = wasTopicConfig[busName][topicSpaceName][GROUPS]
					wasUserArr = wasTopicConfig[busName][topicSpaceName][USERS]
					if ((rafTopicConfig.has_key(busName)) and (rafTopicConfig[busName].has_key(topicSpaceName))):
						rafGroupArr = rafTopicConfig[busName][topicSpaceName][GROUPS]
						for i in range(0, len(wasGroupArr), 3):
							wasTopic = wasGroupArr[i]
							wasGroup = wasGroupArr[i + 1]
							wasRole = wasGroupArr[i + 2]
							if ((wasTopic in rafGroupArr) and (wasGroup in rafGroupArr)):
								topicGroupRoleFound = 'false'
								for j in range(0, len(rafGroupArr), 3):
									rafTopic = rafGroupArr[j]
									rafGroup = rafGroupArr[j + 1]
									rafRole = rafGroupArr[j + 2]
									if ((wasTopic == rafTopic) and (wasGroup == rafGroup) and (wasRole == rafRole)):
										topicGroupRoleFound = 'true'
										break
									#endIf
								#endFor
								if (topicGroupRoleFound == 'false'):
									SCRIPT_LOGGER.debug("Group: " + wasGroup + " with role: " + wasRole + " not found for topic: " + wasTopic)
									cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceName + ' -topic ' + wasTopic + ' -group ' + wasGroup + ' -role ' + wasRole)
									print "Removing Group from topic security config: " + str(cmdArr)
									AdminTask.removeGroupFromTopicRole(cmdArr)
								#endIf
							else:
								SCRIPT_LOGGER.debug("Group: " + wasGroup + " with role: " + wasRole + " not found for topic: " + wasTopic)
								cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceName + ' -topic ' + wasTopic + ' -group ' + wasGroup + ' -role ' + wasRole)
								print "Removing Group from topic security config: " + str(cmdArr)
								AdminTask.removeGroupFromTopicRole(cmdArr)
							#endIf	
						#endFor	
						rafUserArr = rafTopicConfig[busName][topicSpaceName][USERS]
						for i in range(0, len(wasUserArr), 3):
							wasTopic = wasUserArr[i]
							wasUser = wasUserArr[i + 1]
							wasRole = wasUserArr[i + 2]
							if ((wasTopic in rafUserArr) and (wasUser in rafUserArr)):
								topicUserRoleFound = 'false'
								for j in range(0, len(rafUserArr), 3):
									rafTopic = rafUserArr[j]
									rafUser = rafUserArr[j + 1]
									rafRole = rafUserArr[j + 2]
									if ((wasTopic == rafTopic) and (wasUser == rafUser) and (wasRole == rafRole)):
										topicUserRoleFound = 'true'
										break
									#endIf
								#endFor
								if (topicUserRoleFound == 'false'):
									SCRIPT_LOGGER.debug("User: " + wasUser + " with role: " + wasRole + " not found for topic: " + wasTopic)
									cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceName + ' -topic ' + wasTopic + ' -user ' + wasUser + ' -role ' + wasRole)
									print "Removing User from topic security config: " + str(cmdArr)
									AdminTask.removeUserFromTopicRole(cmdArr)
								#endIf
							else:
								SCRIPT_LOGGER.debug("User: " + wasUser + " with role: " + wasRole + " not found for topic: " + wasTopic)
								cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceName + ' -topic ' + wasTopic + ' -user ' + wasUser + ' -role ' + wasRole)
								print "Removing User from topic security config: " + str(cmdArr)
								AdminTask.removeUserFromTopicRole(cmdArr)
							#endIf
						#endFor
					else:
						for i in range(0, len(wasGroupArr), 3):
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceName + ' -topic ' + wasGroupArr[i] + ' -group ' + wasGroupArr[i + 1] + ' -role ' + wasGroupArr[i + 2])
							print "Removing Group from topic security config: " + str(cmdArr)
							AdminTask.removeGroupFromTopicRole(cmdArr)
						#endFor
						for i in range(0, len(wasUserArr), 3):
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpaceName + ' -topic ' + wasUserArr[i] + ' -user ' + wasUserArr[i + 1] + ' -role ' + wasUserArr[i + 2])
							print "Removing User from topic security config: " + str(cmdArr)
							AdminTask.removeUserFromTopicRole(cmdArr)
						#endFor
					#endIf
				#endFor
			#endFor
		#endIf
		
		#Now add all RAF roles from data file to WAS
		for busName in rafTopicConfig.keys():
			for topicSpace in rafTopicConfig[busName].keys():
				rafGroupArr = rafTopicConfig[busName][topicSpace][GROUPS]
				rafUserArr = rafTopicConfig[busName][topicSpace][USERS]
				for i in range(0, len(rafGroupArr), 3):
					cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpace + ' -topic ' + rafGroupArr[i] + ' -group ' + rafGroupArr[i + 1] + ' -role ' + rafGroupArr[i + 2])
					print "Adding Group to topic security config: " + str(cmdArr)
					AdminTask.addGroupToTopicRole(cmdArr)
				#endFor
				for i in range(0, len(rafUserArr), 3):
					cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -topicSpace ' + topicSpace + ' -topic ' + rafUserArr[i] + ' -user ' + rafUserArr[i + 1] + ' -role ' + rafUserArr[i + 2])
					print "Adding User to topic security config: " + str(cmdArr)
					AdminTask.addUserToTopicRole(cmdArr)
				#endFor
			#endFor
		#endFor	
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def writeBusConnectorConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		GROUPS = 'GROUPS'
		USERS = 'USERS'
		
		rafBusConnectorConfig = {}
		for xmlNode in nodeArray:
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			busName = sibusArr[0].getAttrValue('name')
			rafBusConnectorConfig[busName] = {}
			rafBusConnectorConfig[busName][GROUPS] = []
			rafBusConnectorConfig[busName][USERS] = []
			sibAuthGroupArr = xmlNode.getFilteredChildrenArray('SIBAuthGroup')
			if ((sibAuthGroupArr is not None) and (len(sibAuthGroupArr) > 0)):
				for sibAuthGroup in sibAuthGroupArr:
					groupName = sibAuthGroup.getAttrValue('name')
					rafBusConnectorConfig[busName][GROUPS].append(groupName)
				#endFor
			#endIf
			sibAuthUserArr = xmlNode.getFilteredChildrenArray('SIBAuthUser')
			if ((sibAuthUserArr is not None) and (len(sibAuthUserArr) > 0)):
				for sibAuthUser in sibAuthUserArr:
					userName = sibAuthUser.getAttrValue('name')
					rafBusConnectorConfig[busName][USERS].append(userName)
				#endFor
			#endIf
		#endFor
		
		wasBusConnectorConfig = {}
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			wasBusConnectorConfig[busName] = {}
			wasBusConnectorConfig[busName][GROUPS] = []
			wasBusConnectorConfig[busName][USERS] = []
			users = AdminTask.listUsersInBusConnectorRole(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			if ((users is not None) and (users[0] != '')):
				wasBusConnectorConfig[busName][USERS].extend(users)
			#endIf
			groups = AdminTask.listGroupsInBusConnectorRole(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			if ((groups is not None) and (groups[0] != '')):
				wasBusConnectorConfig[busName][GROUPS].extend(groups)
			#endIf
		#endFor

		SCRIPT_LOGGER.debug("RAF config for bus connector roles: " + str(rafBusConnectorConfig))
		SCRIPT_LOGGER.debug("WAS config for bus connector roles: " + str(wasBusConnectorConfig))
		
		if (isAugment == 'false'):
			#remove users/groups in WAS that are not in RAF data file
			for busName in wasBusConnectorConfig.keys():
				wasBusGroups = wasBusConnectorConfig[busName][GROUPS]
				wasBusUsers = wasBusConnectorConfig[busName][USERS]
				if (rafBusConnectorConfig.has_key(busName)):
					rafBusGroups = rafBusConnectorConfig[busName][GROUPS]
					for wasBusGroup in wasBusGroups:
						if (wasBusGroup not in rafBusGroups):
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -group ' + wasBusGroup)
							print "Removing Group from bus connector role: " + str(cmdArr)
							AdminTask.removeGroupFromBusConnectorRole(cmdArr)
						#endIf
					#endFor
					rafBusUsers = rafBusConnectorConfig[busName][USERS]
					for wasBusUser in wasBusUsers:
						if (wasBusUser not in rafBusUsers):
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -user ' + wasBusUser)
							print "Removing User from bus connector role: " + str(cmdArr)
							AdminTask.removeUserFromBusConnectorRole(cmdArr)
						#endIf
					#endFor
				else:
					for wasBusGroup in wasBusGroups:
						cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -group ' + wasBusGroup)
						print "Removing Group from bus connector role: " + str(cmdArr)
						AdminTask.removeGroupFromBusConnectorRole(cmdArr)
					for wasBusUser in wasBusUsers:
						cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -user ' + wasBusUser)
						print "Removing User from bus connector role: " + str(cmdArr)
						AdminTask.removeUserFromBusConnectorRole(cmdArr)
				#endIf
			#endFor			
		#endIf
		
		#Add all users/groups in RAF data file to WAS
		for busName in rafBusConnectorConfig.keys():
			rafBusGroups = rafBusConnectorConfig[busName][GROUPS]
			for rafBusGroup in rafBusGroups:
				cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -group ' + rafBusGroup)
				print "Adding Group to bus connector role: " + str(cmdArr)
				AdminTask.addGroupToBusConnectorRole(cmdArr)
			#endFor
			rafBusUsers = rafBusConnectorConfig[busName][USERS]
			for rafBusUser in rafBusUsers:
				cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -user ' + rafBusUser)
				print "Adding User to bus connector role: " + str(cmdArr)
				AdminTask.addUserToBusConnectorRole(cmdArr)
			#endFor
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def writeDefaultRoleConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
	
		GROUPS = 'GROUPS'
		USERS = 'USERS'

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		rafDefaultConfig = {}
		for xmlNode in nodeArray:
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			busName = sibusArr[0].getAttrValue('name')
			rafDefaultConfig[busName] = {}
			rafDefaultConfig[busName][GROUPS] = []
			rafDefaultConfig[busName][USERS] = []
			rafSibAuthGroupArr = xmlNode.getFilteredChildrenArray('SIBAuthGroup')
			if (rafSibAuthGroupArr is not None and (len(rafSibAuthGroupArr) > 0)):
				for rafSibAuthGroup in rafSibAuthGroupArr:
					groupName = rafSibAuthGroup.getAttrValue('name')
					role = rafSibAuthGroup.getAttrValue('role')
					rafDefaultConfig[busName][GROUPS].append(groupName)
					rafDefaultConfig[busName][GROUPS].append(role)
				#endFor
			#endIf
			rafSibAuthUserArr = xmlNode.getFilteredChildrenArray('SIBAuthUser')
			if (rafSibAuthUserArr is not None and (len(rafSibAuthUserArr) > 0)):
				for rafSibAuthUser in rafSibAuthUserArr:
					userName = rafSibAuthUser.getAttrValue('name')
					role = rafSibAuthUser.getAttrValue('role')
					rafDefaultConfig[busName][USERS].append(userName)
					rafDefaultConfig[busName][USERS].append(role)
				#endFor
			#endIf
		#endFor
		
		wasDefaultConfig = {}
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			wasDefaultConfig[busName] = {}
			wasDefaultConfig[busName][GROUPS] = []
			wasDefaultConfig[busName][USERS] = []
			for role in self.queueRoleTypes:
				groups = AdminTask.listGroupsInDefaultRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role)).split(newline)
				if ((groups is not None) and (groups[0] != '')):
					for group in groups:
						wasDefaultConfig[busName][GROUPS].append(group)
						wasDefaultConfig[busName][GROUPS].append(role)
					#endFor
				#endIf
				users = AdminTask.listUsersInDefaultRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role)).split(newline)
				if ((users is not None) and (users[0] != '')):
					for user in users:
						wasDefaultConfig[busName][USERS].append(user)
						wasDefaultConfig[busName][USERS].append(role)
					#endFor
				#endIf
			#endFor
		#endFor

		SCRIPT_LOGGER.debug("RAF config for default security: " + str(rafDefaultConfig))
		SCRIPT_LOGGER.debug("WAS config for default security: " + str(wasDefaultConfig))
		
		if (isAugment == 'false'):
			#Delete info in WAS that is not present on RAF data file
			for busName in wasDefaultConfig.keys():
				wasGroupArr = wasDefaultConfig[busName][GROUPS]
				wasUserArr = wasDefaultConfig[busName][USERS]
				if (rafDefaultConfig.has_key(busName)):
					rafGroupArr = rafDefaultConfig[busName][GROUPS]
					for i in range(0, len(wasGroupArr), 2):
						wasGroup = wasGroupArr[i]
						wasRole = wasGroupArr[i + 1]
						if (wasGroup in rafGroupArr):
							grpRoleFound = 'false'
							for j in range(0, len(rafGroupArr), 2):
								rafGroup = rafGroupArr[j]
								rafRole = rafGroupArr[j + 1]
								if ((wasGroup == rafGroup) and (wasRole == rafRole)):
									grpRoleFound = 'true'
									break
								#endIf
							#endFor
							if (grpRoleFound == 'false'):
								SCRIPT_LOGGER.debug("Default security settings for group: " + wasGroup + " for role: " + wasRole + " not found.")
								cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + wasRole + ' -group ' + wasGroup)
								print "Removing Group from default security config: " + str(cmdArr)
								AdminTask.removeGroupFromDefaultRole(cmdArr)
							#endIf
						else:
							SCRIPT_LOGGER.debug("Default security settings for group: " + wasGroup + " for role: " + wasRole + " not found.")
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + wasRole + ' -group ' + wasGroup)
							print "Removing Group from default security config: " + str(cmdArr)
							AdminTask.removeGroupFromDefaultRole(cmdArr)
						#endIf
					#endFor
					rafUserArr = rafDefaultConfig[busName][USERS]
					for i in range(0, len(wasUserArr), 2):
						wasUser = wasUserArr[i]
						wasRole = wasUserArr[i + 1]
						if (wasUser in rafUserArr):
							usrRoleFound = 'false'
							for j in range(0, len(rafUserArr), 2):
								rafUser = rafUserArr[j]
								rafRole = rafUserArr[j + 1]
								if ((wasUser == rafUser) and (wasRole == rafRole)):
									usrRoleFound = 'true'
									break
								#endIf
							#endFor
							if (usrRoleFound == 'false'):
								SCRIPT_LOGGER.debug("Default security settings for user: " + wasUser + " for role: " + wasRole + " not found.")
								cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + wasRole + ' -user ' + wasUser)
								print "Removing User from default security config: " + str(cmdArr)
								AdminTask.removeUserFromDefaultRole(cmdArr)
							#endIf
						else:
							SCRIPT_LOGGER.debug("Default security settings for user: " + wasUser + " for role: " + wasRole + " not found.")
							cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + wasRole + ' -user ' + wasUser)
							print "Removing User from default security config: " + str(cmdArr)
							AdminTask.removeUserFromDefaultRole(cmdArr)
						#endIf	
					#endFor
				else: #remove entire GROUP and USER array from WAS
					for i in range(0, len(wasGroupArr), 2):
						cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + wasGroupArr[i + 1] + ' -group ' + wasGroupArr[i])
						print "Removing Group from default security config: " + str(cmdArr)
						AdminTask.removeGroupFromDefaultRole(cmdArr)
					#endFor
					for i in range(0, len(wasUserArr), 2):
						cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + wasUserArr[i + 1] + ' -user ' + wasUserArr[i])
						print "Removing User from default security config: " + str(cmdArr)
						AdminTask.removeUserFromDefaultRole(cmdArr)
				#endIf					
			#endFor				
		#endIf
		
		#Else add all groups/users in RAF data file to WAS.
		for busName in rafDefaultConfig.keys():
			rafGroupArr = rafDefaultConfig[busName][GROUPS]
			for i in range(0, len(rafGroupArr), 2):
				cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + rafGroupArr[i + 1] + ' -group ' + rafGroupArr[i])
				print "Adding Group to default security config: " + str(cmdArr)
				AdminTask.addGroupToDefaultRole(cmdArr)
			#endFor
			rafUserArr = rafDefaultConfig[busName][USERS]
			for i in range(0, len(rafUserArr), 2):
				cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -role ' + rafUserArr[i + 1] + ' -user ' + rafUserArr[i])
				print "Adding User to default security config: " + str(cmdArr)
				AdminTask.addUserToDefaultRole(cmdArr)
			#endFor
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def writeDestinationRoleConfig(self, xmlFile, marker, typeName, isAugment):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
	
		GROUPS = 'GROUPS'
		USERS = 'USERS'
		DEST = 'DESTINATION'

		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		
		rafDestinationConfig = {}
		for xmlNode in nodeArray:
			sibusArr = xmlNode.getFilteredChildrenArray('SIBus')
			busName = sibusArr[0].getAttrValue('name')
			if (not rafDestinationConfig.has_key(busName)):
				rafDestinationConfig[busName] = {}
			destName = xmlNode.getAttrValue('destination')
			rafDestinationConfig[busName][destName] = {}
			rafDestinationConfig[busName][destName][DEST] = []
			rafDestinationConfig[busName][destName][GROUPS] = []
			rafDestinationConfig[busName][destName][USERS] = []
			rafDestinationConfig[busName][destName][DEST].append(xmlNode.getAttrValue('type'))
			if (xmlNode.hasAttr('foreignBus')):
				rafDestinationConfig[busName][destName][DEST].append(xmlNode.getAttrValue('foreignBus'))
			#endIf
			rafSibAuthGroupArr = xmlNode.getFilteredChildrenArray('SIBAuthGroup')
			if (rafSibAuthGroupArr is not None and (len(rafSibAuthGroupArr) > 0)):
				for rafSibAuthGroup in rafSibAuthGroupArr:
					rafDestinationConfig[busName][destName][GROUPS].append(rafSibAuthGroup.getAttrValue('name'))
					rafDestinationConfig[busName][destName][GROUPS].append(rafSibAuthGroup.getAttrValue('role'))
				#endFor
			#endIf
			rafSibAuthUserArr = xmlNode.getFilteredChildrenArray('SIBAuthUser')
			if (rafSibAuthUserArr is not None and (len(rafSibAuthUserArr) > 0)):
				for rafSibAuthUser in rafSibAuthUserArr:
					rafDestinationConfig[busName][destName][USERS].append(rafSibAuthUser.getAttrValue('name'))
					rafDestinationConfig[busName][destName][USERS].append(rafSibAuthUser.getAttrValue('role'))
				#endFor
			#endIf
		#endFor
		
		wasDestinationConfig = {}
		siBuses = AdminTask.listSIBuses().split(newline)
		for bus in siBuses:
			if (bus == ''):
				continue
			#endIf
			busName = self.getName(bus)
			wasDestinationConfig[busName] = {}
			for destType in self.destinationTypes:
				wasDestinations = AdminTask.listAllDestinationsWithRoles(self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType)).split(newline)
				if ((wasDestinations is None) or (wasDestinations[0] == '')):
					continue
				for wasDestination in wasDestinations:
					wasDestinationConfig[busName][wasDestination] = {}
					wasDestinationConfig[busName][wasDestination][GROUPS] = []
					wasDestinationConfig[busName][wasDestination][USERS] = []
					wasDestinationConfig[busName][wasDestination][DEST] = []
					groups = self.getGroupsForDestination(busName, wasDestination, destType)
					wasDestinationConfig[busName][wasDestination][GROUPS].extend(groups)
					users = self.getUsersForDestination(busName, wasDestination, destType)
					wasDestinationConfig[busName][wasDestination][USERS].extend(users)
					wasDestinationConfig[busName][wasDestination][DEST].append(destType)
					if (destType == 'ForeignDestination'):
						wasDestinationConfig[busName][wasDestination][DEST].append(self.foreignBusName)
						self.foreignBusName = ''
					#endIf
				#endFor
			#endFor
		#endFor

		SCRIPT_LOGGER.debug("RAF config for destination security: " + str(rafDestinationConfig))
		SCRIPT_LOGGER.debug("WAS config for destination security: " + str(wasDestinationConfig))
		
		if (isAugment == 'false'):
			for busName in wasDestinationConfig.keys():
				for destination in wasDestinationConfig[busName].keys():
					wasDestinationArr = wasDestinationConfig[busName][destination][DEST]
					wasGroupArr = wasDestinationConfig[busName][destination][GROUPS]
					wasUserArr = wasDestinationConfig[busName][destination][USERS]
					if (rafDestinationConfig.has_key(busName) and (rafDestinationConfig[busName].has_key(destination))):
						rafDestinationArr = rafDestinationConfig[busName][destination][DEST]
						rafGroupArr = rafDestinationConfig[busName][destination][GROUPS]
						rafUserArr = rafDestinationConfig[busName][destination][USERS]
						for i in range(0, len(wasGroupArr), 2):
							wasGroup = wasGroupArr[i]
							wasRole = wasGroupArr[i + 1]
							if (wasGroup in rafGroupArr):
								groupRoleFound = 'false'
								for j in range(0, len(rafGroupArr), 2):
									rafGroup = rafGroupArr[j]
									rafRole = rafGroupArr[j + 1]
									if ((wasGroup == rafGroup) and (wasRole == rafRole)):
										groupRoleFound = 'true'
										break
									#endIf
								#endFor
								if (groupRoleFound == 'false'):
									self.removeGroup(busName, destination, wasDestinationArr, wasGroup, wasRole)
								#endIf 
							else:
								self.removeGroup(busName, destination, wasDestinationArr, wasGroup, wasRole)
							#endIf
						#endFor
						for i in range(0, len(wasUserArr), 2):
							wasUser = wasUserArr[i]
							wasRole = wasUserArr[i + 1]
							if (wasUser in rafUserArr):
								userRoleFound = 'false'
								for j in range(0, len(rafUserArr), 2):
									rafUser = rafUserArr[j]
									rafRole = rafUserArr[j + 1]
									if ((wasUser == rafUser) and (wasRole == rafRole)):
										userRoleFound = 'true'
										break
									#endIf
								#endFor
								if (userRoleFound == 'false'):
									self.removeUser(busName, destination, wasDestinationArr, wasUser, wasRole)
								#endIf 
							else:
								self.removeUser(busName, destination, wasDestinationArr, wasUser, wasRole)
							#endIf
						#endFor
					else: #no destination by this name in RAF data file hence remove it from WAS
						for i in range(0, len(wasGroupArr), 2):
							self.removeGroup(busName, destination, wasDestinationArr, wasGroupArr[i], wasGroupArr[i + 1])
						#endFor
						for i in range(0, len(wasUserArr), 2):
							self.removeUser(busName, destination, wasDestinationArr, wasUserArr[i], wasUserArr[i + 1])
						#endFor
					#endIf
				#endFor
			#endFor
		#endIf
					
		#Now add all users/groups in RAF data file to WAS security config
		for busName in rafDestinationConfig.keys():
			for destination in rafDestinationConfig[busName].keys():
				rafDestArr = rafDestinationConfig[busName][destination][DEST]
				rafGroupArr = rafDestinationConfig[busName][destination][GROUPS]		
				rafUserArr = rafDestinationConfig[busName][destination][USERS]
				for i in range(0, len(rafGroupArr), 2):
					self.addGroup(busName, destination, rafDestArr, rafGroupArr[i], rafGroupArr[i + 1])
				#endFor
				for i in range(0, len(rafUserArr), 2):
					self.addUser(busName, destination, rafDestArr, rafUserArr[i], rafUserArr[i + 1])
				#endFor
			#endFor
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def removeGroup(self, busName, destName, destArr, group, role):
		destType = destArr[0]
		if (destType == 'ForeignDestination'):
			foreignBus = destArr[1]
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -foreignBus ' + foreignBus + ' -destination ' + destName + ' -group ' + group + ' -role ' + role)
			print "Removing Group from destination security role: " + str(cmdArr)
			AdminTask.removeGroupFromDestinationRole(cmdArr)
		else:
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -destination ' + destName + ' -group ' + group + ' -role ' + role)
			print "Removing Group from destination security role: " + str(cmdArr)
			AdminTask.removeGroupFromDestinationRole(cmdArr)
	#endDef
	
	def addGroup(self, busName, destName, destArr, group, role):
		destType = destArr[0]
		if (destType == 'ForeignDestination'):
			foreignBus = destArr[1]
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -foreignBus ' + foreignBus + ' -destination ' + destName + ' -group ' + group + ' -role ' + role)
			print "Adding Group to destination security role: " + str(cmdArr)
			AdminTask.addGroupToDestinationRole(cmdArr)
		else:
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -destination ' + destName + ' -group ' + group + ' -role ' + role)
			print "Adding Group to destination security role: " + str(cmdArr)
			AdminTask.addGroupToDestinationRole(cmdArr)
	#endDef
	
	def removeUser(self, busName, destName, destArr, user, role):
		destType = destArr[0]
		if (destType == 'ForeignDestination'):
			foreignBus = destArr[1]
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -foreignBus ' + foreignBus + ' -destination ' + destName + ' -user ' + user + ' -role ' + role)
			print "Removing User from destination security role: " + str(cmdArr)
			AdminTask.removeUserFromDestinationRole(cmdArr)
		else:
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -destination ' + destName + ' -user ' + user + ' -role ' + role)
			print "Removing User from destination security role: " + str(cmdArr)
			AdminTask.removeUserFromDestinationRole(cmdArr)
	#endDef
	
	def addUser(self, busName, destName, destArr, user, role):
		destType = destArr[0]
		if (destType == 'ForeignDestination'):
			foreignBus = destArr[1]
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -foreignBus ' + foreignBus + ' -destination ' + destName + ' -user ' + user + ' -role ' + role)
			print "Adding User to destination security role: " + str(cmdArr)
			AdminTask.addUserToDestinationRole(cmdArr)
		else:
			cmdArr = self.processAdminTaskArgs('-bus ' + busName + ' -type ' + destType + ' -destination ' + destName + ' -user ' + user + ' -role ' + role)
			print "Adding User to destination security role: " + str(cmdArr)
			AdminTask.addUserToDestinationRole(cmdArr)
	#endDef

	def getGroupsForDestination(self, busName, destName, destType):
		groups = []
		if ((destType == 'Queue') or (destType == 'Port') or (destType == 'Webservice')):
			for role in self.queueRoleTypes:
				wasGroups = AdminTask.listGroupsInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName)).split(newline)
				if ((wasGroups is not None) and (wasGroups[0] != '')):
					for wasGroup in wasGroups:
						groups.append(wasGroup)
						groups.append(role)
					#endFor
				#endIf
			#endFor
		elif (destType == 'Alias'):
			for role in self.aliasRoleTypes:
				wasGroups = AdminTask.listGroupsInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName)).split(newline)
				if ((wasGroups is not None) and (wasGroups[0] != '')):
					for wasGroup in wasGroups:
						groups.append(wasGroup)
						groups.append(role)
					#endFor
				#endIf
			#endFor
		elif (destType == 'ForeignDestination'):
			destinations = AdminTask.listSIBDestinations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for destination in destinations:
				if ((destination is None) or (destination == '')):
					continue
				destinationName = AdminConfig.showAttribute(destination, "identifier")
				if (destinationName == destName):
					self.foreignBusName = AdminConfig.showAttribute(destination, "bus")
					break
				#endIf
			#endFor
			for role in self.foreignRoleTypes:
				wasGroups = AdminTask.listGroupsInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName + ' -foreignBus ' + self.foreignBusName)).split(newline)
				if ((wasGroups is not None) and (wasGroups[0] != '')):
					for wasGroup in wasGroups:
						groups.append(wasGroup)
						groups.append(role)
					#endFor
				#endIf
			#endFor
		else: #This is Topic
			for role in self.topicRoleTypes:
				wasGroups = AdminTask.listGroupsInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName)).split(newline)
				if ((wasGroups is not None) and (wasGroups[0] != '')):
					for wasGroup in wasGroups:
						groups.append(wasGroup)
						groups.append(role)
					#endFor
				#endIf
			#endFor
		#endIf
		return groups
	#endDef	

	def getUsersForDestination(self, busName, destName, destType):
		users = []
		if ((destType == 'Queue') or (destType == 'Port') or (destType == 'Webservice')):
			for role in self.queueRoleTypes:
				wasUsers = AdminTask.listUsersInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName)).split(newline)
				if ((wasUsers is not None) and (wasUsers[0] != '')):
					for wasUser in wasUsers:
						users.append(wasUser)
						users.append(role)
					#endFor
				#endIf
			#endFor
		elif (destType == 'Alias'):
			for role in self.aliasRoleTypes:
				wasUsers = AdminTask.listUsersInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName)).split(newline)
				if ((wasUsers is not None) and (wasUsers[0] != '')):
					for wasUser in wasUsers:
						users.append(wasUser)
						users.append(role)
					#endFor
				#endIf
			#endFor
		elif (destType == 'ForeignDestination'):
			destinations = AdminTask.listSIBDestinations(self.processAdminTaskArgs('-bus ' + busName)).split(newline)
			for destination in destinations:
				if ((destination is None) or (destination == '')):
					continue
				destinationName = AdminConfig.showAttribute(destination, "identifier")
				if (destinationName == destName):
					self.foreignBusName = AdminConfig.showAttribute(destination, "bus")
					break
				#endIf
			#endFor
			for role in self.foreignRoleTypes:
				wasUsers = AdminTask.listUsersInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName + ' -foreignBus ' + self.foreignBusName)).split(newline)
				if ((wasUsers is not None) and (wasUsers[0] != '')):
					for wasUser in wasUsers:
						users.append(wasUser)
						users.append(role)
					#endFor
				#endIf
			#endFor
		else: #This is Topic
			for role in self.topicRoleTypes:
				wasUsers = AdminTask.listUsersInDestinationRole(self.processAdminTaskArgs('-bus ' + busName + ' -role ' + role + ' -type ' + destType + ' -destination ' + destName)).split(newline)
				if ((wasUsers is not None) and (wasUsers[0] != '')):
					for wasUser in wasUsers:
						users.append(wasUser)
						users.append(role)
					#endFor
				#endIf
			#endFor
		#endIf
		return users
	#endDef	

#endClass

class SIBus(SIBMediator):
	def __init__(self, version):
		#super(SIBus,self).__init__()
		self.version = version
		self.configTypeList = ['SIBus', 'SIBForeignBus', 'SIBusMember', 'SIBMessagingEngine', 'SIBDestination', 'SIBMediation', 'SIBSecurity']
		self.configObjList = [Bus(), ForeignBus(), BusMember(self.version), MsgEngine(self.version), Destination(), Mediation(), Security()]
		self.markerList = ['SIB_Bus', 'SIB_ForeignBus', 'SIB_BusMember', 'SIB_MessagingEngine', 'SIB_Destination', 'SIB_Mediation', 'SIB_Security']
		
		self.dmgrNode = AdminControl.getNode()
		self.prodVersion = AdminTask.getMetadataProperty(['-nodeName', self.dmgrNode, '-propertyName', 'com.ibm.websphere.baseProductVersion'])
		if (not (self.prodVersion.find("6.1") >=0)):
			## Include Bootstrap member action if WebSphere version is WAS 7.0 or higher
			self.configTypeList.append('SIBBootstrapMember')
			self.configObjList.append(BootstrapMember())
			self.markerList.append('SIB_BootstrapMember')
		#endIf
	#endDef

	## Imports configuration for all the SIB components from WebSphere
	def importConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		for index in range(0, len(self.configTypeList)):
			try:
				print "---- BEGIN Importing configuration for " + self.configTypeList[index] + " ----"
				data = self.configObjList[index].readConfig(self.configTypeList[index])
				GenericConfigFileWriter.processBasicFile(xmlFile, data, self.markerList[index])
				print "---- END Importing configuration for " + self.configTypeList[index] + " ----"
			except:
				print "--## ERROR: Import failed for " + self.configTypeList[index] + " ##--" 
				print "--## Run the action separately for detailed error messages ##--"
				continue
			#endTry
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def executeConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		for index in range(0, len(self.configTypeList)):
			try:
				print "---- BEGIN Executing configuration for " + self.configTypeList[index] + " ----"
				self.configObjList[index].executeConfig(xmlFile, self.markerList[index], self.configTypeList[index])
				AdminHelper.saveAndSyncCell()
				print "---- END Executing configuration for " + self.configTypeList[index] + " ----"
			except:
				print "--## ERROR: Execute failed for " + self.configTypeList[index] + " ##--"
				print "--## Run the action separately for detailed error messages ##--"
				continue
			#endTry
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def augmentConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		
		for index in range(0, len(self.configTypeList)):
			try:
				print "---- BEGIN Augmenting configuration for " + self.configTypeList[index] + " ----"
				self.configObjList[index].augmentConfig(xmlFile, self.markerList[index], self.configTypeList[index])
				AdminHelper.saveAndSyncCell()
				print "---- END Augmenting configuration for " + self.configTypeList[index] + " ----"
			except:
				print "--## ERROR: Augment failed for " + self.configTypeList[index] + " ##--"
				print "--## Run the action separately for detailed error messages ##--"
				continue
			#endTry
		#endFor
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
	
	def compareConfig(self, xmlFile, marker, typeName):
		SCRIPT_LOGGER.traceEnter([xmlFile, marker, typeName])
		for index in range(0, len(self.configTypeList)):
			try:
				xmlConfigReader = XMLConfigReader()
				xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
				xmlProp = xmlProp.findRAFWContainerNode(self.markerList[index])
				if (self.configTypeList[index] == 'SIBSecurity'):
					nodeArray = []
					nodeArray.append(xmlProp)
					rafwConfig = xmlConfigReader.readXmlConfig(nodeArray)
					if (rafwConfig[0].has_key(CHILDREN)):
						rafwConfig = rafwConfig[0][CHILDREN]
					#endIf 
				else:
					nodeArray = xmlProp.getFilteredNodeArray(self.configTypeList[index])
					rafwConfig = xmlConfigReader.readXmlConfig(nodeArray)
				#endIf
				wasConfig = self.configObjList[index].readConfig(self.configTypeList[index])
				## Compare WebSphere and RAF configuration
				print "---- BEGIN Comparing configuration for " + self.configTypeList[index] + " ----"
				ConfigComparor.compare(self.configTypeList[index], wasConfig, rafwConfig)
				print "---- END Comparing configuration for " + self.configTypeList[index] + " ----"
			except:
				print "--## ERROR: Compare failed for " + self.configTypeList[index] + " ##--"
				print "--## Run the action separately for detailed error messages ##--"
				continue 
			#endTry
		#endFor
		
		SCRIPT_LOGGER.traceExit([xmlFile, marker, typeName])
	#endDef
#endClass

def getMediator(config_type, version):
	if (config_type == "SIBus"):
		thisMediator = Bus()
	elif (config_type == "SIBusMember"):
		thisMediator = BusMember(version)
	elif (config_type == "SIBMessagingEngine"):
		thisMediator = MsgEngine(version)
	elif (config_type == "SIBMediation"):
		thisMediator = Mediation()
	elif (config_type == "SIBDestination"):
		thisMediator = Destination()
	elif (config_type == "SIBForeignBus"):
		thisMediator = ForeignBus()
	elif (config_type == "SIBBootstrapMember"):
		thisMediator = BootstrapMember()
	elif (config_type == "SIBSecurity"):
		thisMediator = Security()
	elif (config_type == "ALL"):
		thisMediator = SIBus(version)
	else:
		raise "Invalid config type supplied: " + str(config_type)
	#endIf 
	return thisMediator
#endDef

def export(optDict=None):
	global version
	scope = optDict['wasscopetype']
	version = optDict['version']
	xmlFile = optDict['properties']
	mode = optDict['mode']
	config_type = optDict['type']
	
	marker = optDict['marker']
	
	thisMediator = getMediator(config_type, version)
	thisMediator.executeConfig(xmlFile, marker, config_type)
#enddef

###########################################################
########################     Main     #####################
###########################################################

SCRIPT_LOGGER = _Logger("siBuses", MessageManager.RB_WEBSPHERE_WAS)

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;properties:;scopename:;mode:;config_type:' )
	
	scope = AdminHelper.buildScope( optDict )
	version = optDict['version']
	xmlFile = optDict['properties']
	mode = optDict['mode']
	config_type = optDict['config_type']
	
	thisMediator = SIBMediator()
	marker = ""
	
	if (config_type == "SIBus"):
		marker = "SIB_Bus"
	elif (config_type == "SIBusMember"):
		marker = "SIB_BusMember"	
	elif (config_type == "SIBMessagingEngine"):
		marker = "SIB_MessagingEngine"
	elif (config_type == "SIBMediation"):
		marker = "SIB_Mediation"
	elif (config_type == "SIBDestination"):
		marker = "SIB_Destination"
	elif (config_type == "SIBForeignBus"):
		marker = "SIB_ForeignBus"
	elif (config_type == "SIBBootstrapMember"):
		marker = "SIB_BootstrapMember"
	elif (config_type == "SIBSecurity"):
		marker = "SIB_Security"
	elif (config_type == "ALL"):
		marker = "ALL"
	else:
		raise "Invalid config type supplied: " + str(config_type)
	#endIf    
	thisMediator = getMediator(config_type, version)
	if (mode == MODE_IMPORT):
		print "Importing " + config_type + " configuration in scope: " + scope
		thisMediator.importConfig(xmlFile, marker, config_type)
	elif (mode == MODE_EXECUTE):
		print "Creating " + config_type + " configuration in scope: " + scope
		thisMediator.executeConfig(xmlFile, marker, config_type)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_COMPARE):
		print "Comparing " + config_type + " configuration in scope: " + scope
		thisMediator.compareConfig(xmlFile, marker, config_type)
	elif (mode == MODE_AUGMENT):
		print "Augmenting " + config_type + " configuration in scope: " + scope
		thisMediator.augmentConfig(xmlFile, marker, config_type)
		AdminHelper.saveAndSyncCell()
	else:
		raise "Unsupported MODE supplied: " + mode
	#endIf
#endIf
