"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: createWP51Cluster.py
	
	TODO: description
"""


import sys
from java.util import Properties
from java.io import FileInputStream


def createMultiBrokerDomain ( domainName, clusterName ):

        global AdminConfig
        global AdminControl

        cellname = AdminControl.getCell( )
        cell = AdminConfig.getid("/Cell:"+cellname+"/" )
        attrib = []
        print "Creating MultibrokerDomain "+clusterName+" on cell "+cellname
        attrib.append(["name", clusterName])
        id = AdminConfig.create("MultibrokerDomain", cell, attrib )

        #set data replication info
        attrib = []
        attrib.append(["encryptionType", "NONE"])
        attrib.append(["serialization", [["entrySerializationKind", "BYTES"], ["propertySerializationKind", "BYTES"]]])
        attrib.append(["requestTimeout", 5])
        attrib.append(["encryptionKeyValue", ""])
        attrib.append(["partition", [["partitionOnEntry", "false"], ["size", 10]]])
        attrib.append(["pooling", [["poolConnections", "false"], ["size", 10]]])

        AdminConfig.create("DataReplication", id, attrib )

        return id
#endDef 

def configureSessionManagement ( serverName, nodeid, clusterName, domainid, serverid, clientPort, serverPort ):
        global AdminConfig

        #create memory repl stuff
        domainName = clusterName
        #createReplicationEntry(serverName, nodeid, domainName, domainid, serverid, clientPort, serverPort )

        #get existing session manager
        smgr = AdminConfig.list("SessionManager", serverid )

        drs = []
        drs.append(["dataReplicationMode", "BOTH"])
        ###THIS LINE WILL CAUSE THE MODIFY TO FAIL WITHOUT PQ74539
        drs.append(["ids", [1, 2, 3, 4, 5, 6, 7, 8, 9]])

        drs.append(["messageBrokerDomainName", domainName])
        drs.append(["preferredLocalDRSBrokerName", serverName])

        print drs

        attrib = []
        attrib.append(["sessionDRSPersistence", drs])
        attrib.append(["sessionPersistenceMode", "DATA_REPLICATION"])
        attrib.append(["tuningParams", [["allowOverflow", "false"], ["writeContents", "ONLY_UPDATED_ATTRIBUTES"], ["writeFrequency", "TIME_BASED_WRITE"], ["writeInterval", 120]]])
        print "Configuring session management for "+serverName+" on "+domainName

        AdminConfig.modify(smgr, attrib )
#endDef 

def createReplicationEntry ( serverName, nodeid, domainName, domainid, serverid, clientPort, serverPort ):
        global AdminConfig

        host = getHostName(nodeid )

        attrib = []
        clientendpoint = [["host", host], ["port", clientPort]]
        serverendpoint = [["host", host], ["port", serverPort]]

        attrib.append(["brokerName", serverName])
        attrib.append(["clientEndPoint", clientendpoint])
        attrib.append(["brokerEndPoint", serverendpoint])

        print "creating MultiBrokerRoutingEntry "+serverName
        AdminConfig.create("MultiBrokerRoutingEntry", domainid, attrib )

        #need to attach this to a server via an SMS
        attrib = []
        attrib.append(["domainName", domainName])
        attrib.append(["brokerName", serverName])
        attrib.append(["enable", "true"])
        AdminConfig.create("SystemMessageServer", serverid, attrib )
#endDef 

def createCluster ( clusterName, nodes, namePrefix, serversPerNode, weight, primaryNode, domainid, clientPort, serverPort, transportStartPort, transportInc  ):

        #--------------------------------------------------------------
        # set up globals
        #--------------------------------------------------------------
        global AdminConfig
        global AdminControl
        global AdminApp

        #---------------------------------------------------------
        # We assume that there is only one cell, and we are on it
        #---------------------------------------------------------
        cellname = AdminControl.getCell( )
        cell = AdminConfig.getid("/Cell:"+cellname+"/" )

        #---------------------------------------------------------
        # Construct the attribute list to be used in creating a ServerCluster
        # attribute.
        #---------------------------------------------------------
        mySpecialEndPoints = [ "BOOTSTRAP_ADDRESS", "SOAP_CONNECTOR_ADDRESS", "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS",
          "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS", "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS", "WC_adminhost", "WC_defaulthost", "WC_defaulthost_secure",
          "WC_defaulthost_secure" ]

        name_attr = ["name", clusterName]
        desc_attr = ["description", clusterName+" cluster"]
        pref_attr = ["preferLocal", "true"]
        statem_attr = ["stateManagement", [["initialState", "STOP"]]]
        attrs = [name_attr, desc_attr, pref_attr, statem_attr]

        #---------------------------------------------------------
        # Create the server cluster by converting WebSphere_Portal to a cluster
        #---------------------------------------------------------
        print "cluster: creating the ServerCluster "+clusterName

        cluster = AdminConfig.getid("/Cell:"+cellname+"/ServerCluster:"+clusterName )
        if (len(cluster) == 0):
                primary_server = AdminConfig.getid("/Cell:"+cellname+"/Node:"+primaryNode+"/Server:WebSphere_Portal" )
                cluster = AdminConfig.convertToCluster(primary_server, clusterName )
        #endIf 

        #---------------------------------------------------------
        # For each node, create the required number of servers
        #
        #---------------------------------------------------------

        index = 0
        for nodeName in nodes.split(","):
                node = AdminConfig.getid("/Node:"+nodeName+"/" )
                # stop servers we don't need
                print "Stopping WebSphere_Portal"
                AdminHelper.stopServer('WebSphere_Portal', nodeName )
                print "Stopping server1"
                AdminHelper.stopServer('server1', nodeName )
                i = 1  #forStart
                portIndex = 1  #forStart
                while ( i <= serversPerNode ):  #forTest
                       uid = 0
                       uid += (index * serversPerNode + i)
                       serverName = namePrefix + str(uid)
                       name_attr = ["memberName", serverName]
                       weight_attr = ["weight", weight]
                       uniquePorts_attr = ["genUniquePorts", "false"]
                       attrs = [name_attr, weight_attr, uniquePorts_attr]
                       print "cluster: creating server "+serverName+" on node "+nodeName
                       serverid = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+serverName+"/" )
                       if (len(serverid) == 0):
                            server = AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [['+nodeName+' '+serverName+' "" "" false false]]]') 
                            #server = AdminConfig.createClusterMember(cluster, node, attrs, primary_server )
                            serverid = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+serverName+"/" )
                            nodeid = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/" )
                            # Now we're going to adjust the tcp transports of TRANSPORT_STARTING_POINT was defined
                            myPort = ((portIndex-1) * transportInc) + transportStartPort
                            if ( transportStartPort > 0 ):
                               for sEPoint in mySpecialEndPoints:
                                   sAttrs = '[-nodeName ' + nodeName + ' -endPointName ' + sEPoint + ' -port ' + str(myPort) + ' -modifyShared]'
                                   print "\t\t --## Setting %10s:%40s  == %5s ##--" % ( serverName,sEPoint,str(myPort) )
                                   AdminTask.modifyServerPort( serverName, sAttrs )
                                   myPort = myPort+1
                                #endFor
                            #endif

                            jvm = AdminConfig.list("JavaVirtualMachine", serverid )

                            # create a replication entry for this member
                            createReplicationEntry(serverName, nodeid, clusterName, domainid, serverid, clientPort, serverPort )
                        
                       clientPort=clientPort+2
                       serverPort=serverPort+2
                       i += 1  #forNext
                #endWhile  (#endFor)

                index = index+1
        #endFor 

        #---------------------------------------------------------
        # save changes
        #
        #---------------------------------------------------------

        print "cluster: saving config changes."
        AdminConfig.save( )

        #---------------------------------------------------------
        # Ask the ClusterMgr to refresh its list of clusters
        #
        #---------------------------------------------------------

        clusterMgr = AdminControl.completeObjectName("type=ClusterMgr,cell="+cellname+",*" )
        if (len(clusterMgr) == 0):
                print "cluster: Error -- clusterMgr MBean not found for cell "+cellname
                return 
        #endIf 
        AdminControl.invoke(clusterMgr, "retrieveClusters" )

        # Syncronize the nodes
        AdminHelper.syncNodes( nodes )

        #---------------------------------------------------------
        # Ask the Cluster MBean to start the cluster
        #
        #---------------------------------------------------------

#        cluster = AdminControl.completeObjectName("type=Cluster,name="+clusterName+",*" )
#        print "cluster: Invoking start for cluster "+clusterName
#        AdminControl.invoke(cluster, "start" )

#endDef #Read properties file.

def cleanUp ( nodes ):
        global AdminControl
        global AdminConfig
        cellName = AdminControl.getCell( )

        for nodeName in nodes.split(","):
                wpid = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:WebSphere_Portal/" )
                server1id = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:server1/" )


                # remove servers we don't need
                print "Removing "+wpid
                AdminConfig.remove(wpid )
                print "Removing "+server1id
                AdminConfig.remove(server1id )
                AdminConfig.save( )
        #endFor 
#endDef 

def getHostName ( nodeid ):
        global AdminConfig
        hostAttr = AdminConfig.show(nodeid, "hostName" )
        attr = hostAttr[1:len(hostAttr)-1]
        attr=attr.split()
        return attr[1]
#endDef 

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
arglen=len(sys.argv)
num_exp_args=1
if (arglen < num_exp_args):
    raise "One argument is required. This argument should be a properties file."
#endIf

propFile=sys.argv[0]
properties=Properties();

try:
    properties.load(FileInputStream(propFile))
    print "Succesfully read property file "+propFile
except:
    raise "Cannot read property file "+propFile

clusterName = str(properties.getProperty("CLUSTER_NAME"))
nodes = str(properties.getProperty("NODES"))
# remove quotes from nodes property
prefix = str(properties.getProperty("PREFIX"))
primaryNode = str(properties.getProperty("PRIMARY_NODE"))
serverPort = int(properties.getProperty("DRS_SERVER_PORT"))
clientPort = int(properties.getProperty("DRS_CLIENT_PORT"))
perNode = int(properties.getProperty("PERNODE"))
weight = 1
domainName = clusterName
transportStartPort = int(properties.getProperty("TRANSPORT_STARTING_POINT"))
transportInc = int(properties.getProperty("TRANSPORT_NODE_INCREMENTOR"))

domainid = createMultiBrokerDomain(domainName, clusterName )

createCluster(clusterName, nodes, prefix, perNode, weight, primaryNode, domainid, clientPort, serverPort, transportStartPort, transportInc  )
cleanUp(nodes )

AdminHelper.saveAndSyncCell()

