"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: resourceEnvironmentEntries.py
	
	This script handles Resource Enviroment Entries / Factories, post target of resource_environment_providers
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py 
		-f resourceEnvironmentEntries.py 
		-scope ${SCOPE} -scopename <scope name> 
		-properties <property file> 
"""
import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import Globals
import java

from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigWriter import ConfigWriter
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigValidator import ConfigValidator
from XmlProperty import InvalidXmlConfigException
from Logger import _Logger
from AdminHelper import AdminHelper
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

resourceEnvironmentEntriesLogger = _Logger("resourceEnvironmentEntries", MessageManager.RB_WEBSPHERE_WAS)

class dsMediator:
	def createConfig(self, scope, scopeType, xmlFile, marker, excludedTypes):
	
		typeName = "ResourceEnvEntry"
		scopeId = AdminConfig.getid( scope )
		##print "Creating configuration of type "+typeName+" at scope "+scopeId
		resourceEnvironmentEntriesLogger.log("CRWWA2024I",[typeName,scopeId])
		myConfigWriter = ConfigWriter();
		myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId, excludedTypes)
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		updateReferences = []
		if ( nodeArray != None):
			for xmlNode in nodeArray:
				self._createResEnvEntry(xmlNode, myConfigWriter, scope)
				updateReferences.append(xmlNode)
			#endFor
		#endIf
		myConfigWriter.updateWASReferenceAttributes(updateReferences, scopeId, ["ResourceEnvironmentProvider", "builtin"])
	
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker):
	
		typeName = "ResourceEnvEntry"
		scopeId = AdminConfig.getid( scope )
		configValidator = ConfigValidator()
		myConfigWriter = ConfigWriter();
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		updateReferences = []
		if ( nodeArray != None):
			for xmlNode in nodeArray:
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					#print "Info: Processing " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					resourceEnvironmentEntriesLogger.log("CRWWA5032I",[typeName,xmlNode.getAttrValue("jndiName")])
					self._createResEnvEntry(xmlNode, myConfigWriter, scope)
					updateReferences.append(xmlNode)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode)
						updateReferences.append(xmlNode)
					else:
						##print "Warning: " + typeName + " will not be created."
						resourceEnvironmentEntriesLogger.log("CRWWA2025I",[typeName])
				#endIf
			#endFor
		#endIf
		
		myConfigWriter.updateWASReferenceAttributes(updateReferences, scopeId, ["ResourceEnvironmentProvider", "builtin"])
	
	#endDef
	
	def _createResEnvEntry(self, xmlNode, myConfigWriter, scope):
		jndiNameDisplay = xmlNode.getAttrValue("jndiName", Globals.ATTRIBUTE_VALUE_MISSING)
		try:
			parentId = AdminHelper.findProviderId(xmlNode, scope, "ResourceEnvironmentProvider", "name")
			##print "Info: Creating ResourceEnvEntry with jndiName " + jndiNameDisplay
			resourceEnvironmentEntriesLogger.log("CRWWA2026I",[jndiNameDisplay])
			myConfigWriter.createWASObject(xmlNode, parentId, ["ResourceEnvironmentProvider", "builtin"])
		except InvalidXmlConfigException, e:
			##print "Error: Unable to create ResourceEnvEntry with jndiName:"
			resourceEnvironmentEntriesLogger.log("CRWWA2027I",[jndiNameDisplay])
			#print "       " + jndiNameDisplay
			##print "Caused by: Unable to find ResourceEnvironmentProvider"
			
			#print "Caused by: " + str(e)
			resourceEnvironmentEntriesLogger.log("CRWWA5033I",[str(e)])
			raise e
		#endTry
	#endDef
	
#endClass

class resEnvEntriesReader(ConfigReader):
	##########################################################
	## Reads all data from WAS with the supplied id, then processes all attributes
	## that contain WAS ids into children. 
	##
	## Returns a dict with the following keys
	## id -- the type of the WAS config element referred to by the supplied id
	## attrs -- the attributes of the id, with all attributes referring to WAS ids removed
	## children 
	## An array of similar dicts, referring to each child referenced by this configuration
	## (each child contain the same:) 
	## ---id 
	## ---attrs
	## ---children
	##########################################################
	def showAll(self, id):
		self.LOGGER.traceEnter(id)
		if (str(id).split("#")[1].find(" ") >= 0):
			print "WARNING: ignored key = " + str(id)
			self.LOGGER.traceExit(str(None))
			return None
		#endIf
		# print "reading AllConfigData under: " + id
		# self.importedIds.append(id)
		subAttrs = self.show(id)
		children = []
		configElements = self.removeChildIdsToProcess(id, subAttrs)
		
		## process reference ids
		refkeys = configElements.referenceIds.keys()
		refkeys.sort()
		resEnvProvider = None
			
		for childKey in refkeys:
			childIds = configElements.referenceIds[childKey]
			for childId in childIds:
				if (childId not in self.importedIds):
					child = {}
					childType = self.getWASType(childId)
					child['id'] = childType
					child['children'] = []
					childAttrs = self.show(childId)
					if (childType == "ResourceEnvironmentProvider"):
						resEnvProvider = {}
						resEnvProvider[Globals.RAFW_PARENT_TYPE] = childType
						resEnvProvider[Globals.RAFW_PARENT_NAME] = childAttrs["name"]
					#endIf
					## remove all fields containing object ids
					self.removeChildIdsToProcess(childId, childAttrs)
					## add those attributes which are used to locate the object
					uniqueAttrs = self.configTypeKeys.getUniqueAttrs(childType)
					child['attrs'] = {}
					for uniqueAttr in uniqueAttrs:
						if (childAttrs.has_key(uniqueAttr)):
							child['attrs'][uniqueAttr] = childAttrs[uniqueAttr]
						#endIf
					#endFor
					if (len(child['attrs'].keys()) == 0):
						child['attrs'] = childAttrs
					#endIf
					child['attrs'][Globals.WAS_KEY_ATTR_NAME] = childKey
					child['attrs'][Globals.RAFW_TYPE] = Globals.RAFW_TYPE_REFERENCE
					
					#attempt to fix ambiguous references for Referenceable type from within ResourceEnvEntry
					if childType == "Referenceable" and resEnvProvider is not None:
						child['attrs'][Globals.RAFW_PARENT_NAME]=resEnvProvider[Globals.RAFW_PARENT_NAME]
						child['attrs'][Globals.RAFW_PARENT_TYPE]=resEnvProvider[Globals.RAFW_PARENT_TYPE]
					#endIf
					children.append(child)
				#endIf
			#endFor
		#endFor
		## process higher priority children first
		for childKey in configElements.highPriorityIds.keys():
			childIds = configElements.highPriorityIds[childKey]
			for childId in childIds:
				child = self.processId(childId)
				if (child != None and child['id'] not in self.excludedTypes):
					child['attrs'][Globals.WAS_KEY_ATTR_NAME] = childKey
					children.append(child)
				#endIf
			#endFor
		#endFor
		## process regular priority children second
		#for childKey in childIds['none'].keys():
		for childKey in configElements.lowPriorityIds.keys():
			childIds = configElements.lowPriorityIds[childKey]
			for childId in childIds:
				child = self.processId(childId)
				if (child != None and child['id'] not in self.excludedTypes):
					child['attrs']['WASKey'] = childKey
					if (child['id'] != "builtin"):
						children.append(child)
				#endIf
			#endFor
		#endFor
		data = {}
		data['id'] = self.getWASType(id)
		data['attrs'] = subAttrs
		data['children'] = children
		
		self.LOGGER.traceExit(data)
		return data
	#endDef
#endClass

def export(optDict=None):
	scope = optDict['wasscopetype']
	scopeType = optDict['scope']
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	excludedTypes =optDict['excludedtypes'] 

	typeName = optDict['type'] 
	thisMediator = dsMediator()
	marker = optDict['marker']
	myReader = resEnvEntriesReader()
	
	thisMediator.createConfig(scope, scopeType, xmlFile, marker, excludedTypes)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	scopeType = optDict['scope']
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	excludedTypes = [ "CacheInstance", "SchedulerConfiguration", "EventBusTransmissionProfile", 
					"JMSTransmissionProfile", "ObjectCacheInstance", "EventGroupProfileList", 
					"DataStoreProfile", "FilterFactoryProfile", "ServletCacheInstance", "EventServerProfile", 
					"EmitterFactoryProfile", "WorkManagerInfo", "TimerManagerInfo", "ObjectPoolManagerInfo"]   
					   
	typeName = "ResourceEnvEntry" 
	thisMediator = dsMediator()
	marker = "resourceEnvironmentEntries"
	myReader = resEnvEntriesReader()
	
	if (mode == MODE_EXECUTE):
		##print "Creating Resource Environment Entries in scope: " +scope
		resourceEnvironmentEntriesLogger.log("CRWWA2029I",[scope])
		thisMediator.createConfig(scope, scopeType, xmlFile, marker, excludedTypes)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
		##print "Augmenting Resource Environment Entries in scope: " +scope
		resourceEnvironmentEntriesLogger.log("CRWWA2030I",[scope])
		thisMediator.augmentConfig(scope, scopeType, xmlFile, marker)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing Resource Environment Entries in scope: " +scope
		resourceEnvironmentEntriesLogger.log("CRWWA2031I",[scope])
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, [typeName], excludedTypes , myReader)
	
	elif (mode == MODE_COMPARE):
		##print "Comparing Resource Environment Entries in scope: " +scope
		resourceEnvironmentEntriesLogger.log("CRWWA2032I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, [typeName], excludedTypes )
	
	else:
		##print "Unsupported MODE supplied: " + mode
		resourceEnvironmentEntriesLogger.log("CRWWA0008W",[mode])
	#endIf
#endIf
