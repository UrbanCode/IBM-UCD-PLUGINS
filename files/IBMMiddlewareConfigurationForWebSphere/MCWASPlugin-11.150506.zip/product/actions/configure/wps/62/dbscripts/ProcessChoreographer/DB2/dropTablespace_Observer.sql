--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to drop tablespaces for DB2 UDB
-- Run the script with the following sequence:
--      db2 connect to OBSVRDB
--      db2 -tf dropTablespace_Observer.sql


----------------------
-- Drop tablespaces --
----------------------

DROP TABLESPACE OBSVRTS;

--
--
--
