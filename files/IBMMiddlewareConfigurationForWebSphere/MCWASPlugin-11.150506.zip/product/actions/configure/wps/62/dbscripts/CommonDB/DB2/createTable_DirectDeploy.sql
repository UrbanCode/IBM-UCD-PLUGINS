-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2008. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

create table d2d_item (
	id varchar(255) not null, 
	state varchar(20) not null,
	item_level int not null,
	module_name varchar(255),
	application_name varchar(255),
	version varchar(30), 
	wps_version varchar(10),
	new_app_name varchar(255),
	primary key (id));

create table d2d_progress (
	item_id varchar(255) not null,
	progress INTEGER,
	progress_msg varchar(255),
	progress_error_code  varchar(255),
	primary key (item_id));

create table d2d_content (
	item_id varchar(255) not null,
	pi	blob,
	primary key (item_id));

create table d2d_metadata(
	item_id varchar(255) not null,
	name varchar(255) not null,
	value varchar(255) );

create table d2d_lock(
	item_lock character(1),
	lastUpdate timestamp);

insert into d2d_lock values ('x', null);

create table d2d_message(
	item_id varchar(255) not null,
	seq int not null,
	id	varchar(63),
	description varchar(1024),
	affected_resource varchar(255),
	location varchar(63),
	folder varchar(255),
	chr varchar(63),
	tag	varchar(63),
	severity varchar(15),
	time timestamp,
	primary key (item_id, seq));
