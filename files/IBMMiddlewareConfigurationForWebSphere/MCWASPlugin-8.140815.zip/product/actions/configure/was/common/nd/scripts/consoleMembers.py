"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: consoleMembers.py
	
	This script is used to manage console users
	It is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f consoleMembers.py
		-scope <scope: cell>
		-properties <consoleMembers xml file>
		-mode <import|execute|compare|augment>
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from ConfigValidator import ConfigValidator
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriter

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

class ConsoleMemberMediator:
	##--------------------------------------------------------------------
	## Imports the members of an existing cell into a RAFW configuration file.
	## xmlFile - the file that the configuration will be written to
	## marker - the marker used to specify where in the xml file data should be injected
	## typeNames - list of WAS configuration types to read from WAS and write to configuration
	##--------------------------------------------------------------------
	def importConsole(self, xmlFile, marker, typeNames):
		data = self.readConfigData(typeNames)
		myFileWriter = ConfigFileWriter("consoleMembers.vm")
		# replace file contents it into the file
		myFileWriter.processBasicFile (xmlFile, data, marker)
	#endDef

	def readConfigData(self, typeNames):
		myConfigReader = ConfigReader()
		data = []
		roles = self.readRoles()
		for roleName in roles.keys():
			role = roles[roleName]
		
			mapping = {}
			mapping["role"] = roleName
		
			for configType in typeNames:
				children = []
				mapping[configType] = children
				for objId in AdminConfig.list( configType, role ).split( newline ):
					if ( len(objId) > 0 ):
						children.append(myConfigReader.show(objId))
					#endIf
				#endFor
			#endFor
			data.append(mapping)
		#endFor
		return data
	#endDef

	"""
 
 	Creates WAS configuration based on the supplied configuration properties
 
 	xmlFile - file that stores the configuration
 	typeNames - WAS configuration types to write
 
	"""
	def createConsole(self, xmlFile, marker, typeNames):

		myConfigWriter = ConfigWriter()
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)

		roles = self.readRoles()
		for typeName in typeNames:
			myConfigWriter.removeExistingConfig(None, typeName)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			for xmlNode in nodeArray:
				roleName = xmlNode.getAttrValue("role")
				name = xmlNode.getAttrValue("name")
				if (roles.has_key(roleName)):
					roleId = roles[roleName]
					print "Adding console member " + str(name) + " to role " + str(roleName)
					configId=AdminConfig.create( typeName, roleId, [["name", name]])
					if (xmlNode.hasAttr("accessId")):
						accessId = xmlNode.getAttrValue("accessId")
						AdminConfig.modify(configId, [["accessId", accessId]])
					#endIf
				else:
					print "Error -- Invalid Role name: '" + str(roleName) + "' could not be found in configuration."
					self.printRoles(roles)
					raise "Invalid Role name: '" + str(roleName) + "' could not be found in configuration."
				#endIf
			#endFor
		#endFor
	#endDef

	def printRoles(self, roles):
		print "Valid roles are:"
		for roleName in roles.keys():
			print "    " + str(roleName)
		#endFor
	#endDef

	"""
 
 	Augments WAS configuration based on the supplied configuration properties
 
 	xmlFile - file that stores the configuration
 	typeNames - WAS configuration types to write
 
	"""
	def augmentConsole(self, xmlFile, marker, typeNames):

		configValidator = ConfigValidator()
		myConfigWriter = ConfigWriter()
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)

		roles = self.readRoles()
		for typeName in typeNames:
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			for xmlNode in nodeArray:
				roleName = xmlNode.getAttrValue("role")
				name = xmlNode.getAttrValue("name")
				if (roles.has_key(roleName)):
					roleId = roles[roleName]
					configId = configValidator.validateUniqueAttr2(xmlNode, roleId, "name")
					if (configId is None):
						print "Adding console member " + str(name) + " to role " + str(roleName)
						configId=AdminConfig.create(typeName, roleId, [["name", name]])
					#endIf
					if (xmlNode.hasAttr("accessId")):
						accessId = xmlNode.getAttrValue("accessId")
						AdminConfig.modify(configId, [["accessId", accessId]])
					#endIf
				else:
					print "Error -- Invalid Role name: '" + str(roleName) + "' could not be found in configuration."
					self.printRoles(roles)
					raise "Invalid Role name: '" + str(roleName) + "' could not be found in configuration."
				#endIf
			#endFor
		#endFor
	#endDef

	def compareConsole(self, xmlFile, marker, typeNames):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		xmlConfigReader = XMLConfigReader()
		configData = self.readConfigData(typeNames)

		# initialize data struct
		data = {}
		for configType in typeNames:
			data[configType] = []
		#endFor
		## iterate over the children from WAS config
		for mapping in configData:
			roleName = mapping['role']
			for configType in typeNames:
				for child in mapping[configType]:
					attrs = {}
					attrs['role'] = roleName
					attrs['name'] = child['name']
					if (child.has_key('accessId')):
						attrs['accessId'] = child['accessId']
					#endIf
					values = {}
					values['id'] = configType
					values['attrs'] = attrs
					values['children'] = []
					## organize type into 2 buckets to be compared against the xml
					data[configType].extend([values])
				#endFor
			#endFor
		#endFor
		
		# create comparator class that sorts objects on "role" name
		class _ConsoleMemberComparator(util.Comparator):
			def compare(self, objOne, objTwo):
				attrStr = "attrs"
				roleStr = "role"
				objOneStr = str(objOne)
				if (isinstance(objOne, util.Map)):
					if (objOne.get(attrStr) is not None):
						objOneAttr = objOne.get(attrStr)
						if (objOneAttr.get(roleStr) is not None):
							objOneStr = objOneAttr.get(roleStr)
						#endIf
					#endIf
				#endIf
				objTwoStr = str(objTwo)
				if (isinstance(objTwo, util.Map)):
					if (objTwo.get(attrStr) is not None):
						objTwoAttr = objTwo.get(attrStr)
						if (objTwoAttr.get(roleStr) is not None):
							objTwoStr = objTwoAttr.get(roleStr)
						#endIf
					#endIf
				#endIf
				return (lang.String(objOneStr).compareTo(lang.String(objTwoStr)))
			#endDef
		#endClass
		
		myComparatorObj = _ConsoleMemberComparator()
		# get wasConfig
		for typeName in typeNames:
			wasConfig = data[typeName]

			# get rafwConfig
			filteredNodes = xmlProp.getFilteredNodeArray(typeName)
			rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
			
			ConfigComparor.compare(typeName, wasConfig, rafwConfig, myComparatorObj)
   		#endFor
   	#endDef

	##
	## reads available roles from WAS and returns as a dict
	##
	def readRoles(self):
		roles = AdminConfig.getid("/AuthorizationTableExt:admin-authz.xml/RoleAssignmentExt:/").split( newline )
	
		roleDict={}
		for role in roles:
			if ( role == None or role == ""):
				break
			#endIf
			roleType = AdminConfig.showAttribute(role, "role")
			roleName = AdminConfig.showAttribute(roleType, "roleName")
			roleDict[roleName]=role
		#endFor
		
		authorRoles = AdminConfig.getid("/AuthorizationTableExt:audit-authz.xml/RoleAssignmentExt:/").split( newline )
		
		for role in authorRoles:
			if ( role == None or role == ""):
				break
			#endIf
			roleType = AdminConfig.showAttribute(role, "role")
			roleName = AdminConfig.showAttribute(roleType, "roleName")
			roleDict[roleName]=role
		#endFor
	
		if ( roleDict == {} ):
			raise "Error -- Insufficient privileges to modify administrative user/group settings. "
		#endIf
		
		return roleDict
	#endDef
	
#endClass

newline = java.lang.System.getProperty("line.separator")

'''
This is the function that is used by quick export to push the configuration data back to WAS
'''
def export(optDict=None):
	propFile = optDict['properties']
	mode = optDict['mode']
	marker = optDict['marker']
	## read/write GroupExt and UserExt config types from WAS
	typeNames = [optDict['type']]
	thisMediator = ConsoleMemberMediator()
	
	thisMediator.createConsole(propFile, marker, typeNames)
	#endif
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:' )
	propFile = optDict['properties']
	mode = optDict['mode']
	marker = "consoleMembers"
	## read/write GroupExt and UserExt config types from WAS
	typeNames = ["GroupExt", "UserExt"]
	thisMediator = ConsoleMemberMediator()
	
	if (mode == MODE_EXECUTE):
		print "Creating Console Users/Groups"
		thisMediator.createConsole(propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
		
	elif (mode == MODE_AUGMENT):
		print "Augmenting Console Users/Groups"
		thisMediator.augmentConsole(propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		print "Importing Console Users/Groups"
		thisMediator.importConsole(propFile, marker, typeNames)
		
	elif (mode == MODE_COMPARE):
		print "Comparing Console Users/Groups"
		thisMediator.compareConsole(propFile, marker, typeNames)
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf