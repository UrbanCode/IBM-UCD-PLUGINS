"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: postPortalClusterConfig.py
	
	TODO: description
"""


import org.python.modules
from sys import argv
from java.util import Properties
from java.io import FileInputStream


### functions ###

def updateJVM(serverId, jvmHeapMax, jvmHeapMin, jvmGenericArguments, webThreadPoolMax, webThreadPoolMin, webThreadPoolGrowable, webTimeout ):


        print serverId 
        print jvmHeapMax
        print jvmHeapMin
        print jvmGenericArguments
        print webThreadPoolMax
        print webThreadPoolMin
        print webThreadPoolGrowable
        print webTimeout
	processDef = AdminConfig.showAttribute(serverId, 'processDefinition')
	jvm = AdminConfig.showAttribute(processDef,'jvmEntries')
	jvm = jvm[1:len(jvm)-1]

	#update jvm args
	print "Getting jvm proccess definition attributes"
	print "Setting jvm arguments="+jvmGenericArguments
	AdminConfig.modify(jvm,[['genericJvmArguments',jvmGenericArguments]])  

	print "Setting jvm initialHeapSize="+jvmHeapMin
	AdminConfig.modify(jvm,[['initialHeapSize',jvmHeapMin]])
	print "Setting jvm maximumHeapSize="+jvmHeapMax
	AdminConfig.modify(jvm,[['maximumHeapSize',jvmHeapMax]])

	#get the Web Container
	print "Getting WebContainer"
	wc=AdminConfig.list("WebContainer",serverId)

	#get the thread pool
	print "Getting Thread pool"
	tp=AdminConfig.showAttribute(wc,"threadPool")

	#modify the min threads
	print "Setting maximumSize="+str(webThreadPoolMax) 
	AdminConfig.modify(tp,[["maximumSize",webThreadPoolMax]])

	#modify the max threads
	print "Setting minimumSize="+str(webThreadPoolMin) 
	AdminConfig.modify(tp,[["minimumSize",webThreadPoolMin]])

	#modify the max threads
	print "Setting isGrowable="+str(webThreadPoolGrowable) 
	AdminConfig.modify(tp,[["isGrowable",webThreadPoolGrowable]])
 
def updateJDBC(cellname, nodes, jdbcName, dsName, dbStmtCacheSize, dbPoolSizeMax, dbPoolSizeMin ):
	
	# portal defines it's dsns at the node level so we'll need to loop through the nodes
	for nodename in nodes.split(","):
		dataSource = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/JDBCProvider:"+jdbcName+"/DataSource:"+dsName+"/" )
		print AdminConfig.required('DataSource')
		print "Getting DataSource "+dsName+" on node "+nodeName
		print "Setting dsn statementCacheSize="+dbStmtCacheSize
		AdminConfig.modify(dataSource,[['statementCacheSize',dbStmtCacheSize]])  


		attrib = []
		attrib.append(["maxConnections", dbPoolSizeMax])
		attrib.append(["minConnections", dbPoolSizeMin])
		print "Setting dsn maxConnections="+dbPoolSizeMax
		print "Setting dsn minConnection="+dbPoolSizeMin
		AdminConfig.modify(dataSource,[['connectionPool', attrib]])  



### MAIN #####

arglen=len(sys.argv)
num_exp_args=1
if (arglen < num_exp_args):
    raise "One argument is required. This argument should be a properties file."
#endIf

propFile=sys.argv[0]
properties=Properties();

try:
    properties.load(FileInputStream(propFile))
    print "Succesfully read property file "+propFile
except:
    raise "Cannot read property file "+propFile

# cluster info
clusterName=str(properties.getProperty("CLUSTER_NAME"))
nodes=str(properties.getProperty("NODES"))

# JVM settings
jvmHeapMax=str(properties.getProperty("JVM_HEAP_MAX"))
jvmHeapMin=str(properties.getProperty("JVM_HEAP_MIN"))
jvmGenericArguments=str(properties.getProperty("JVM_GENERIC_ARGUMENTS"))

# Web Container
webThreadPoolMax=str(properties.getProperty("WEB_THREAD_POOL_MAX"))
webThreadPoolMin=str(properties.getProperty("WEB_THREAD_POOL_MIN"))
webThreadPoolGrowable=str(properties.getProperty("WEB_THREAD_POOL_GROWABLE"))
webTimeout=str(properties.getProperty("SESSION_TIMEOUT"))

# WP config dbs JDBC settings
wpsDbStmtCacheSize=str(properties.getProperty("WPS_DB_STMT_CACHE_SIZE"))
wpsDbPoolSizeMax=str(properties.getProperty("WPS_DB_POOL_SIZE_MAX"))
wpsDbPoolSizeMin=str(properties.getProperty("WPS_DB_POOL_SIZE_MIN"))
wmmDbStmtCacheSize=str(properties.getProperty("WMM_DB_STMT_CACHE_SIZE"))
wmmDbPoolSizeMax=str(properties.getProperty("WMM_DB_POOL_SIZE_MAX"))
wmmDbPoolSizeMin=str(properties.getProperty("WMM_DB_POOL_SIZE_MIN"))

cell = AdminConfig.list("Cell" )
cellName = AdminConfig.showAttribute(cell, "name" )
clusters = AdminConfig.list("ServerCluster", cell )
for aCluster in clusters.split():
	cName = AdminConfig.showAttribute(aCluster, "name" )
	if (clusterName == cName):
		memberlist = AdminConfig.showAttribute(aCluster, "members" )
		members = memberlist[1:len(memberlist)-1]
		for member in members.split():
			nodeName = AdminConfig.showAttribute(member, "nodeName" )
			serverName = AdminConfig.showAttribute(member, "memberName" )
			serverId = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
			print "Updating "+serverName+" on node "+nodeName
			updateJVM(serverId, jvmHeapMax, jvmHeapMin, jvmGenericArguments, webThreadPoolMax, webThreadPoolMin, webThreadPoolGrowable, webTimeout )
		#endFor
	#EndIf
#endFor

# update the JVMS in this cluster

# update the DSNs
updateJDBC(cellName, nodes, "wpsdbJDBC", "wpsdbDS", wpsDbStmtCacheSize, wpsDbPoolSizeMax, wpsDbPoolSizeMin)
updateJDBC(cellName, nodes, "wpsdbJDBC", "wmmDS", wmmDbStmtCacheSize, wmmDbPoolSizeMax, wmmDbPoolSizeMin)

AdminHelper.saveAndSyncCell()