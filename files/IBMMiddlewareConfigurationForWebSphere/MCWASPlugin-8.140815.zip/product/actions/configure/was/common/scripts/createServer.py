"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: createServer.py
	
	This script is to create an server on a node with given jvm template properties.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f createServer.py -servername <server name> -nodename <node name> -template <jvm template name> 
		-servername <server name>: specify the name of the server to be created
		-nodename <node name>: specify the node name of the server to be created 
		-template <jvm template name>: specify the name of the jvm template, if not specified or not exist, the default will be uses
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
import sys

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'servername:;nodename:;template:;os:' )

cellname = AdminControl.getCell()
nodename = optDict['nodename']
servername = optDict['servername']

createServerLogger = _Logger("createServer", MessageManager.RB_WEBSPHERE_WAS)

# Check if it is a valid node
node = AdminConfig.getid( '/Cell:' + cellname + '/Node:' + nodename + '/' )

if node == "":
	raise "\ncreateServer.py: Error -- Invalid node name: " + nodename 
#endIf

# Check if a server by this name already existing on the node
server = AdminConfig.getid("/Cell:" + cellname + "/Node:" + nodename + "/Server:" + servername + "/")

if server != "":
	raise "\ncreateServer.py: Warn -- Server " + servername + " already created on node " + nodename
#endIf

templName = optDict['template']

if templName != "":
	templ = AdminConfig.listTemplates('Server', templName)
#endif


if templName == "" or templ == "" or templName is None:
	osName = optDict['os']
	if osName == 'zos':
		templName="defaultZOS"
	else:
		templName="default"
	#endif
#endif


#print "Creating server: " +servername +" using template: " +templName
createServerLogger.log("CRWWA1009I",[servername,templName])

#AdminTask.createApplicationServer(nodename, ['-name', servername, '-templateName', templName])
AdminTask.createApplicationServer( nodename, "-name " +servername +" -templateName " +templName )

# if desired, we can add an enhancement to set the ports on the new server
# by calling  WasConfig.updateServerPorts(wasVersion, nodeName, serverName, 1, 0, transportStartPort)
# see createCluster.py for details

AdminHelper.saveAndSyncCell()

#end main		


