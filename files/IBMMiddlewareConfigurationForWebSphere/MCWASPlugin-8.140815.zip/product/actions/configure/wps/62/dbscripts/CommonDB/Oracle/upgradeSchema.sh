#!/bin/sh
#
# BEGIN COPYRIGHT
# *************************************************************************
# Licensed Materials - Property of IBM 
# 5724-L01, 5655-N53, 5724-I82, 5655-R15
# (C) Copyright IBM Corporation 2006. All rights reserved. 
# US Government Users Restricted Rights - Use, duplication, or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# *************************************************************************
# END COPYRIGHT

#------------------------------------------------------------------------------
# Description:   Configure Oracle Database environment during Migrtaion based 
# 				 Migrating WBI version
#				 This file for use on Linux/Unix systems's bash
# 
#
# Usage: 
#                upgradeSchema.sh   <product_version>  <dbName> <dbuser>
#  
# Example:
#                upgradeSchema.bat 602 orcl dbCommonUserId  
#                password will be prompted
#------------------------------------------------------------------------------

#-----------------------------------------
# Print Message
#-----------------------------------------
print_message() {
echo
echo ======================================================================
echo "Usage: upgradeSchema.sh  <product_version>  <dbName> <dbuser>"
echo 
echo "Parameters:"
echo "product_version   -  Specify the migration version ie., 602 or 610 or 612 "
echo "dbname            -  Oracle Instance Name(SID) ie., orcl"
echo "dbuser            -  User who can execute common scripts ie.,dbCommonUserId"
echo 
echo "Examples:"
echo "     1.upgradeSchema.sh "
echo "     2.upgradeSchema.sh 602 orcl dbCommonUserId"
echo ======================================================================
echo
exit
}

#-----------------------------------------
# Ask user for WBI migrtaion version
#-----------------------------------------
get_product_version() {
   while true; do
      if [ -n "$PRODUCT_VERSION" ]; then
         PRODUCT_VERSION=$PRODUCT_VERSION
         break
      else
         echo         
		 echo "Enter WBI version that you migrtated [602 | 610 |612]:"
         read PRODUCT_VERSION
         continue
      fi
   done
}

#--------------------------------------------
# Ask user for Database name
#--------------------------------------------
get_db_name() {
   while true; do
      if [ -n "$DB_NAME" ]; then
         DB_NAME=$DB_NAME
         break
      else
         echo         
		 echo "Enter Oracle SID[orcl]:"
         read DB_NAME
         continue
      fi
   done
}

#--------------------------------------------
# Ask user for Database user
#--------------------------------------------
get_db_user() {
   while true; do
      if [ -n "$DB_USER" ]; then
         DB_USER=$DB_USER
         break
      else
         echo         
		 echo "Enter Oracle user[dbCommonUserId]:"
         read DB_USER
         continue
      fi
   done
}


if [ $# == 0 -o $# == 3  ]; then
   	PRODUCT_VERSION=$1
	DB_NAME=$2
	DB_USER=$3
else
	echo
	echo "One or more parameters are missing..."
	echo
    print_message
fi


CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

#call the following subroutine to get oracle credentials
get_product_version
get_db_name
get_db_user

#Connect to the database specifying the id and the password

ls | grep "upgradeSchema${PRODUCT_VERSION}_" | sed s/^/\@/ > $PRODUCT_VERSION.sql
echo quit >> $PRODUCT_VERSION.sql

rc=0

sqlplus $DB_USER@$DB_NAME @$PRODUCT_VERSION.sql

rc=$?

rm -f  $PRODUCT_VERSION.sql

if [ $rc -ne 0 ] ; then
    echo 
    echo "username/password/dbname may be wrong. Please re-enter correct username/password/SID."
	echo
fi

exit $?

