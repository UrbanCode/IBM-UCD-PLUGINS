--BEGIN CMVC
--*************************************************************************
--
--  Workfile: WBISRVR/ws/code/scheduler.wbi/src/dbscripts/CommonDB/DB2/createTable_AppScheduler.sql, wbi.scheduler, WBI62.WBISRVR, of0914.16
--  Last update: 07/03/16 03:24:21
--  SCCS path, id: /family/botp/vc/10/9/8/9/s.67 1.2
--
--*************************************************************************
--END CMVC
--BEGIN COPYRIGHT
--*************************************************************************
--
--  Licensed Materials - Property of IBM
--  5724-L01, 5655-N53, 5724-I82, 5655-R15
--  (C) Copyright IBM Corporation 2004, 2006, 2007.
--  All rights reserved. US Government Users Restricted Rights - Use,
--  duplication, or disclosure restricted by GSA ADP Schedule Contract with
--  IBM Corp.
--
--*************************************************************************
--END COPYRIGHT
--
-- Scriptfile to create schema (tables) in DB2 on iSeries
------------------------------------------------------------------------
-- The code assumes an implicit schema, i.e. the tables
-- and views have to be created in a collection that has
-- the name of the user connected to use the product.
-- You may want to create the collection using:
--     db2 create collection <username>
-- before applying this script
------------------------------------------------------------------------
-- 1. Process this script in the DB2 command line processor
-- Example:
--            db2 connect to <dbname> user <user name> using <user password>
--            db2 -tf createTable_AppScheduler.sql

-- create the schema

CREATE TABLE WSCH_TASK
(
  TASKID             BIGINT                NOT NULL ,
  VERSION            VARCHAR(5)            NOT NULL ,
  ROW_VERSION        INTEGER               NOT NULL ,
  TASKTYPE           INTEGER               NOT NULL ,
  TASKSUSPENDED      SMALLINT              NOT NULL ,
  CANCELLED          SMALLINT              NOT NULL ,
  NEXTFIRETIME       BIGINT                NOT NULL ,
  STARTBYINTERVAL    VARCHAR(254)                   ,
  STARTBYTIME        BIGINT                         ,
  VALIDFROMTIME      BIGINT                         ,
  VALIDTOTIME        BIGINT                         ,
  REPEATINTERVAL     VARCHAR(254)                   ,
  MAXREPEATS         INTEGER               NOT NULL ,
  REPEATSLEFT        INTEGER               NOT NULL ,
  TASKINFO           BLOB(102400) LOGGED NOT COMPACT ,
  NAME               VARCHAR(254)          NOT NULL ,
  AUTOPURGE          INTEGER               NOT NULL ,
  FAILUREACTION      INTEGER                        ,
  MAXATTEMPTS        INTEGER                        ,
  QOS                INTEGER                        ,
  PARTITIONID        INTEGER                        ,
  OWNERTOKEN         VARCHAR(200)          NOT NULL ,
  CREATETIME         BIGINT                NOT NULL
) ;

ALTER TABLE WSCH_TASK ADD PRIMARY KEY (TASKID);

CREATE INDEX WSCH_TASK_IDX1 ON WSCH_TASK
(
  TASKID, OWNERTOKEN
) ;

CREATE INDEX WSCH_TASK_IDX2 ON WSCH_TASK
(
  NEXTFIRETIME ASC ,
  REPEATSLEFT ,
  PARTITIONID
) CLUSTER;

CREATE TABLE WSCH_TREG
(
  REGKEY             VARCHAR(254)          NOT NULL ,
  REGVALUE           VARCHAR(254)
) ;

ALTER TABLE WSCH_TREG ADD PRIMARY KEY (REGKEY);

CREATE TABLE WSCH_LMGR
(
  LEASENAME          VARCHAR(254)          NOT NULL ,
  LEASEOWNER         VARCHAR(254)          NOT NULL ,
  LEASE_EXPIRE_TIME  BIGINT                         ,
  DISABLED           VARCHAR(5)
) ;

ALTER TABLE WSCH_LMGR ADD PRIMARY KEY (LEASENAME);

CREATE TABLE WSCH_LMPR
(
  LEASENAME          VARCHAR(254)          NOT NULL ,
  NAME               VARCHAR(254)          NOT NULL ,
  VALUE              VARCHAR(254)          NOT NULL
) ;

CREATE INDEX WSCH_LMPR_IDX1 ON WSCH_LMPR
(
  LEASENAME, NAME
) ;
