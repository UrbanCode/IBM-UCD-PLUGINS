--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to drop schema in Oracle 9i and Oracle 10g
-- Process this script using SQL*Plus
----------------------------------------------------------------------
-- The following variable needs to be changed for customization and
-- before running this script.
-- @SCHEMA@ = Schema name
----------------------------------------------------------------------
-- example: sqlplus scott/tiger@mydb @dropSchema_Observer.sql
-- or, at the sqlplus prompt, enter
-- SQL> @dropSchema_Observer.sql


-----------------
-- Drop tables --
-----------------

DROP TABLE @SCHEMA@.OBSERVER_VERSION;

DROP TABLE @SCHEMA@.INST_PRC_T;

DROP TABLE @SCHEMA@.INST_ACT_T;

DROP TABLE @SCHEMA@.EVENT_PRC_T;

DROP TABLE @SCHEMA@.EVENT_ACT_T;

DROP TABLE @SCHEMA@.QUERY_T;

DROP TABLE @SCHEMA@.SLICES_T;

DROP TABLE @SCHEMA@.OPEN_EVENTS_T;

--------------------------------------------------------------------------------
--  Licensed Materials - Property of IBM
--  5655-FLW (C) Copyright IBM Corporation 2005,2007.
--  All Rights Reserved.
--  US Government Users Restricted Rights-
--  Use, duplication or disclosure restricted
--  by GSA ADP Schedule Contract with IBM Corp.
--------------------------------------------------------------------------------
--   Version 1.3
--   Last update: 07/07/17 03:30:22
--------------------------------------------------------------------------------
--
-- SQL snippet to drop Observer UDFs
-- for Oracle 9i and Oracle 10g
--
--------------------------------------------------------------------------------
--
-- Note:
--
-- If you used the java based Observer functions, you also must uninstall the
-- jar file bpcodbutil.jar from the database as follows:
--
-- $ORACLE_HOME/bin/dropjava -user <user>/<password>@<database> bpcodbutil.jar
--
--------------------------------------------------------------------------------
-- Following variables needs to be changed for customization and
-- before running this script:
--
--   @SCHEMA@ = Schema Qualifier


-------------------
-- Drop function --
-------------------

DROP FUNCTION @SCHEMA@.INTERVALIN;
DROP FUNCTION @SCHEMA@.OBSVR_JAR_ACTIVE;
QUIT
