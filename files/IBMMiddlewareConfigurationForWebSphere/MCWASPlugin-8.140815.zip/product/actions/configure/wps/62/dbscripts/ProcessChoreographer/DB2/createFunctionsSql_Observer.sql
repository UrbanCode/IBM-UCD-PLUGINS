--------------------------------------------------------------------------------
--  Licensed Materials - Property of IBM
--  5655-FLW (C) Copyright IBM Corporation 2005,2007.
--  All Rights Reserved.
--  US Government Users Restricted Rights-
--  Use, duplication or disclosure restricted
--  by GSA ADP Schedule Contract with IBM Corp.
--------------------------------------------------------------------------------
--   Version 1.4
--   Last update: 07/07/17 03:04:47
--------------------------------------------------------------------------------
--
-- SQL snippet for Observer SQL based UDF
-- for DB2 (distributed)
--
--------------------------------------------------------------------------------

----------------------
-- Create functions --
----------------------

CREATE FUNCTION @SCHEMA@.INTERVALIN (INTERVAL INT, TS_START TIMESTAMP, TS_END TIMESTAMP)
  RETURNS INTEGER
  LANGUAGE SQL
  READS SQL DATA
  NO EXTERNAL ACTION
  DETERMINISTIC
  RETURN TIMESTAMPDIFF(INTERVAL,CHAR(TS_END - TS_START));

CREATE FUNCTION @SCHEMA@.INTERVALIN (INTERVAL INT, TS_START TIMESTAMP, VC_END VARCHAR(26))
  RETURNS INTEGER
  LANGUAGE SQL
  CONTAINS SQL
  NO EXTERNAL ACTION
  DETERMINISTIC
  RETURN TIMESTAMPDIFF(INTERVAL,CHAR(CAST(VC_END AS TIMESTAMP) - TS_START));

CREATE FUNCTION @SCHEMA@.INTERVALIN (INTERVAL INT, VC_START VARCHAR(26), TS_END TIMESTAMP)
  RETURNS INTEGER
  LANGUAGE SQL
  READS SQL DATA
  NO EXTERNAL ACTION
  DETERMINISTIC
  RETURN TIMESTAMPDIFF(INTERVAL,CHAR(TS_END - CAST(VC_START AS TIMESTAMP)));

CREATE FUNCTION @SCHEMA@.INTERVALIN (INTERVAL INT, VC_START VARCHAR(26), VC_END VARCHAR(26))
  RETURNS INTEGER
  LANGUAGE SQL
  READS SQL DATA
  NO EXTERNAL ACTION
  DETERMINISTIC
  RETURN TIMESTAMPDIFF(INTERVAL,CHAR(CAST(VC_END AS TIMESTAMP) - CAST(VC_START AS TIMESTAMP)));

CREATE FUNCTION @SCHEMA@.OBSVR_JAR_ACTIVE ()
  RETURNS INTEGER
  LANGUAGE SQL
  NO EXTERNAL ACTION
  DETERMINISTIC
  RETURN 0;

