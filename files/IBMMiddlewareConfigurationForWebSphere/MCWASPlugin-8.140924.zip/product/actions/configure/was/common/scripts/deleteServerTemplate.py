"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: deleteServerTemplate.py
	
	This script is to delete an server template on a node.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f deleteServerTemplate.py -nodename <node name> -template <jvm template name>
		-template <template name>: specify the name of the server template to be created
		-nodename <node name>: specify the node name of the server template to be created 
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import sys

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'nodename:;template:' )

cellname = AdminControl.getCell()
nodename = optDict['nodename']

deleteServerTemplateLogger = _Logger("deleteServerTemplate", MessageManager.RB_WEBSPHERE_WAS)

# Check if it is a valid node
node = AdminConfig.getid( '/Cell:' + cellname + '/Node:' + nodename + '/' )

if node == "":
	raise "\ndeleteServerTemplate.py: Error -- Invalid node name: " + nodename 
#endIf

templName = optDict['template']

if templName == "":
	raise "\ndeleteServerTemplate.py: Error -- template name is not specified. "
#endif

# Check if a template by this name already existing on the node

templ = AdminConfig.listTemplates('Server', templName)
	
if templ == "":
	#print "\ndeleteServerTemplate.py: Warn -- the template " + templName + " is not exist. "
	deleteServerTemplateLogger.log("CRWWA1013W",[templName])
else:
	AdminTask.deleteServerTemplate(templ)
	AdminHelper.saveAndSyncCell()
#endIf

#end main		


