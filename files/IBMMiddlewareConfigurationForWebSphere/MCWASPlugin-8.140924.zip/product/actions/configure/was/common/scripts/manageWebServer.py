"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: manageWebServer.py
	
	This script is to manage an existing web server sub config based on type
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f manageWebServer.py 
		-properties <server xml file> 
		-config_type <sub config element name>
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
import Globals
import ConfigMediator

from ConfigWriter import ConfigWriter
from ConfigFileWriter import ConfigFileWriter
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from XmlProperty import SkipNamedAttribute
from AdminHelper import AdminHelper
#import Logger
from Logger import _Logger
from ConfigReader import newline
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

manageWebServerLogger = _Logger("manageWebServer", MessageManager.RB_WEBSPHERE_WAS)	
newline = java.lang.System.getProperty("line.separator")

class ManageWebServer:
	def __init__(self, mode):
		# a cache of previously discovered mgmt scope ids
		self.mode = mode
		self.GenericConfigFileWriter = ConfigFileWriter()
	#endDef
	
	def processServer(self, pairs, xmlFile, configType, save="1"):
		
		if (self.mode == ConfigMediator.MODE_EXECUTE):
			#We don't care about the node names in execute mode
			serverIds = []
			for p in pairs:
				serverIds.append(p[1])
			#endFor
			myConfigWriter = ConfigWriter();
			##print "Updating server config: "
			manageWebServerLogger.log("CRWWA2008I")
			serversByName = self.getServerIdByNameDict(serverIds)
			xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
			##We only store the node to help with propogating the plugin
			xmlProp.addSkipAttributeOnWriteFilter(SkipNamedAttribute('node'))
			xmlProp = xmlProp.findRAFWContainerNode(configType)
			xmlServers = xmlProp.getFilteredNodeArray("Server")
			for xmlServer in xmlServers:
				nodeArray = xmlServer.getFilteredChildrenArray(configType)
				## if xmlServer object has a name attribute, update the server given by that name
				if (xmlServer.hasAttr("name")) :
					serverName = xmlServer.getAttrValue("name")
					if (serversByName.has_key(serverName)):
						serverId = serversByName[serverName]
						objId, configType = self.processConfigType(serverId, configType)
						myConfigWriter.updateWASObject(nodeArray, objId, configType)
					else:
						##print "WebServer configuration does not exist in the cell.  It cannot be updated: " + serverName
						manageWebServerLogger.log("CRWWA2009I",[serverName])
				else:
					## else update all servers in the cell
					for serverId in serverIds:
						objId, configType = self.processConfigType(serverId, configType)
						myConfigWriter.updateWASObject(nodeArray, objId, configType)
					#endFor
				#endIf
			#endFor
			if save is not None:
				AdminHelper.saveAndSyncCell()
			#endIf
		elif (self.mode == ConfigMediator.MODE_IMPORT):
			#print "Importing server config: " 
			manageWebServerLogger.log("CRWWA5021I")
			# this is going to get the info for each server in scope, writing all to the config file
			data = []
			for pair in pairs:
				nodeName = pair[0]
				serverId = pair[1]
				##print "processing server: " + serverId + " on Node " + nodeName
				manageWebServerLogger.log("CRWWA2010I",[serverId,nodeName])
				config = self.readServerConfigData(serverId, nodeName, configType)
				data.append(config)
			#endFor
	
			# inject it into the file
			self.GenericConfigFileWriter.processBasicFile(xmlFile, data, configType)
	
		elif (self.mode == ConfigMediator.MODE_COMPARE):
			self.compareServers(pairs, xmlFile, configType)
		else:
			##print "Unsupported MODE supplied: " + mode
			manageWebServerLogger.log("CRWWA2011I",[self.mode])
		#endIf
	#endDef
	
	def compareServers(self, pairs, xmlFile, configType):
	
		if (len(pairs) == 0):
			##print "   No Servers of type 'WEB_SERVER' found in WebSphere configuration."
			manageWebServerLogger.log("CRWWA2014I")
		#endIf
		wasConfig = []
		for pair in pairs:
			nodeName = pair[0]
			serverId = pair[1]
			serverId, configType = self.processConfigType(serverId, configType)
			# get wasConfig
			serverConfig = self.readServerConfigData(serverId, nodeName, configType)
			wasConfig.append(serverConfig)
		#endFor
			
		# get rafwConfig
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(configType)
		
		filteredNodes = xmlProp.getFilteredNodeArray("Server")
		xmlConfigReader = XMLConfigReader()
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		
		ConfigComparor.compare(configType, wasConfig, rafwConfig)
	#endDef
	
	def getServerIdByNameDict(self, serverIds):
		serversByName = {}
		for serverId in serverIds:
			name=AdminConfig.showAttribute(serverId,"name")
			serversByName[name] = serverId
		#endFor
		return serversByName
	#endDef
	
	def processConfigType(self, scopeId, configType):
		## if configType contains [.] process until the last type 
		## and use that id as the scopeid
		start = configType.rfind('.') + 1
		if (start > 0):
			preTypes = configType[0:configType.rfind('.')]
			end = len(configType)
			configType = configType[start:end]
			types = preTypes.split('.')
			for type in types:
				#print "configType=" + configType
				manageWebServerLogger.log("CRWWA5029I",[configType])
				#print "this type=" + type
				manageWebServerLogger.log("CRWWA5030I",[type])
				#print "scopeId=" + scopeId
				manageWebServerLogger.log("CRWWA5031I",[scopeId])
				scopeId = AdminConfig.list( type, scopeId ).split( newline )[0]
			#endFor
		#endIf
		return [scopeId, configType]
	#endDef
	
	def readServerConfigData(self, serverId, nodeName, configType):
		## save original config type for later usage in writing the xml
		rafwConfigType = configType
		
		serverId, configType = self.processConfigType(serverId, configType)
		
		data = []
		for objId in AdminConfig.list( configType, serverId ).split( newline ):
			#print "found: " + objId
			manageWebServerLogger.log("CRWWA5026I",[objId])
			if ( len(objId) > 0 ):
				importedIds = []
				## exclude the serverId from the import, so that we don't get the parent, 
				## but only the children config elements
				importedIds.append(serverId)
				excludedTypes = []
				myConfigReader = ConfigReader(importedIds, excludedTypes)
				
				configData = myConfigReader.showAll(objId)
				configData['id'] = rafwConfigType
				data.append(configData)
			#endIf
		#endFor
		## add the parent wrapper info to be used on update
		config = {}
		config['id'] = "Server"
		config['attrs'] = {}
		serverName=AdminConfig.showAttribute(serverId,"name")
		config['attrs']['name'] = serverName
		config['attrs']['node'] = nodeName
		config['children'] = data
		return config
	#endDef
	
	def findServersInScope(self):	
		pairs = []
		
		nodes = AdminHelper.listNodes();
		for node in nodes:
			nodeName = AdminConfig.showAttribute(node, 'name')
			servers= AdminConfig.list('WebServer', node).split(newline)
			for server in servers:
				if server != "":
					serverName = AdminConfig.showAttribute(server, 'name')
					##print 'Found WebServer ' + str(serverName) + ' on Node ' + str(nodeName)
					manageWebServerLogger.log("CRWWA2015I",[str(serverName),str(nodeName)])
					pairs.append([nodeName, server])
				#endIf
			#endFor
		#endFor
		return pairs
	#endDef
	
	def processWebServers(self, xmlFile, configType, save="1"):
		nodeServerPairs = self.findServersInScope()
		self.processServer(nodeServerPairs, xmlFile, configType, save)
	#endDef
#endClass

def export(optDict=None):
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	configType = optDict['type']
	mws = ManageWebServer(mode)
	mws.processWebServers(xmlFile, configType, None)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:;config_type:' )
	
	# get scope
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	configType = optDict['config_type']
	mws = ManageWebServer(mode)
	mws.processWebServers(xmlFile, configType)
#endIf