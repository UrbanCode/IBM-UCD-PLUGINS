"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: mailProviders.py
	
	Creates, Imports, Compares and Augments Mail Providers and Mail Sessions 
	at the selected scope in a WAS cell
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from AdminHelper import AdminHelper
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigValidator import ConfigValidator
from XmlProperty import InvalidXmlConfigException
import Globals

class MailConfigReader(ConfigReader):
	
	def __init__(self, importedIds=[], excludedTypes = [], excludedAttributes = []):
		ConfigReader.__init__(self, importedIds, excludedTypes, excludedAttributes)
		self.LOGGER = _Logger("MailConfigReader", MessageManager.RB_WEBSPHERE_WAS)
	#endDef	
	
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
		
		data = []
		scopeId = AdminConfig.getid(scope)
		if (len(scopeId) == 0):
			self.LOGGER.error("ERROR: unable to find parent scope: " + scope + "  Cannot read config data.")
			return data
		#endIf
	
		for objId in AdminConfig.list(configType, scopeId).split(newline):
			self.importedIds = []
			## if anything found, is in scope
			if (len(objId) > 0 and AdminHelper.isInScope(scopeType, objId)):
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							match = "yes"
	           		#endIf
					if (match == "no"):
						self.LOGGER.log("Importing " + objId)
						self.importedIds.append(objId)
						data.append(self.showAll(objId))
				else:
					self.LOGGER.log("Importing " + objId)
					self.importedIds.append(objId)
					data.append(self.showAll(objId))
				#endIf
			#endIf
		#endFor
		return data
	#endDef
	
	def getWASType(self, id):
		"""
		Overrides getWASType in ConfigReader to handle <builtin> cases.  Built ins can be more than just the MailProvider
		so for all other built ins, we handle them like real config types, so that the reference handling logic on write
		can correctly find and update references to these specific builtins
		"""
		self.LOGGER.traceEnter(id)
		## based on id, if this is a built-in and we can match it a real config type
		if (id.find("#builtin") > 0 and (not id.find("#builtin_mailprovider") > 0)):
			self.LOGGER.trace("found a builtin: " + id)
			self.LOGGER.trace("and its not the mail provider, replacing type with <ProtocolProvider>")
			wasType = "ProtocolProvider"
		else:
			wasType = ConfigReader.getWASType(self, id)
		#endIf
		self.LOGGER.traceExit(wasType)
		return wasType
	#endDef
	
#endClass

class dsMediator:
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames, augment):
	
		self.myConfigWriter = ConfigWriter();
		self.myConfigWriter.setConfigReader(MailConfigReader())
		typeNames.append("builtin")
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		scopeId = AdminConfig.getid( scope )
		parentIdNodeArray = []
		for typeName in typeNames:
			if (augment):
				parentIdNodeArray.extend(self.augmentConfigType(scopeId, scopeType, xmlProp, typeName))
			else:
				parentIdNodeArray.extend(self.createConfigType(scopeId, scopeType, xmlProp, typeName))
			#endIf
		#endFor
		## the only references for MailSession should be contained within the MailProvider parent
		## so for this case, the initial scope to search from is the MailProvider id
		for parentIdNode in parentIdNodeArray:
			parentId = parentIdNode[0]
			xmlNode = parentIdNode[1]
			self.myConfigWriter.updateWASReferenceAttributes([xmlNode], parentId, ["MailProvider", "builtin"])
		#endFor
	#endDef
	
	def createConfigType(self, scopeId, scopeType, xmlProp, typeName):
		SCRIPT_LOGGER.traceEnter([scopeId, scopeType, xmlProp, typeName])
	
		## find object ids for references and set the same on objects created by this method
		
		if ( typeName != "builtin" ):
			self.myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
		#endIf
	
	 	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	 	parentIdNodeArray = []
	
		for xmlNode in nodeArray:
			if (typeName == "MailSession"):
				parentId = self.createMailSession(xmlNode) 
				parentIdNodeArray.append([parentId, xmlNode])
			elif (typeName == "builtin"):
				mailProviderName= "Built-in Mail Provider"
				parentId = AdminHelper.findProviderIdByName( scope, 'MailProvider', mailProviderName)[0]
				self.myConfigWriter.modify(parentId, xmlNode, [])
				parentIdNodeArray.append([parentId, xmlNode])
			else:
				#typeName is MailProvider
				mailProviderName = xmlNode.getAttrValue("name")
				parentId = AdminConfig.getid(scope)
				self.myConfigWriter.createWASObject(xmlNode, parentId)
				parentIdNodeArray.append([parentId, xmlNode])
			#endIf
		#endFor
		SCRIPT_LOGGER.traceExit()
		return parentIdNodeArray
	#endDef

	def augmentConfigType(self, scopeId, scopeType, xmlProp, typeName):
		SCRIPT_LOGGER.traceEnter([scopeId, scopeType, xmlProp, typeName])
	
		## find object ids for references and set the same on objects created by this method
		configValidator = ConfigValidator()
	 	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	 	parentIdNodeArray = []
	
		for xmlNode in nodeArray:
			if (typeName == "MailSession"):
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					##print "Info: Processing " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					SCRIPT_LOGGER.log("CRWWA1108I", [typeName, xmlNode.getAttrValue("jndiName")])
					parentId = self.createMailSession(xmlNode)
					parentIdNodeArray.append([parentId, xmlNode])
				else:
					if (SystemUtils.updateOnAugment()):
						self.myConfigWriter.modify(childId, xmlNode)
						parentId = AdminHelper.findProviderId(xmlNode, scope, "MailProvider", "name", "builtin")
						parentIdNodeArray.append([parentId, xmlNode])
					else:
						##print "Warning: " + typeName + " will not be created."
						SCRIPT_LOGGER.log("CRWWA1109W", [typeName])
				#endIf
			elif (typeName == "builtin"):
				mailProviderName= "Built-in Mail Provider"
				parentId = AdminHelper.findProviderIdByName( scope, 'MailProvider', mailProviderName)[0]
				childArray = xmlNode.getChildrenArray()
				for xmlChild in childArray:
					childId = configValidator.validateUniqueAttrs2(xmlChild, scopeId)
					childType = xmlChild.getNodeNameFixed()
					if (childId is None):
						##print "Info: Creating " + childType + " under " + mailProviderName
						SCRIPT_LOGGER.log("CRWWA1149I", [childType, mailProviderName])
						self.myConfigWriter.createWASObject(xmlChild, parentId)
					else:
						if (SystemUtils.updateOnAugment()):
							self.myConfigWriter.modify(childId, xmlChild)
						else:
							##print "Warning: " + childType + " under " + mailProviderName + " will not be created."
							SCRIPT_LOGGER.log("CRWWA1149W", [childType, mailProviderName])
						#endIf
					#endIf
				#endFor
			else:
				#typeName is MailProvider
				mailProviderName = xmlNode.getAttrValue("name")
				childId = configValidator.validate2(xmlNode, scopeId)
				if (childId is None):
					##print "Info: Creating " + typeName + " with name " + mailProviderName
					SCRIPT_LOGGER.log("CRWWA1149I", [typeName, mailProviderName])
					self.myConfigWriter.createWASObject(xmlNode, scopeId)
					parentIdNodeArray.append([scopeId, xmlNode])
				else:
					if (SystemUtils.updateOnAugment()):
						self.myConfigWriter.modify(childId, xmlNode)
						parentIdNodeArray.append([childId, xmlNode])
					else:
						##print "Warning: " + typeName + " will not be created."
						SCRIPT_LOGGER.log("CRWWA1109W", [typeName])
					#endIf
				#endIf
			#endIf
		#endFor
		SCRIPT_LOGGER.traceExit()
		return parentIdNodeArray
	#endDef

	"""
	returns the parent id under which the mail session was created
	"""
	def createMailSession(self, xmlNode):
		try:
			jndiNameDisplay = xmlNode.getAttrValue("jndiName", Globals.ATTRIBUTE_VALUE_MISSING)
			# xml could define MailProvider or <builtin>
			parentId = AdminHelper.findProviderId(xmlNode, scope, "MailProvider", "name", "builtin")
			SCRIPT_LOGGER.trace("Found MailProvider with id: " + str(parentId))
			##print "Info: Creating MailSession with jndiName: " + jndiNameDisplay
			SCRIPT_LOGGER.log("CRWWA1150I", [jndiNameDisplay])
			self.myConfigWriter.createWASObject(xmlNode, parentId, ['builtin', "MailProvider" ])
			return parentId
		except InvalidXmlConfigException, e:
			##print "Error: The MailProvider cannot be found for a custom or built in MailProvider"
			SCRIPT_LOGGER.log("CRWWA1150E")
			##print "The MailSession cannot be created without a valid MailProvider"
			SCRIPT_LOGGER.log("CRWWA1155I")
			raise e
		#endTry
	#endDef	
#endClass

def compareMailConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, myConfigReader):
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	xmlConfigReader = XMLConfigReader()
	# get wasConfig
	for typeName in typeNames:
		wasConfig = myConfigReader.readConfigData(scope, scopeType, typeName, excludedTypes)

		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(typeName)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		if (typeName == "MailProvider"):
			# we also need to include <builtin> in the comparison
			builtInFilteredNodes = xmlProp.getFilteredNodeArray("builtin")
			rafwConfig = rafwConfig + xmlConfigReader.readXmlConfig(builtInFilteredNodes)
		#endIf	
		ConfigComparor.compare(typeName, wasConfig, rafwConfig)
	#endFor
#endDef

def export(optDict=None):
	global scope
	scope = optDict['wasscopetype']
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	
	mode = optDict['mode']
	excludeTypes = optDict['excludedtypes']
	
	excludedAttributes = optDict['excludedattrs']
	myConfigReader = MailConfigReader()
	myConfigReader.setExcludedAttributes(excludedAttributes)
	
	typeNames = [optDict['type']]
	thisMediator = dsMediator()
	global SCRIPT_LOGGER
	SCRIPT_LOGGER = _Logger("mailProviders", MessageManager.RB_WEBSPHERE_WAS)
	marker = optDict['marker']
	
	thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames, 0)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	
	mode = optDict['mode']
	excludeTypes = []
	
	excludedAttributes = ['MailSession.mailStorePort', 'MailSession.mailTransportPort']
	myConfigReader = MailConfigReader()
	myConfigReader.setExcludedAttributes(excludedAttributes)
	
	typeNames = ["MailProvider","MailSession"]
	thisMediator = dsMediator()
	SCRIPT_LOGGER = _Logger("mailProviders", MessageManager.RB_WEBSPHERE_WAS)
	marker = "mailProviders"
	
	if (mode == MODE_EXECUTE):
	
		##print "Creating Mail Providers in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA1151I", [scope])
		thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames, 0)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
		##print "Augmenting Mail Providers in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA1152I", [scope])
		thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames, 1)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing Mail Providers in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA1153I", [scope])
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, myConfigReader)
	
	elif (mode == MODE_COMPARE):
		##print "Comparing Mail Providers in RAFW and WAS in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA1154I", [scope])
		compareMailConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, myConfigReader)
	
	else:
		##print "Unsupported MODE supplied: " + mode
		SCRIPT_LOGGER.log("CRWWA0008W", [mode])
	#endIf
#endIf