-- @start_restricted_prolog@
-- Licensed Materials - Property of IBM
-- 
-- 5724-I82 5724-L01 5655-N53 5655-R15 5655-N63               
-- Copyright IBM Corporation 2005 All Rights Reserved.
-- US Government Users Restricted Rights- Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- @end_restricted_prolog@

-- DB2UDB V8.2 schema for Message Logger Mediation

CREATE SCHEMA ESBLOG;

CREATE TABLE ESBLOG.MSGLOG
  (TIMESTAMP TIMESTAMP NOT NULL,
   MESSAGEID VARCHAR(36) NOT NULL,
   MEDIATIONNAME VARCHAR(256) NOT NULL,
   MODULENAME VARCHAR(256),
   MESSAGE CLOB(100000K),
   VERSION VARCHAR(10));

ALTER TABLE ESBLOG.MSGLOG
  ADD CONSTRAINT PK_MSGLOG PRIMARY KEY (TIMESTAMP, MESSAGEID, MEDIATIONNAME);

