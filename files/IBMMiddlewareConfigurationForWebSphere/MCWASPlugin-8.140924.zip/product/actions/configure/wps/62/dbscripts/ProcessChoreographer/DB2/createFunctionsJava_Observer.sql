--------------------------------------------------------------------------------
--  Licensed Materials - Property of IBM
--  5655-FLW (C) Copyright IBM Corporation 2007.
--  All Rights Reserved.
--  US Government Users Restricted Rights-
--  Use, duplication or disclosure restricted
--  by GSA ADP Schedule Contract with IBM Corp.
--------------------------------------------------------------------------------
--   Version 1.4
--   Last update: 07/07/17 03:03:50
--------------------------------------------------------------------------------
--
-- SQL snippet for Observer java based UDF
-- for DB2 (distributed)
--------------------------------------------------------------------------------
--
-- Before you can use this SQL file to switch to the Java based Observer
-- functions, you must ensure that you have installed the utility jar
-- $WAS_HOME/lib/bpcodbutil.jar using the setupEventCollector tool or by
-- using the following command, locally on the database server, connected to
-- the database:
--
--    db2 call sqlj.install_jar('file:pathURL','BPCODBUTIL')
--
-- where pathURL is a fully qualified URL to the jar file.
--
-- For example:
--
-- - On Windows platforms, if the jar file is in the directory c:\tmp,
--   you must enter the command:
--
--     db2 call sqlj.install_jar('file:c:/tmp/bpcodbutil.jar','BPCODBUTIL')
--
-- - On Linux and UNIX platforms, if the jar file is in the directory /tmp,
--   you must enter the command:
--
--     db2 call sqlj.install_jar('file:/tmp/bpcodbutil.jar','BPCODBUTIL')
--
-- Note:
--
--   If you receive
--
--     SQL20201N The install, replace or remove of "<jar-id>" failed as the jar
--     name is invalid.
--
--   the jar file may already be installed. Use REPLACE_JAR then instead.
--------------------------------------------------------------------------------

----------------------
-- Create functions --
----------------------
CREATE FUNCTION
  @SCHEMA@.INTERVALIN ( INT, TIMESTAMP, TIMESTAMP)
  RETURNS INT
  EXTERNAL NAME '@SCHEMA@.BPCODBUTIL:com.ibm.bpe.observer.dbutil.TimestampUtil.intervalinInt'
  LANGUAGE JAVA
  PARAMETER STYLE JAVA
  DETERMINISTIC
  FENCED THREADSAFE
  RETURNS NULL ON NULL INPUT
  NO SQL
  NO EXTERNAL ACTION
  ALLOW PARALLEL;

CREATE FUNCTION
  @SCHEMA@.INTERVALIN ( INT, TIMESTAMP, VARCHAR(26))
  RETURNS INT
  EXTERNAL NAME '@SCHEMA@.BPCODBUTIL:com.ibm.bpe.observer.dbutil.TimestampUtil.intervalinInt'
  LANGUAGE JAVA
  PARAMETER STYLE JAVA
  DETERMINISTIC
  FENCED THREADSAFE
  RETURNS NULL ON NULL INPUT
  NO SQL
  NO EXTERNAL ACTION
  ALLOW PARALLEL;

CREATE FUNCTION
  @SCHEMA@.INTERVALIN ( INT, VARCHAR(26), TIMESTAMP)
  RETURNS INT
  EXTERNAL NAME '@SCHEMA@.BPCODBUTIL:com.ibm.bpe.observer.dbutil.TimestampUtil.intervalinInt'
  LANGUAGE JAVA
  PARAMETER STYLE JAVA
  DETERMINISTIC
  FENCED THREADSAFE
  RETURNS NULL ON NULL INPUT
  NO SQL
  NO EXTERNAL ACTION
  ALLOW PARALLEL;

CREATE FUNCTION
  @SCHEMA@.INTERVALIN ( INT, VARCHAR(26), VARCHAR(26))
  RETURNS INT
  EXTERNAL NAME '@SCHEMA@.BPCODBUTIL:com.ibm.bpe.observer.dbutil.TimestampUtil.intervalinInt'
  LANGUAGE JAVA
  PARAMETER STYLE JAVA
  DETERMINISTIC
  FENCED THREADSAFE
  RETURNS NULL ON NULL INPUT
  NO SQL
  NO EXTERNAL ACTION
  ALLOW PARALLEL;

CREATE FUNCTION @SCHEMA@.OBSVR_JAR_ACTIVE ()
  RETURNS INTEGER
  LANGUAGE SQL
  NO EXTERNAL ACTION
  DETERMINISTIC
  RETURN 1;

