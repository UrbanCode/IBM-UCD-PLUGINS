-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- Copyright IBM Corporation 2008. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT


-- *******************************************
-- Schema change from 6.0.2 to 6.2
-- *******************************************

-- *******************************************
-- Populate data into SCHEMAVERSIONINFO
-- *******************************************
INSERT INTO SchemaVersionInfo VALUES ('recovery.ejb', 6, 2, 0, 0, 1);

INSERT INTO SchemaVersionInfo VALUES ('interfaceMediation', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('relationshipService', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('scheduler.wbi', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('customization', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('persistentlockmanager', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('governance', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('DirectDeploy', 6, 2, 0, 0, 0);

INSERT INTO SchemaVersionInfo VALUES ('WPS', 6, 2, 0, 0, 0);  
