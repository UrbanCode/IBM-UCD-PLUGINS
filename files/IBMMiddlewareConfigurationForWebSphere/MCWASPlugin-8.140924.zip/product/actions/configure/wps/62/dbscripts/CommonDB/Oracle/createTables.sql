--
-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2006,2008. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

define username = &1
accept password prompt 'Enter Oracle Password: ' hide
define host_string = &2
connect &username/&password@&host_string;
@createTable_AppScheduler.sql
@createTable_CommonDB.sql
@createTable_customization.sql
@createTable_lockmanager.sql
@createTable_mediation.sql
@createTable_Recovery.sql
@createTable_RelationshipMetadataTable.sql
@createTable_RelationshipViewMetaTable.sql
@insertTable_CommonDB.sql
@createTable_EsbLoggerMediation.sql
@createTable_governancerepository.sql
@createTable_DirectDeploy.sql
quit