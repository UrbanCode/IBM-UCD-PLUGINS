/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
package com.urbancode.air.plugin.datastage;
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;

public class DataStageHelper {


    public DataStageHelper() {
    }

    // Confirm each file ends with .dsx or .xml
    public void checkExtensions(String ... files) {
        if (files) {
            for (file in files) {
                if (!file.endsWith(".dsx") && !file.endsWith(".xml")) {
                    throw new Exception("${file} does not end with .dsx or .xml. All files must end with one of these two extensions.")
                }
            }
        }
        else {
            println "No files were given for extension checks."
        }
    }

    // Confirm each file ends with .dsx
    public void checkDSXExtensions(String ... files) {
        if (files) {
            for (file in files) {
                if (!file.endsWith(".dsx")) {
                    throw new Exception("${file} does not end with .dsx. All files must end with this extension.")
                }
            }
        }
        else {
            println "No files were given for DSX extension check."
        }
    }

    // Confirm each file ends with .isx
    public void checkISXExtensions(String ... isxs) {
        if (isxs) {
            def failFiles = []
            for (isx in isxs) {
                if (!isx.endsWith(".isx")) {
                    println "File '${isx}' does not end with .isx. All files must end with this extension."
                    failFiles << isx
                    continue
                }
                File file = new File(isx)
                if (!file.isFile()){
                    println "$File '{isx}' was not found. Please enter a valid pathname."
                    failFiles << isx
                    continue
                }
            }
            if (failFiles.size() > 0){
                throw new FileNotFoundException("The following files are invalid: ${failFiles}")
            }
        }
        else {
            println "No files were given for ISX extension check."
        }
    }

    // Closure to get the output from the dscmds
    def systemOutput = ""
    public def getSystemOutput = {Process proc ->
        def out = new PrintStream(System.out, true)
        def outputStream = new StringBuilder()
        try {
            proc.waitForProcessOutput(outputStream, out)
        }
        finally {
            out.flush();
        }
        systemOutput = outputStream.toString()
    }
}