/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def workDir = new File(".")
def ch = new CommandHelper(workDir)
def clusterName = props['cluster']
def nodeName = props['node']

def args = ['Powershell.exe', 'import-module', 'FailoverClusters', ';', 'Start-ClusterNode']

if (clusterName) {
    args << '-cluster'
    args << clusterName
}
args << '-name'
args << nodeName

ch.runCommand("Starting cluster services for the one specified node", args)
println "Cluster service started on the node."