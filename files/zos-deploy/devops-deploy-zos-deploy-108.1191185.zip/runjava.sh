#!/bin/sh
##############################################################################
##                                                                          ##
##  JVM Launcher for zOS                                                    ##
##                                                                          ##
##############################################################################

# Added /usr/lib directory to LIBPATH to include
# Binder shared libraries iewbndd6.so, iewbnddx.so and
# RACF Libraries libIRRRacf.so, libIRRRacf64.so
export LIBPATH=$LIBPATH:/usr/lib:$AGENT_BIN_HOME/lib/zos/:$PLUGIN_HOME/lib

echo "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$@"
echo '================================================================================'
exec "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$@"