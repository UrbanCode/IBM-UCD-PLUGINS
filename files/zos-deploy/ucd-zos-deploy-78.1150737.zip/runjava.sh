#!/bin/sh
##############################################################################
##                                                                          ##
##  JVM Launcher for zOS                                                    ##
##                                                                          ##
##############################################################################
echo "$JAVA_HOME"/bin/java "-Djava.library.path=$AGENT_BIN_HOME/lib/zos/" $JAVA_OPTS $ZOS_JAVA_OPTS "$@"
echo '================================================================================'
exec "$JAVA_HOME"/bin/java "-Djava.library.path=$AGENT_BIN_HOME/lib/zos/" $JAVA_OPTS $ZOS_JAVA_OPTS "$@"