import com.urbancode.air.CommandHelper

final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def cmdHelper = new CommandHelper(new File('.'));

final def packageFile = props['packageFile'];
final def updateOptions = (props['updateOptions']!=null && props['updateOptions'].trim() != "")?props['updateOptions'].split('\n'):null;
def packageFiles = packageFile.split('\n');

println "Using values : "
println "Package : " + packageFile

def cmdArgs = ['rpm', '-U'];

updateOptions.each {
   cmdArgs << it;
}

packageFiles.each {
   cmdArgs << it;
}

cmdHelper.runCommand("Updateing Package", cmdArgs);
