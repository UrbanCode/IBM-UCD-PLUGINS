import com.urbancode.air.CommandHelper

final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def cmdHelper = new CommandHelper(new File('.'));

final def packageNames = props['packageNames']?.split('\n');
final def uninstallOptions = (props['removeOptions']!=null && props['removeOptions'].trim() != "")?props['removeOptions'].split('\n'):null;

println "Using values : "
println "Package : " + packageNames

def cmdArgs = ['rpm', '-e'];

uninstallOptions.each {
   cmdArgs << it;
}

packageNames.each {
   cmdArgs << it;
}
cmdHelper.runCommand("Uninstalling Package", cmdArgs);
