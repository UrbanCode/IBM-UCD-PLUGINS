/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

final def workDir = new File('.').canonicalFile

def tomcatManagerUrl = props['tomcatManagerUrl'];
println "ManagerURL : " + tomcatManagerUrl;
def tomcatManagerUsername = props['tomcatUsername'];
println "ManagerUsername : " + tomcatManagerUsername;
def tomcatManagerPassword = props['tomcatPassword'];
def tomcatContext = props['tomcatContext'];
println "Tomcat context : " + tomcatContext;
def PLUGIN_HOME = System.getenv("PLUGIN_HOME");

def pluginHomeFile = new File(PLUGIN_HOME);
if (!pluginHomeFile.exists()) {
    throw new RuntimeException("Cannot get PLUGIN_HOME");
}

def libDir = new File(pluginHomeFile, "lib");
if (!libDir.exists()) {
    throw new RuntimeException("Cannot get lib directory!");
}

def catalinaJar = new File(libDir, "catalina-ant.jar");
if (!catalinaJar.exists()) {
    throw new RuntimeException("Cannot find cantalina-ant.jar!");
}

def ant = new AntBuilder();

try {
    ant.path(id:"tomcat.classpath") {
        pathelement(path:catalinaJar.getAbsolutePath());
    }
    ant.taskdef(name:"undeploy", classname:"org.apache.catalina.ant.UndeployTask", classpathref:"tomcat.classpath")
    ant.undeploy(url:"${tomcatManagerUrl}",
               username:"${tomcatManagerUsername}",
               password:"${tomcatManagerPassword}",
               path:"${tomcatContext}")
}
catch (Exception e) {
    System.out.println("Error deploying!");
    e.printStackTrace();
    System.exit(1);
}
