import com.urbancode.air.CommandHelper

final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
def regKey = props['regKey'];
def regType = props['regType'];
def regName = props['regName'];
def regData = props['regData'];
def forceString = props['force']
def force = Boolean.valueOf(forceString)
def ch = new CommandHelper(new File('.'));

def keyFound = true;
def args = [];
    
try {
    args = ['REG', 'QUERY', regKey, '/v', regName];
    ch.runCommand(args.join(' '), args);
}
catch (e) {
    //registry key was not found
    keyFound = false
}

try 
{
    if (!keyFound || force) {
        args = ['REG', 'ADD', regKey, '/v', regName, '/t', regType, '/d', regData];
        if (force) {
        	args << '/f'
        }
        
        ch.runCommand(args.join(' '), args);
    }
    else {
        //the key was found and we're not overwriting it
        throw new RuntimeException("The key already exists and overwrite was not enabled");
    }
}

catch (e) {
    println e
    System.exit 1
}
