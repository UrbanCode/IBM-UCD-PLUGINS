import com.urbancode.air.CommandHelper

final def props = new Properties()
final def inputPropsFile = new File(args[0])
final def inputPropsStream = null
try {
    inputPropsStream = new FileInputStream(inputPropsFile)
    props.load(inputPropsStream)
}
catch (IOException e) {
    throw new RuntimeException(e)
}
def regKey = props['regKey']
def destPath = props['destPath']
def forceString = props['force']

def force = Boolean.valueOf(forceString)

println "Registry Key:\t"+regKey
println "Destination file:\t"+destPath
println "Force overwrite:\t"+force

def ch = new CommandHelper(new File('.'))
try 
{
    def args = [];
    args = ['REG', 'EXPORT', regKey, destPath]
    if (force) {
    	args << '/y'
    }
    else if (new File(destPath)?.exists()) {
        throw new RuntimeException("File exists, and 'Force File Overwrite' is not selected");
    }
    
    ch.runCommand(args.join(' '), args)
}
catch (e) {
    println e
    System.exit 1
}
