#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* UrbanCode Build
* UrbanCode Release
* AnthillPro
* (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.*
import com.urbancode.air.securedata.Base64Codec;
import groovy.lang.GroovyClassLoader
import groovy.lang.Binding
import groovy.lang.GroovyShell
import java.io.File
import java.util.List
import java.util.Properties
import java.lang.Exception

final def workDir = new File('.').canonicalFile
final def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties()
final CommandHelper cmdHelper = new CommandHelper(workDir);

final def scriptBody = props['scriptBody']
final def groovyHome = props['groovyHome']
String classPaths = props['classPaths'] ?: ""
final def spawnProcess = Boolean.valueOf(props['spawnProcess'])

final def apTEncKey = apTool.getEncKey();
def encKey = apTEncKey != null ? apTEncKey : ""

final def apToolCipher = apTool.getSuite()
def cipher = (apToolCipher != "" && apToolCipher != null) ? apToolCipher : null

assert groovyHome
cmdHelper.removeEnvironmentVariable("GROOVY_HOME")

def script = """
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.securedata.Base64Codec;

final apTool = new AirPluginTool(args[0], args[1]);
final def suite = ${cipher != null ? "\"${cipher}\"" : "null"};
final def inProps = apTool.getStepProperties("${encKey}", suite);
final def outProps = new Properties();

addShutdownHook({
    outProps.each { key, value ->
        apTool.setOutputProperty(key, value);
    }
    apTool.setOutputProperties("${encKey}",  suite);
});

${scriptBody};
"""

List<String> classPathsToInclude = classPaths.split(",|\n")*.trim() - [""];
println("[Info] Externally supplied classPaths :" + classPathsToInclude);


def PLUGIN_HOME = new File(System.getenv("PLUGIN_HOME"));
def libDir = new File(PLUGIN_HOME, "lib");

def classpath = [];
classpath << new File(".")
classpath << new File(PLUGIN_HOME, "classes")
classpath << new File(libDir, "CommonsUtil.jar")
classpath << new File(libDir, "securedata.jar")
classpath << new File(libDir, "jettison.jar")
classpath << new File(libDir, "commons-codec.jar")

//Adding external classpaths specified by user
classPathsToInclude.each { cp ->
    File file = new File(cp)
    if (file.exists()) {
        classpath << file
    } else {
        throw new Exception("classpath : $cp - Not found - Please enter valid classpath.")
    }
}

if (spawnProcess) {
    String flattenedClasspath = classpath.collect { File cp -> cp.absolutePath }
            .join(File.pathSeparator)
    if (apTool.isWindows) {
        flattenedClasspath = "\"${flattenedClasspath}\""
    }
    File scriptFile = null;
    try {
        scriptFile = File.createTempFile("groovy_script_", ".groovy")
        scriptFile.text = script

        def groovyExec = new File(new File(groovyHome, "bin"), "groovy${apTool.isWindows ? '.bat' : ''}").absolutePath

        def command = [groovyExec, "-cp", flattenedClasspath, scriptFile.absolutePath,
                       args[0], args[1]]
        cmdHelper.runCommand("Running Groovy Script", command)
    } finally {
        if(scriptFile != null && scriptFile.exists())
            scriptFile.delete()
    }

} else {
    // --- Begin GroovyShell-based execution ---
    // Prepare GroovyClassLoader with custom classpath

    GroovyClassLoader loader = new GroovyClassLoader(this.class.classLoader)
    classpath.each { file ->
        loader.addURL(file.toURI().toURL())
    }

    // Prepare Binding with args and any other variables
    Binding binding = new Binding()
    binding.setVariable('args', this.args)

    // Evaluate the script in the current JVM
    GroovyShell shell = new GroovyShell(loader, binding)
    shell.evaluate(script)
    // --- End GroovyShell-based execution ---

}
