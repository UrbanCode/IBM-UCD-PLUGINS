/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.bmc.arsys.api.*;
import java.util.*;
import java.lang.*;


def user = props['user'];
def password = props['password'];
def server = props['server'] 
def port = Integer.valueOf(props['port']);
def filePath = props['filePath'];

ARServerUser arUser = new ARServerUser(user, password, "", "", server, port);
arUser.login();
println "Connected to ${server} as user ${user}";

arUser.importDefFromFile(filePath);