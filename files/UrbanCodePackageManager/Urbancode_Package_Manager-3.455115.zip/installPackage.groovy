#!/usr/bin/env groovy

import com.urbancode.air.CommandHelper


final def isWindows = (System.getProperty("os.name") =~ /(?i)windows/).find()
final def workDir = new File(".").canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def packageFile = new File(props["packageFile"])
final def PACKAGER_HOME = new File(props["packagerHome"])
final def installProperties = props["installProperties"]
final def forceInstallBool = Boolean.valueOf(props["forceInstall"])
final def skipDependencyCheckBool = Boolean.valueOf(props["skipDependencyCheck"])
final def impersonateUser = props["impersonateUser"]
final def impersonatePass = props["impersonatePass"]
final def inventoryName = props["inventory"]

final def installPropertiesArray = installProperties?.readLines()?.toArray(new String[0])

final def packagerBin = new File(PACKAGER_HOME, "bin")
final def packagerExe = new File(packagerBin, "packager" + (isWindows ? ".cmd" : ".sh")) 

//------------------------------------------------------------------------------
// PREPARE COMMAND LINE
//------------------------------------------------------------------------------
  
def command = [packagerExe.absolutePath, "install", packageFile.absolutePath]

if (forceInstallBool) {
    command << "-f"
}
if (skipDependencyCheckBool) {
    command << "-d"
}
if (impersonateUser != null && impersonateUser.length() > 0) {
    command << "-u" + impersonateUser
}
if (impersonatePass != null && impersonatePass.length() > 0) {
    command << "-p" + impersonatePass
}
if (inventoryName != null && inventoryName.length() > 0) {
    command << "-i" + inventoryName
}

installPropertiesArray.each() { installProperty ->
    command << installProperty
}

//------------------------------------------------------------------------------
// EXECUTE COMMAND LINE
//------------------------------------------------------------------------------

def ch = new CommandHelper(packagerBin);
ch.runCommand("Installing Package", command);
