package com.urbancode.air.plugin.rtw

class CommandLineHelper {
	
	CommandLineHelper() {
	}
	
	public def executeAndReturnValue(def cmdargs){
		def procBuilder = new ProcessBuilder(cmdargs);
		def statusProc = procBuilder.start();
		
		statusProc.waitFor();
		def installbr = new BufferedReader(new InputStreamReader(statusProc.getInputStream()));
		StringBuilder installcmdsb = new StringBuilder();
		def str = "";
		while((str= installbr.readLine())!=null){
			println "InstallDir " + str;
			installcmdsb.append(str+"\n");
		}
		return installcmdsb.toString();
	}

}
