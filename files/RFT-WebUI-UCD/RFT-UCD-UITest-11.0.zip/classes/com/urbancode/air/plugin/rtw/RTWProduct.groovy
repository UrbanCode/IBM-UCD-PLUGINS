package com.urbancode.air.plugin.rtw

// RIT, RFT
enum RTWProduct {
	RPT("com.ibm.rational.performance.tester_"), RTWec("com.ibm.rational.functional.tester_"), RST("com.ibm.rational.service.tester_"),
	MTE("com.ibm.rational.test.workbench.mobile_")	
	
	private featurepkg;
	
	RTWProduct(def fpkg){
		featurepkg = fpkg;
	}
	
	def getFeaturePackage(){
		return featurepkg;
	}
}

