package com.urbancode.air.plugin.automation

public class QCRunTest extends AutomationBase {
    
    String folder
    String testSetName
    boolean skipOutput
    String skipInt
    String remoteHost
    boolean runLocally
    String runLocallyInt
    
    public void execute() {
        init()
                
        if (skipOutput) {
            skipInt = "1"
        }
        else {
            skipInt = "0"
        }
        
        if(runLocally) {
            runLocallyInt = "1"
        }
        else {
            runLocallyInt = "0"
        }
        
        def command = generateCommand()
        runCommand("Running Test Set", command)
    }
    
    private def generateCommand() {
        def command = [cscriptExe]
        command << PLUGIN_HOME + "\\qc_run_test_set.vbs"
        command << serverUrl
        command << username
        command << password
        command << domain
        command << project
        command << folder
        command << testSetName
        command << skipInt
        command << runLocallyInt
        if (remoteHost) {
            command << remoteHost
        }
        
        return command
    }
}