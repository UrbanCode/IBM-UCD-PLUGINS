if (password && passwordscript) {
  errors.password = "Only Password or Password Script may be entered"
  errors.passwordscript = "Only Password or Password Script may be entered"
}
