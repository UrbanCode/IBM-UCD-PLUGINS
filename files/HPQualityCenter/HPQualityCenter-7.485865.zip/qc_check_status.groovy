import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def workDir = new File('.').canonicalFile
def stepProps = apTool.getStepProperties()

def dir = new File(workDir, stepProps['workDirOffset'] ?: '.').canonicalFile

def serverUrl = stepProps['serverUrl']
def username = stepProps['username']
def password = stepProps['password'] ? stepProps['password'] : stepProps['passwordscript']

def domain = stepProps['qcdomain']
def project = stepProps['qcproject']
def issueIds = stepProps['issueIds']
def failMode = stepProps['failmode']
def expectedState = stepProps['expectedState']

QCCheckStatus comment = new QCCheckStatus()
comment.serverUrl = serverUrl
comment.username = username
comment.password = password
comment.domain = domain
comment.project = project

comment.issueIds = issueIds
comment.failMode = failMode
comment.expectedState = expectedState
comment.workDir = dir

comment.execute()