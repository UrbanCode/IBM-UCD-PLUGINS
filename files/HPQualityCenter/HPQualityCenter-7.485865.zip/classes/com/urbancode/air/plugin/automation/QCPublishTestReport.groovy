package com.urbancode.air.plugin.automation

import com.urbancode.air.http.*

public class QCPublishTestReport extends AutomationBase {

    String folder
    String testSetName
    String remoteHost
    String outFileName
    String reportName
    
    def outputFile = ""    
    public void execute() {
        init()
        
        outputFile = new File(outFileName)
       
        def command = generateCommand()
        runCommand("Publishing Test Results", command)
    }
    
    private def generateCommand() {
        def command = [cscriptExe]
        command << PLUGIN_HOME + "\\qc_publish_test_report.vbs"
        command << serverUrl
        command << username
        command << password
        command << domain
        command << project
        command << folder
        command << reportName
        command << testSetName
        command << outputFile
        
        return command
    }
}