---
name: cac-download-resource-template
description: Download a DevOps Deploy resource template and export it to JSON or YAML using cached CAC credentials.
---

# Resource Template Download Skill

## Purpose

This skill enables users to download DevOps Deploy resource templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download resource template [name]
* get resource template [name]
* export resource template [name]
* save resource template [name]
* fetch resource template [name]

## How It Works

When a user requests a resource template download:

1. Check for cached CAC credentials.
2. Extract the resource template name from the request.
3. Determine the output filename.
4. Verify credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading resource templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
download-resource-template.cmd "<resource-template-name>" <output-file>

# macOS / Linux
./download-resource-template "<resource-template-name>" <output-file>
```

### Parameters

| Parameter              | Description                                 |
| ---------------------- | ------------------------------------------- |
| resource-template-name | Name of the resource template to download   |
| output-file            | Output file name (.json or .yaml)           |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Resource template name
* Optional output filename
* Optional output format

Examples:

* `download resource template MyResourceTemplate`

    * Resource template: `MyResourceTemplate`

* `get Agent Relay resource template as YAML`

    * Resource template: `Agent Relay`
    * Format: `yaml`

* `export Base Resource Template to base-template.yaml`

    * Resource template: `Base Resource Template`
    * File: `base-template.yaml`

### Step 2: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If the user specifies JSON, use `<resource-template-name>.json`.
* If the user specifies YAML, use `<resource-template-name>.yaml`.
* Default to `<resource-template-name>.json`.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed with the download until credentials have been configured.

### Step 4: Execute Download Command

```bash
# Windows
download-resource-template.cmd "<resource-template-name>" <output-file>

# macOS / Linux
./download-resource-template "<resource-template-name>" <output-file>
```

Requirements:

* Execute from an environment where the CAC commands are available.
* Wrap resource template names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Resource template '<resource-template-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1

User:

```text
download resource template MyResourceTemplate
```

Actions:

1. Resource template = `MyResourceTemplate`
2. Output file = `MyResourceTemplate.json`
3. Verify credentials
4. Execute:

```bash
# Windows
download-resource-template.cmd "MyResourceTemplate" MyResourceTemplate.json

# macOS / Linux
./download-resource-template "MyResourceTemplate" MyResourceTemplate.json
```

Response:

```text
Resource template 'MyResourceTemplate' downloaded successfully to MyResourceTemplate.json.
```

### Example 2

User:

```text
get Agent Relay resource template as YAML
```

Actions:

1. Resource template = `Agent Relay`
2. Output file = `Agent Relay.yaml`
3. Verify credentials
4. Execute:

```bash
# Windows
download-resource-template.cmd "Agent Relay" "Agent Relay.yaml"

# macOS / Linux
./download-resource-template "Agent Relay" "Agent Relay.yaml"
```

Response:

```text
Resource template 'Agent Relay' downloaded successfully to Agent Relay.yaml.
```

## Error Handling

### Missing Resource Template Name

```text
Which resource template would you like to download?
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading resource templates.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Resource Template Not Found

```text
Resource template '<resource-template-name>' was not found.

Please verify the resource template name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The resource template download failed.

Please verify:

- The resource template name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the resource template
```

## Natural Language Patterns

Recognize:

* download resource template [name]
* get resource template [name]
* export resource template [name]
* fetch resource template [name]
* save resource template [name]
* download [name] resource template
* get [name] resource template as json
* get [name] resource template as yaml
* export [name] resource template to [filename]
* save [name] resource template to [filename]
