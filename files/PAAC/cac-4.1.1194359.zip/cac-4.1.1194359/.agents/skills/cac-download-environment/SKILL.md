---
name: cac-download-environment
description: Download a DevOps Deploy environment and export it to JSON or YAML using cached CAC credentials. Environment downloads require both environment name and application name.
---

# Environment Download Skill

## Purpose

This skill enables users to download DevOps Deploy environments using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download environment [name]
* get environment [name]
* export environment [name]
* save environment [name]
* fetch environment [name]
* download environment [environment-name] from [application-name]

## Critical Requirement

Environment downloads require **both**:

1. Environment Name
2. Application Name

If the application name is not provided, ask the user for it before proceeding.

## How It Works

When a user requests an environment download:

1. Extract the environment name.
2. Extract the application name.
3. Validate that both values are present.
4. Determine the output filename.
5. Verify CAC credentials are available.
6. Execute the download command.
7. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading environments.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
download-environment.cmd "<environment-name>" "<application-name>" <output-file>

# macOS / Linux
./download-environment "<environment-name>" "<application-name>" <output-file>
```

### Parameters

| Parameter        | Description                       |
| ---------------- | --------------------------------- |
| environment-name | Name of the environment           |
| application-name | Name of the parent application    |
| output-file      | Output file name (.json or .yaml) |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Environment name
* Application name
* Optional output filename
* Optional output format

Examples:

* `download environment DEV from MyApp`

    * Environment: `DEV`
    * Application: `MyApp`

* `get Production environment of Payment Gateway`

    * Environment: `Production`
    * Application: `Payment Gateway`

* `export TEST environment from Auth Service to test.yaml`

    * Environment: `TEST`
    * Application: `Auth Service`
    * Output file: `test.yaml`

### Step 2: Validate Required Parameters

If the application name is missing:

```text
Which application does this environment belong to?

Please provide the application name.

Example:
Download environment DEV from MyApp
```

Do not proceed until both values are available.

### Step 3: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<environment-name>_<application-name>.json`.
* If YAML is requested, use `<environment-name>_<application-name>.yaml`.
* Default to `<environment-name>_<application-name>.json`.

### Step 4: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 5: Execute Download Command

```bash
# Windows
download-environment.cmd "<environment-name>" "<application-name>" <output-file>

# macOS / Linux
./download-environment "<environment-name>" "<application-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use cached credentials automatically.

### Step 6: Confirm Success

```text
Environment '<environment-name>' from application '<application-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: Environment and Application Provided

User:

```text
download environment DEV from MyApp
```

Actions:

1. Environment = `DEV`
2. Application = `MyApp`
3. Output file = `DEV_MyApp.json`
4. Verify credentials
5. Execute:

```bash
# Windows
download-environment.cmd "DEV" "MyApp" DEV_MyApp.json

# macOS / Linux
./download-environment "DEV" "MyApp" DEV_MyApp.json
```

Response:

```text
Environment 'DEV' from application 'MyApp' downloaded successfully to DEV_MyApp.json.
```

### Example 2: Missing Application Name

User:

```text
download environment Production
```

Response:

```text
Which application does this environment belong to?

Example:
Download environment Production from PaymentApp
```

### Example 3: Custom Output File

User:

```text
export Test Environment from Payment Gateway to test-env.yaml
```

Actions:

1. Environment = `Test Environment`
2. Application = `Payment Gateway`
3. Output file = `test-env.yaml`
4. Verify credentials
5. Execute:

```bash
# Windows
download-environment.cmd "Test Environment" "Payment Gateway" test-env.yaml

# macOS / Linux
./download-environment "Test Environment" "Payment Gateway" test-env.yaml
```

Response:

```text
Environment 'Test Environment' from application 'Payment Gateway' downloaded successfully to test-env.yaml.
```

## Error Handling

### Missing Environment Name

```text
Which environment would you like to download?
```

### Missing Application Name

```text
Which application does this environment belong to?

Example:
Download environment <environment-name> from <application-name>
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading environments.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Environment Not Found

```text
Environment '<environment-name>' was not found in application '<application-name>'.

Please verify both names and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The environment download failed.

Please verify:

- The environment name is correct
- The application name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the environment
```

## Natural Language Patterns

Recognize:

* download environment [environment-name] from [application-name]
* get environment [environment-name] of [application-name]
* export environment [environment-name] from application [application-name]
* fetch [environment-name] environment from [application-name]
* save environment [environment-name] from [application-name]
* [environment-name] environment of [application-name]
* [environment-name] from [application-name] to [filename]

### Keywords for Application Context

* from
* of
* in
* belonging to
* application
* app

