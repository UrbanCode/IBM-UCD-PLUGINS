---
name: cac-upload-component-template
description: Upload a DevOps Deploy component template from JSON or YAML using cached CAC credentials.
---

# Component Template Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy component templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload component template [name]
* import component template [name]
* create component template [name]
* push component template [name]
* deploy component template [name]

## How It Works

When a user requests a component template upload:

1. Check for cached CAC credentials.
2. Extract the component template name and source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading component templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
upload-component-template.cmd <input-file>

# macOS / Linux
./upload-component-template <input-file>
```

### Parameters

| Parameter  | Description                      |
| ---------- | -------------------------------- |
| input-file | Input file name (.json or .yaml) |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Component template name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload component template MyTemplate from mytemplate.json
* import component template Payment Gateway from payment-gateway-template.yaml
* create component template Auth Service using auth-template.json
* push component template from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
# Windows
upload-component-template.cmd <input-file>

# macOS / Linux
./upload-component-template <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Component template '<component-template-name>' uploaded successfully from <input-file>.
```

## Error Handling

### Missing Component Template Name

```text
Which component template would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading component templates.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The component template upload failed.

Please verify:

- The component template name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload component templates
```

### Component Template Already Exists

```text
A component template with the name '<component-template-name>' already exists.

The existing component template will be updated.
```

## Natural Language Patterns

Recognize:

* upload component template [name]
* import component template [name]
* create component template [name]
* push component template [name]
* deploy component template [name]
* upload [name] component template
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload component template [name] from [filename]
* import [name] as json
* import [name] as yaml
