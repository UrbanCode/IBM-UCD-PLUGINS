---
name: cac-download-generic-process-all
description: Download all DevOps Deploy generic processes and export them to JSON or YAML using inline or cached CAC credentials.
---

# Download All Generic Processes Skill

## Purpose

This skill enables users to download all DevOps Deploy generic processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download all generic processes
* get all generic processes
* export all generic processes
* fetch all generic processes
* save all generic processes as json/yaml

## How It Works

When a user requests downloading all generic processes:

1. Extract the desired output format from the request.
2. Verify CAC credentials are available.
3. Execute the download-all command.
4. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-generic-process-all <username> <password> <server-url> <output-file-type>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-generic-process-all <username> <password> <server-url> <output-file-type>
```

### With Cached Credentials

```bash
# Windows
download-generic-process-all.cmd <output-file-type>

# macOS / Linux
./download-generic-process-all <output-file-type>
```

### Parameters

| Parameter        | Description                                    |
| ---------------- | ---------------------------------------------- |
| username         | CAC server username (inline credentials only) |
| password         | CAC server password (inline credentials only) |
| server-url       | CAC server URL (inline credentials only)      |
| output-file-type | Output format: `json` or `yaml`               |

Use either inline credentials or cached credentials from the CAC configuration. All generic processes are downloaded into individual files in the current directory.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Output format (JSON or YAML)

Examples:

* `download all generic processes as JSON`
* `get all generic processes in yaml format`
* `export all generic processes`

### Step 2: Extract Credentials and Output Format

Rules:

* If inline credentials are provided, extract username, password, and server-url
* If the user specifies JSON, use `json`.
* If the user specifies YAML, use `yaml`.
* Default to `json`.

### Step 3: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 4: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-generic-process-all <username> <password> <server-url> <output-file-type>
```

**Option B: With Cached Credentials**

```bash
# Windows
download-generic-process-all.cmd <output-file-type>

# macOS / Linux
./download-generic-process-all <output-file-type>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Use either inline credentials or cached credentials automatically.

### Step 5: Confirm Success

```text
All generic processes downloaded successfully in <output-file-type> format.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download all generic processes as JSON
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Format = `json`
5. Execute:

```bash
download-generic-process-all myuser mypassword https://url:8443 json
```

Response:

```text
All generic processes downloaded successfully in json format.
```

### Example 2: With Cached Credentials

User:

```text
get all generic processes as yaml
```

Actions:

1. Format = `yaml`
2. Verify cached credentials
3. Execute:

```bash
# Windows
download-generic-process-all.cmd yaml

# macOS / Linux
./download-generic-process-all yaml
```

Response:

```text
All generic processes downloaded successfully in yaml format.
```

### Example 3: With Inline Credentials and YAML Format

User:

```text
export all generic processes in yaml format from server https://deploy.company.com:8443 with user admin password secret123
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Format = `yaml`
5. Execute:

```bash
download-generic-process-all admin secret123 https://deploy.company.com:8443 yaml
```

Response:

```text
All generic processes downloaded successfully in yaml format.
```

## Error Handling

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading generic processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The generic processes download failed.

Please verify:
- The server is accessible
- Your credentials are valid
- You have permission to access generic processes
```

## Natural Language Patterns

Recognize:

* download all generic processes
* get all generic processes
* export all generic processes
* fetch all generic processes
* save all generic processes
* download all generic processes as json
* download all generic processes as yaml
* get all generic processes in json format
* get all generic processes in yaml format
* download all generic processes with username [user] password [pass] server [url]
* download all generic processes from server [url] with credentials [user] [pass] as [format]

