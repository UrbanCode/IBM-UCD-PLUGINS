---
name: cac-download-component-process-all
description: Download all DevOps Deploy processes for a given component and export them to JSON or YAML using inline or cached CAC credentials.
---

# Download All Component Processes Skill

## Purpose

This skill enables users to download all processes for a specific DevOps Deploy component using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download all processes for component [name]
* get all component processes for [name]
* export all processes for component [name]
* fetch all processes from component [name]
* download all [component] processes

## How It Works

When a user requests downloading all processes for a component:

1. Extract the component name from the request.
2. Extract the desired output format.
3. Verify CAC credentials are available.
4. Execute the download-all command.
5. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-component-process-all <username> <password> <server-url> <component-name> <output-file-type>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-component-process-all <username> <password> <server-url> <component-name> <output-file-type>
```

### With Cached Credentials

```bash
# Windows
download-component-process-all.cmd "<component-name>" <output-file-type>

# macOS / Linux
./download-component-process-all "<component-name>" <output-file-type>
```

### Parameters

| Parameter        | Description                                    |
| ---------------- | ---------------------------------------------- |
| username         | CAC server username (inline credentials only) |
| password         | CAC server password (inline credentials only) |
| server-url       | CAC server URL (inline credentials only)      |
| component-name   | Name of the component                          |
| output-file-type | Output format: `json` or `yaml`               |

Use either inline credentials or cached credentials from the CAC configuration. All processes for the given component are downloaded into individual files in the current directory.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Component name (REQUIRED)
* Output format (JSON or YAML)

Examples:

* `download all processes for component MyComponent`
* `get all processes for Payment Service as yaml`
* `export all processes from Auth Module`

### Step 2: Verify Component Name

If the component name is missing:

```text
Which component's processes would you like to download?
```

Do not proceed until the component name is provided.

### Step 3: Determine Output Format

Rules:

* If the user specifies JSON, use `json`.
* If the user specifies YAML, use `yaml`.
* Default to `json`.

### Step 4: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 5: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-component-process-all <username> <password> <server-url> "<component-name>" <output-file-type>
```

**Option B: With Cached Credentials**

```bash
# Windows
download-component-process-all.cmd "<component-name>" <output-file-type>

# macOS / Linux
./download-component-process-all "<component-name>" <output-file-type>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap component names containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 6: Confirm Success

```text
All processes for component '<component-name>' downloaded successfully in <output-file-type> format.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download all processes for component MyComponent as JSON
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Component = `MyComponent`
5. Format = `json`
6. Execute:

```bash
download-component-process-all myuser mypassword https://url:8443 MyComponent json
```

Response:

```text
All processes for component 'MyComponent' downloaded successfully in json format.
```

### Example 2: With Cached Credentials

User:

```text
get all processes for Payment Service as yaml
```

Actions:

1. Component = `Payment Service`
2. Format = `yaml`
3. Verify cached credentials
4. Execute:

```bash
# Windows
download-component-process-all.cmd "Payment Service" yaml

# macOS / Linux
./download-component-process-all "Payment Service" yaml
```

Response:

```text
All processes for component 'Payment Service' downloaded successfully in yaml format.
```

### Example 3: With Inline Credentials

User:

```text
download all processes for component MyComponent as yaml with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Component = `MyComponent`
5. Format = `yaml`
6. Execute:

```bash
download-component-process-all admin secret123 https://deploy.company.com:8443 MyComponent yaml
```

Response:

```text
All processes for component 'MyComponent' downloaded successfully in yaml format.
```

## Error Handling

### Missing Component Name

```text
Which component's processes would you like to download?
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading component processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Component Not Found

```text
Component '<component-name>' was not found.

Please verify the component name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Download Failure

```text
The component processes download failed.

Please verify:
- The component name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access component processes
```

## Natural Language Patterns

Recognize:

* download all processes for component [name]
* get all component processes for [name]
* export all processes for component [name]
* fetch all processes from component [name]
* download all [name] component processes
* download all processes for [name] as json
* download all processes for [name] as yaml
* download all processes for component [name] with username [user] password [pass] server [url]
* download all [name] processes from server [url] with credentials [user] [pass]

