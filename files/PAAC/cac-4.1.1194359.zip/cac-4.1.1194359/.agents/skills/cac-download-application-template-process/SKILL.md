---
name: cac-download-application-template-process
description: Download a DevOps Deploy application template process and export it to JSON or YAML using inline or cached CAC credentials.
---

# Application Template Process Download Skill

## Purpose

This skill enables users to download DevOps Deploy application template processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download application template process [name]
* get application template process [name]
* export application template process [name]
* fetch application template process [name]
* download process [name] from application template [template-name]

## How It Works

When a user requests an application template process download:

1. Extract the process name from the request.
2. Extract the application template name (REQUIRED).
3. Determine the output filename.
4. Verify CAC credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-application-template-process <username> <password> <server-url> <application-template-process-name> <application-template-name> <output-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-application-template-process <username> <password> <server-url> <application-template-process-name> <application-template-name> <output-file>
```

### With Cached Credentials

```bash
# Windows
download-application-template-process.cmd "<process-name>" "<application-template-name>" <output-file>

# macOS / Linux
./download-application-template-process "<process-name>" "<application-template-name>" <output-file>
```

### Parameters

| Parameter                        | Description                                                  |
| -------------------------------- | ------------------------------------------------------------ |
| username                         | CAC server username (inline credentials only)              |
| password                         | CAC server password (inline credentials only)              |
| server-url                       | CAC server URL (inline credentials only)                   |
| application-template-process-name | Name of the application template process to download       |
| application-template-name        | Name of the parent application template (REQUIRED)         |
| output-file                      | Output file name (.json or .yaml)                          |

Use either inline credentials or cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Application template name (REQUIRED)
* Optional output filename
* Optional output format

Examples:

* `download application template process Deploy from MyAppTemplate`
* `get Build Process from Payment App Template as YAML`
* `export Install Process from Auth App Template to install.yaml`

### Step 2: Verify Application Template Context

**CRITICAL**: Application template processes REQUIRE an application template context.

If application template name is missing:

```text
Application template processes require a parent application template.

Which application template does this process belong to?
```

Do not proceed until the application template name is provided.

### Step 3: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<process-name>.json`.
* If YAML is requested, use `<process-name>.yaml`.
* Default to `<process-name>.json`.

### Step 4: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 5: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-application-template-process <username> <password> <server-url> "<application-template-process-name>" "<application-template-name>" <output-file>
```

**Option B: With Cached Credentials**

```bash
# Windows
download-application-template-process.cmd "<process-name>" "<application-template-name>" <output-file>

# macOS / Linux
./download-application-template-process "<process-name>" "<application-template-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 6: Confirm Success

```text
Application Template Process '<process-name>' from application template '<application-template-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download application template process Deploy from MyAppTemplate
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Process = `Deploy`
5. Application Template = `MyAppTemplate`
6. Output file = `Deploy.json`
7. Execute:

```bash
download-application-template-process myuser mypassword https://url:8443 Deploy MyAppTemplate Deploy.json
```

Response:

```text
Application Template Process 'Deploy' from application template 'MyAppTemplate' downloaded successfully to Deploy.json.
```

### Example 2: With Cached Credentials

User:

```text
get Build Process from Payment App Template as YAML
```

Actions:

1. Process = `Build Process`
2. Application Template = `Payment App Template`
3. Output file = `Build Process.yaml`
4. Verify cached credentials
5. Execute:

```bash
# Windows
download-application-template-process.cmd "Build Process" "Payment App Template" "Build Process.yaml"

# macOS / Linux
./download-application-template-process "Build Process" "Payment App Template" "Build Process.yaml"
```

Response:

```text
Application Template Process 'Build Process' from application template 'Payment App Template' downloaded successfully to Build Process.yaml.
```

### Example 3: With Inline Credentials

User:

```text
export Install Process from Auth App Template to install.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Process = `Install Process`
5. Application Template = `Auth App Template`
6. Output file = `install.json`
7. Execute:

```bash
download-application-template-process admin secret123 https://deploy.company.com:8443 "Install Process" "Auth App Template" install.json
```

Response:

```text
Application Template Process 'Install Process' from application template 'Auth App Template' downloaded successfully to install.json.
```

## Error Handling

### Missing Process Name

```text
Which application template process would you like to download?
```

### Missing Application Template Name

```text
Application template processes require a parent application template.

Which application template does this process belong to?
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading application template processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Process Not Found

```text
Application Template Process '<process-name>' was not found in application template '<application-template-name>'.

Please verify:
- The process name is correct
- The application template name is correct
- The process exists in the specified application template
```

### Application Template Not Found

```text
Application Template '<application-template-name>' was not found.

Please verify the application template name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Download Failure

```text
The application template process download failed.

Please verify:
- The process name is correct
- The application template name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the application template process
```

## Natural Language Patterns

Recognize:

* download application template process [name] from [template]
* download application template process [name] from [template] with username [user] password [pass] server [url]
* download [name] from [template] with credentials [user] [pass] from server [url]
* get application template process [name] from [template]
* export application template process [name] from [template]
* fetch application template process [name] from [template]
* save application template process [name] from [template]
* download [name] process from application template [template]
* get [name] from [template] application template process
