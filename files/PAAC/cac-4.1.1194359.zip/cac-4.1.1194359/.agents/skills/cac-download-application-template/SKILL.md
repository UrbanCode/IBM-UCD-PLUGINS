---
name: cac-download-application-template
description: Download a DevOps Deploy application template and export it to JSON or YAML using cached CAC credentials.
---

# Application Template Download Skill

## Purpose

This skill enables users to download DevOps Deploy application templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download application template [name]
* get application template [name]
* export application template [name]
* save application template [name]
* fetch application template [name]

## How It Works

When a user requests an application template download:

1. Check for cached CAC credentials.
2. Extract the application template name from the request.
3. Determine the output filename.
4. Verify credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading application templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
download-application-template.cmd "<application-template-name>" <output-file>

# macOS / Linux
./download-application-template "<application-template-name>" <output-file>
```

### Parameters

| Parameter                 | Description                                    |
| ------------------------- | ---------------------------------------------- |
| application-template-name | Name of the application template to download   |
| output-file               | Output file name (.json or .yaml)              |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Application template name
* Optional output filename
* Optional output format

Examples:

* `download application template MyAppTemplate`

    * Application template: `MyAppTemplate`

* `get Payment Gateway application template as YAML`

    * Application template: `Payment Gateway`
    * Format: `yaml`

* `export Auth Service application template to auth-template.yaml`

    * Application template: `Auth Service`
    * File: `auth-template.yaml`

### Step 2: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If the user specifies JSON, use `<application-template-name>.json`.
* If the user specifies YAML, use `<application-template-name>.yaml`.
* Default to `<application-template-name>.json`.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed with the download until credentials have been configured.

### Step 4: Execute Download Command

```bash
# Windows
download-application-template.cmd "<application-template-name>" <output-file>

# macOS / Linux
./download-application-template "<application-template-name>" <output-file>
```

Requirements:

* Execute from an environment where the CAC commands are available.
* Wrap application template names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Application template '<application-template-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1

User:

```text
download application template MyAppTemplate
```

Actions:

1. Application template = `MyAppTemplate`
2. Output file = `MyAppTemplate.json`
3. Verify credentials
4. Execute:

```bash
# Windows
download-application-template.cmd "MyAppTemplate" MyAppTemplate.json

# macOS / Linux
./download-application-template "MyAppTemplate" MyAppTemplate.json
```

Response:

```text
Application template 'MyAppTemplate' downloaded successfully to MyAppTemplate.json.
```

### Example 2

User:

```text
get Payment Gateway application template as YAML
```

Actions:

1. Application template = `Payment Gateway`
2. Output file = `Payment Gateway.yaml`
3. Verify credentials
4. Execute:

```bash
# Windows
download-application-template.cmd "Payment Gateway" "Payment Gateway.yaml"

# macOS / Linux
./download-application-template "Payment Gateway" "Payment Gateway.yaml"
```

Response:

```text
Application template 'Payment Gateway' downloaded successfully to Payment Gateway.yaml.
```

## Error Handling

### Missing Application Template Name

```text
Which application template would you like to download?
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading application templates.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Application Template Not Found

```text
Application template '<application-template-name>' was not found.

Please verify the application template name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The application template download failed.

Please verify:

- The application template name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the application template
```

## Natural Language Patterns

Recognize:

* download application template [name]
* get application template [name]
* export application template [name]
* fetch application template [name]
* save application template [name]
* download [name] application template
* get [name] application template as json
* get [name] application template as yaml
* export [name] application template to [filename]
* save [name] application template to [filename]
