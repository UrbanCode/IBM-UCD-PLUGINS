---
name: cac-download-environment-template
description: Download a DevOps Deploy environment template and export it to JSON or YAML using cached CAC credentials. Environment template downloads require both application template name and environment template name.
---

# Environment Template Download Skill

## Purpose

This skill enables users to download DevOps Deploy environment templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download environment template [name]
* get environment template [name]
* export environment template [name]
* save environment template [name]
* fetch environment template [name]
* download environment template [environment-template-name] from [application-template-name]

## Critical Requirement

Environment template downloads require **both**:

1. Application Template Name (the parent application template)
2. Environment Template Name

If the application template name is not provided, ask the user for it before proceeding.

## How It Works

When a user requests an environment template download:

1. Extract the environment template name.
2. Extract the application template name.
3. Validate that both values are present.
4. Determine the output filename.
5. Verify CAC credentials are available.
6. Execute the download command.
7. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading environment templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
download-environment-template.cmd "<application-template-name>" "<environment-template-name>" <output-file>

# macOS / Linux
./download-environment-template "<application-template-name>" "<environment-template-name>" <output-file>
```

### Parameters

| Parameter                   | Description                                  |
| --------------------------- | -------------------------------------------- |
| application-template-name   | Name of the parent application template      |
| environment-template-name   | Name of the environment template to download |
| output-file                 | Output file name (.json or .yaml)            |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Environment template name
* Application template name
* Optional output filename
* Optional output format

Examples:

* `download environment template DEV-Template from MyAppTemplate`

    * Environment template: `DEV-Template`
    * Application template: `MyAppTemplate`

* `get Production-Template environment template of Payment Gateway Template`

    * Environment template: `Production-Template`
    * Application template: `Payment Gateway Template`

* `export TEST-Template environment template from Auth Service Template to test-template.yaml`

    * Environment template: `TEST-Template`
    * Application template: `Auth Service Template`
    * Output file: `test-template.yaml`

### Step 2: Validate Required Parameters

If the application template name is missing:

```text
Which application template does this environment template belong to?

Please provide the application template name.

Example:
Download environment template DEV-Template from MyAppTemplate
```

Do not proceed until both values are available.

### Step 3: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<environment-template-name>.json`.
* If YAML is requested, use `<environment-template-name>.yaml`.
* Default to `<environment-template-name>.json`.

### Step 4: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 5: Execute Download Command

```bash
# Windows
download-environment-template.cmd "<application-template-name>" "<environment-template-name>" <output-file>

# macOS / Linux
./download-environment-template "<application-template-name>" "<environment-template-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use cached credentials automatically.

### Step 6: Confirm Success

```text
Environment template '<environment-template-name>' from application template '<application-template-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: Both Names Provided

User:

```text
download environment template DEV-Template from MyAppTemplate
```

Actions:

1. Environment template = `DEV-Template`
2. Application template = `MyAppTemplate`
3. Output file = `DEV-Template.json`
4. Verify credentials
5. Execute:

```bash
# Windows
download-environment-template.cmd "MyAppTemplate" "DEV-Template" DEV-Template.json

# macOS / Linux
./download-environment-template "MyAppTemplate" "DEV-Template" DEV-Template.json
```

Response:

```text
Environment template 'DEV-Template' from application template 'MyAppTemplate' downloaded successfully to DEV-Template.json.
```

### Example 2: Missing Application Template Name

User:

```text
download environment template Production-Template
```

Response:

```text
Which application template does this environment template belong to?

Example:
Download environment template Production-Template from PaymentAppTemplate
```

### Example 3: Custom Output File

User:

```text
export Test-Template environment template from Payment Gateway Template to test-template.yaml
```

Actions:

1. Environment template = `Test-Template`
2. Application template = `Payment Gateway Template`
3. Output file = `test-template.yaml`
4. Verify credentials
5. Execute:

```bash
# Windows
download-environment-template.cmd "Payment Gateway Template" "Test-Template" test-template.yaml

# macOS / Linux
./download-environment-template "Payment Gateway Template" "Test-Template" test-template.yaml
```

Response:

```text
Environment template 'Test-Template' from application template 'Payment Gateway Template' downloaded successfully to test-template.yaml.
```

## Error Handling

### Missing Environment Template Name

```text
Which environment template would you like to download?
```

### Missing Application Template Name

```text
Which application template does this environment template belong to?

Example:
Download environment template <environment-template-name> from <application-template-name>
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading environment templates.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Environment Template Not Found

```text
Environment template '<environment-template-name>' was not found in application template '<application-template-name>'.

Please verify both names and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The environment template download failed.

Please verify:

- The environment template name is correct
- The application template name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the environment template
```

## Natural Language Patterns

Recognize:

* download environment template [environment-template-name] from [application-template-name]
* get environment template [environment-template-name] of [application-template-name]
* export environment template [environment-template-name] from application template [application-template-name]
* fetch [environment-template-name] environment template from [application-template-name]
* save environment template [environment-template-name] from [application-template-name]
* [environment-template-name] environment template of [application-template-name]
* [environment-template-name] from [application-template-name] to [filename]

### Keywords for Application Template Context

* from
* of
* in
* belonging to
* application template
* app template
