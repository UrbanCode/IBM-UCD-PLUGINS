---
name: cac-upload-application-template
description: Upload a DevOps Deploy application template from JSON or YAML using cached CAC credentials.
---

# Application Template Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy application templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload application template [name]
* import application template [name]
* create application template [name]
* push application template [name]
* deploy application template [name]

## How It Works

When a user requests an application template upload:

1. Check for cached CAC credentials.
2. Extract the application template name and source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading application templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
upload-application-template.cmd <input-file>

# macOS / Linux
./upload-application-template <input-file>
```

### Parameters

| Parameter  | Description                      |
| ---------- | -------------------------------- |
| input-file | Input file name (.json or .yaml) |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Application template name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload application template MyAppTemplate from myapptemplate.json
* import application template Payment Gateway from payment-gateway-template.yaml
* create application template Auth Service using auth-template.json
* push application template from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
# Windows
upload-application-template.cmd <input-file>

# macOS / Linux
./upload-application-template <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Application template '<application-template-name>' uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1

User:

```text
upload application template MyAppTemplate from myapptemplate.json
```

Actions:

1. Application template = `MyAppTemplate`
2. Source file = `myapptemplate.json`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-application-template.cmd myapptemplate.json

# macOS / Linux
./upload-application-template myapptemplate.json
```

Response:

```text
Application template 'MyAppTemplate' uploaded successfully from myapptemplate.json.
```

### Example 2

User:

```text
import Payment Gateway application template from payment-gateway-template.yaml
```

Actions:

1. Application template = `Payment Gateway`
2. Source file = `payment-gateway-template.yaml`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-application-template.cmd payment-gateway-template.yaml

# macOS / Linux
./upload-application-template payment-gateway-template.yaml
```

Response:

```text
Application template 'Payment Gateway' uploaded successfully from payment-gateway-template.yaml.
```

## Error Handling

### Missing Application Template Name

```text
Which application template would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading application templates.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The application template upload failed.

Please verify:

- The application template name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload application templates
```

### Application Template Already Exists

```text
An application template with the name '<application-template-name>' already exists.

The existing application template will be updated.
```

## Natural Language Patterns

Recognize:

* upload application template [name]
* import application template [name]
* create application template [name]
* push application template [name]
* deploy application template [name]
* upload [name] application template
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload application template [name] from [filename]
* import [name] as json
* import [name] as yaml
