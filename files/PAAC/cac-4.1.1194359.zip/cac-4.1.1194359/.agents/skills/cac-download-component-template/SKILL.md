---
name: cac-download-component-template
description: Download a DevOps Deploy component template and export it to JSON or YAML using cached CAC credentials.
---

# Component Template Download Skill

## Purpose

This skill enables users to download DevOps Deploy component templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download component template [name]
* get component template [name]
* export component template [name]
* save component template [name]
* fetch component template [name]

## How It Works

When a user requests a component template download:

1. Check for cached CAC credentials.
2. Extract the component template name from the request.
3. Determine the output filename.
4. Verify credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading component templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
download-component-template.cmd "<component-template-name>" <output-file>

# macOS / Linux
./download-component-template "<component-template-name>" <output-file>
```

### Parameters

| Parameter               | Description                                |
| ----------------------- | ------------------------------------------ |
| component-template-name | Name of the component template to download |
| output-file             | Output file name (.json or .yaml)          |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Component template name
* Optional output filename
* Optional output format

Examples:

* download component template MyTemplate
* get Payment Gateway component template as YAML
* export Auth Service component template to auth-template.yaml

### Step 2: Determine Output File

Rules:

* Use the filename provided by the user when present.
* Use `<component-template-name>.json` when JSON is requested.
* Use `<component-template-name>.yaml` when YAML is requested.
* Default to `<component-template-name>.json`.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Download Command

```bash
# Windows
download-component-template.cmd "<component-template-name>" <output-file>

# macOS / Linux
./download-component-template "<component-template-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap component template names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Component template '<component-template-name>' downloaded successfully to <output-file>.
```

## Error Handling

### Missing Component Template Name

```text
Which component template would you like to download?
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading component templates.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Component Template Not Found

```text
Component template '<component-template-name>' was not found.

Please verify the component template name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The component template download failed.

Please verify:

- The component template name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the component template
```

## Natural Language Patterns

Recognize:

* download component template [name]
* get component template [name]
* export component template [name]
* fetch component template [name]
* save component template [name]
* download [name] component template
* get [name] component template as json
* get [name] component template as yaml
* export [name] component template to [filename]
* save [name] component template to [filename]
