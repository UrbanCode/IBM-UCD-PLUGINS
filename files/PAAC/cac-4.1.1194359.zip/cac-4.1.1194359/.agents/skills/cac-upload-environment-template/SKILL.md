---
name: cac-upload-environment-template
description: Upload a DevOps Deploy environment template from JSON or YAML using cached CAC credentials.
---

# Environment Template Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy environment templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload environment template [name]
* import environment template [name]
* create environment template [name]
* push environment template [name]
* deploy environment template [name]

## How It Works

When a user requests an environment template upload:

1. Check for cached CAC credentials.
2. Extract the source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading environment templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
upload-environment-template.cmd <input-file>

# macOS / Linux
./upload-environment-template <input-file>
```

### Parameters

| Parameter  | Description                      |
| ---------- | -------------------------------- |
| input-file | Input file name (.json or .yaml) |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Environment template name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload environment template DEV-Template from dev-template.json
* import environment template Production-Template from prod-template.yaml
* create environment template Test-Template using test-template.json
* push environment template from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
# Windows
upload-environment-template.cmd <input-file>

# macOS / Linux
./upload-environment-template <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Environment template '<environment-template-name>' uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1

User:

```text
upload environment template DEV-Template from dev-template.json
```

Actions:

1. Environment template = `DEV-Template`
2. Source file = `dev-template.json`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-environment-template.cmd dev-template.json

# macOS / Linux
./upload-environment-template dev-template.json
```

Response:

```text
Environment template 'DEV-Template' uploaded successfully from dev-template.json.
```

### Example 2

User:

```text
import Production-Template environment template from prod-template.yaml
```

Actions:

1. Environment template = `Production-Template`
2. Source file = `prod-template.yaml`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-environment-template.cmd prod-template.yaml

# macOS / Linux
./upload-environment-template prod-template.yaml
```

Response:

```text
Environment template 'Production-Template' uploaded successfully from prod-template.yaml.
```

## Error Handling

### Missing Environment Template Name

```text
Which environment template would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading environment templates.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The environment template upload failed.

Please verify:

- The environment template name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload environment templates
```

### Environment Template Already Exists

```text
An environment template with the name '<environment-template-name>' already exists.

The existing environment template will be updated.
```

## Natural Language Patterns

Recognize:

* upload environment template [name]
* import environment template [name]
* create environment template [name]
* push environment template [name]
* deploy environment template [name]
* upload [name] environment template
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload environment template [name] from [filename]
* import [name] as json
* import [name] as yaml
