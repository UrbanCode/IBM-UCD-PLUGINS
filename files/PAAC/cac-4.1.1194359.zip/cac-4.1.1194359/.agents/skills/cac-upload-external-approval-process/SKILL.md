---
name: cac-upload-external-approval-process
description: Upload a DevOps Deploy external approval process from JSON or YAML using cached CAC credentials.
---

# External Approval Process Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy external approval processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload external approval process [name]
* import external approval [name]
* create approval process [name]
* push external approval [name]
* deploy external approval process [name]
* upload EAP [name]

## How It Works

When a user requests an external approval process upload:

1. Check for cached CAC credentials.
2. Extract the process name and source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading external approval processes.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
upload-external-approval-process.cmd "<process-name>" <input-file>

# macOS / Linux
./upload-external-approval-process "<process-name>" <input-file>
```

### Parameters

| Parameter    | Description                           |
| ------------ | ------------------------------------- |
| process-name | Name of the external approval process |
| input-file   | Input file name (.json or .yaml)      |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload external approval process ApprovalFlow from approval.json
* import Manager Approval from manager-approval.yaml
* create Security Review EAP using review.json
* push external approval from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
# Windows
upload-external-approval-process.cmd "<process-name>" <input-file>

# macOS / Linux
./upload-external-approval-process "<process-name>" <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap process names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
External Approval Process '<process-name>' uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1

User:

```text
upload external approval process ApprovalFlow from approval.json
```

Actions:

1. Process = `ApprovalFlow`
2. Source file = `approval.json`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-external-approval-process.cmd "ApprovalFlow" approval.json

# macOS / Linux
./upload-external-approval-process "ApprovalFlow" approval.json
```

Response:

```text
External Approval Process 'ApprovalFlow' uploaded successfully from approval.json.
```

### Example 2

User:

```text
import Manager Approval from manager-approval.yaml
```

Actions:

1. Process = `Manager Approval`
2. Source file = `manager-approval.yaml`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-external-approval-process.cmd "Manager Approval" manager-approval.yaml

# macOS / Linux
./upload-external-approval-process "Manager Approval" manager-approval.yaml
```

Response:

```text
External Approval Process 'Manager Approval' uploaded successfully from manager-approval.yaml.
```

### Example 3

User:

```text
create Security Review EAP using review.json
```

Actions:

1. Process = `Security Review`
2. Source file = `review.json`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-external-approval-process.cmd "Security Review" review.json

# macOS / Linux
./upload-external-approval-process "Security Review" review.json
```

Response:

```text
External Approval Process 'Security Review' uploaded successfully from review.json.
```

## Error Handling

### Missing Process Name

```text
Which external approval process would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading external approval processes.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The external approval process upload failed.

Please verify:

- The process name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload external approval processes
```

### Process Already Exists

```text
An external approval process with the name '<process-name>' already exists.

Please choose a different name or update the existing process.
```

## Natural Language Patterns

Recognize:

* upload external approval process [name]
* import external approval [name]
* create approval process [name]
* push external approval [name]
* deploy external approval process [name]
* upload EAP [name]
* import EAP [name]
* upload [name] external approval
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload external approval process [name] from [filename]
* import [name] as json
* import [name] as yaml

### Keywords to Recognize

* external approval process
* external approval
* approval process
* EAP

