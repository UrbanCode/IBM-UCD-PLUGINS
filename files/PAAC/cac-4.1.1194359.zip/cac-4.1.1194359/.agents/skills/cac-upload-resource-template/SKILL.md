---
name: cac-upload-resource-template
description: Upload a DevOps Deploy resource template from JSON or YAML using cached CAC credentials.
---

# Resource Template Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy resource templates using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload resource template [name]
* import resource template [name]
* create resource template [name]
* push resource template [name]
* deploy resource template [name]

## How It Works

When a user requests a resource template upload:

1. Check for cached CAC credentials.
2. Extract the source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading resource templates.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
upload-resource-template.cmd <input-file>

# macOS / Linux
./upload-resource-template <input-file>
```

### Parameters

| Parameter  | Description                      |
| ---------- | -------------------------------- |
| input-file | Input file name (.json or .yaml) |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Resource template name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload resource template MyResourceTemplate from myresourcetemplate.json
* import resource template Agent Relay from agent-relay-template.yaml
* create resource template Base Template using base-template.json
* push resource template from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
# Windows
upload-resource-template.cmd <input-file>

# macOS / Linux
./upload-resource-template <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Resource template '<resource-template-name>' uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1

User:

```text
upload resource template MyResourceTemplate from myresourcetemplate.json
```

Actions:

1. Resource template = `MyResourceTemplate`
2. Source file = `myresourcetemplate.json`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-resource-template.cmd myresourcetemplate.json

# macOS / Linux
./upload-resource-template myresourcetemplate.json
```

Response:

```text
Resource template 'MyResourceTemplate' uploaded successfully from myresourcetemplate.json.
```

### Example 2

User:

```text
import Agent Relay resource template from agent-relay-template.yaml
```

Actions:

1. Resource template = `Agent Relay`
2. Source file = `agent-relay-template.yaml`
3. Verify credentials
4. Execute:

```bash
# Windows
upload-resource-template.cmd agent-relay-template.yaml

# macOS / Linux
./upload-resource-template agent-relay-template.yaml
```

Response:

```text
Resource template 'Agent Relay' uploaded successfully from agent-relay-template.yaml.
```

## Error Handling

### Missing Resource Template Name

```text
Which resource template would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading resource templates.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The resource template upload failed.

Please verify:

- The resource template name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload resource templates
```

### Resource Template Already Exists

```text
A resource template with the name '<resource-template-name>' already exists.

The existing resource template will be updated.
```

## Natural Language Patterns

Recognize:

* upload resource template [name]
* import resource template [name]
* create resource template [name]
* push resource template [name]
* deploy resource template [name]
* upload [name] resource template
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload resource template [name] from [filename]
* import [name] as json
* import [name] as yaml
