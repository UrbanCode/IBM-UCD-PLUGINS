---
name: cac-download-component
description: Download a DevOps Deploy component and export it to JSON or YAML using cached CAC credentials.
---

# Component Download Skill

## Purpose

This skill enables users to download DevOps Deploy components using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download component [name]
* get component [name]
* export component [name]
* save component [name]
* fetch component [name]

## How It Works

When a user requests a component download:

1. Check for cached CAC credentials.
2. Extract the component name from the request.
3. Determine the output filename.
4. Verify credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading components.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
# Windows
download-component.cmd "<component-name>" <output-file>

# macOS / Linux
./download-component "<component-name>" <output-file>
```

### Parameters

| Parameter      | Description                       |
| -------------- | --------------------------------- |
| component-name | Name of the component to download |
| output-file    | Output file name (.json or .yaml) |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Component name
* Optional output filename
* Optional output format

Examples:

* download component MyComponent
* get Payment Gateway component as YAML
* export Auth Service component to auth.yaml

### Step 2: Determine Output File

Rules:

* Use the filename provided by the user when present.
* Use `<component-name>.json` when JSON is requested.
* Use `<component-name>.yaml` when YAML is requested.
* Default to `<component-name>.json`.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Download Command

```bash
# Windows
download-component.cmd "<component-name>" <output-file>

# macOS / Linux
./download-component "<component-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap component names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Component '<component-name>' downloaded successfully to <output-file>.
```

## Error Handling

### Missing Component Name

```text
Which component would you like to download?
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading components.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Component Not Found

```text
Component '<component-name>' was not found.

Please verify the component name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The component download failed.

Please verify:

- The component name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the component
```

## Natural Language Patterns

Recognize:

* download component [name]
* get component [name]
* export component [name]
* fetch component [name]
* save component [name]
* download [name] component
* get [name] as json
* get [name] as yaml
* export [name] to [filename]
* save [name] to [filename]

