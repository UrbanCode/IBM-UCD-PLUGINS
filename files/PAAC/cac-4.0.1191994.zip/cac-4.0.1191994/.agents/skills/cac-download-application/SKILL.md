---
name: cac-download-application
description: Download a DevOps Deploy application and export it to JSON or YAML using cached CAC credentials.
---

# Application Download Skill

## Purpose

This skill enables users to download DevOps Deploy applications using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download application [name]
* get application [name]
* export application [name]
* save application [name]
* fetch application [name]

## How It Works

When a user requests an application download:

1. Check for cached CAC credentials.
2. Extract the application name from the request.
3. Determine the output filename.
4. Verify credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading applications.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash id="ebv4lt"
download-application.cmd "<application-name>" <output-file>
```

### Parameters

| Parameter        | Description                         |
| ---------------- | ----------------------------------- |
| application-name | Name of the application to download |
| output-file      | Output file name (.json or .yaml)   |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Application name
* Optional output filename
* Optional output format

Examples:

* `download application MyApp`

    * Application: `MyApp`

* `get Payment Gateway application as YAML`

    * Application: `Payment Gateway`
    * Format: `yaml`

* `export Auth Service app to auth.yaml`

    * Application: `Auth Service`
    * File: `auth.yaml`

### Step 2: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If the user specifies JSON, use `<application-name>.json`.
* If the user specifies YAML, use `<application-name>.yaml`.
* Default to `<application-name>.json`.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text id="e8z8v8"
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed with the download until credentials have been configured.

### Step 4: Execute Download Command

```bash id="z3qthq"
download-application.cmd "<application-name>" <output-file>
```

Requirements:

* Execute from an environment where the CAC commands are available.
* Wrap application names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text id="uqyzk4"
Application '<application-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1

User:

```text id="1hk7wb"
download application MyApp
```

Actions:

1. Application = `MyApp`
2. Output file = `MyApp.json`
3. Verify credentials
4. Execute:

```bash id="f10tq4"
download-application.cmd "MyApp" MyApp.json
```

Response:

```text id="rz23ju"
Application 'MyApp' downloaded successfully to MyApp.json.
```

### Example 2

User:

```text id="e3zdtf"
get Payment Gateway application as YAML
```

Actions:

1. Application = `Payment Gateway`
2. Output file = `Payment Gateway.yaml`
3. Verify credentials
4. Execute:

```bash id="tghlfe"
download-application.cmd "Payment Gateway" "Payment Gateway.yaml"
```

Response:

```text id="6y2m9s"
Application 'Payment Gateway' downloaded successfully to Payment Gateway.yaml.
```

## Error Handling

### Missing Application Name

```text id="j71pwz"
Which application would you like to download?
```

### Missing Credentials

```text id="gy4vv7"
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading applications.
```

### Invalid Format

```text id="6zgs5f"
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Application Not Found

```text id="t0l7rn"
Application '<application-name>' was not found.

Please verify the application name and try again.
```

### Authentication Failure

```text id="ktlt1d"
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Download Failure

```text id="m11u4q"
The application download failed.

Please verify:
- The application name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the application
```

## Natural Language Patterns

Recognize:

* download application [name]
* get application [name]
* export application [name]
* fetch application [name]
* save application [name]
* download [name] application
* download [name] app
* get [name] as json
* get [name] as yaml
* export [name] to [filename]
* save [name] to [filename]

