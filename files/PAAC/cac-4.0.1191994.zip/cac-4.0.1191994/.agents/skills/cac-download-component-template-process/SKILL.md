---
name: cac-download-component-template-process
description: Download a DevOps Deploy component template process and export it to JSON or YAML using inline or cached CAC credentials.
---

# Component Template Process Download Skill

## Purpose

This skill enables users to download DevOps Deploy component template processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download component template process [name]
* get component template process [name]
* export component template process [name]
* fetch component template process [name]
* download process [name] from component template [template-name]

## How It Works

When a user requests a component template process download:

1. Extract the process name from the request.
2. Extract the component template name (REQUIRED).
3. Determine the output filename.
4. Verify CAC credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-component-template-process <username> <password> <server-url> <component-template-process-name> <component-template-name> <output-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-component-template-process <username> <password> <server-url> <component-template-process-name> <component-template-name> <output-file>
```

### With Cached Credentials

```bash
download-component-template-process.cmd "<process-name>" "<component-template-name>" <output-file>
```

### Parameters

| Parameter                       | Description                                                |
| ------------------------------- | ---------------------------------------------------------- |
| username                        | CAC server username (inline credentials only)            |
| password                        | CAC server password (inline credentials only)            |
| server-url                      | CAC server URL (inline credentials only)                 |
| component-template-process-name | Name of the component template process to download       |
| component-template-name         | Name of the parent component template (REQUIRED)         |
| output-file                     | Output file name (.json or .yaml)                        |

Use either inline credentials or cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Component template name (REQUIRED)
* Optional output filename
* Optional output format

Examples:

* `download component template process Deploy from MyTemplate`
* `get Build Process from Payment Template as YAML`
* `export Install Process from Auth Template to install.yaml`

### Step 2: Verify Component Template Context

**CRITICAL**: Component template processes REQUIRE a component template context.

If component template name is missing:

```text
Component template processes require a parent component template.

Which component template does this process belong to?
```

Do not proceed until the component template name is provided.

### Step 3: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<process-name>.json`.
* If YAML is requested, use `<process-name>.yaml`.
* Default to `<process-name>.json`.

### Step 4: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 5: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-component-template-process <username> <password> <server-url> "<component-template-process-name>" "<component-template-name>" <output-file>
```

**Option B: With Cached Credentials**

```bash
download-component-template-process.cmd "<process-name>" "<component-template-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 6: Confirm Success

```text
Component Template Process '<process-name>' from component template '<component-template-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download component template process Deploy from MyTemplate
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Process = `Deploy`
5. Component Template = `MyTemplate`
6. Output file = `Deploy.json`
7. Execute:

```bash
download-component-template-process myuser mypassword https://url:8443 Deploy MyTemplate Deploy.json
```

Response:

```text
Component Template Process 'Deploy' from component template 'MyTemplate' downloaded successfully to Deploy.json.
```

### Example 2: With Cached Credentials

User:

```text
get Build Process from Payment Template as YAML
```

Actions:

1. Process = `Build Process`
2. Component Template = `Payment Template`
3. Output file = `Build Process.yaml`
4. Verify cached credentials
5. Execute:

```bash
download-component-template-process.cmd "Build Process" "Payment Template" "Build Process.yaml"
```

Response:

```text
Component Template Process 'Build Process' from component template 'Payment Template' downloaded successfully to Build Process.yaml.
```

### Example 3: With Inline Credentials

User:

```text
export Install Process from Auth Template to install.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Process = `Install Process`
5. Component Template = `Auth Template`
6. Output file = `install.json`
7. Execute:

```bash
download-component-template-process admin secret123 https://deploy.company.com:8443 "Install Process" "Auth Template" install.json
```

Response:

```text
Component Template Process 'Install Process' from component template 'Auth Template' downloaded successfully to install.json.
```

## Error Handling

### Missing Process Name

```text
Which component template process would you like to download?
```

### Missing Component Template Name

```text
Component template processes require a parent component template.

Which component template does this process belong to?
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading component template processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Process Not Found

```text
Component Template Process '<process-name>' was not found in component template '<component-template-name>'.

Please verify:
- The process name is correct
- The component template name is correct
- The process exists in the specified component template
```

### Component Template Not Found

```text
Component Template '<component-template-name>' was not found.

Please verify the component template name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Download Failure

```text
The component template process download failed.

Please verify:
- The process name is correct
- The component template name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the component template process
```

## Natural Language Patterns

Recognize:

* download component template process [name] from [template]
* download component template process [name] from [template] with username [user] password [pass] server [url]
* download [name] from [template] with credentials [user] [pass] from server [url]
* get component template process [name] from [template]
* export component template process [name] from [template]
* fetch component template process [name] from [template]
* save component template process [name] from [template]
* download [name] process from component template [template]
* get [name] from [template] component template process

