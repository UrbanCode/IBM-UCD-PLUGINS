---
name: cac-setup
description: Use this skill when the user wants to configure CAC credentials, setup authentication, show current configuration, or clear cached credentials for DevOps Deploy Configuration as Code (CAC).
---

# CAC Setup Skill

## Purpose

This skill manages authentication credentials for the Configuration as Code (CAC) system.

It allows users to:

* Configure and save credentials
* View the current configuration
* Clear saved credentials
* Validate authentication settings

## When to Activate

Activate this skill when the user mentions:

* setup CAC
* configure CAC credentials
* save credentials
* login to CAC
* authenticate to CAC
* show CAC configuration
* display current setup
* view saved credentials
* clear CAC credentials
* reset CAC configuration
* remove saved credentials

## Credential Storage

### Configuration File Location

* **Windows:** `%USERPROFILE%\.cac\config.properties`
* **Linux/macOS:** `~/.cac/config.properties`

### File Format

```properties
server-url=https://server:8443
username=user
password=<encrypted>
```

### Security

* Passwords are stored in encrypted form.
* Passwords must never be displayed in logs or responses.
* Password values must always be masked.
* HTTPS should be used whenever possible.

## Commands

### Setup Credentials

**Command**

```bash
cac setup --server-url <url> --user <username> --pass <password>
```

### Show Current Configuration

**Command**

```bash
cac setup --show
```

### Clear Configuration

**Command**

```bash
cac setup --clear
```

## Execution Workflow

### Setup Credentials

#### Step 1: Extract Parameters

Extract:

* server-url
* username
* password

#### Step 2: Validate Input

Validate:

* Server URL is provided
* Server URL begins with `http://` or `https://`
* Username is provided
* Password is provided

If any value is missing:

```text
To setup CAC, I need:

- Server URL (for example: https://server:8443)
- Username
- Password
```

#### Step 3: Check Existing Configuration

If a configuration already exists:

```text
Existing CAC credentials were found.

Server: <server-url>
Username: <username>

Overwriting will replace the current configuration.

Do you want to continue? (yes/no)
```

#### Step 4: Execute Command

```bash
cac setup --server-url <url> --user <username> --pass <password>
```

Requirements:

* Execute from an environment where `cac setup` is available.
* Wait for command completion before responding.
* Require user approval before executing commands containing credentials.

#### Step 5: Confirm Success

```text
CAC credentials saved successfully.

Server: <server-url>
Username: <username>

Credentials have been securely stored and can be reused by other CAC skills.
```

---

### Show Configuration

#### Step 1: Execute

```bash
cac setup --show
```

#### Step 2: Display Results

Example:

```text
Current Configuration

Config File: <config-path>
Server URL: <server-url>
Username: <username>
Password: ***
```

---

### Clear Configuration

#### Step 1: Request Confirmation

```text
Are you sure you want to clear the saved CAC credentials? (yes/no)
```

#### Step 2: Execute

```bash
cac setup --clear
```

#### Step 3: Confirm Success

```text
CAC credentials cleared successfully.

You will need to configure credentials again before performing CAC operations.
```

## Additional Behavior

### Existing Valid Configuration

If valid credentials already exist and the user requests setup again without providing new values:

1. Show the current configuration (with the password masked).
2. Ask whether the user wants to update the existing configuration.
3. Do not overwrite credentials without confirmation.

## Error Handling

### Invalid Server URL

```text
Server URL must begin with http:// or https://

Example:
https://ucd.example.com:8443
```

### Missing Parameters

```text
The following parameters are required:

- Server URL
- Username
- Password
```

### Existing Credentials

```text
CAC credentials already exist.

Do you want to overwrite the current configuration? (yes/no)
```

### Authentication Validation Failed

```text
Unable to authenticate with the provided credentials.

Please verify:

- Server URL
- Username
- Password
- Network connectivity
```

### Setup Failure

```text
Failed to save CAC credentials.

Please verify:

- The server URL is valid
- You have permission to write to the configuration directory
- The configuration directory is accessible
```

### No Configuration Found

```text
No CAC configuration was found.

Please run setup first by providing:

- Server URL
- Username
- Password
```

## Integration with Other Skills

If another CAC skill requires credentials and none are configured:

```text
No cached CAC credentials were found.

Please configure credentials first using:

Setup CAC with server <url>, username <user>, password <password>
```

## Security Guidelines

1. Never display passwords in plain text.
2. Never log passwords.
3. Always mask passwords in command output.
4. Prefer HTTPS endpoints.
5. Require confirmation before overwriting existing credentials.
6. Require confirmation before clearing credentials.
7. Store credentials only in the configured CAC configuration location.

