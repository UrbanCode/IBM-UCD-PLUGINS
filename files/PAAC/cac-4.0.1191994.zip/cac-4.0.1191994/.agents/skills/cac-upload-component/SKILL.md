---
name: cac-upload-component
description: Upload a DevOps Deploy component from JSON or YAML using cached CAC credentials.
---

# Component Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy components using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload component [name]
* import component [name]
* create component [name]
* push component [name]
* deploy component [name]

## How It Works

When a user requests a component upload:

1. Check for cached CAC credentials.
2. Extract the component name and source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading components.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
upload-component.cmd "<component-name>" <input-file>
```

### Parameters

| Parameter      | Description                       |
| -------------- | --------------------------------- |
| component-name | Name of the component to upload   |
| input-file     | Input file name (.json or .yaml)  |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Component name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload component MyComponent from mycomponent.json
* import Payment Gateway from payment-gateway.yaml
* create Auth Service using auth.json
* push component from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
upload-component.cmd "<component-name>" <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap component names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Component '<component-name>' uploaded successfully from <input-file>.
```

## Error Handling

### Missing Component Name

```text
Which component would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading components.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The component upload failed.

Please verify:

- The component name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload components
```

### Component Already Exists

```text
A component with the name '<component-name>' already exists.

Please choose a different name or update the existing component.
```

## Natural Language Patterns

Recognize:

* upload component [name]
* import component [name]
* create component [name]
* push component [name]
* deploy component [name]
* upload [name] component
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload component [name] from [filename]
* import [name] as json
* import [name] as yaml

