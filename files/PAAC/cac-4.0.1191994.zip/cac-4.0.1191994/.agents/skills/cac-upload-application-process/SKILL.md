---
name: cac-upload-application-process
description: Upload a DevOps Deploy application process from JSON or YAML using inline or cached CAC credentials.
---

# Application Process Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy application processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload application process [name]
* import application process [name]
* create app process [name]
* push application process [name]
* deploy application process [name]
* upload app process [name] to application [app-name]

## How It Works

When a user requests an application process upload:

1. Check for cached CAC credentials.
2. Extract the source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
upload-application-process <username> <password> <server-url> <input-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
upload-application-process <username> <password> <server-url> <input-file>
```

### With Cached Credentials

```bash
upload-application-process.cmd <input-file>
```

### Parameters

| Parameter  | Description                                    |
| ---------- | ---------------------------------------------- |
| username   | CAC server username (inline credentials only) |
| password   | CAC server password (inline credentials only) |
| server-url | CAC server URL (inline credentials only)      |
| input-file | Input file name (.json or .yaml)              |

Use either inline credentials or cached credentials from the CAC configuration. The process name and application name are read from the input file.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Source filename
* Source format (JSON or YAML)

Examples:

* upload application process from deploy.json
* import application process from build.yaml
* push app process from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 4: Execute Upload Command

**Option A: With Inline Credentials**

```bash
upload-application-process <username> <password> <server-url> <input-file>
```

**Option B: With Cached Credentials**

```bash
upload-application-process.cmd <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap file paths containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 5: Confirm Success

```text
Application Process uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
upload application process from deploy.json
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Source file = `deploy.json`
5. Execute:

```bash
upload-application-process myuser mypassword https://url:8443 deploy.json
```

Response:

```text
Application Process uploaded successfully from deploy.json.
```

### Example 2: With Cached Credentials

User:

```text
import application process from build.yaml
```

Actions:

1. Source file = `build.yaml`
2. Verify cached credentials
3. Execute:

```bash
upload-application-process.cmd build.yaml
```

Response:

```text
Application Process uploaded successfully from build.yaml.
```

### Example 3: With Inline Credentials

User:

```text
push app process from install.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Source file = `install.json`
5. Execute:

```bash
upload-application-process admin secret123 https://deploy.company.com:8443 install.json
```

Response:

```text
Application Process uploaded successfully from install.json.
```

## Error Handling

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before uploading application processes.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Application Not Found

```text
Application '<application-name>' was not found.

Please verify the application name and try again.
```

### Upload Failure

```text
The application process upload failed.

Please verify:
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload application processes
```

## Natural Language Patterns

Recognize:

* upload application process from [file]
* import application process from [file]
* create app process from [file]
* push application process from [file]
* deploy app process from [file]
* upload application process from [file] with username [user] password [pass] server [url]
* upload [file] to server [url] with credentials [user] [pass]

