---
name: cac-download-generic-process
description: Download a DevOps Deploy generic process and export it to JSON or YAML using inline or cached CAC credentials.
---

# Generic Process Download Skill

## Purpose

This skill enables users to download DevOps Deploy generic processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download generic process [name]
* get generic process [name]
* export generic process [name]
* save generic process [name]
* fetch generic process [name]
* download process [name] (without application or component context)

## How It Works

When a user requests a generic process download:

1. Extract the process name from the request.
2. Determine the output filename.
3. Verify CAC credentials are available.
4. Execute the download command.
5. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-generic-process <username> <password> <server-url> <process-name> <output-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-generic-process <username> <password> <server-url> <process-name> <output-file>
```

### With Cached Credentials

```bash
download-generic-process.cmd "<process-name>" <output-file>
```

### Parameters

| Parameter    | Description                                    |
| ------------ | ---------------------------------------------- |
| username     | CAC server username (inline credentials only) |
| password     | CAC server password (inline credentials only) |
| server-url   | CAC server URL (inline credentials only)      |
| process-name | Name of the generic process to download       |
| output-file  | Output file name (.json or .yaml)             |

Use either inline credentials or cached credentials from the CAC configuration.

## Distinguishing Generic Processes

**IMPORTANT**: Generic processes are standalone processes that do NOT belong to an application or component.

If the user mentions:
* "application process" → Use **download-application-process** skill
* "component process" → Use **download-component-process** skill
* "generic process" or just "process" (without parent context) → Use this skill

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Optional output filename
* Optional output format

Examples:

* `download generic process CleanupProcess`
* `get Notification Handler generic process as YAML`
* `export Audit Logger process to audit.yaml`

### Step 2: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<process-name>.json`.
* If YAML is requested, use `<process-name>.yaml`.
* Default to `<process-name>.json`.

### Step 3: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 4: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-generic-process <username> <password> <server-url> "<process-name>" <output-file>
```

**Option B: With Cached Credentials**

```bash
download-generic-process.cmd "<process-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 5: Confirm Success

```text
Generic Process '<process-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download generic process CleanupProcess as JSON
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Process = `CleanupProcess`
5. Output file = `CleanupProcess.json`
6. Execute:

```bash
download-generic-process myuser mypassword https://url:8443 CleanupProcess CleanupProcess.json
```

Response:

```text
Generic Process 'CleanupProcess' downloaded successfully to CleanupProcess.json.
```

### Example 2: With Cached Credentials

User:

```text
get Notification Handler generic process as YAML
```

Actions:

1. Process = `Notification Handler`
2. Output file = `Notification Handler.yaml`
3. Verify cached credentials
4. Execute:

```bash
download-generic-process.cmd "Notification Handler" "Notification Handler.yaml"
```

Response:

```text
Generic Process 'Notification Handler' downloaded successfully to Notification Handler.yaml.
```

### Example 3: With Inline Credentials and Custom Output

User:

```text
export Audit Logger process to audit.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Process = `Audit Logger`
5. Output file = `audit.json`
6. Execute:

```bash
download-generic-process admin secret123 https://deploy.company.com:8443 "Audit Logger" audit.json
```

Response:

```text
Generic Process 'Audit Logger' downloaded successfully to audit.json.
```

### Example 4: With Inline Credentials

User:

```text
download Automated Incident Capture as JSON from server https://url:8443 with user myuser and password mypassword
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Process = `Automated Incident Capture`
5. Output file = `Automated Incident Capture.json`
6. Execute:

```bash
download-generic-process myuser mypassword https://url:8443 "Automated Incident Capture" "Automated Incident Capture.json"
```

Response:

```text
Generic Process 'Automated Incident Capture' downloaded successfully to Automated Incident Capture.json.
```

## Error Handling

### Missing Process Name

```text
Which generic process would you like to download?
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading generic processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Process Not Found

```text
Generic Process '<process-name>' was not found.

Please verify the process name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The generic process download failed.

Please verify:
- The process name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the generic process
```

## Natural Language Patterns

Recognize:

* download generic process [name]
* get generic process [name]
* export generic process [name]
* fetch generic process [name]
* save generic process [name]
* download [name] generic process
* get [name] process (when no application/component context)
* export process [name] (when no application/component context)
* download generic process [name] with username [user] password [pass] server [url]
* download [name] from server [url] with credentials [user] [pass]

