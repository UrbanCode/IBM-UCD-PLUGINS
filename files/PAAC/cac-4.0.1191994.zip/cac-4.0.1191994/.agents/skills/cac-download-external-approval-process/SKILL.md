---
name: cac-download-external-approval-process
description: Download a DevOps Deploy external approval process and export it to JSON or YAML using cached CAC credentials.
---

# External Approval Process Download Skill

## Purpose

This skill enables users to download DevOps Deploy external approval processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download external approval process [name]
* get external approval [name]
* export approval process [name]
* save external approval [name]
* fetch external approval process [name]
* download EAP [name]

## How It Works

When a user requests an external approval process download:

1. Extract the process name.
2. Determine the output filename.
3. Verify CAC credentials are available.
4. Execute the download command.
5. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before downloading external approval processes.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
download-external-approval-process.cmd "<process-name>" <output-file>
```

### Parameters

| Parameter    | Description                           |
| ------------ | ------------------------------------- |
| process-name | Name of the external approval process |
| output-file  | Output file name (.json or .yaml)     |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Optional output filename
* Optional output format

Examples:

* `download external approval process ApprovalFlow`
* `get Manager Approval external approval as YAML`
* `export Security Review EAP to review.yaml`

### Step 2: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<process-name>.json`.
* If YAML is requested, use `<process-name>.yaml`.
* Default to `<process-name>.json`.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Download Command

```bash
download-external-approval-process.cmd "<process-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap process names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
External Approval Process '<process-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1

User:

```text
download external approval process ApprovalFlow
```

Actions:

1. Process = `ApprovalFlow`
2. Output file = `ApprovalFlow.json`
3. Verify credentials
4. Execute:

```bash
download-external-approval-process.cmd "ApprovalFlow" ApprovalFlow.json
```

Response:

```text
External Approval Process 'ApprovalFlow' downloaded successfully to ApprovalFlow.json.
```

### Example 2

User:

```text
get Manager Approval external approval as YAML
```

Actions:

1. Process = `Manager Approval`
2. Output file = `Manager Approval.yaml`
3. Verify credentials
4. Execute:

```bash
download-external-approval-process.cmd "Manager Approval" "Manager Approval.yaml"
```

Response:

```text
External Approval Process 'Manager Approval' downloaded successfully to Manager Approval.yaml.
```

### Example 3

User:

```text
download EAP Security Review to security.json
```

Actions:

1. Process = `Security Review`
2. Output file = `security.json`
3. Verify credentials
4. Execute:

```bash
download-external-approval-process.cmd "Security Review" security.json
```

Response:

```text
External Approval Process 'Security Review' downloaded successfully to security.json.
```

## Error Handling

### Missing Process Name

```text
Which external approval process would you like to download?
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before downloading external approval processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Process Not Found

```text
External Approval Process '<process-name>' was not found.

Please verify the process name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The external approval process download failed.

Please verify:

- The process name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the process
```

## Natural Language Patterns

Recognize:

* download external approval process [name]
* get external approval [name]
* export external approval process [name]
* fetch external approval [name]
* save external approval process [name]
* download EAP [name]
* get EAP [name]
* download approval process [name]
* [name] external approval to [filename]
* get [name] as json
* get [name] as yaml

### Keywords to Recognize

* external approval process
* external approval
* approval process
* EAP

