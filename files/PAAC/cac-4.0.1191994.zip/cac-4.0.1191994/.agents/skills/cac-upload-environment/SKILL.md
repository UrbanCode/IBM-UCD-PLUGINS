---
name: cac-upload-environment
description: Upload a DevOps Deploy environment from JSON or YAML using cached CAC credentials. Environment uploads require both environment name and application name.
---

# Environment Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy environments using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload environment [name]
* import environment [name]
* create environment [name]
* push environment [name]
* deploy environment [name]
* upload environment [environment-name] to [application-name]

## Critical Requirement

Environment uploads require **both**:

1. Environment Name
2. Application Name

If the application name is not provided, ask the user for it before proceeding.

## How It Works

When a user requests an environment upload:

1. Extract the environment name.
2. Extract the application name.
3. Validate that both values are present.
4. Verify the source file exists and is valid.
5. Verify CAC credentials are available.
6. Execute the upload command.
7. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading environments.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
upload-environment.cmd "<environment-name>" "<application-name>" <input-file>
```

### Parameters

| Parameter        | Description                       |
| ---------------- | --------------------------------- |
| environment-name | Name of the environment           |
| application-name | Name of the parent application    |
| input-file       | Input file name (.json or .yaml)  |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Environment name
* Application name
* Source filename
* Source format (JSON or YAML)

Examples:

* `upload environment DEV to MyApp from dev.json`

    * Environment: `DEV`
    * Application: `MyApp`
    * Source file: `dev.json`

* `import Production environment of Payment Gateway from prod.yaml`

    * Environment: `Production`
    * Application: `Payment Gateway`
    * Source file: `prod.yaml`

* `create TEST environment in Auth Service using test.json`

    * Environment: `TEST`
    * Application: `Auth Service`
    * Source file: `test.json`

### Step 2: Validate Required Parameters

If the application name is missing:

```text
Which application does this environment belong to?

Please provide the application name.

Example:
Upload environment DEV to MyApp from dev.json
```

Do not proceed until both values are available.

### Step 3: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 4: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 5: Execute Upload Command

```bash
upload-environment.cmd "<environment-name>" "<application-name>" <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use cached credentials automatically.

### Step 6: Confirm Success

```text
Environment '<environment-name>' from application '<application-name>' uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1: Environment and Application Provided

User:

```text
upload environment DEV to MyApp from dev.json
```

Actions:

1. Environment = `DEV`
2. Application = `MyApp`
3. Source file = `dev.json`
4. Verify credentials
5. Execute:

```bash
upload-environment.cmd "DEV" "MyApp" dev.json
```

Response:

```text
Environment 'DEV' from application 'MyApp' uploaded successfully from dev.json.
```

### Example 2: Missing Application Name

User:

```text
upload environment Production from prod.yaml
```

Response:

```text
Which application does this environment belong to?

Example:
Upload environment Production to PaymentApp from prod.yaml
```

### Example 3: Custom Source File

User:

```text
import Test Environment in Payment Gateway from test-env.yaml
```

Actions:

1. Environment = `Test Environment`
2. Application = `Payment Gateway`
3. Source file = `test-env.yaml`
4. Verify credentials
5. Execute:

```bash
upload-environment.cmd "Test Environment" "Payment Gateway" test-env.yaml
```

Response:

```text
Environment 'Test Environment' from application 'Payment Gateway' uploaded successfully from test-env.yaml.
```

## Error Handling

### Missing Environment Name

```text
Which environment would you like to upload?
```

### Missing Application Name

```text
Which application does this environment belong to?

Example:
Upload environment <environment-name> to <application-name>
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading environments.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The environment upload failed.

Please verify:

- The environment name is correct
- The application name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload environments
```

### Environment Already Exists

```text
An environment with the name '<environment-name>' already exists in application '<application-name>'.

Please choose a different name or update the existing environment.
```

## Natural Language Patterns

Recognize:

* upload environment [environment-name] to [application-name]
* import environment [environment-name] of [application-name]
* create environment [environment-name] in [application-name]
* push environment [environment-name] from [application-name]
* deploy environment [environment-name] to [application-name]
* upload [environment-name] environment to [application-name]
* import [environment-name] from [filename] to [application-name]
* create [environment-name] using [filename] in [application-name]
* push [environment-name] from [filename] to [application-name]
* upload environment [environment-name] to [application-name] from [filename]
* import [environment-name] as json to [application-name]
* import [environment-name] as yaml to [application-name]

### Keywords for Application Context

* to
* of
* in
* belonging to
* application
* app

