---
name: cac-download-component-process
description: Download a DevOps Deploy component process and export it to JSON or YAML using inline or cached CAC credentials.
---

# Component Process Download Skill

## Purpose

This skill enables users to download DevOps Deploy component processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download component process [name]
* get component process [name]
* export component process [name]
* save component process [name]
* fetch component process [name]
* download component process [name] from component [component-name]

## How It Works

When a user requests a component process download:

1. Extract the process name from the request.
2. Extract the component name (REQUIRED for component processes).
3. Determine the output filename.
4. Verify CAC credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-component-process <username> <password> <server-url> <component-process-name> <component-name> <output-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-component-process <username> <password> <server-url> <component-process-name> <component-name> <output-file>
```

### With Cached Credentials

```bash
download-component-process.cmd "<process-name>" "<component-name>" <output-file>
```

### Parameters

| Parameter              | Description                                         |
| ---------------------- | --------------------------------------------------- |
| username               | CAC server username (inline credentials only)     |
| password               | CAC server password (inline credentials only)     |
| server-url             | CAC server URL (inline credentials only)          |
| component-process-name | Name of the component process to download         |
| component-name         | Name of the parent component (REQUIRED)           |
| output-file            | Output file name (.json or .yaml)                 |

Use either inline credentials or cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Component name (REQUIRED)
* Optional output filename
* Optional output format

Examples:

* `download component process Deploy from MyComponent`
* `get Build Process from Payment Service component as YAML`
* `export Install Process from Auth Module component to install.yaml`

### Step 2: Verify Component Context

**CRITICAL**: Component processes REQUIRE a component context.

If component name is missing:

```text
Component processes require a parent component.

Which component does this process belong to?
```

Do not proceed until the component name is provided.

### Step 3: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<process-name>.json`.
* If YAML is requested, use `<process-name>.yaml`.
* Default to `<process-name>.json`.

### Step 4: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 5: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-component-process <username> <password> <server-url> "<component-process-name>" "<component-name>" <output-file>
```

**Option B: With Cached Credentials**

```bash
download-component-process.cmd "<process-name>" "<component-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 6: Confirm Success

```text
Component Process '<process-name>' from component '<component-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download component process Deploy from MyComponent
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Process = `Deploy`
5. Component = `MyComponent`
6. Output file = `Deploy.json`
7. Execute:

```bash
download-component-process myuser mypassword https://url:8443 Deploy MyComponent Deploy.json
```

Response:

```text
Component Process 'Deploy' from component 'MyComponent' downloaded successfully to Deploy.json.
```

### Example 2: With Cached Credentials

User:

```text
get Build Process from Payment Service component as YAML
```

Actions:

1. Process = `Build Process`
2. Component = `Payment Service`
3. Output file = `Build Process.yaml`
4. Verify cached credentials
5. Execute:

```bash
download-component-process.cmd "Build Process" "Payment Service" "Build Process.yaml"
```

Response:

```text
Component Process 'Build Process' from component 'Payment Service' downloaded successfully to Build Process.yaml.
```

### Example 3: With Inline Credentials

User:

```text
export Install Process from Auth Module to install.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Process = `Install Process`
5. Component = `Auth Module`
6. Output file = `install.json`
7. Execute:

```bash
download-component-process admin secret123 https://deploy.company.com:8443 "Install Process" "Auth Module" install.json
```

Response:

```text
Component Process 'Install Process' from component 'Auth Module' downloaded successfully to install.json.
```

## Error Handling

### Missing Process Name

```text
Which component process would you like to download?
```

### Missing Component Name

```text
Component processes require a parent component.

Which component does this process belong to?
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading component processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Process Not Found

```text
Component Process '<process-name>' was not found in component '<component-name>'.

Please verify:
- The process name is correct
- The component name is correct
- The process exists in the specified component
```

### Component Not Found

```text
Component '<component-name>' was not found.

Please verify the component name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The component process download failed.

Please verify:
- The process name is correct
- The component name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the component process
```

## Natural Language Patterns

Recognize:

* download component process [name] from [component]
* get component process [name] from [component]
* export component process [name] from [component]
* fetch component process [name] from [component]
* save component process [name] from [component]
* download [name] process from component [component]
* get [name] from [component] component process
* export [component] component process [name]
* download component process [name] from [component] with username [user] password [pass] server [url]
* download [name] from [component] with credentials [user] [pass] from server [url]

