---
name: cac-upload-generic-process
description: Upload a DevOps Deploy generic process from JSON or YAML using inline or cached CAC credentials.
---

# Generic Process Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy generic processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload generic process [name]
* import generic process [name]
* create generic process [name]
* push generic process [name]
* deploy generic process [name]
* upload process [name] (without application or component context)

## How It Works

When a user requests a generic process upload:

1. Check for cached CAC credentials.
2. Extract the source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
upload-generic-process <username> <password> <server-url> <input-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
upload-generic-process <username> <password> <server-url> <input-file>
```

### With Cached Credentials

```bash
upload-generic-process.cmd <input-file>
```

### Parameters

| Parameter  | Description                                    |
| ---------- | ---------------------------------------------- |
| username   | CAC server username (inline credentials only) |
| password   | CAC server password (inline credentials only) |
| server-url | CAC server URL (inline credentials only)      |
| input-file | Input file name (.json or .yaml)              |

Use either inline credentials or cached credentials from the CAC configuration. The process name is read from the input file.

## Distinguishing Generic Processes

**IMPORTANT**: Generic processes are standalone processes that do NOT belong to an application or component.

If the user mentions:
* "application process" → Use **upload-application-process** skill
* "component process" → Use **upload-component-process** skill
* "generic process" or just "process" (without parent context) → Use this skill

## Execution Steps

### Step 1: Parse User Request

Extract:

* Source filename
* Source format (JSON or YAML)

Examples:

* upload generic process from cleanup.json
* import generic process from handler.yaml
* push generic process from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 4: Execute Upload Command

**Option A: With Inline Credentials**

```bash
upload-generic-process <username> <password> <server-url> <input-file>
```

**Option B: With Cached Credentials**

```bash
upload-generic-process.cmd <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap file paths containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 5: Confirm Success

```text
Generic Process uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
upload generic process from cleanup.json
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Source file = `cleanup.json`
5. Execute:

```bash
upload-generic-process myuser mypassword https://url:8443 cleanup.json
```

Response:

```text
Generic Process uploaded successfully from cleanup.json.
```

### Example 2: With Cached Credentials

User:

```text
import generic process from handler.yaml
```

Actions:

1. Source file = `handler.yaml`
2. Verify cached credentials
3. Execute:

```bash
upload-generic-process.cmd handler.yaml
```

Response:

```text
Generic Process uploaded successfully from handler.yaml.
```

### Example 3: With Inline Credentials

User:

```text
push generic process from aic.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Source file = `aic.json`
5. Execute:

```bash
upload-generic-process admin secret123 https://deploy.company.com:8443 aic.json
```

Response:

```text
Generic Process uploaded successfully from aic.json.
```

## Error Handling

### Missing Process Name

```text
Which generic process would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before uploading generic processes.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The generic process upload failed.

Please verify:
- The process name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload generic processes
```

### Process Already Exists

```text
A generic process with the name '<process-name>' already exists.

Please choose a different name or update the existing process.
```

## Natural Language Patterns

Recognize:

* upload generic process from [file]
* import generic process from [file]
* create generic process from [file]
* push generic process from [file]
* deploy generic process from [file]
* upload process from [file] (when no application/component context)
* upload generic process from [file] with username [user] password [pass] server [url]
* upload [file] to server [url] with credentials [user] [pass]

