---
name: cac-download-application-process
description: Download a DevOps Deploy application process and export it to JSON or YAML using inline or cached CAC credentials.
---

# Application Process Download Skill

## Purpose

This skill enables users to download DevOps Deploy application processes using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* download application process [name]
* get application process [name]
* export application process [name]
* save application process [name]
* fetch application process [name]
* download application process [name] from application [application-name]

## How It Works

When a user requests an application process download:

1. Extract the process name from the request.
2. Extract the application name (REQUIRED for application processes).
3. Determine the output filename.
4. Verify CAC credentials are available.
5. Execute the download command.
6. Return the result to the user.

## Credential Management

### Inline Credentials (Recommended)

Provide credentials directly in the command:

```bash
download-application-process <username> <password> <server-url> <application-process-name> <application-name> <output-file>
```

### Cached Credentials (Alternative)

Alternatively, use cached credentials from the CAC configuration file:

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup for Cached Credentials

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If using inline credentials, the setup skill is not required.

## Command Structure

### With Inline Credentials

```bash
download-application-process <username> <password> <server-url> <application-process-name> <application-name> <output-file>
```

### With Cached Credentials

```bash
download-application-process.cmd "<process-name>" "<application-name>" <output-file>
```

### Parameters

| Parameter                | Description                                         |
| ------------------------ | --------------------------------------------------- |
| username                 | CAC server username (inline credentials only)     |
| password                 | CAC server password (inline credentials only)     |
| server-url               | CAC server URL (inline credentials only)          |
| application-process-name | Name of the application process to download       |
| application-name         | Name of the parent application (REQUIRED)         |
| output-file              | Output file name (.json or .yaml)                 |

Use either inline credentials or cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Process name
* Application name (REQUIRED)
* Optional output filename
* Optional output format

Examples:

* `download application process Deploy from MyApplication`
* `get Build Process from Payment Service application as YAML`
* `export Install Process from Auth Module application to install.yaml`

### Step 2: Verify Application Context

**CRITICAL**: Application processes REQUIRE an application context.

If application name is missing:

```text
Application processes require a parent application.

Which application does this process belong to?
```

Do not proceed until the application name is provided.

### Step 3: Determine Output File

Rules:

* If the user specifies a filename, use it.
* If JSON is requested, use `<process-name>.json`.
* If YAML is requested, use `<process-name>.yaml`.
* Default to `<process-name>.json`.

### Step 4: Verify Credentials

Check whether credentials are provided (inline or cached).

If using inline credentials:
* Verify username, password, and server-url are provided

If using cached credentials:
* Check whether a valid CAC configuration exists
* If credentials are missing:

```text
No cached CAC credentials were found.

Please provide inline credentials or configure credentials using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are available.

### Step 5: Execute Download Command

**Option A: With Inline Credentials**

```bash
download-application-process <username> <password> <server-url> "<application-process-name>" "<application-name>" <output-file>
```

**Option B: With Cached Credentials**

```bash
download-application-process.cmd "<process-name>" "<application-name>" <output-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap names containing spaces in quotes.
* Use either inline credentials or cached credentials automatically.

### Step 6: Confirm Success

```text
Application Process '<process-name>' from application '<application-name>' downloaded successfully to <output-file>.
```

## Example Interactions

### Example 1: With Inline Credentials

User:

```text
download application process Deploy from MyApplication
```

Actions:

1. Username = `myuser`
2. Password = `mypassword`
3. Server URL = `https://url:8443`
4. Process = `Deploy`
5. Application = `MyApplication`
6. Output file = `Deploy.json`
7. Execute:

```bash
download-application-process myuser mypassword https://url:8443 Deploy MyApplication Deploy.json
```

Response:

```text
Application Process 'Deploy' from application 'MyApplication' downloaded successfully to Deploy.json.
```

### Example 2: With Cached Credentials

User:

```text
get Build Process from Payment Service application as YAML
```

Actions:

1. Process = `Build Process`
2. Application = `Payment Service`
3. Output file = `Build Process.yaml`
4. Verify cached credentials
5. Execute:

```bash
download-application-process.cmd "Build Process" "Payment Service" "Build Process.yaml"
```

Response:

```text
Application Process 'Build Process' from application 'Payment Service' downloaded successfully to Build Process.yaml.
```

### Example 3: With Inline Credentials

User:

```text
export Install Process from Auth Module to install.json with username admin password secret123 server https://deploy.company.com:8443
```

Actions:

1. Username = `admin`
2. Password = `secret123`
3. Server URL = `https://deploy.company.com:8443`
4. Process = `Install Process`
5. Application = `Auth Module`
6. Output file = `install.json`
7. Execute:

```bash
download-application-process admin secret123 https://deploy.company.com:8443 "Install Process" "Auth Module" install.json
```

Response:

```text
Application Process 'Install Process' from application 'Auth Module' downloaded successfully to install.json.
```

## Error Handling

### Missing Process Name

```text
Which application process would you like to download?
```

### Missing Application Name

```text
Application processes require a parent application.

Which application does this process belong to?
```

### Missing Credentials

```text
No credentials provided.

Please provide inline credentials (username, password, server-url) or configure CAC credentials using the setup skill before downloading application processes.
```

### Invalid Format

```text
Supported formats are JSON and YAML.

Which format would you like to use?
```

### Process Not Found

```text
Application Process '<process-name>' was not found in application '<application-name>'.

Please verify:
- The process name is correct
- The application name is correct
- The process exists in the specified application
```

### Application Not Found

```text
Application '<application-name>' was not found.

Please verify the application name and try again.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Download Failure

```text
The application process download failed.

Please verify:
- The process name is correct
- The application name is correct
- The server is accessible
- Your credentials are valid
- You have permission to access the application process
```

## Natural Language Patterns

Recognize:

* download application process [name] from [app]
* get application process [name] from [app]
* export application process [name] from [app]
* fetch application process [name] from [app]
* save application process [name] from [app]
* download [name] process from application [app]
* get [name] from [app] application process
* export [app] application process [name]
* download application process [name] from [app] with username [user] password [pass] server [url]
* download [name] from [app] with credentials [user] [pass] from server [url]

