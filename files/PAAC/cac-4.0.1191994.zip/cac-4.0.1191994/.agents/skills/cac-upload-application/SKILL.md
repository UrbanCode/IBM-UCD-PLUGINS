---
name: cac-upload-application
description: Upload a DevOps Deploy application from JSON or YAML using cached CAC credentials.
---

# Application Upload Skill

## Purpose

This skill enables users to upload DevOps Deploy applications using natural language without requiring knowledge of the underlying command syntax.

## When to Activate

Activate this skill when the user mentions:

* upload application [name]
* import application [name]
* create application [name]
* push application [name]
* deploy application [name]

## How It Works

When a user requests an application upload:

1. Check for cached CAC credentials.
2. Extract the application name and source file from the request.
3. Verify the source file exists and is valid.
4. Verify credentials are available.
5. Execute the upload command.
6. Return the result to the user.

## Credential Management

### Configuration File Location

* Windows: `%USERPROFILE%\.cac\config.properties`
* Linux/macOS: `~/.cac/config.properties`

### Setup Required

Credentials must be configured before uploading applications.

Use the **setup** skill to:

* Configure credentials
* View current configuration
* Clear saved credentials

If credentials are not available, direct the user to use the setup skill.

## Command Structure

```bash
upload-application.cmd "<application-name>" <input-file>
```

### Parameters

| Parameter        | Description                       |
| ---------------- | --------------------------------- |
| application-name | Name of the application to upload |
| input-file       | Input file name (.json or .yaml)  |

The command automatically uses cached credentials from the CAC configuration.

## Execution Steps

### Step 1: Parse User Request

Extract:

* Application name
* Source filename
* Source format (JSON or YAML)

Examples:

* upload application MyApp from myapp.json
* import Payment Gateway from payment-gateway.yaml
* create Auth Service using auth.json
* push application from config.yaml

### Step 2: Verify Source File

Rules:

* Confirm the file exists at the specified path.
* Validate the file format (.json or .yaml).
* Ensure the file is readable.

### Step 3: Verify Credentials

Check whether a valid CAC configuration exists.

If credentials are missing:

```text
No cached CAC credentials were found.

Please configure credentials first using the setup skill.

Example:
Setup CAC with server <url>, username <user>, password <password>
```

Do not proceed until credentials are configured.

### Step 4: Execute Upload Command

```bash
upload-application.cmd "<application-name>" <input-file>
```

Requirements:

* Execute from an environment where CAC commands are available.
* Wrap application names containing spaces in quotes.
* Use cached credentials automatically.

### Step 5: Confirm Success

```text
Application '<application-name>' uploaded successfully from <input-file>.
```

## Example Interactions

### Example 1

User:

```text
upload application MyApp from myapp.json
```

Actions:

1. Application = `MyApp`
2. Source file = `myapp.json`
3. Verify credentials
4. Execute:

```bash
upload-application.cmd "MyApp" myapp.json
```

Response:

```text
Application 'MyApp' uploaded successfully from myapp.json.
```

### Example 2

User:

```text
import Payment Gateway from payment-gateway.yaml
```

Actions:

1. Application = `Payment Gateway`
2. Source file = `payment-gateway.yaml`
3. Verify credentials
4. Execute:

```bash
upload-application.cmd "Payment Gateway" payment-gateway.yaml
```

Response:

```text
Application 'Payment Gateway' uploaded successfully from payment-gateway.yaml.
```

## Error Handling

### Missing Application Name

```text
Which application would you like to upload?
```

### Missing Source File

```text
Which file would you like to upload from?
```

### Source File Not Found

```text
The file '<filename>' was not found.

Please verify the file path and try again.
```

### Invalid File Format

```text
Supported formats are JSON and YAML.

Please provide a file with .json or .yaml extension.
```

### Missing Credentials

```text
No cached CAC credentials were found.

Please configure CAC credentials using the setup skill before uploading applications.
```

### Authentication Failure

```text
Authentication failed.

Please verify your CAC credentials or re-run the setup skill.
```

### Invalid Configuration

```text
The CAC configuration appears to be invalid.

Please reconfigure your credentials using the setup skill.
```

### Upload Failure

```text
The application upload failed.

Please verify:

- The application name is correct
- The source file is valid and properly formatted
- The server is accessible
- Your credentials are valid
- You have permission to upload applications
```

### Application Already Exists

```text
An application with the name '<application-name>' already exists.

Please choose a different name or update the existing application.
```

## Natural Language Patterns

Recognize:

* upload application [name]
* import application [name]
* create application [name]
* push application [name]
* deploy application [name]
* upload [name] application
* import [name] from [filename]
* create [name] using [filename]
* push [name] from [filename]
* upload application [name] from [filename]
* import [name] as json
* import [name] as yaml

