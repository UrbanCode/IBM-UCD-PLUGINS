@echo off
setlocal

REM Licensed Materials - Property of HCL*
REM (c) Copyright HCL Technologies Ltd. 2020. All Rights Reserved.
REM
REM Note to U.S. Government Users Restricted Rights:
REM Use, duplication or disclosure restricted by GSA ADP Schedule
REM Contract with HCL Technologies Ltd.
REM
REM * Trademark of HCL Technologies Limited

set PACC_LOCATION=%~dp0.
set PACC_PROGRAM=%~n0

if "%1"=="-h" (
    goto :HelpMenu
) else if "%1"=="--help" (
    goto :HelpMenu
) else if "%1"=="--version" (
    goto :Version
) else if "%1"=="-v" (
    goto :Version
) else if "%1"=="setup" (
    goto :Setup
)

if "%1:~0,1%"=="-" (
    echo Invalid argument: %1
    echo Use -h or --help for valid options.
    exit /b 1
)

java "-Dpacc.location=%PACC_LOCATION%" "-Dpacc.program=%PACC_PROGRAM%" -cp "%PACC_LOCATION%\lib\cac-4.1.1194664.jar" ucd.pacc.main.HelpMenu %*
exit /b 0

:HelpMenu
java "-Dpacc.location=%PACC_LOCATION%" "-Dpacc.program=%PACC_PROGRAM%" -cp "%PACC_LOCATION%\lib\cac-4.1.1194664.jar" ucd.pacc.main.HelpMenu
exit /b 0

:Version
echo cac version 4.1.1194664
exit /b 0

:Setup
set SETUP_ARGS=
for /f "tokens=1,* delims= " %%a in ("%*") do set SETUP_ARGS=%%b
java "-Dpacc.location=%PACC_LOCATION%" "-Dpacc.program=%PACC_PROGRAM%" -cp "%PACC_LOCATION%\lib\cac-4.1.1194664.jar" ucd.pacc.main.SetupConfigMain %SETUP_ARGS%
exit /b 0
