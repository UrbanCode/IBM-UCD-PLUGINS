/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
if(cluster && (node || server || cell)) {
  errors.cell = "If cluster is specified than server, node, and cell should not be!"
  errors.node = "If cluster is specified than server, node, and cell should not be!"
  errors.server = "If cluster is specified than server, node, and cell should not be!"
  errors.cluster = "If cluster is specified than server, node, and cell should not be!"
}
if(!cluster) {
    if(!node || !server) {
        errors.node = "A node and Server must be specified if cluster is not specified"
        errors.server = "A node and Server must be specified if cluster is not specified"
    }
}