/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2002-2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.plugin.websphere.WebSphereBatchScriptHelper
import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

final def action = args[2];

def appName = props['appName'];
def appEdition = props['appEdition']
def webModList = props['webModList'];
def command;
StringBuilder builder = new StringBuilder();
builder.append("updateWebModules(")
                .append("'").append(appName).append("'").append(",")
                .append("'").append(appEdition?:"").append("'").append(",")
                .append("'").append(action).append("'").append(",")
                .append("'").append(webModList.replace("\n","\\n")).append("'")
              .append(")");
command = builder.toString();

WebSphereBatchScriptHelper helper = new WebSphereBatchScriptHelper(props);
helper.execute(command);
