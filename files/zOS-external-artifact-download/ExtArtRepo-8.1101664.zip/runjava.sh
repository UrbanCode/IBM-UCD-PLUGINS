#!/bin/sh
##############################################################################
##                                                                          ##
##  JVM Launcher for zOS                                                    ##
##                                                                          ##
##############################################################################
echo "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$@"
exec "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$@"
