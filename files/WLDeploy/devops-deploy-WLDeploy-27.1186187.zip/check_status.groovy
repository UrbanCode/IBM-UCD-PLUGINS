/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2013, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.wldeploy.WebLogicStatusHelper

final def workDir = new File('.').canonicalFile
AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties(System.getenv("UCD_SECRET_VAR"), System.getenv("UCD_SUITE_VAR"))

final def jmxUrl = props['jmxUrl']
def user = props['user']
def pass = props['password']
final def configFile = props['configFile']
final def keyFile = props['keyFile']
def targets = props['targets']
def badStatuses = []
targets = targets.split(',')

try {
    WebLogicStatusHelper helper = new WebLogicStatusHelper()
    if (configFile) {
        user = helper.getUser(configFile, keyFile)
        pass = helper.getPass(configFile, keyFile)
    }
    helper.initConn(jmxUrl, user, pass)
    targets.each { target ->
        System.out.println("Checking Target ${target}")
        def status = helper.getManagedServerStatus(target)
        if (status instanceof List) {
            status.each { serverStatusPair ->
                println serverStatusPair
                if (serverStatusPair[1] != "RUNNING") {
                    badStatuses << [serverStatusPair[0], serverStatusPair[1]]
                }
            }
        }
        else {
            println status
            if (status != "RUNNING") {
                badStatuses << [target, status]
            }
        }
    }
    helper.closeConn()

    if (!badStatuses.isEmpty()) {
        badStatuses.each { status ->
            System.out.println(status[0] + " is not in a 'RUNNING' state : " + status[1])
        }
        System.exit(1)
    }
    System.exit(0)
}
catch (Exception e) {
    e.printStackTrace()
    throw e
}
