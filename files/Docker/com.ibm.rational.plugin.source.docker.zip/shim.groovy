// This shim facilitates debugging.  If the dockerRegistryName property contains an initial
// %1234% then 1234 is the debug port that can be used when remote debugging.
Properties readPropertyFile(File inputPropsFile) {
    final def props = new Properties();
    try {
        FileInputStream inputPropsStream = new FileInputStream(inputPropsFile);
        props.load(inputPropsStream);
    } catch (IOException e) {
        throw new RuntimeException(e);
    }
    return props
}

void writePropertyFile(Properties props, File outputPropsFile, String comment) {
    try {
        FileOutputStream outputPropsStream = new FileOutputStream(outputPropsFile);
        props.store(outputPropsStream, comment);
    } catch (IOException e) {
        throw new RuntimeException(e);
    }
}

final String DOCKER_REGISTRY_URL = "dockerImageName"
ArrayList<String> arguments = args
File inputPropsFile = new File(arguments[arguments.size() - 2])
Properties props = readPropertyFile(inputPropsFile)
String dockerRegistryURL = props[DOCKER_REGISTRY_URL]
if (dockerRegistryURL.startsWith('%')) {
    // there is an initial %port% so strip off the port number and re-write the properties file with the corrected property
    String[] ss = dockerRegistryURL.split('%')
    String url = ""
    // ss[0] is empty
    port = ss[1]
    if (ss.size() == 3) {
        url = ss[2]
    }
    println "remote debug using port: " + port
    props[DOCKER_REGISTRY_URL] = url
    writePropertyFile(props, inputPropsFile, "Replaced " + DOCKER_REGISTRY_URL)
    arguments = new ArrayList<String>(([arguments[0], "-Xdebug", "-Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=" + port] << arguments[1..-1]).flatten())
}
arguments.execute().waitForProcessOutput(System.out, System.err)
