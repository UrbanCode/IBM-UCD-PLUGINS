# UrbanCode Deploy Docker Source Plugin - Users's Guide

Requires UrbanCodeDeploy 6.1.0.3

## Description
This plugin is for creating Component Versions.
In the Component > ComponentName > Configuration > [ Source Config Type ] > "Docker Tag Importer".  
The plugin provides a few Configuration fields to read a docker registry and contained docker image (.ie docker repository).
The "Import New Versions" command will create a Component Version object for each docker image tag.

## Getting started
Load the source plugin.  Settings > Source Config Plugins > Load Plugin

Let's walk through an example of creating the UrbanCode Deploy component versions that will later be used to
docker pull and docker run an image:

    docker pull clmdocker01.ratl.swg.usma.ibm.com:5000/ibmbid/testtracker:1.1
    
Create a new component: Components > Create New Component
In the  Source Config Type drop down click: Docker Tag Importer.

The docker command can be mapped to the source plugin's fields:

* Docker Registry: clmdocker01.ratl.swg.usma.ibm.com:5000
* Docker Registry Username/Password - the credentials (optional) required to access the clmdocker01.ratl.swg.usma.ibm.com:5000 registry
* Docker [Namespace/]Repository: ibmbid/testtracker

## Import New Version
Once the component has been configured (verify with the Components > ComponentName > Configuration > Basic Settings)
it is possible for Imort New Versions to create a Component Version for each docker image tag.

Use the Components > ComponentName > Versions > Import New Versions command button.
This will create the component versions which will be visible after the command completes if the "Refresh" link is clicked.
Click the "Output Log" for some debugging information.

Here is the complete summary of the objects created:

Settings > Statuses > Version Statuses - Version Statuses.
After created you can change the properties (like the color) but not the names.
* Exists - initially green
* Missing - initially red

Components > ComponentName > Configuration > Version Properties Definition - Component version property definitions that are 
available for use by automation plugins.  The Name of the created properties should not be changed.
* dockerImageId
* dockerImageTag

Component Version objects.  One of these is created for each docker image tag:

Component > ComponentName > Versions > SpecificVersion > Configuration > Basic Settings -
* version: 1.1 1234567890ab - docker tag followed by the first 12 characters of the docker image id (checksum)
* description: 1234567890abcd... - full 64 hex character check sum of the docker image

Component > ComponentName > Versions > SpecificVersion >  Configuration > Version Properties
* dockerImageId: 1234567890abcd... -  full 64 hex character check sum of the docker image (same as description)
* dockerImageTag: 1.1 - docker tag

Note:
Importing new will not copy the docker image to the Code Station.
Choosing Copy to CodeStation has no effect.
Process automation steps, provided by the Docker Automation plugin, are executed on agent's installed on Docker hosts.
These Docker hosts must have access to the Docker Registry referenced above.
