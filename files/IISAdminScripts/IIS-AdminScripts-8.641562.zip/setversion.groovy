/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.CommandHelper
import java.util.regex.Pattern;
import java.util.regex.Matcher;

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cmd = 'SET';
def website = props['path'];
def iiswebPath = "C:\\Windows\\system32\\iisweb.vbs";
def version = props['version']
def regiisPath = "C:\\Windows\\microsoft.net\\framework\\${version}\\aspnet_regiis.exe";

def cscriptExe = "cscript.exe"

def ch = new CommandHelper(new File('.'));

def args = [];

args = [cscriptExe, iiswebPath, '/query', "${website}"];

OutputStream oStream = new ByteArrayOutputStream();
PrintStream stream = new PrintStream(oStream);
ch.runCommand(args.join(' '), args) { proc ->
    try {
        proc.waitForProcessOutput(stream, System.out);
    }
    finally {
       stream.flush();
    }
}

//now we need to parse out the actual path to the website
BufferedReader input = new BufferedReader(new StringReader(oStream.toString()));
Pattern pat = Pattern.compile("^" + website + " \\((.*)\\).*");
String line;
while ((line = input.readLine()) != null) {
    Matcher matcher = pat.matcher(line);
    if (matcher.matches()) {
        break;
    }
}
Matcher matcher = pat.matcher(line);

if (!matcher.find()) {
    throw new RuntimeException("Website not found!");
}

def websitePath = matcher.group(1);

def cmdArs = [];
cmdArgs = [regiisPath, '-s'];
cmdArgs << websitePath + "/ROOT";
ch.runCommand(cmdArgs.join(' '), cmdArgs);
    
    
