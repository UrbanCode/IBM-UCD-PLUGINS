import com.urbancode.air.CommandHelper
import java.util.regex.Pattern;
import java.util.regex.Matcher;

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cmd = 'SET';
def vdiroffset = props['vdiroffset'];
def website = props['path'];
def adsPath = "C:\\InetPub\\AdminScripts\\adsutil.vbs";
def iiswebPath = "C:\\Windows\\system32\\iisweb.vbs";
def parameters = (props['parameters']?props['parameters'].split('\n'):null);

def cscriptExe = "cscript.exe"

if (!vdiroffset.startsWith('/')) {
   vdiroffset = '/' + vdiroffset;
}

def ch = new CommandHelper(new File('.'));

def args = [];

args = [cscriptExe, iiswebPath, '/query', "${website}"];

OutputStream oStream = new ByteArrayOutputStream();
PrintStream stream = new PrintStream(oStream);
ch.runCommand(args.join(' '), args) { proc ->
    try {
        proc.waitForProcessOutput(stream, System.out);
    }
    finally {
       stream.flush();
    }
}

//now we need to parse out the actual path to the website
BufferedReader input = new BufferedReader(new StringReader(oStream.toString()));
Pattern pat = Pattern.compile("^" + website + " \\((.*)\\).*");
String line;
while ((line = input.readLine()) != null) {
    Matcher matcher = pat.matcher(line);
    if (matcher.matches()) {
        break;
    }
}
Matcher matcher = pat.matcher(line);

if (!matcher.find()) {
    throw new RuntimeException("Website not found!");
}

def websitePath = matcher.group(1);

parameters.each { parameter ->
    def name = parameter.split('=',2)[0];
    def value = parameter.split('=',2)[1];
    println "Setting attibute ${websitePath}/${name} to ${value}"

    def cmdArs = [];
    cmdArgs = [cscriptExe, adsPath, cmd];
    cmdArgs << websitePath + vdiroffset + "/" + name;
    cmdArgs << value;
    ch.runCommand(cmdArgs.join(' '), cmdArgs);
}
    
    
