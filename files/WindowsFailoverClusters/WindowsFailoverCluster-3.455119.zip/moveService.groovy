import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import java.util.concurrent.*

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def workDir = new File(".")
def ch = new CommandHelper(workDir)
def clusterName = props['cluster']
def nodeName = props['node']
def serviceList = props['service']?.tokenize(',')?.findAll{ it && it.trim().length() > 0 }?.collectAll{ it.trim() }
boolean parallel = props['parallel'].equals("true")
def exceptionsThrown = 0

def threadList = []
if (parallel) {
    def pool = Executors.newFixedThreadPool(serviceList.size())
    def futures = []
    def defer = { c -> futures << pool.submit(c as Callable) }
    
    move = { service ->
      defer { moveService(service, clusterName, nodeName, ch) }
    }
    
    serviceList.each{ service -> 
        println "Sending command to move application/service ${service}."
        move(service) 
        }
    pool.shutdown()
    for (future in futures) {
        exceptionsThrown += future.get()
    }
}
else {
    for (serviceName in serviceList) {
        exceptionsThrown += moveService(serviceName, clusterName, nodeName, ch)
    }
}
if (exceptionsThrown) {
    throw new java.lang.Exception("${exceptionsThrown} exception(s) were thrown in these commands. Failing the step.")
}
println "All commands succeeded."

def moveService(def serviceName, def clusterName, def nodeName, def ch) {
    try {
        serviceName = "'" + serviceName + "'"
        nodeName = "'" + nodeName + "'"
        def args = ['Powershell.exe', 'import-module', 'FailoverClusters', ';', 'Move-ClusterGroup']
        
        args << '-name'
        args << serviceName
        args << '-node'
        args << nodeName
        if (clusterName) {
            args << '-cluster'
            args << clusterName
        }
        
        def result = ch.runCommand("Moving the application/service ${serviceName} to node ${nodeName}.", args) { Process proc ->
            proc.out.close() // close stdin
            proc.consumeProcessErrorStream(System.out) // forward stderr
            outputText = proc.text.trim();
        }
        if (outputText.contains("Failed")) {
            result = 1
        }
        println result ? "The service ${serviceName} failed to move to the new node. " : "The service ${serviceName} was moved to the new node."
        return result
    }
    catch (Exception e) {
        e.printStackTrace()
        return 1
    }

}