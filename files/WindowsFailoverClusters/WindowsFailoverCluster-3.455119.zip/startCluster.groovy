import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def workDir = new File(".")
def ch = new CommandHelper(workDir)
def clusterName = props['cluster']
def wait = props['wait']
def args = ['Powershell.exe', 'import-module', 'FailoverClusters', ';', 'Start-Cluster']

if (clusterName) {
    args << '-name'
    args << clusterName
}

if (wait) {
    if (!wait.isInteger()) {
        println "Wait time should be an integer. Defaulting to 0 seconds."
        wait = '0'
    }
    args << '-wait'
    args << wait
}

ch.runCommand("Starting cluster services for all nodes", args)