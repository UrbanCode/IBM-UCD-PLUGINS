import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def workDir = new File(".")
def ch = new CommandHelper(workDir)
def clusterName = props['cluster']

def args = ['Powershell.exe', 'import-module', 'FailoverClusters', ';', 'Stop-Cluster']

if (clusterName) {
    args << '-name'
    args << clusterName
}
//get past confirmation dialogue
args << '-Force'

ch.runCommand("Stopping cluster services for the entire cluster", args)
println "Cluster service stopped"