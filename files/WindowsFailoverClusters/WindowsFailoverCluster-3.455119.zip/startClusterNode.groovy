import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def workDir = new File(".")
def ch = new CommandHelper(workDir)
def clusterName = props['cluster']
def nodeName = props['node']

def args = ['Powershell.exe', 'import-module', 'FailoverClusters', ';', 'Start-ClusterNode']

if (clusterName) {
    args << '-cluster'
    args << clusterName
}
args << '-name'
args << nodeName

ch.runCommand("Starting cluster services for the one specified node", args)
println "Cluster service started on the node."