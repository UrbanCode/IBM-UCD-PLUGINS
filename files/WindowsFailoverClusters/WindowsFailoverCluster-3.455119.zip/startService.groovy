import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import java.util.concurrent.*

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties()

def workDir = new File(".")
def ch = new CommandHelper(workDir)
def clusterName = props['cluster']
def serviceList = props['service']?.tokenize(',')?.findAll{ it && it.trim().length() > 0 }?.collectAll{ it.trim() }
boolean parallel = props['parallel'].equals("true")
def exceptionsThrown = 0

def threadList = []
if (parallel) {
    def pool = Executors.newFixedThreadPool(serviceList.length)
    def futures = []
    def defer = { c -> futures << pool.submit(c as Callable) }
    
    start = { service ->
      defer { startService(service, clusterName, ch) }
    }
    
    serviceList.each{ service -> 
        println "Sending command to start service ${service}."
        start(service) 
        }
    pool.shutdown()
    for (future in futures) {
        exceptionsThrown += future.get()
    }
}
else {
    for (serviceName in serviceList) {
        exceptionsThrown += startService(serviceName, clusterName, ch)
    }
}
if (exceptionsThrown) {
    throw new java.lang.Exception("${exceptionsThrown} exception(s) were thrown in these commands. Failing the step.")
}
println "All commands succeeded."

def startService(def serviceName, def clusterName, def ch) {
    try {
        serviceName = "'" + serviceName + "'"
        def args = ['Powershell.exe', 'import-module', 'FailoverClusters', ';', 'Start-ClusterGroup']
        
        args << '-name'
        args << serviceName
        if (clusterName) {
            args << '-cluster'
            args << clusterName
        }
        def outputText = ""
        def result = ch.runCommand("Bringing the application/service ${serviceName} online.", args) { Process proc ->
            proc.out.close() // close stdin
            proc.consumeProcessErrorStream(System.out) // forward stderr
            outputText = proc.text.trim();
        }
        if (outputText.contains("Failed")) {
            result = 1
        }
        println result ? "The service failed to come online." : "The service was brought online."
        return result
    }
    catch (Exception e) {
        e.printStackTrace()
        return 1
    }

}