/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

final def workDir = new File('.').canonicalFile

def out = System.out;

out.println("Getting properties!");
def agentHome = System.getenv("AGENT_HOME");

if (agentHome == null) {
    throw new NullPointerException("Could not find environment variable 'AGENT_HOME'.");
}

while (agentHome.endsWith("/")) {
     agentHome = agentHome.substring(0, agentHome.length() - 1);
}
def agentWorkDir = agentHome + "/var/work/";
def agentName = "";
def installedPropsFile = new File(agentHome + "/conf/agent/installed.properties");
Properties installedProps = new Properties();

def installInputStream = null;
try {
    installInputStream = new FileInputStream(installedPropsFile);
    installedProps.load(installInputStream);
}
finally {
    if (installInputStream != null) {
        installInputStream.close();
    }
}

airPluginTool.setOutputProperty("workDir", agentWorkDir)
airPluginTool.setOutputProperty("Name", installedProps.get("locked/agent.name"))
airPluginTool.setOutputProperties()
