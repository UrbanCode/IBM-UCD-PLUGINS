/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.commons.fileutils.FileUtils
import com.urbancode.air.AirPluginTool

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

final def workDir = new File('.').canonicalFile

def out = System.out;
def includes = props['includePatterns'];
if (includes != null && includes.trim().length() > 0) {
    includes = includes.split('\n') as List;
}
else {
    includes = null;
}

out.println("Getting Environment!");
def environment = System.getenv();

def AGENT_HOME = environment.get("AGENT_HOME");

File agentHomeFile = new File(AGENT_HOME);

def installedPropertiesFile = new File(agentHomeFile, "conf/agent/installed.properties");
def installedPropsStream = null;
try {
    installPropsStream = new FileInputStream(installedPropertiesFile);
    installedProps.load(installPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e.getMessage(), e);
}
finally {
    if (installedPropsStream != null) {
        try {
            installedPropsStream.close();
        }
        catch (Throwable t) {
            //swallow
        }
    }
}

for (String key : environment.keySet()) {
    if (includes != null && includes.size() > 0) {
        if (includes.contains(key)) {
            airPluginTool.setOutputProperty(key, environment.get(key))
        }
    }
    else {
        airPluginTool.setOutputProperty(key, environment.get(key))
    }
}

//add some special stuff
def hostName = "";
try {
    hostName = InetAddress.localHost.canonicalHostName;
}
catch (Exception e) {
    System.out.println("Could not get canonical hostname : " +e.getMessage());
    try {
        hostName = InetAddress.localHost.hostName;
    }
    catch (Exception ex) {
        System.out.println("Could not get hostname : " + e.getMessage());
    }
}
airPluginTool.setOutputProperty("Hostname", hostName)

def jvmProps = System.getProperties();

for (String key : jvmProps.keySet()) {
    airPluginTool.setOutputProperty("sys."+key, jvmProps.get(key))
}



for (def netface in NetworkInterface.networkInterfaces) {
    def suffix = "if-"
    def name = netface.getName();
    int i = 0;
    for (def addr in netface.getInetAddresses()) {
        def postfix = "-" + i.toString() + "-ip";
        def propName = suffix + name + postfix;
        airPluginTool.setOutputProperty(propName, addr.getHostAddress())
        i++;
    }
}

def getIPFromSocket = { host, port ->
    Socket sock = null;
    String result = "";
    try {
        sock = new Socket(host, Integer.valueOf(port));
        result = sock.getLocalAddress().toString();
        while (result.startsWith("/")) {
            result = result.substring(1);
        }
    }
    catch (Throwable t) {
        System.out.println("Error obtaining IP :"+ t.getMessage());
        t.printStackTrace();
    }
    return result;
}

def weburl = System.getenv("AH_WEB_URL");
def webURI = new URI(weburl);
def remoteHost = webURI.getHost();
def remotePort = webURI.getPort();
def proxyHost = System.getenv("PROXY_HOST")
def proxyPort = System.getenv("PROXY_PORT")

String ip = "";
if (proxyHost != null && proxyPort != null) {
    ip = getIPFromSocket(proxyHost, proxyPort);
}
else {
    ip = getIPFromSocket(remoteHost, remotePort);
}
airPluginTool.setOutputProperty("ip", ip)

// Update the ILMT file on the agent according to the licensing scheme used on the server

agentHome = System.getenv("AGENT_HOME")
if (agentHome == null || agentHome.length() == 0) {
  throw new NullPointerException("Could not find environment variable 'AGENT_HOME'")
}

agentHomeFile = new File(agentHome)
ILMT_BASE_PATH = new File(args[2])
ILMT_DEST = new File(agentHome, "properties/version")
ILMT_AUTHORIZED = "IBM_UrbanCode_Deploy_Managed_Virtual_Server-6.0.1.swtag"
ILMT_FLOATING = "IBM_UrbanCode_Deploy_Agent-6.0.1.swtag"
ILMT_PVU = "IBM_UrbanCode_Deploy_-_Managed_Node-6.0.1.swtag"

LICENSE_AUTHORIZED = "SERVER_AUTHORIZED"
LICENSE_FLOATING = "SERVER_FLOATING"
LICENSE_PVU = "SERVER_PVU"
LICENSE_NONE = "NONE"
LICENSE_DEV = "DEV"

println "Updating ILMT file..."

def licenseType = props.getProperty("licenseType", "NONE")

if (licenseType == null || licenseType.length() == 0) {
  throw new NullPointerException("No server license type specified")
}

String ilmtFileName = getIlmtFile(licenseType)

cleanDir(ILMT_DEST)

// If NONE is the license type, this will be null.
if (ilmtFileName == null) {
    println "WARNING: Server specified no licensing type. This agent will run without a license file."
}
else {
    File src = new File(ILMT_BASE_PATH, ilmtFileName)
    if (!src.exists() || !src.canRead()) {
      throw new RuntimeException("Cannot find or read file: " + src.getAbsolutePath())
    }
    
    File dest = new File(ILMT_DEST, ilmtFileName)
    try {
      println "Copying from " + src.getAbsolutePath() + " to " + dest.getAbsolutePath()
      FileUtils.copyFile(src, dest)
    }
    catch (IOException e) {
      throw new RuntimeException("Failed to copy ILMT file", e)
    }
}

def cleanDir(path) {
  Iterator<File> itr = FileUtils.getDirectoryFiles(path);
  while (itr.hasNext()) {
    File delete = itr.next();
    System.out.println("Deleting file: " + delete.getAbsolutePath());
    FileUtils.deleteFile(delete);
  }
}

def getIlmtFile(licenseType) {
  String result = "";
  if (LICENSE_AUTHORIZED.equals(licenseType)) {
    result = ILMT_AUTHORIZED;
  }
  else if (LICENSE_FLOATING.equals(licenseType)) {
    result = ILMT_FLOATING;
  }
  else if (LICENSE_PVU.equals(licenseType)) {
    result = ILMT_PVU;
  }
  else if (LICENSE_NONE.equals(licenseType) || LICENSE_DEV.equals(licenseType)) {
    result = null;
  }
  else {
    throw new RuntimeException("Unknown Server License Type: " + licenseType);
  }
  return result;
}


airPluginTool.setOutputProperties()
